// ESKIMO-2 / EP-6036 – Promo Code configuration: new "Custom Image" field (AC1) and removing uploaded
// images from "Custom Icon Image" / "Custom Image" (AC2).
// Test cases: testcases/ESKIMO-2/ESKIMO-2.md. Runs serially on a promo code created by this run
// (E2EESK2<timestamp>), deleted in afterAll.
// Evidence (portal format): every step → screenshot + AC / steps / expected in evidence/ESKIMO-2-promo-custom-image/;
// report: npm run report:evidence -- ESKIMO-2 promo-custom-image "EP-6036 · STG Admin"
import { test, expect, type Browser, type Locator, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc, type EvidenceMeta } from "../_support/evidence";

const ID = "@ESKIMO-2";
const AC1 = "EP-6036 AC1";
const AC2 = "EP-6036 AC2";
const ICON = "Custom Icon Image";
const IMAGE = "Custom Image";
const CODE = `E2EESK2${Date.now()}`;
const evidence = createEvidence("ESKIMO-2", "promo-custom-image");

type Upload = { name: string; mimeType: string; buffer: Buffer };

// Images are drawn by the browser (canvas) so PNG and JPEG are real, decodable files.
async function drawImage(page: Page, w: number, h: number, mimeType: "image/png" | "image/jpeg", name: string): Promise<Upload> {
  const dataUrl = await page.evaluate(({ w, h, mimeType }) => {
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#5ebdff"; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "#d74242"; ctx.fillRect(0, 0, w / 2, h / 2);
    return c.toDataURL(mimeType);
  }, { w, h, mimeType });
  return { name, mimeType, buffer: Buffer.from(dataUrl.split(",")[1], "base64") };
}
const GIF: Upload = {
  name: "e2e.gif", mimeType: "image/gif",
  buffer: Buffer.from("R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==", "base64"),
};
const BIG: Upload = { name: "e2e-big.png", mimeType: "image/png", buffer: Buffer.alloc(Math.round(2.1 * 1024 * 1024), 1) };

const spinnerGone = (page: Page) =>
  page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 20000 }).catch(() => {});
const short = (v: unknown) =>
  v === null || v === undefined || v === "" ? "(empty)" : String(v).slice(0, 110) + (String(v).length > 110 ? "…" : "");

test.describe.serial(`ESKIMO-2 Promo Code Custom Image ${ID}`, () => {
  test.describe.configure({ retries: 0 });
  test.setTimeout(180_000);

  let admin: { ctx: any; page: Page };
  let scratch: Page; // data cards (request/response) are rendered here, the app page stays as is
  let created = false;
  let img: { square: Upload; squareJpg: Upload; wide: Upload };

  const drawerOf = (page: Page) => page.locator(".ant-drawer-content:visible").first();
  const field = (drawer: Locator, label: string) =>
    drawer.locator(".ant-form-item").filter({ has: drawer.page().locator(`label[title="${label}"]`) }).first();
  const preview = (f: Locator) => f.locator("img.recommend-thumbnail");
  const placeholder = (f: Locator) => f.locator("span.recommend-thumbnail");
  const errorOf = (f: Locator) => f.locator(".ant-form-item-explain-error");
  const upload = (f: Locator, file: Upload) => f.locator("input[type=file]").setInputFiles(file);
  // "Remove" is revealed on hover over the preview (CSS opacity/visibility), like a user would see it.
  const removeBtn = (f: Locator) => f.locator("button.btn-remove", { hasText: "Remove" });
  async function removeImage(f: Locator) {
    await preview(f).hover();
    await expect(removeBtn(f)).toBeVisible();
    await removeBtn(f).click();
  }

  // Screenshot first, assert after: run the checks, record the step (FAILED + actual error if a check
  // failed), then rethrow. `checks` may return "actual" lines shown under the expected result.
  async function verify(page: Page, testInfo: TestInfo, meta: Omit<EvidenceMeta, "status">, checks: () => Promise<string[] | void>) {
    let err: unknown;
    let actual: string[] = [];
    try { actual = (await checks()) || []; } catch (e) { err = e; }
    const expected = [...meta.expected, ...actual.map((a) => `→ actual: ${a}`)];
    if (err) expected.push(`✗ ${String((err as Error).message).split("\n").find((l) => l.trim()) ?? err}`.slice(0, 300));
    await evidence.saveScreenshot(page, testInfo, { ...meta, expected, status: err ? "failed" : undefined });
    if (err) throw err;
  }

  // Request/response as a table on the scratch page.
  async function dataCard(testInfo: TestInfo, heading: string, rows: [string, unknown][], meta: Omit<EvidenceMeta, "status">, checks: () => Promise<string[] | void>) {
    const body = `<table><tr><th>Field</th><th>Value</th></tr>${rows.map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(short(v))}</td></tr>`).join("")}</table>`;
    await scratch.setContent(`<!DOCTYPE html><html><head><meta charset="utf-8"><style>
      body{font-family:Arial,sans-serif;padding:24px;color:#222} h2{font-size:16px;margin:0 0 12px}
      table{border-collapse:collapse;width:100%;font-size:13px}
      th,td{border:1px solid #d0d0d0;padding:6px 10px;text-align:left;word-break:break-all} th{background:#f0f4ff}
    </style></head><body><h2>${esc(heading)}</h2>${body}</body></html>`);
    await verify(scratch, testInfo, meta, checks);
  }

  async function openList(page: Page) {
    // Same-hash goto does not remount the SPA (an open drawer/mask can stay): reload instead.
    if (page.url().includes("#/promo-codes")) await page.reload({ waitUntil: "domcontentloaded" });
    else await page.goto(`${ADMIN_URL}/#/promo-codes`, { waitUntil: "domcontentloaded" });
    await page.getByRole("button", { name: "New Promo Code" }).waitFor({ state: "visible", timeout: 30000 });
    await spinnerGone(page);
  }

  async function searchPromo(page: Page) {
    await openList(page);
    const search = page.getByPlaceholder("Search by Promo Code");
    await search.fill(CODE);
    const res = page.waitForResponse((r) => r.url().includes("/api/gift-code/promo") && r.request().method() === "POST", { timeout: 30000 }).catch(() => null);
    await search.press("Enter");
    await res;
    await spinnerGone(page);
    const row = page.locator(".ant-table-tbody tr.ant-table-row").filter({ hasText: CODE }).first();
    await row.waitFor({ state: "visible", timeout: 30000 });
    return row;
  }

  // Open Edit for the test promo; returns the drawer and the detail the BE returned.
  async function openEdit(page: Page) {
    const row = await searchPromo(page);
    const detailP = page.waitForResponse((r) => /\/api\/gift-code\/promo\/v2\/[^/?]+$/.test(r.url()) && r.request().method() === "GET", { timeout: 30000 });
    await row.getByRole("button", { name: "Edit" }).click();
    const detail = (await (await detailP).json())?.data;
    const drawer = drawerOf(page);
    await expect(drawer.locator(".ant-drawer-title")).toHaveText("Edit Promo Code");
    await spinnerGone(page);
    await expect(field(drawer, IMAGE)).toBeVisible();
    return { drawer, detail };
  }

  // Click Ok (save); returns the request body the FE sent and the BE answer (asserted by the caller).
  async function save(drawer: Locator) {
    const page = drawer.page();
    const resP = page.waitForResponse((r) => r.url().includes("/api/gift-code/promo/v2") && ["PUT", "POST"].includes(r.request().method()), { timeout: 90000 });
    await drawer.locator("button.btn-action-ok").click();
    const res = await resP;
    const body = await res.json().catch(() => null);
    const sent = res.request().postDataJSON();
    const ok = res.ok() && !!body?.isSuccess;
    if (ok) await expect(drawer).toBeHidden({ timeout: 15000 });
    return { sent, body, ok, status: `HTTP ${res.status()} isSuccess=${body?.isSuccess}` };
  }

  async function closeDrawer(drawer: Locator) {
    await drawer.locator("button.btn-action-cancel").click();
    await expect(drawer).toBeHidden({ timeout: 10000 });
  }

  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    test.setTimeout(180_000);
    admin = await adminSession(browser);
    scratch = await admin.ctx.newPage();
    const page = admin.page;
    img = {
      square: await drawImage(page, 64, 64, "image/png", "e2e-square.png"),
      squareJpg: await drawImage(page, 64, 64, "image/jpeg", "e2e-square.jpg"),
      wide: await drawImage(page, 100, 50, "image/png", "e2e-wide.png"),
    };
    // Test data: a fresh promo code (Percentage 10%, Max Redemption 1).
    await openList(page);
    await page.getByRole("button", { name: "New Promo Code" }).click();
    const drawer = drawerOf(page);
    await expect(drawer.locator(".ant-drawer-title")).toHaveText("New Promo Code");
    await field(drawer, "Promo Code").locator("input").fill(CODE);
    await field(drawer, "Max Redemption").locator("input").fill("1");
    await field(drawer, "Percent (%)").locator("input").fill("10");
    const r = await save(drawer);
    expect(r.ok, `create test promo: ${r.status}`).toBe(true);
    created = true;
    console.log(`[INFO] created promo ${CODE}`);
  });

  test.afterAll(async () => {
    test.setTimeout(120_000);
    if (created) {
      try {
        const page = admin.page;
        const row = await searchPromo(page);
        await row.getByRole("button", { name: "Delete" }).click();
        const del = page.waitForResponse((r) => r.url().includes("/api/gift-code/promo") && r.request().method() === "DELETE", { timeout: 30000 });
        await page.getByRole("button", { name: "Confirm" }).click();
        console.log(`[INFO] cleanup: deleted ${CODE} → HTTP ${(await del).status()}`);
      } catch (e) {
        console.log(`[WARN] cleanup failed, delete promo ${CODE} by hand: ${(e as Error).message}`);
      }
    }
    await admin?.ctx.close();
  });

  test(`TC-01 Custom Image field shown after Custom Icon Image ${ID}`, async ({}, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Custom Image field in Promo Configuration");
    const page = admin.page;
    const expected = [
      `"${IMAGE}" field is right after "${ICON}"`,
      "Both fields have an upload button and the 1:1 placeholder",
    ];
    const check = async (drawer: Locator) => {
      const labels = (await drawer.locator(".ant-form-item-label label").allInnerTexts()).map((t) => t.trim());
      const i = labels.indexOf(ICON);
      expect(i, `"${ICON}" missing, labels: ${labels.join(" | ")}`).toBeGreaterThanOrEqual(0);
      expect(labels[i + 1], `field after "${ICON}"`).toBe(IMAGE);
      for (const name of [ICON, IMAGE]) {
        const f = field(drawer, name);
        await expect(f.locator("input[type=file]"), `${name}: upload input`).toHaveCount(1);
        await expect(f.locator(".image-upload label"), `${name}: upload button`).toBeVisible();
        await expect(placeholder(f), `${name}: placeholder`).toHaveText("1:1");
      }
      await field(drawer, IMAGE).scrollIntoViewIfNeeded();
      return [`labels: … ${labels.slice(Math.max(0, i - 1), i + 2).join(" → ")} …`];
    };
    await test.step("1-2. New Promo Code → Promo Configuration", async () => {
      await openList(page);
      await page.getByRole("button", { name: "New Promo Code" }).click();
      const drawer = drawerOf(page);
      await expect(drawer.locator(".ant-drawer-title")).toHaveText("New Promo Code");
      await verify(page, testInfo, {
        ac: AC1, title: "New Promo Code drawer: Custom Image field",
        steps: ["Admin → Promo Codes → New Promo Code", "Scroll Promo Configuration to the image fields"],
        expected,
      }, () => check(drawer));
      await closeDrawer(drawer);
    });
    await test.step("3. Edit Promo Code → Promo Configuration", async () => {
      const { drawer } = await openEdit(page);
      await verify(page, testInfo, {
        ac: AC1, title: "Edit Promo Code drawer: Custom Image field",
        steps: [`Admin → Promo Codes → search "${CODE}" → Edit`, "Scroll Promo Configuration to the image fields"],
        expected,
      }, () => check(drawer));
      await closeDrawer(drawer);
    });
  });

  test(`TC-02 Upload square PNG to Custom Image ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-02 Upload square PNG to Custom Image");
    const page = admin.page;
    const { drawer } = await openEdit(page);
    const f = field(drawer, IMAGE);
    await test.step("Upload PNG 64×64", () => upload(f, img.square));
    await verify(page, testInfo, {
      ac: AC1, title: "Custom Image accepts a square PNG",
      steps: [`Edit "${CODE}"`, `${IMAGE} → upload PNG 64×64`, "Hover the preview"],
      expected: ["Preview shown", '"Remove" button shown on hover', "No error"],
    }, async () => {
      await expect(preview(f)).toBeVisible();
      await expect(preview(f)).toHaveAttribute("src", /^data:image\/png;base64,/);
      await preview(f).hover();
      await expect(removeBtn(f), "Remove shown on hover").toBeVisible();
      await expect(removeBtn(f)).toHaveCSS("opacity", "1"); // fade-in done before the screenshot
      await expect(errorOf(f)).toHaveCount(0);
    });
    await closeDrawer(drawer);
  });

  test(`TC-03 Upload square JPEG to Custom Image ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-03 Upload square JPEG to Custom Image");
    const page = admin.page;
    const { drawer } = await openEdit(page);
    const f = field(drawer, IMAGE);
    await test.step("Upload JPEG 64×64", () => upload(f, img.squareJpg));
    await verify(page, testInfo, {
      ac: AC1, title: "Custom Image accepts a square JPEG",
      steps: [`Edit "${CODE}"`, `${IMAGE} → upload JPEG 64×64`],
      expected: ["Preview shown (image/jpeg)", "No error"],
    }, async () => {
      await expect(preview(f)).toHaveAttribute("src", /^data:image\/jpeg;base64,/);
      await expect(errorOf(f)).toHaveCount(0);
      await f.scrollIntoViewIfNeeded();
    });
    await closeDrawer(drawer);
  });

  // AC1 "validation same as Custom icon image": the same bad file gets the same error on both fields.
  const invalidCases: [string, string, () => Upload, RegExp, string][] = [
    ["TC-04", "non-square PNG 100×50", () => img.wide, /1:1/, "square 1:1 error"],
    ["TC-05", "file 2.1MB", () => BIG, /2\s?MB/i, "2MB size error"],
    ["TC-06", "GIF file", () => GIF, /JPG, JPEG, PNG/, "JPG/JPEG/PNG type error"],
  ];
  for (const [tc, what, file, pattern, errName] of invalidCases) {
    test(`${tc} ${what} rejected like Custom Icon Image ${ID}`, async ({}, testInfo) => {
      evidence.setCase(`${tc} ${what} rejected – same as Custom Icon Image`);
      const page = admin.page;
      const { drawer } = await openEdit(page);
      const errors: Record<string, string> = {};
      const norm = (s: string) => s.replace(/\b(Icon|Image)\b/g, "X");
      for (const name of [ICON, IMAGE]) {
        await test.step(`Upload ${what} to ${name}`, async () => {
          const f = field(drawer, name);
          const hadPreview = await preview(f).count();
          await upload(f, file());
          const isImage = name === IMAGE;
          await verify(page, testInfo, {
            ac: AC1, title: `${name}: ${what} rejected`,
            steps: [`Edit "${CODE}"`, `${name} → upload ${what}`],
            expected: [
              `${name} shows the ${errName}`,
              "The file is not accepted (no new preview)",
              ...(isImage ? [`Same message as ${ICON} (Icon/Image label aside)`] : []),
            ],
          }, async () => {
            await expect(errorOf(f), `${name}: error expected`).toBeVisible();
            errors[name] = (await errorOf(f).innerText()).trim();
            expect(errors[name]).toMatch(pattern);
            await expect(preview(f), `${name}: file must not be accepted`).toHaveCount(hadPreview);
            await f.scrollIntoViewIfNeeded();
            if (isImage) expect(norm(errors[IMAGE]), "same validation as Custom Icon Image").toBe(norm(errors[ICON]));
            return isImage ? [`${ICON}: "${errors[ICON]}"`, `${IMAGE}: "${errors[IMAGE]}"`] : [`"${errors[name]}"`];
          });
        });
      }
      await closeDrawer(drawer);
    });
  }

  test(`TC-07 Save Custom Icon + Custom Image persists ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-07 Save Custom Icon + Custom Image");
    const page = admin.page;
    await test.step("1-2. Upload square PNG to both fields → Save", async () => {
      const { drawer } = await openEdit(page);
      await upload(field(drawer, ICON), img.square);
      await upload(field(drawer, IMAGE), img.square);
      await verify(page, testInfo, {
        ac: AC1, title: "Both image fields filled before Save",
        steps: [`Edit "${CODE}"`, `${ICON} → upload PNG 64×64`, `${IMAGE} → upload PNG 64×64`],
        expected: ["Both fields show a preview"],
      }, async () => {
        await expect(preview(field(drawer, ICON))).toBeVisible();
        await expect(preview(field(drawer, IMAGE))).toBeVisible();
        await field(drawer, IMAGE).scrollIntoViewIfNeeded();
      });
      const r = await save(drawer);
      await dataCard(testInfo, "PUT /api/gift-code/promo/v2 (Save)", [
        ["response", r.status], ["customIcon (sent)", r.sent?.customIcon], ["customImage (sent)", r.sent?.customImage],
      ], {
        ac: AC1, title: "Save sends both images",
        steps: ["Click Ok (save)"],
        expected: ["Save succeeds", "Request carries customIcon and customImage"],
      }, async () => {
        expect(r.ok, r.status).toBe(true);
        expect(r.sent?.customIcon, "request customIcon").toBeTruthy();
        expect(r.sent?.customImage, "request customImage").toBeTruthy();
      });
    });
    await test.step("3. Reopen Edit", async () => {
      const { drawer, detail } = await openEdit(page);
      await verify(page, testInfo, {
        ac: AC1, title: "Reopen: both images persisted",
        steps: [`Reopen Edit "${CODE}"`],
        expected: ["Both fields show the saved image", "GET detail returns customIcon and customImage"],
      }, async () => {
        expect(detail.customIcon, "detail.customIcon").toBeTruthy();
        expect(detail.customImage, "detail.customImage").toBeTruthy();
        await expect(preview(field(drawer, ICON))).toBeVisible();
        await expect(preview(field(drawer, IMAGE))).toBeVisible();
        await field(drawer, IMAGE).scrollIntoViewIfNeeded();
        return [`customIcon = ${short(detail.customIcon)}`, `customImage = ${short(detail.customImage)}`];
      });
      await closeDrawer(drawer);
    });
  });

  test(`TC-08 Remove Custom Image ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-08 Remove Custom Image");
    const page = admin.page;
    await test.step("Edit → Custom Image → Remove → Save", async () => {
      const { drawer, detail } = await openEdit(page);
      expect(detail.customImage, "precondition: Custom Image saved (TC-07)").toBeTruthy();
      const f = field(drawer, IMAGE);
      await removeImage(f);
      await verify(page, testInfo, {
        ac: AC2, title: "Custom Image cleared after Remove",
        steps: [`Edit "${CODE}" (both images saved)`, `${IMAGE} → hover → Remove`],
        expected: [`${IMAGE} back to the 1:1 placeholder`, `${ICON} keeps its image`],
      }, async () => {
        await expect(placeholder(f)).toHaveText("1:1");
        await expect(preview(field(drawer, ICON))).toBeVisible();
        await f.scrollIntoViewIfNeeded();
      });
      const r = await save(drawer);
      await dataCard(testInfo, "PUT /api/gift-code/promo/v2 (Save after Remove)", [
        ["response", r.status], ["removeCustomImage", r.sent?.removeCustomImage], ["removeCustomIcon", r.sent?.removeCustomIcon],
      ], {
        ac: AC2, title: "Save sends removeCustomImage=true",
        steps: ["Click Ok (save)"],
        expected: ["Save succeeds", "removeCustomImage = true", "removeCustomIcon = false"],
      }, async () => {
        expect(r.ok, r.status).toBe(true);
        expect(r.sent?.removeCustomImage).toBe(true);
        expect(r.sent?.removeCustomIcon).toBe(false);
      });
    });
    await test.step("Reopen Edit", async () => {
      const { drawer, detail } = await openEdit(page);
      await verify(page, testInfo, {
        ac: AC2, title: "Reopen: Custom Image removed, Custom Icon kept",
        steps: [`Reopen Edit "${CODE}"`],
        expected: [`${IMAGE} empty (1:1 placeholder)`, `${ICON} still shows its image`, "GET detail: customImage empty, customIcon kept"],
      }, async () => {
        expect(detail.customImage || "", "detail.customImage").toBe("");
        expect(detail.customIcon, "detail.customIcon kept").toBeTruthy();
        await expect(placeholder(field(drawer, IMAGE))).toHaveText("1:1");
        await expect(preview(field(drawer, ICON))).toBeVisible();
        await field(drawer, IMAGE).scrollIntoViewIfNeeded();
        return [`customImage = ${short(detail.customImage)}`, `customIcon = ${short(detail.customIcon)}`];
      });
      await closeDrawer(drawer);
    });
  });

  test(`TC-09 Remove Custom Icon Image ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-09 Remove Custom Icon Image");
    const page = admin.page;
    await test.step("Edit → Custom Icon Image → Remove → Save", async () => {
      const { drawer, detail } = await openEdit(page);
      expect(detail.customIcon, "precondition: Custom Icon saved").toBeTruthy();
      const f = field(drawer, ICON);
      await removeImage(f);
      await verify(page, testInfo, {
        ac: AC2, title: "Custom Icon Image cleared after Remove",
        steps: [`Edit "${CODE}" (Custom Icon saved)`, `${ICON} → hover → Remove`],
        expected: [`${ICON} back to the 1:1 placeholder`],
      }, async () => {
        await expect(placeholder(f)).toHaveText("1:1");
        await f.scrollIntoViewIfNeeded();
      });
      const r = await save(drawer);
      await dataCard(testInfo, "PUT /api/gift-code/promo/v2 (Save after Remove)", [
        ["response", r.status], ["removeCustomIcon", r.sent?.removeCustomIcon], ["removeCustomImage", r.sent?.removeCustomImage],
      ], {
        ac: AC2, title: "Save sends removeCustomIcon=true",
        steps: ["Click Ok (save)"],
        expected: ["Save succeeds", "removeCustomIcon = true"],
      }, async () => {
        expect(r.ok, r.status).toBe(true);
        expect(r.sent?.removeCustomIcon).toBe(true);
      });
    });
    await test.step("Reopen Edit", async () => {
      const { drawer, detail } = await openEdit(page);
      await verify(page, testInfo, {
        ac: AC2, title: "Reopen: Custom Icon Image removed",
        steps: [`Reopen Edit "${CODE}"`],
        expected: [`${ICON} empty (1:1 placeholder)`, "GET detail: customIcon empty"],
      }, async () => {
        expect(detail.customIcon || "", "detail.customIcon").toBe("");
        await expect(placeholder(field(drawer, ICON))).toHaveText("1:1");
        await field(drawer, ICON).scrollIntoViewIfNeeded();
        return [`customIcon = ${short(detail.customIcon)}`];
      });
      await closeDrawer(drawer);
    });
  });

  test(`TC-10 Remove then Cancel keeps the image ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-10 Remove then Cancel keeps the image");
    const page = admin.page;
    await test.step("Precondition: save a Custom Image", async () => {
      const { drawer } = await openEdit(page);
      await upload(field(drawer, IMAGE), img.square);
      const r = await save(drawer);
      expect(r.ok, `precondition save: ${r.status}`).toBe(true);
    });
    await test.step("Edit → Custom Image → Remove → Cancel", async () => {
      const { drawer } = await openEdit(page);
      const f = field(drawer, IMAGE);
      await removeImage(f);
      await verify(page, testInfo, {
        ac: AC2, title: "Custom Image removed in the form (not saved yet)",
        steps: [`Edit "${CODE}" (Custom Image saved)`, `${IMAGE} → hover → Remove`],
        expected: [`${IMAGE} shows the 1:1 placeholder`],
      }, async () => {
        await expect(placeholder(f)).toHaveText("1:1");
        await f.scrollIntoViewIfNeeded();
      });
      await closeDrawer(drawer);
    });
    await test.step("Reopen Edit → image still there", async () => {
      const { drawer, detail } = await openEdit(page);
      await verify(page, testInfo, {
        ac: AC2, title: "Cancel: Custom Image still saved",
        steps: ["Click Cancel (no save)", `Reopen Edit "${CODE}"`],
        expected: [`${IMAGE} still shows the saved image`, "GET detail: customImage not empty"],
      }, async () => {
        expect(detail.customImage, "detail.customImage").toBeTruthy();
        await expect(preview(field(drawer, IMAGE))).toBeVisible();
        await field(drawer, IMAGE).scrollIntoViewIfNeeded();
        return [`customImage = ${short(detail.customImage)}`];
      });
      await closeDrawer(drawer);
    });
  });
});
