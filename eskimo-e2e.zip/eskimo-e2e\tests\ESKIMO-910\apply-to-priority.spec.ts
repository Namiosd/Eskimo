// ESKIMO-910 / ESKIMO-365 (EA-4281) - White Label Application Fee: Apply To PRIORITY edge cases.
// Priority (1 = highest): 1 Specific plan > 2 Any Fixed {country} > 3 Any Unlimited {country} > 4 Any {Global/Region/Country} Plan
//   > 5 Any Fixed {n GB} / Any Unlimited {x} days > 6 Any {type} (Any Fixed / Any Unlimited) > 7 Any Data Plan (base).
// Partner: WhiteLabel Partner 2 (PN101609, storefront wellatsea). Customer: testwhitelabeluat2@yopmail.com. STAGE only.
// Keeps the user's current rules, adds one rule per priority level with a UNIQUE % (snapshot before, restore after).
// Which rule won is read from the purchase: today BE applies the rule % as a customer discount
// (paid = listed x (100 - p%)), so the paid amount identifies p. The fee check (Value = listed x p%) is reported separately.
// Evidence: npm run report:evidence -- ESKIMO-910 apply-to-priority
import path from "node:path";
import { test, expect, type Browser, type Locator, type Page, type TestInfo } from "@playwright/test";
import { createEvidence, esc } from "../_support/evidence";
import {
  api, tokenOf, apiMessage, findPartner, readPartner, corporateBody, diff,
  openCorporate, corporate, focus, clickOk, stateFile, adminSessionRetry as adminSess, type PartnerState,
} from "../_support/whitelabel";
import {
  WL_URL, CARD_OK, newShopper, pickPlan, goToCheckout, continueToPayment, payWithCard, readCompletePage, adminToken, membersByEmail,
} from "../_support/wellatsea";
import { snapshotMailIds, verifyOrders, ordersTableHtml, type PaidOrder } from "./_orders";

const ID = "@ESKIMO-910";
const AC = "WL Application Fee - Apply To priority (EA-4281)";
// BE rejects some rule pairs as "Duplicated Discount benefit" (ignores countryId / unlimitedDayCount):
//   Any Fixed Japan + Any Fixed, Any Unlimited Japan + Any Unlimited, Any Unlimited Japan + Any Unlimited 7 Days, Any Unlimited 7 Days + Any Unlimited.
// So the levels are split into three compatible sets, run one after the other: E2E_910_PRIORITY_SET=A | B | C.
const SET = (process.env.E2E_910_PRIORITY_SET || "A").toUpperCase() as "ALL" | "A" | "B" | "C";
const evidence = createEvidence("ESKIMO-910", "apply-to-priority-" + SET.toLowerCase());
const P2 = process.env.E2E_WL_PARTNER_NAME || "WhiteLabel Partner 2";
const MEMBER_EMAIL = process.env.E2E_910_PRIORITY_EMAIL || "testwhitelabeluat2@yopmail.com";

// Rules this spec ADDS (each % unique so the paid amount tells which rule won). Existing rules stay.
type RuleDef = { key: string; priority: number; sortNo: number; search: string; pick: RegExp; fee: number };
const ALL_ADD: (RuleDef & { sets: string })[] = [
  { key: "Any Fixed Japan", priority: 2, sortNo: 6, search: "Any Fixed Japan", pick: /^Any Fixed Japan$/i, fee: 19, sets: "ALLA" },
  { key: "Any Unlimited Japan", priority: 3, sortNo: 5, search: "Any Unlimited Japan", pick: /^Any Unlimited Japan$/i, fee: 18, sets: "ALLA" },
  { key: "Any Japan Plan", priority: 4, sortNo: 4, search: "Any Japan", pick: /^Any Japan( Plan)?$/i, fee: 16, sets: "ALLABC" },
  { key: "Any Asia Pacific Plan", priority: 4, sortNo: 4, search: "Any Asia Pacific", pick: /^Any Asia Pacific( Plan)?$/i, fee: 17, sets: "ALLA" },
  { key: "Any Fixed 5GB", priority: 5, sortNo: 3, search: "Any Fixed 5GB", pick: /^Any Fixed 5\s*GB$/i, fee: 14, sets: "ALLAB" },
  { key: "Any Unlimited 7 Days", priority: 5, sortNo: 3, search: "Any Unlimited 7", pick: /^Any Unlimited 7\s*Days?$/i, fee: 15, sets: "ALLB" },
  { key: "Any Fixed (type)", priority: 6, sortNo: 2, search: "Any Fixed", pick: /^Any Fixed$/i, fee: 11, sets: "ALLB" },
  { key: "Any Unlimited (type)", priority: 6, sortNo: 2, search: "Any Unlimited", pick: /^Any Unlimited$/i, fee: 12, sets: "ALLC" },
];
const ADD: RuleDef[] = ALL_ADD.filter((r) => (SET === "ALL" ? r.sets.startsWith("ALL") : r.sets.replace("ALL", "").includes(SET)));
// Rules the user may already have; their fee is read from the live snapshot (the user's config changes between runs).
const EXISTING = [
  { key: "Japan 10GB (specific)", priority: 1, match: (p: any) => p.dataPlanId === "3a16ecaa-4554-48fc-0f06-08dbd475e39d" },
  { key: "Any Fixed 30GB", priority: 5, match: (p: any) => !p.dataPlanId && Number(p.dataPlanUnitValue) === 30 },
];
const existingFees = (plans: any[]) => Object.fromEntries(EXISTING.map((e) => [e.key, plans.find(e.match)]).filter(([, p]) => p).map(([k, p]: any) => [k, Number(p.value)]));

// Edge cases: candidates in priority order; the first one that exists must win, else the base rule.
type Case = { id: string; label: string; page: string; area: RegExp; unlimited?: boolean; tile: string; candidates: string[]; why: string };
const ALL_CASES: (Case & { set: string })[] = [
  // --- set ALL: every level at once (Japan 10GB 10, Any Fixed Japan 19, Any Unlimited Japan 18, Any Japan 16, Any Asia Pacific 17,
  //     Any Fixed 5GB 14, Any Unlimited 7 Days 15, Any Fixed 11, Any Unlimited 12, Any Fixed 30GB 88, base 20)
  { set: "ALL", id: "E1", label: "Japan 10GB", page: "japan", area: /^Japan/i, tile: "10GB", candidates: ["Japan 10GB (specific)", "Any Fixed Japan", "Any Japan Plan", "Any Fixed (type)"], why: "P1 specific beats P2/P4/P6" },
  { set: "ALL", id: "E2", label: "Japan 5GB", page: "japan", area: /^Japan/i, tile: "5GB", candidates: ["Any Fixed Japan", "Any Japan Plan", "Any Fixed 5GB", "Any Fixed (type)"], why: "P2 Any Fixed Japan beats P4/P5/P6" },
  { set: "ALL", id: "E3", label: "Japan Unlimited 7 days", page: "japan", area: /^Japan/i, unlimited: true, tile: "7days", candidates: ["Any Unlimited Japan", "Any Japan Plan", "Any Unlimited 7 Days", "Any Unlimited (type)"], why: "P3 Any Unlimited Japan beats P4/P5/P6" },
  { set: "ALL", id: "E4", label: "Japan Unlimited 3 days", page: "japan", area: /^Japan/i, unlimited: true, tile: "3days", candidates: ["Any Unlimited Japan", "Any Japan Plan", "Any Unlimited (type)"], why: "P3 beats P4/P6 (no 3-day rule)" },
  { set: "ALL", id: "E5", label: "Vietnam 5GB", page: "vietnam", area: /^Vietnam/i, tile: "5GB", candidates: ["Any Fixed 5GB", "Any Fixed (type)"], why: "P5 Any Fixed 5GB beats P6; Japan rules must not apply" },
  { set: "ALL", id: "E6", label: "Vietnam Unlimited 7 days", page: "vietnam", area: /^Vietnam/i, unlimited: true, tile: "7days", candidates: ["Any Unlimited 7 Days", "Any Unlimited (type)"], why: "P5 Any Unlimited 7 Days beats P6" },
  { set: "ALL", id: "E7", label: "Vietnam Unlimited 3 days", page: "vietnam", area: /^Vietnam/i, unlimited: true, tile: "3days", candidates: ["Any Unlimited (type)"], why: "only P6 Any Unlimited matches; Any Unlimited Japan must not apply" },
  { set: "ALL", id: "E8", label: "Vietnam 3GB", page: "vietnam", area: /^Vietnam/i, tile: "3GB", candidates: ["Any Fixed (type)"], why: "only P6 Any Fixed matches; Any Fixed Japan must not apply" },
  { set: "ALL", id: "E9", label: "Asia Pacific 5GB (region)", page: "japan", area: /^Asia Pacific/i, tile: "5GB", candidates: ["Any Asia Pacific Plan", "Any Fixed 5GB", "Any Fixed (type)"], why: "P4 region beats P5/P6; Japan rules must NOT apply to a region plan" },
  { set: "ALL", id: "E10", label: "Global 30GB", page: "japan", area: /^Global/i, tile: "30GB", candidates: ["Any Fixed 30GB", "Any Fixed (type)"], why: "P5 Any Fixed 30GB applies to a Global plan; beats P6" },
  // --- set A: Any Fixed Japan 19, Any Unlimited Japan 18, Any Japan 16, Any Asia Pacific 17, Any Fixed 5GB 14 (+ Japan 10GB 10, Any Fixed 30GB 88, base 20)
  { set: "A", id: "A1", label: "Japan 10GB", page: "japan", area: /^Japan/i, tile: "10GB", candidates: ["Japan 10GB (specific)", "Any Fixed Japan", "Any Japan Plan"], why: "P1 specific beats P2 Any Fixed Japan / P4 Any Japan" },
  { set: "A", id: "A2", label: "Japan 5GB", page: "japan", area: /^Japan/i, tile: "5GB", candidates: ["Any Fixed Japan", "Any Japan Plan", "Any Fixed 5GB"], why: "P2 Any Fixed Japan beats P4 Any Japan / P5 Any Fixed 5GB" },
  { set: "A", id: "A3", label: "Japan Unlimited 7 days", page: "japan", area: /^Japan/i, unlimited: true, tile: "7days", candidates: ["Any Unlimited Japan", "Any Japan Plan"], why: "P3 Any Unlimited Japan beats P4 Any Japan; Any Fixed Japan must not apply to unlimited" },
  { set: "A", id: "A4", label: "Vietnam 5GB", page: "vietnam", area: /^Vietnam/i, tile: "5GB", candidates: ["Any Fixed 5GB"], why: "P5 Any Fixed 5GB; Japan rules must not apply to Vietnam" },
  { set: "A", id: "A5", label: "Asia Pacific 5GB (region)", page: "japan", area: /^Asia Pacific/i, tile: "5GB", candidates: ["Any Asia Pacific Plan", "Any Fixed 5GB"], why: "P4 region beats P5; Any Fixed Japan / Any Japan must NOT apply to a region plan" },
  { set: "A", id: "A6", label: "Global 30GB", page: "japan", area: /^Global/i, tile: "30GB", candidates: ["Any Fixed 30GB"], why: "P5 Any Fixed 30GB applies to a Global plan" },
  { set: "A", id: "A7", label: "Vietnam 3GB", page: "vietnam", area: /^Vietnam/i, tile: "3GB", candidates: [], why: "no rule matches -> base Any Data Plan" },
  // --- set B: Any Japan 16, Any Fixed 5GB 14, Any Unlimited 7 Days 15, Any Fixed 11 (+ Japan 10GB 10, Any Fixed 30GB 88, base 20)
  { set: "B", id: "B1", label: "Vietnam Unlimited 7 days", page: "vietnam", area: /^Vietnam/i, unlimited: true, tile: "7days", candidates: ["Any Unlimited 7 Days"], why: "P5 Any Unlimited 7 Days" },
  { set: "B", id: "B2", label: "Vietnam Unlimited 3 days", page: "vietnam", area: /^Vietnam/i, unlimited: true, tile: "3days", candidates: [], why: "no rule matches (Any Unlimited 7 Days must not apply to 3 days) -> base" },
  { set: "B", id: "B3", label: "Vietnam 3GB", page: "vietnam", area: /^Vietnam/i, tile: "3GB", candidates: ["Any Fixed (type)"], why: "only P6 Any Fixed matches" },
  { set: "B", id: "B4", label: "Vietnam 5GB", page: "vietnam", area: /^Vietnam/i, tile: "5GB", candidates: ["Any Fixed 5GB", "Any Fixed (type)"], why: "P5 Any Fixed 5GB beats P6 Any Fixed" },
  { set: "B", id: "B5", label: "Japan Unlimited 7 days", page: "japan", area: /^Japan/i, unlimited: true, tile: "7days", candidates: ["Any Japan Plan", "Any Unlimited 7 Days"], why: "P4 Any Japan beats P5 Any Unlimited 7 Days / P6" },
  { set: "B", id: "B6", label: "Japan 3GB", page: "japan", area: /^Japan/i, tile: "3GB", candidates: ["Any Japan Plan", "Any Fixed (type)"], why: "P4 Any Japan beats P6 Any Fixed" },
  // --- set C: Any Japan 16, Any Unlimited 12 (+ Japan 10GB 10, Any Fixed 30GB 88, base 20)
  { set: "C", id: "C1", label: "Vietnam Unlimited 3 days", page: "vietnam", area: /^Vietnam/i, unlimited: true, tile: "3days", candidates: ["Any Unlimited (type)"], why: "P6 Any Unlimited" },
  { set: "C", id: "C2", label: "Japan Unlimited 3 days", page: "japan", area: /^Japan/i, unlimited: true, tile: "3days", candidates: ["Any Japan Plan", "Any Unlimited (type)"], why: "P4 Any Japan beats P6 Any Unlimited" },
  { set: "C", id: "C3", label: "Vietnam 3GB", page: "vietnam", area: /^Vietnam/i, tile: "3GB", candidates: [], why: "Any Unlimited must not apply to a fixed plan -> base" },
];
const CASES: Case[] = ALL_CASES.filter((c) => c.set === SET);

type State = { p2?: PartnerState & { plans?: any[] }; added?: Record<string, string>; gaps?: string[]; order?: { sorted: boolean; labels: string[] } };
const st = stateFile(path.join(path.dirname(evidence.SCREENSHOT_DIR), "ESKIMO-910-priority-state-" + SET + ".json"));
const load = () => st.load<State>();
const save = (s: State) => st.save(s);

const shot = (page: Page, testInfo: TestInfo, title: string, steps: string[], expected: string[], ok = true) =>
  evidence.saveScreenshot(page, testInfo, { ac: AC, title, steps, expected, status: ok ? undefined : "failed" });
const table = (head: string[], rows: unknown[][]) =>
  "<table><tr>" + head.map((h) => "<th>" + esc(h) + "</th>").join("") + "</tr>" + rows.map((r) => "<tr>" + r.map((c) => "<td>" + esc(c) + "</td>").join("") + "</tr>").join("") + "</table>";
async function card(browser: Browser, testInfo: TestInfo | undefined, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const savedLine = (x: Awaited<ReturnType<typeof clickOk>>) =>
  "PUT /api/partner/v2 -> " + x.status + " " + x.message + (x.toasts.length ? " ; toast: " + x.toasts.join(" | ") : "");
const plansOf = (detail: any) => detail?.configuration?.whiteLabelSetting?.plans ?? [];

// --- snapshot / restore (rules re-created with empty ids) ---
function remember(saved: Awaited<ReturnType<typeof clickOk>>) {
  const s = load();
  if (!s.p2) return;
  s.p2.restored = false;
  if (saved.status === 200 && saved.reqBody?.configuration?.hasCorporate) s.p2.feBody = saved.reqBody;
  save(s);
}
async function restoreAll(browser: Browser, testInfo: TestInfo | undefined) {
  const s = load();
  if (!s.p2 || s.p2.restored || !s.p2.feBody) return true;
  const { ctx, page } = await adminSess(browser);
  try {
    const token = await tokenOf(page);
    evidence.setCase("Cleanup - restore Partner 2");
    const noId = (ps: any[]) => (ps ?? []).map(({ id, ...rest }) => ({ ...rest, value: Number(rest.value) }));
    let now = await readPartner(token, s.p2);
    const equal = () => JSON.stringify(noId(plansOf(now.detail))) === JSON.stringify(noId(s.p2!.plans ?? [])) && now.fee === s.p2!.fee && diff(s.p2!.snapshot, now.snap).every((x) => x.same);
    const notes: string[] = [];
    for (let i = 1; i <= 3 && !equal(); i++) {
      const body = corporateBody(s.p2.feBody, !!s.p2.snapshot.hasCorporate, s.p2.setting);
      body.configuration.whiteLabelSetting = { plans: (s.p2.plans ?? []).map((p: any) => ({ ...p, id: "" })) };
      const r = await api(token, "PUT", "/api/partner/v2", body, 2);
      notes.push("#" + i + " PUT partner -> " + r.status + " " + apiMessage(r.json));
      if (now.fee !== s.p2.fee) {
        const payload = s.p2.fee === null ? { clearOverride: true } : { platformFeePercent: s.p2.fee, clearOverride: false };
        const f = await api(token, "PUT", "/api/payment/connect/partners/" + s.p2.code + "/fee", payload, 2);
        notes.push("#" + i + " PUT fee -> " + f.status + " " + apiMessage(f.json));
      }
      now = await readPartner(token, s.p2);
    }
    s.p2.restored = equal();
    save(s);
    await card(browser, testInfo, "Restore - Partner 2 back to the user's config",
      table(["Item", "Snapshot", "Now"], [["Base fee", s.p2.fee, now.fee], ["Rules", (s.p2.plans ?? []).length, plansOf(now.detail).length], ["Equal", "", s.p2.restored ? "same" : "DIFF"]]) + "<p>" + esc(notes.join(" ; ") || "nothing to restore") + "</p>",
      { ac: AC, title: "Restore Partner 2 (cleanup)", steps: notes.length ? notes : ["Already equal"], expected: ["Base 20 + Japan 10GB 10 + Any Fixed 30GB 88 (user's config)"], status: s.p2.restored ? undefined : "failed" });
    console.log("[ESKIMO-910 priority] restore: " + (s.p2.restored ? "OK (verified)" : "NOT VERIFIED - restore manually!") + " " + notes.join(" ; "));
    return s.p2.restored;
  } finally { await ctx.close(); }
}

// --- Admin UI fee-rule helpers (Apply To is a virtual list: type to filter; never press Escape = closes the drawer) ---
const addBtn = (page: Page) => page.locator(".custom-button-add-gift-code").filter({ hasText: /Add Application Fee|New Application Fee/i }).first();
const feeRows = (drawer: Locator) => corporate(drawer).body.locator(".list-data-merchant .merchant-item");
async function addFeeRule(page: Page, drawer: Locator, rule: RuleDef) {
  await addBtn(page).click();
  await page.waitForTimeout(900);
  const row = feeRows(drawer).last();
  await row.waitFor({ state: "visible", timeout: 10000 });
  const sel = row.locator(".ant-select").first();
  await sel.scrollIntoViewIfNeeded().catch(() => {});
  await sel.locator(".ant-select-selector").first().click();
  const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ state: "visible", timeout: 15000 });
  // the option list loads async: typing before it is filled returned "no option" for the first rule (2026-10-27)
  await dd.locator(".ant-select-item-option").first().waitFor({ state: "visible", timeout: 15000 }).catch(() => {});
  await page.keyboard.type(rule.search, { delay: 30 });
  await page.waitForTimeout(800);
  const target = dd.locator(".ant-select-item-option").filter({ hasText: rule.pick }).first();
  if (!(await target.count())) {
    for (let k = 0; k < rule.search.length; k++) await page.keyboard.press("Backspace");
    await page.waitForTimeout(1500);
    await page.keyboard.type(rule.search, { delay: 60 });
    await page.waitForTimeout(1500);
  }
  const opts = (await dd.locator(".ant-select-item-option-content").allInnerTexts()).map((x) => x.trim());
  let chosen = "";
  if (await target.count()) {
    chosen = (await target.innerText()).trim();
    await target.click();
    const fee = row.locator("input.ant-input").first();
    await fee.fill(String(rule.fee));
    await focus(fee);
  } else {
    // option missing: clear the search and remove the empty row so the save is not blocked
    for (let k = 0; k < rule.search.length; k++) await page.keyboard.press("Backspace");
    await row.locator(".merchant-item-delete button").first().click().catch(() => {});
    const confirm = page.locator(".ant-modal-confirm:visible, .ant-popover:visible").getByRole("button", { name: /OK|Confirm|Yes/i }).first();
    if (await confirm.isVisible({ timeout: 2000 }).catch(() => false)) await confirm.click();
  }
  return { chosen, opts };
}
async function readFeeRulesUI(drawer: Locator) {
  const rows = feeRows(drawer);
  const out: { applyTo: string; fee: string }[] = [];
  for (let i = 0; i < (await rows.count()); i++) {
    const r = rows.nth(i);
    out.push({
      applyTo: (await r.locator(".ant-select").first().locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim(),
      fee: (await r.locator("input.ant-input").first().inputValue({ timeout: 2000 }).catch(() => "")).trim(),
    });
  }
  return out;
}
// EA-4281 sorting no. of an Apply To label (1 = Any Data Plan ... 7 = specific plan)
function sortNoOf(label: string) {
  if (/^Any Data Plan$/i.test(label)) return 1;
  if (/^Any (Fixed|Unlimited)$/i.test(label)) return 2;
  if (/^Any Fixed \d+\s*GB$/i.test(label) || /^Any Unlimited \d+\s*Days?$/i.test(label)) return 3;
  if (/^Any Unlimited /i.test(label)) return 5;
  if (/^Any Fixed /i.test(label)) return 6;
  if (/^Any /i.test(label)) return 4;
  return 7;
}

// --- Storefront purchase (fixed via pickPlan; unlimited via the "Unlimited data plan" card) ---
async function buy(browser: Browser, c: Case) {
  const { ctx, page } = await newShopper(browser);
  try {
    let plan = "";
    if (!c.unlimited) {
      plan = await pickPlan(page, { countryPath: "/en/plans/" + c.page + "-esim", area: c.area, data: c.tile });
    } else {
      await page.goto(WL_URL + "/en/plans/" + c.page + "-esim", { waitUntil: "domcontentloaded" });
      await page.locator(".day-card").first().waitFor({ state: "visible", timeout: 90000 });
      await page.getByText(/Loading plans/i).first().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
      await page.getByText("Unlimited data plan", { exact: true }).first().click({ timeout: 20000 });
      await page.waitForTimeout(2500);
    }
    const days = c.tile.match(/^(\d+)\s*days?$/i);
    const tile = c.unlimited
      // tile text is "7days" + "US$ 22.00" glued ("7daysUS$"): no \b after "days"
      ? page.locator(".wl-coverage-area-card").filter({ hasText: c.area }).first().locator(".day-card").filter({ hasText: new RegExp("^\\s*" + days![1] + "\\s*days?", "i") }).first()
      : page.locator(".wl-coverage-area-card").filter({ hasText: c.area }).first().locator(".day-card")
        .filter({ has: page.locator(".day-card__value", { hasText: new RegExp("^\\s*" + c.tile.replace(/GB$/i, "") + "\\s*$") }) }).filter({ hasText: /GB/i }).first();
    if (c.unlimited) {
      await tile.scrollIntoViewIfNeeded({ timeout: 15000 }).catch(() => {});
      await tile.click({ timeout: 20000 });
      await page.locator(".wl-selected-plan-name").first().waitFor({ state: "visible", timeout: 10000 }).catch(() => {});
      plan = (await page.locator(".wl-selected-plan-name").first().innerText({ timeout: 10000 }).catch(() => "")).trim();
    }
    const tileText = (await tile.innerText({ timeout: 10000 }).catch(() => "")).replace(/\s+/g, " ");
    const listedPrice = Number((tileText.match(/\$\s*([\d.,]+)/) ?? [])[1]?.replace(/,/g, "") ?? NaN);
    await goToCheckout(page);
    // a temporary "try again" on checkout is retried once, like a customer would
    let pay = await continueToPayment(page, "E2e910 " + c.id, MEMBER_EMAIL);
    if (pay.outcome !== "card" && /try again/i.test(pay.errors.join(" "))) { await page.waitForTimeout(5000); pay = await continueToPayment(page, "E2e910 " + c.id, MEMBER_EMAIL); }
    if (pay.outcome !== "card") throw new Error("Checkout did not reach the card step (" + pay.outcome + "): " + pay.errors.join("; "));
    const res = await payWithCard(page, CARD_OK);
    if (res.outcome !== "complete") throw new Error("Payment did not complete (" + res.outcome + "): " + res.error);
    const complete = await readCompletePage(page);
    return { plan, listedPrice, tileText, orderNumber: complete.orderNumber };
  } finally { await ctx.close(); }
}

test.describe("ESKIMO-910 Apply To priority set " + SET + " " + ID, () => {
  test.describe.configure({ mode: "serial", timeout: 10 * 60 * 1000 });

  test.beforeAll(async ({ browser }) => {
    test.setTimeout(300000);
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await adminToken(page);
      const s = load();
      if (!s.p2 || s.p2.restored || !s.p2.feBody) {
        const p = await findPartner(t, P2);
        if (!p) throw new Error("Partner " + P2 + " not found");
        const now = await readPartner(t, p);
        s.p2 = { id: p.id, code: p.code, name: p.name, snapshot: now.snap, setting: now.detail?.configuration?.corporateSetting, fee: now.fee, feBody: undefined, restored: false, plans: plansOf(now.detail) };
        s.added = {};
        save(s);
      }
      console.log("[ESKIMO-910 priority] snapshot: base=" + s.p2.fee + " rules=" + JSON.stringify((s.p2.plans ?? []).map((r: any) => [r.dataPlanId ? "plan" : "", r.dataPlanUnitValue, r.value])));
    } finally { await ctx.close(); }
  });
  test.afterAll(async ({ browser }, testInfo) => { await restoreAll(browser, testInfo); });

  test("PRI-00 Add one rule per priority level (unique %) + verify saved order " + ID, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("PRI-00 setup rules");
    const { ctx, page } = await adminSess(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const existing = s.p2!.plans ?? [];
      const missingExisting: string[] = []; // informational only: existing rules are optional now
      const o = await openCorporate(page, P2);
      // Apply To options load after the drawer opens: until then existing rows show raw values
      // ("ANY_FIXED_UNIT|30", a plan GUID) and the first search finds nothing -> wait for real labels (2026-10-27)
      const raw = (x: string) => /^[A-Z_]+\|/.test(x) || /^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(x);
      let before = await readFeeRulesUI(o.drawer);
      for (const until = Date.now() + 45000; before.some((r) => raw(r.applyTo)) && Date.now() < until;) {
        await page.waitForTimeout(1500);
        before = await readFeeRulesUI(o.drawer);
      }
      const added: Record<string, string> = {};
      const gaps: string[] = [];
      for (const r of ADD) {
        const res = await addFeeRule(page, o.drawer, r);
        if (res.chosen) added[r.key] = res.chosen;
        else gaps.push(r.key + " (search \"" + r.search + "\" -> " + (res.opts.slice(0, 8).join(" / ") || "no option") + ")");
      }
      const uiRows = await readFeeRulesUI(o.drawer);
      await shot(page, testInfo, "PRI-00 Rules before Ok", ["Existing rows: " + before.map((r) => r.applyTo + "=" + r.fee).join(" | "), "Added: " + Object.entries(added).map(([k, v]) => k + " -> \"" + v + "\"").join(" ; "), ...(gaps.length ? ["Apply To option NOT available: " + gaps.join(" ; ")] : [])],
        ["Every EA-4281 Apply To level can be added (unique %)"], gaps.length === 0);
      const saved = await clickOk(page, o.drawer);
      remember(saved);
      s.added = added;
      save({ ...load(), added });
      const now = await readPartner(token, s.p2!);
      const plans = plansOf(now.detail);
      // reopen: rule list must be sorted by sorting no. (Any Data Plan top ... Specific bottom)
      const r2 = await openCorporate(page, P2);
      const after = await readFeeRulesUI(r2.drawer);
      const sortNos = after.map((x) => sortNoOf(x.applyTo));
      const sorted = sortNos.every((n, i) => i === 0 || sortNos[i - 1] <= n);
      await shot(page, testInfo, "PRI-00 Reopened: rule order", ["Order after save: " + after.map((x) => x.applyTo + "(" + sortNoOf(x.applyTo) + ")=" + x.fee).join(" | ")], ["Sorted by sorting no.: Any {type}(2) -> Any Fixed GB / Unlimited days(3) -> Any location(4) -> Any Unlimited country(5) -> Any Fixed country(6) -> Specific(7)"], sorted);
      await card(browser, testInfo, "PRI-00 - saved rules (API) + order (UI)",
        table(["#", "Apply To (UI after save)", "Sorting no.", "Fee %"], after.map((x, i) => [i + 1, x.applyTo, sortNoOf(x.applyTo), x.fee])) +
        "<p>" + esc(savedLine(saved)) + "</p><p>Base fee: " + esc(now.fee) + " ; API rules: " + plans.length + "</p>" +
        (gaps.length ? "<p><b>Apply To options not available:</b> " + esc(gaps.join(" ; ")) + "</p>" : "") +
        (missingExisting.length ? "<p><b>Expected existing rules not found:</b> " + esc(missingExisting.join(", ")) + "</p>" : ""),
        { ac: AC, title: "PRI-00 DATA rules + order", steps: [savedLine(saved), "API rules: " + plans.length + " (existing " + existing.length + " + added " + Object.keys(added).length + ")", "Sorted: " + sorted, ...(gaps.length ? ["Gaps: " + gaps.join(" ; ")] : [])],
          expected: ["Save 200", "All levels available", "Rule list sorted Any Data Plan (top) ... Specific (bottom)"], status: saved.status === 200 && sorted && gaps.length === 0 ? undefined : "failed" });
      console.log("[ESKIMO-910 priority] save=" + saved.status + " added=" + Object.keys(added).length + " gaps=" + gaps.length + " sorted=" + sorted + " order=" + after.map((x) => x.applyTo).join(" | "));
      expect(saved.status, "save: " + savedLine(saved)).toBe(200);
      expect(missingExisting, "user's existing rules present").toEqual([]);
      // gaps / order are asserted at the end of PRI-01 so a failure here does not skip the purchases (serial)
      save({ ...load(), gaps, order: { sorted, labels: after.map((x) => x.applyTo) } });
    } finally { await ctx.close(); }
  });

  test("PRI-01 Purchases: the highest-priority matching rule wins (set " + SET + ") " + ID, async ({ browser }, testInfo) => {
    test.setTimeout(60 * 60 * 1000);
    evidence.setCase("PRI-01 priority per plan");
    const s = load();
    const added = s.added ?? {};
    const base = s.p2!.fee as number;
    const feeOf: Record<string, number> = Object.fromEntries([...ADD.filter((r) => added[r.key]).map((r) => [r.key, r.fee]), ...Object.entries(existingFees(s.p2!.plans ?? []))]);
    const ruleByPct = new Map<number, string>([...Object.entries(feeOf).map(([k, v]) => [v, k] as [number, string]), [base, "Any Data Plan (base)"]]);
    const seenMails = await snapshotMailIds(MEMBER_EMAIL);
    const orders: PaidOrder[] = [];
    for (const c of CASES) {
      await test.step(c.id + " " + c.label, async () => {
        const expectedRule = c.candidates.find((k) => feeOf[k] !== undefined) ?? "Any Data Plan (base)";
        const expectedPct = feeOf[expectedRule] ?? base;
        const r = await buy(browser, c).catch((e) => ({ error: String(e).split("\n")[0] }) as any);
        orders.push({ key: c.id + " " + c.label, orderNumber: r.orderNumber ?? "", listedPrice: Number(r.listedPrice), expectedPct, expectedRule, areaRe: c.area, data: c.tile, error: r.error });
        await card(browser, testInfo, c.id + " buy " + c.label, "<p>" + esc(r.error ? "FAILED: " + r.error : "Plan: " + r.plan + " ; listed US$ " + r.listedPrice + " ; order " + r.orderNumber) + "</p>",
          { ac: AC, title: c.id + " buy " + c.label, steps: ["Storefront /en/plans/" + c.page + "-esim -> " + (c.unlimited ? "Unlimited data plan -> " : "") + c.tile + " (" + c.area.source + ")", r.error ? r.error : "Order " + r.orderNumber],
            expected: ["Rule " + expectedRule + " (" + expectedPct + "%) - " + c.why], status: r.error ? "failed" : undefined });
      });
    }
    const t = await (async () => { const { ctx, page } = await adminSess(browser); try { return await adminToken(page); } finally { await ctx.close(); } })();
    const checks = await verifyOrders(t, MEMBER_EMAIL, orders, seenMails,
      (page, title, steps, expected, ok) => evidence.saveScreenshot(page, testInfo, { ac: AC, title: "PRI-01 " + title, steps, expected, status: ok ? undefined : "failed" }));
    // which rule won = Value / listed price (falls back to the discount reading if the customer was charged less)
    const rows: unknown[][] = [];
    let priorityFails = 0;
    for (const c of checks) {
      const pct = Number.isFinite(c.paid) && c.paid < c.listed - 0.01 ? Math.round(100 - (c.paid / c.listed) * 100) : Math.round(c.appliedPct);
      const appliedRule = ruleByPct.get(pct) ?? (Number.isFinite(pct) ? "? (" + pct + "%)" : "-");
      const priorityOk = !!c.whi && pct === c.expectedPct;
      if (!priorityOk) priorityFails++;
      rows.push([c.key, c.expectedRule + " " + c.expectedPct + "%", appliedRule + " " + pct + "%", priorityOk ? "PASS" : "FAIL"]);
      expect.soft(priorityOk, c.key + ": expected rule " + c.expectedRule + " (" + c.expectedPct + "%), applied " + appliedRule).toBe(true);
      for (const [k, v] of Object.entries(c.checks)) if (!(k.startsWith("receipt") && c.mail.status === "blocked") && k !== "Value = listed x rule %") expect.soft(v, c.key + ": " + k).toBe(true);
    }
    await card(browser, testInfo, "PRI-01 - which rule won per plan (priority)",
      table(["Case", "Expected rule (EA-4281)", "Applied rule", "Priority"], rows),
      { ac: AC, title: "PRI-01 DATA priority per plan", steps: rows.map((r) => r.join(" | ")), expected: CASES.map((c) => c.id + ": " + c.why), status: priorityFails ? "failed" : undefined });
    await card(browser, testInfo, "PRI-01 - per order: PUR, paid, Eskimo Sales, Application Fee, receipt email", ordersTableHtml(checks, esc),
      { ac: AC, title: "PRI-01 DATA orders", steps: checks.map((c) => c.key + ": " + c.orderNumber + " / " + (c.whi || "no WHI") + " ; paid $" + c.paid + "/" + c.listed + " ; Value $" + c.value + " ; Eskimo Sales " + (c.sale.found ? "$" + c.sale.value : "NOT FOUND") + " ; email " + c.mail.status + " -> " + (c.ok ? "PASS" : "FAIL")),
        expected: ["Customer pays the listed price", "Value = listed x winning rule %", "Eskimo Sales record = Data Purchase", "1 receipt email per order, Total Amount = paid"], status: checks.every((c) => c.ok) ? undefined : "failed" });
    console.log("[ESKIMO-910 priority] " + checks.map((c, i) => c.key + " exp " + c.expectedRule + " " + c.expectedPct + "% got " + rows[i][2] + " paid " + c.paid + "/" + c.listed + " value " + c.value + " sale " + (c.sale.found ? c.sale.value : "-") + " mail " + c.mail.status + " " + rows[i][3]).join(" ;; "));
    console.log("[ESKIMO-910 priority] priority fails=" + priorityFails + " order fails=" + checks.filter((c) => !c.ok).length);
    expect.soft(s.gaps ?? [], "PRI-00: Apply To option available for every priority level").toEqual([]);
    expect.soft(s.order?.sorted, "PRI-00: rule list sorted by EA-4281 sorting no. after save: " + (s.order?.labels ?? []).join(" | ")).toBe(true);
  });
});
