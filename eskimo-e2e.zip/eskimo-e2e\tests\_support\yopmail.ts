// Yopmail inbox reader (ported from eskimo_portal/e2e/helpers/yopmail.js) - reads real test emails, no bypass.
//   https://yopmail.com/en/?login=<name>  -> iframe#ifinbox (rows .m: .lmf from, .lms subject, .lmh time) + iframe#ifmail (open mail)
// The inbox is PUBLIC: test data only. Cloudflare "Verify you are human" is never bypassed: in a headed browser we wait
// for a person to tick it, otherwise the caller gets an error and records BLOCKED.
import { chromium, type Browser, type BrowserContext, type Page } from "@playwright/test";

export const YOPMAIL_BASE = process.env.E2E_YOPMAIL_BASE || "https://yopmail.com/en/";
const loginOf = (address: string) => String(address || "").split("@")[0].trim().toLowerCase();

export type MailRow = { id: string; from: string; subject: string; time: string };
export type MailContent = { text: string; html: string; links: { text: string; href: string; rawHref: string | null }[]; unreadable?: boolean };

export async function waitIfCaptcha(page: Page, timeoutMs = Number(process.env.E2E_YOPMAIL_CAPTCHA_WAIT_MS || 180000)) {
  const blocked = async () => {
    const txt = await page.locator("body").innerText({ timeout: 3000 }).catch(() => "");
    if (/confirm you.?re human|verify you are human/i.test(txt)) return true;
    return page.frames().some((f) => /challenges\.cloudflare\.com|turnstile/i.test(f.url()));
  };
  if (!(await blocked())) return false;
  console.log("[ACTION] yopmail shows a Cloudflare 'Verify you are human' check - please tick it in the browser window (waiting up to " + Math.round(timeoutMs / 1000) + "s)");
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    await page.waitForTimeout(3000);
    if (!(await blocked())) { await page.waitForTimeout(1500); return true; }
  }
  throw new Error("yopmail blocked by Cloudflare 'Verify you are human' - not solved");
}

export async function openInbox(context: BrowserContext, address: string) {
  const p = await context.newPage();
  await p.goto(YOPMAIL_BASE + "?login=" + encodeURIComponent(loginOf(address)), { waitUntil: "domcontentloaded", timeout: 60000 });
  await p.locator("#ifinbox").waitFor({ state: "attached", timeout: 30000 });
  await p.waitForTimeout(1500);
  await waitIfCaptcha(p);
  return p;
}

export async function refreshInbox(page: Page) {
  const btn = page.locator("#refresh").first();
  if (await btn.isVisible().catch(() => false)) await btn.click().catch(() => {});
  else await page.reload({ waitUntil: "domcontentloaded" }).catch(() => {});
  await page.waitForTimeout(1500);
  await waitIfCaptcha(page);
}

/** Mails on inbox page 1 (newest first). */
export async function listMails(page: Page): Promise<MailRow[]> {
  const frame = page.frame({ name: "ifinbox" });
  if (!frame) return [];
  await frame.waitForSelector(".m", { timeout: 10000 }).catch(() => {});
  return frame.$$eval(".m", (els) => els.map((e) => ({
    id: e.id,
    from: ((e.querySelector(".lmf") as HTMLElement)?.innerText || "").trim(),
    subject: ((e.querySelector(".lms") as HTMLElement)?.innerText || "").trim(),
    time: ((e.querySelector(".lmh") as HTMLElement)?.innerText || "").trim(),
  }))).catch(() => []);
}

async function readMailOnce(page: Page, mailId: string): Promise<MailContent> {
  await waitIfCaptcha(page);
  await page.frameLocator("#ifinbox").locator('[id="' + mailId + '"]').first().click();
  await page.frameLocator("#ifmail").locator("body").waitFor({ timeout: 20000 });
  await page.waitForTimeout(1200);
  const frame = page.frame({ name: "ifmail" })!;
  return frame.evaluate(() => {
    const el = (document.querySelector("#mail") as HTMLElement) || document.body;
    return {
      text: el.innerText,
      html: el.innerHTML,
      links: Array.from(el.querySelectorAll("a")).map((a) => ({ text: (a.innerText || "").trim(), href: (a as HTMLAnchorElement).href || "", rawHref: a.getAttribute("href") })),
    };
  });
}

/** Open one mail; re-read once if the body is empty (captcha popped up mid-read). */
export async function readMail(page: Page, mailId: string): Promise<MailContent> {
  let c = await readMailOnce(page, mailId);
  for (let i = 0; i < 2 && !String(c.text || "").trim(); i++) {
    await waitIfCaptcha(page);
    await page.reload({ waitUntil: "domcontentloaded" }).catch(() => {});
    await page.locator("#ifinbox").waitFor({ state: "attached", timeout: 30000 }).catch(() => {});
    await page.waitForTimeout(2500);
    c = await readMailOnce(page, mailId);
  }
  c.unreadable = !String(c.text || "").trim();
  return c;
}

/** Headed browser for yopmail only (so a person can tick a Cloudflare check). Caller closes it. */
export async function yopmailBrowser(): Promise<Browser> {
  return chromium.launch({ headless: process.env.E2E_YOPMAIL_HEADLESS === "1" });
}
