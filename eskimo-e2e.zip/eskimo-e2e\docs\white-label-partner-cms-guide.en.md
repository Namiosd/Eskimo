# Partner Guide: Managing Your Website on the Partner Portal

| | |
|---|---|
| **For** | White Label partners (your operations and customer support team) |
| **Scope** | Sign in → connect Stripe → set up branding and website content → domain and email sender → go live → support customers |
| **Last updated** | 26 Oct 2026 |

---

## 1. Overview

### 1.1 What you do, what Eskimo does

| Who | Responsible for |
|---|---|
| **You (Partner)** | Connect **Stripe** to accept payments; edit the website's **branding and content** (name, logo, colours, text, images, links); add the **DNS records** for your website domain and email sender; support your customers |
| **Eskimo team** | Activate your partner account; create the website and its **page layout** (which content blocks each page has, and in what order); configure the domain and email sender you provide, send you the **DNS records**; check and **launch** the website; manage **data plans and prices** |

> You **cannot** add, remove or reorder content blocks, and you **cannot** change prices or the plan list. For these changes, contact the Eskimo business team.

### 1.2 Flow

```
LANES
```

### 1.3 When you need to wait for Eskimo

| You want to… | Eskimo first needs to |
|---|---|
| See your website under **My Website** | Create the website and assign it to your account |
| Add DNS records | Configure the domain and email sender you provided, then send you the DNS records |
| Have customers buy on the website | Check and **launch** the website (after your Stripe connection is done) |
| Add, remove or reorder content blocks | Change the page layout at your request |

---

## 2. Before you start

1. Your **Partner Portal account** and access to the login email's mailbox to receive the OTP code.
2. **Company and bank account details** for Stripe.
3. A **subdomain** for the website (e.g. `esim.yourdomain.com`) and **DNS access** to your main domain. If you want Eskimo to email your customers: your own **email domain** and **email sender details** (Sender name, From address, Reply-to).
4. **Brand assets:**
    - **Logo**: a **transparent PNG** (transparent background), **under 1 MB**. Do not use JPEG or a logo with a coloured background: it shows as a box on the Header and Footer.
    - **Primary and secondary colours** (`#RRGGBB`, e.g. `#1957F5`).
    - **Images** for the banner, highlight tiles and install guide: PNG or JPEG, **under 5 MB** each.
    - **Copy**: headings, introduction, FAQs, support email, social media links.

---

## 3. Step 1 — Sign in to the Partner Portal

1. Open the Partner Portal link Eskimo sent you.
2. Enter your email → request a code → enter the **OTP code** from your email → sign in.
3. Click **My Website** in the left menu. The **Edit Website Content** screen opens.

> If you see *"No website has been assigned to you yet. Please contact your account manager."*, Eskimo has not created or assigned your website yet. Contact the Eskimo business team.

![My Website screen](images/partner-cms/01-cms-workspace.png)

| Area | Purpose |
|---|---|
| **Page tabs** | Switch between the 5 pages: Home, Plan Detail, Checkout, Data Balance, Install eSIM. The number is the count of content blocks |
| **Brand identity** | Brand name, logo, colours |
| **Stripe payments** | Stripe status and connect button |
| **Preview** | The selected page, close to the live website |
| **Pencil button** | On each content block, opens **Configure &lt;block name&gt;** |
| **Save Page / Save All (N pages)** | Publishes changes to the website |

---

## 4. Step 2 — Connect Stripe

Customer payments on your website are processed through **your Stripe account**. The website only accepts payments once Stripe is **Verified**.

1. In **My Website**, find **Stripe payments** → click **Connect Stripe**.
2. You are taken to **Stripe**. Enter your company details and payout account, and complete verification.
3. If interrupted, return to **My Website** → click **Continue setup**.

> The **Connect Stripe / Continue setup** buttons only show for accounts with the **Owner** or **Admin User** role. Other roles see the status only.

| Status | Meaning | What to do |
|---|---|---|
| **Not Connected** / **—** | Not connected | Click **Connect Stripe** |
| **Pending verification** | Stripe is verifying | Wait; if Stripe asks for more information, click **Continue setup** |
| **Verified** | Ready to accept payments | Done |

> The status can take **a few minutes** to update after Stripe finishes verification. Reload the page to see the latest.

---

## 5. Step 3 — Branding and website content

### 5.1 How to edit — two different Save buttons

1. Select the page in the page tabs → click the **pencil** on the block to edit.
2. Edit → click **Save** in the dialog → **only updates the preview**.
3. Continue with other blocks and pages.
4. Click **Save Page / Save All** (bottom right) → **publishes to the website**, toast `Saved: "<page name>"`.

> ⚠️ **Save** in a dialog ≠ **Save Page**. Only **Save Page / Save All** publishes to the website. Always click it before leaving the screen.

**Input types**

| Type | Usage |
|---|---|
| Single / multi-line text | Fields marked *"one per line"*: each line becomes a bullet |
| Link (URL) | A website page (`/esim`) or full link (`https://...`), `mailto:`, `tel:`. A page the website does not have shows an orange warning and the link is **not displayed**. Do **not** add a language prefix (use `/esim`, not `/en/esim`) |
| Image | Click **Upload** to upload from your computer |
| Icon | Pick from the built-in library (wifi, globe, shield…), searchable |
| List | **+ Add** adds a row, **Remove** deletes it. Buttons grey out at the minimum / maximum count |
| ✓ / ! / ✕ select | Comparison table: `✓ Yes`, `! Partly`, `✕ No` |
| `{brand}` placeholder | Replaced with your Brand name in any block. E.g. `Why {brand}?` → *Why Your Brand?* |
| `{country}` placeholder | Only in the Plan Detail Hero heading. E.g. `{country} eSIM` → *Japan eSIM* |

### 5.2 Brand identity

![Brand identity](images/partner-cms/02-brand-identity.png)

| Field | Where it appears |
|---|---|
| **Brand name** | Browser tab title and every `{brand}` (including the copyright line) |
| **Logo** (**Upload**) | Header and Footer on every page. **Transparent PNG**, under 1 MB. **Always use Upload**: image links pasted from elsewhere will not show. Without a logo, the Brand name shows as text |
| **Primary** | Buttons, accent headings, links, payment form |
| **Secondary** | Region cards in the plan list and the install step cards (Install Steps) |

Colours must be `#RRGGBB`; otherwise the website falls back to the default colour. Then click **Save Page** → toast `Branding saved`.

### 5.3 Header and Footer

Each page has **its own** Header and Footer. Configure them **identically on all 5 pages** for a consistent site, then **Save All**.

![Configure Header](images/partner-cms/06-configure-header.png)

- **Header — Navigation links**: each item has a *Label* and *URL*, e.g. `Travel eSIM` → `/esim`, `Install eSIM` → `/install-esim`. The logo comes from Brand identity. The **My Data** button shows on the right automatically, unless your menu already links to `/data-balance`.

![Configure Footer](images/partner-cms/07-configure-footer.png)

| Footer field | Description |
|---|---|
| **Support email** | Your support email, shown in the *Need help?* line (hidden when empty) |
| **Column 1/2/3 title + links** | Three footer columns. Links with an empty URL, or pointing to a page the website does not have, are dropped; a column with no remaining links is hidden, even if it has a title |
| **Social links** | Icon (facebook, instagram, youtube-play, tiktok…) and URL. A row with an empty URL **still shows its icon**: remove unused rows |
| **Locale/currency label** | e.g. `EN • USD — $` |
| **Copyright text** | e.g. `© 2026 {brand}` |

### 5.4 Content per page

| Page | Block | What you can edit |
|---|---|---|
| **Home** | Banner | Background image, heading, description, country search label and hint (empty → *"Search N+ countries"* using the real count), call-to-action text and link (empty text → no button), rating |
| | Data Plan Section | Heading, highlight line, description. Regions and country counts are **automatic** |
| | Transfer Data | Eyebrow label, heading, description, 1–4 features (icon, title, description), 1–4 highlight tiles (title, description, image) |
| | More Reasons Grid | Heading, 3–9 reasons (icon, title, description) |
| | Video Section | Video link (YouTube or `.mp4`), 2 overlay text lines |
| | Comparison Table | Heading, description, 4 column names, 1–12 comparison rows (✓ / ! / ✕) |
| | Install Steps | Heading, description, 3–8 summary steps |
| | Reviews | Heading, 3–9 reviews (name, date, text) |
| | FAQ | Heading, description, 1–9 questions and answers (**+ Add Question**) |
| | Recommendations | Heading, 3 tab names, guide links for tab 3. Tab 1 (popular countries) and tab 2 (regions) are **automatic** |
| **Plan Detail** | Plan Detail Hero | Page heading (use `{country}`), rating, 2 plan-type tabs (name, badge, features), 3–4 feature cards |
| | Sticky Checkout Bar | Payment button text. Plan name and price are **automatic** |
| **Checkout** | — | Header and Footer only; the payment form is provided by the system |
| **Install eSIM** | Install eSIM Guide | Heading, description, iOS / Android tab names, the word before step numbers (`Step` → *Step 1, Step 2…*), 1–8 steps per OS (title, bullets, up to 4 images) |
| **Data Balance** | Data Balance Screen | Page title, *My Plans* / *History* tab names, empty-state text, *How to install eSIM* link text, *Buy more data* button text. The customer's plans, data and history are **automatic** |
| | Data & eSIM Information | Heading, Fixed plan benefits (3–8) and Unlimited plan benefits (3–8) |

![Configure Banner](images/partner-cms/04-configure-banner.png)
![Configure FAQ](images/partner-cms/05-configure-faq.png)
![Configure Plan Detail Hero](images/partner-cms/08-configure-plan-detail-hero.png)
![Configure Install eSIM Guide](images/partner-cms/09-configure-install-guide.png)
![Configure Data Balance Screen](images/partner-cms/10-configure-data-balance.png)

### 5.5 Automatic content

These always show live system data so customers see the right plans and prices; you do not enter them:
- Countries, regions and country counts.
- Data plans, allowances, prices.
- Popular countries and regions in Recommendations.
- Plan name and price on the checkout bar.
- The customer's plans, remaining data and history in My Data.

### 5.6 Save and check

1. Click **Save Page / Save All**, wait for `Saved: …`.
2. Open the website and reload. New content usually appears within **about 30 seconds**; if not, wait and reload after a minute.

![Website after configuration](images/partner-cms/13-storefront-home.png)

> Each partner sees and edits **only its own website**. Images you upload are stored for your website only.

---

## 6. Step 4 — Domain and email sender

1. Send Eskimo:
    - The **subdomain** for your website, e.g. `esim.yourdomain.com` (not the root domain `yourdomain.com`).
    - If you want Eskimo to email your customers: the **email sender details** on your email domain (Sender name, From address, Reply-to).
2. Eskimo configures them and sends you the **DNS records**:

| Record | Used for |
|---|---|
| CNAME **esim.yourdomain.com** | Routes the website to Eskimo so customers open it on your domain |
| CNAME **_acme-challenge.esim.yourdomain.com** | Issues and auto-renews the HTTPS certificate. ⚠️ **Never remove it**: without it the website stops opening at the next renewal (months later) |
| Email authentication records (Type / Host / Value), only if Eskimo sends emails | Sends customer emails from your address |

3. Add them all to your main domain's DNS as **DNS only, not proxied** (Cloudflare: grey cloud).
4. Tell Eskimo so they can check. The website runs on your domain once DNS points correctly; emails are sent from your address once the domain is verified.

> **Who emails customers:** if Eskimo sends them, you must have your own **email domain** and complete the email part above. If you do not give Eskimo an email domain, you **handle** sending the order confirmation, the eSIM QR code and the My Data sign-in OTP to customers yourself via the **External API**, and skip the email part; Eskimo then sends no emails.

> Need help adding DNS records → contact the **Eskimo business team**.

---

## 7. Step 5 — Go live

1. Once Stripe is **Verified**, your content is complete and the DNS records are in place, tell Eskimo.
2. Eskimo checks and **launches** the website. The website only opens once your Stripe is **Verified**, even if the domain and DNS are done.
3. Check the website on desktop and mobile: all 5 pages, logo, colours, links, support email.

**Good to know while the website is live:**
- The website only sells during the **agreed partnership period**. When the partnership is paused or has ended, the website shows **"This store isn't available — Please check back later."** and customers cannot buy. Contact the Eskimo business team if you see this page unexpectedly.
- You can edit content at any time (see 5.6).

![Website when not selling](images/corporate-program/07-store-unavailable.png)

---

## 8. How customers buy and use eSIMs (for your support team)

> Text in `this style` is shown verbatim on the website.

### 8.1 Customer journey

| # | Stage | Customer action | Result |
|---|---|---|---|
| 1 | **Pick a plan** | Open the website → pick a country / region → pick a plan | Sees your brand's plan list |
| 2 | **Checkout** | Enter First name + Email → pay by card | Payment succeeds |
| 3 | **Receive eSIM** | (automatic) | Email with the eSIM **QR code** and a link to My Data: sent by Eskimo from your email address, or by you if you use your own email system (Step 4) |
| 4 | **My Data** | Open the Magic Link, or enter Email + OTP code | Sees plans, remaining data, history |
| 5 | **Buy more** | Buy a new plan with the **same email** | The data is added to the same email: shown in My Data under **My Plans** and **History**, and used on the **eSIM already activated** (no new eSIM to install) |

**The payment result decides whether the customer can see My Data:**

| Payment result | What the customer gets | My Data |
|---|---|---|
| **Successful** | Confirmation page with the Order number; eSIM and plan created for the email entered | **Available** (Magic Link or Email + OTP) after about 30–60 seconds |
| **Failed** (card declined, payment did not go through) | Error message, **not charged**, **no** eSIM, **no** plan | **Not available**. An email with no successful purchase gets no sign-in code |

> A customer whose payment failed just needs to **pay again successfully with the same email**. The order then completes normally and My Data becomes available, with no duplicate account.

**Principles:**
- The store is in **English**, priced in **USD**, and takes **card payments through Stripe**. There is no language switcher, currency switcher or promo code.
- Customer data expires **2 years** after purchase.
- **Customer accounts are separate per brand.** The same email on another website is a different account; plans and history are not shared.
- If you send customer emails yourself (via the External API), you must send the **order confirmation**, the **eSIM QR code** and the My Data sign-in **OTP**.

### 8.2 Buying

1. Pick a plan → click the checkout button (default **`Checkout`**).
2. Enter **First name** and **Email** (receives the eSIM and is the My Data login, so it must be spelled correctly) → **`Continue to payment`**.
3. Enter the card → **`Pay US$ …`** → `Processing payment…`.
4. The confirmation page shows the **Order number** (`PUR-PN…`), plan, total, the eSIM email and `Payment received — we're preparing your eSIM`.

### 8.3 Accessing My Data

- **Magic Link** in the email: straight into the wallet, no code needed, reusable.
- **Email + OTP**: click **`My Data`** → enter the purchase email → **`Send code`** → enter the **4-digit code** (expires after **5 minutes**) → **`View my data`**. After sign-in the session is kept for **7 days** on the same device, so the customer can reopen My Data without a new code.

In the wallet: **My Plans** tab (country, remaining data; unlimited plans show a label such as `Unlimited 30 days`) and **History** (date, plan, status).

### 8.4 Common messages

**Checkout**

| Situation | Message | Tell the customer |
|---|---|---|
| Empty first name | `Enter your first name.` | Enter First name |
| Empty / invalid email | `Enter a valid email address.` | Enter a valid email |
| Checkout opened with no plan | `No plan selected` | Go back and pick a plan |
| Too many payment attempts | `Too many checkout attempts. Please wait a few minutes and try again.` | Wait a few minutes |

**Payment**

| Situation | Message | Tell the customer |
|---|---|---|
| Card declined | `Your card has been declined.` | **Not charged**. Try another card with the same email |
| Payment could not start | `We couldn't start your payment. Please try again in a moment.` | Retry shortly |
| Payment failed | `Your payment didn't go through.` + `You haven't been charged. You can try again with the same or a different card.` | Not charged, retry |
| Bank still confirming | `Your bank is still confirming the payment. We'll email your eSIM as soon as it goes through — no need to pay again.` | **Do not pay again**, wait for the email |
| Result could not be confirmed | `We couldn't confirm your payment` + `Please check your email before trying again — if the payment went through, your eSIM is on its way.` | **Check email first** to avoid paying twice |

**My Data**

| Situation | Message | Tell the customer |
|---|---|---|
| Email never purchased, or just purchased | `We're unable to process your request yet. Please purchase a data plan with this email to get started.` | Check the email used at checkout; if just purchased, wait 30–60 s and `Send code` again |
| Wrong / old code | `Invalid OTP` or `That code isn't valid any more. Request a new one.` | Use the latest code or request a new one |
| Too many wrong codes | `Too many invalid attempts. Please request a new OTP and try again in a few minutes.` | Wait a few minutes, request a new code |
| Too many code requests | `Too many codes requested. Please wait a few minutes and try again.` | Wait a few minutes |
| Code could not be sent | `We couldn't send your code right now. Please try again.` | Retry |
| Magic Link expired / broken | `That link has expired. Enter the email you used at checkout and we'll send you a code.` | Sign in with Email + OTP |

---

## 9. Troubleshooting

| Issue | What to do |
|---|---|
| My Website shows *"No website has been assigned to you yet…"* | Eskimo has not created or assigned your website. Contact the business team |
| No **Connect Stripe** button | Your account is not an Owner / Admin User. Use an account with that role, or contact Eskimo |
| Edited but the website hasn't changed | **Save Page / Save All** not clicked (the dialog's Save only updates the preview), or 30 seconds – 1 minute hasn't passed |
| Logo not showing | Upload the logo with the **Upload** button, PNG under 1 MB |
| Logo shows with a white / coloured box | The logo file has a background. Export it again as a **transparent PNG** and upload it again |
| A link does not show on the website | Empty URL, a page the website does not have, or an `/en` prefix. See Appendix A |
| Extra social media icon | A row with an empty URL still shows its icon. Remove that row |
| Header / Footer differ between pages | Each page has its own Header / Footer. Configure all 5 pages, then **Save All** |
| Website shows *"This store isn't available"* | The website is not launched yet (usually because Stripe is not **Verified**: see Step 2), or the partnership is paused / ended. Contact the business team |
| The website does not open on your domain | Check both CNAMEs are added and set to DNS only; if it still fails, contact the business team |
| A customer did not receive the eSIM email | Ask them to check spam and the email used at checkout. If you send customer emails yourself, check your sending system |
| A customer asks for a **refund** | Refunds for website orders are **not available yet**. Contact the Eskimo business team before taking any action |

---

## Appendices

### Appendix A — Website paths

| Path | Page |
|---|---|
| `/` | Home |
| `/esim` | Plans by country / region |
| `/plans/<country>-esim` | Plan detail (`/plans/japan-esim`, `/plans/global-esim`) |
| `/checkout` | Checkout |
| `/data-balance` | My Data |
| `/install-esim` | eSIM install guide; add `?platform=ios` or `?platform=android` to open that tab |

In the browser the site uses a language prefix (e.g. `/en/data-balance`), but links entered in the Partner Portal must **omit the prefix** (`/data-balance`). Links to other websites use the full `https://...` address.

### Appendix B — Image upload limits

| Type | Format | Max |
|---|---|---|
| Logo | **Transparent PNG** | 1 MB |
| Content block images (banner, highlight tiles, install guide) | PNG, JPEG | 5 MB |

### Appendix C — Content blocks per page

| Page | Content blocks (default display order) |
|---|---|
| **Home** | Header → Banner → Data Plan Section → Transfer Data → More Reasons Grid → Video Section → Comparison Table → Install Steps → Reviews → FAQ → Recommendations → Footer |
| **Plan Detail** | Header → Plan Detail Hero → Sticky Checkout Bar → Footer |
| **Checkout** | Header → Footer (payment form provided by the system) |
| **Data Balance** | Header → Data Balance Screen → Data & eSIM Information → Footer |
| **Install eSIM** | Header → Install eSIM Guide (iOS / Android) → Footer |
