# ESKIMO-751 – [EP-5963] [Admin] Template & Website Structure Management

Source: the acceptance criteria AC1 / AC2 / AC3 of item ESKIMO-751 (Jira EP-5963). Retest after the move to the new platform.
These test cases were drafted by QC from the AC (there is no BA test-case file). The steps follow the earlier
verification in eskimo_portal `e2e/admin/white-label-website-structure.spec.js` (staging, 14/14 pass on 2026-10-06).

Environment: Admin Portal QA = E2E_ADMIN_URL (https://app-eskimo-admin-qa-sea-001.azurewebsites.net), which calls the stage API = E2E_API_URL.
Admin login: E2E_ADMIN_EMAIL / E2E_ADMIN_PASSWORD (OTP).
Screen: menu "White Label" → `#/white-label-templates` ("Website Templates").

QC decisions (2026-10-15):
- Exactly ONE record is created: a draft website cloned from the System Default template. All structure edits happen only on that record.
  It is deleted at the end (TC-13), and also in afterAll if the run stops early.
- System Default template and websites that belong to other partners are READ-ONLY: never Save, never Delete.
- Assign partner: the test partner WLBe2e (PN847236) already owns site-0gx5wz, so the clone is NOT assigned to anyone.
  TC-07 checks only the Assign Partner modal (search + partner list) and then presses Cancel. The real assign is manual / not run.

## TC-01 Website Templates page lists the reusable System Default template (AC1)
- Steps:
  1. Admin QA → menu White Label → Website Templates
- Expected:
  - The page shows the table of templates and websites
  - At least 1 row has Type = "System Default"

## TC-02 System Default template is built from the Eskimo eCommerce site, split into reusable modules (AC1, DATA)
- Steps:
  1. GET /api/white-label/templates → the System Default template
  2. GET /api/white-label/templates/{id}
- Expected:
  - The template name refers to the Eskimo eCommerce website
  - The template has ≥ 1 page, and each page has its own list of modules (pages[].modules[])
  - At least one module type is used on more than 1 page (reused across pages)

## TC-03 Structure editor shows the template's modules and an extensible module library (AC1, view only)
- Steps:
  1. On the System Default row, click "Edit Structure"
  2. Look at the sections of the selected page; open "+ Add Section" and read the list
  3. Close the dropdown and the editor WITHOUT saving
- Expected:
  - The page shows ≥ 1 module/section
  - The library contains the AC examples: Header, Banner, Product section, Feature section, Footer
  - The library has more modules for future pages (≥ 5 options)

## TC-04 Create a new website from the default template (AC2 "Create from a default template")
- Steps:
  1. On the System Default row, click "Clone"
- Expected:
  - Toast "Website draft created"
  - Exactly 1 new record (GET /api/white-label/websites before and after) shows as a "Partner Website" row

## TC-05 The new website inherits the template's structure at the time of cloning (AC3, DATA)
- Steps:
  1. GET /api/white-label/websites/{newId} right after TC-04
- Expected:
  - Same pages (compared by page id) and the same ordered modules in every page as the template

## TC-06 Enter a website name (AC2 "Enter a website name") — UNCLEAR
- Steps:
  1. Look for a way to enter the website name when creating it (Clone) or on the website row
- Expected (from the AC): Admin can enter a name for the new website
- Note: the deployed UI has no name field. The new website is called "Untitled Website Draft", and the name only changes through Assign Partner.
  Earlier (Jira) the ticket owner accepted this. QC needs to confirm: pass with the note, or fail.

## TC-07 Assign Partner modal (AC2 "assign to partner") — modal only, no assign
- Steps:
  1. On our new row, click "Assign Partner" → modal "Assign Partner — <name>"
  2. Open the Partner field, check that the list shows partners; type "WLBe2e" in the search
  3. Press Cancel (do not Assign)
- Expected:
  - The modal opens with a required, searchable Partner field and a list of partners
  - (Info, not asserted) whether WLBe2e is offered. It already owns site-0gx5wz, and the FE hides partners that already have a website.
- The real assign is not run (WLBe2e is taken) → manual.

## TC-08 Add a module to a page and save (AC2)
- Steps:
  1. On our row, click "Edit Structure" → choose a page
  2. "+ Add Section" → pick a module that is not on the page yet
  3. Save Page
- Expected:
  - The canvas shows one more section; toast "Saved: …"
  - (DATA) GET website detail: module count = count at clone + 1

## TC-09 Remove a module from a page and save (AC2)
- Steps:
  1. "Edit Structure" on our row → Remove (trash icon) on the module added in TC-08 → confirm "Remove"
  2. Save Page
- Expected:
  - The canvas shows one fewer section
  - (DATA) module count = count after TC-08 − 1 (back to the count at clone)

## TC-10 Reorder modules by drag and drop and save (AC2)
- Steps:
  1. "Edit Structure" on our row → drag a section by its handle (Drag to reorder) to another position
  2. Save Page
- Expected:
  - The canvas shows the new order
  - (DATA) the saved module order changed, and the set of modules is the same

## TC-11 Changes on the cloned website do not affect the original template (AC3, DATA)
- Steps:
  1. After TC-08–TC-10, GET the System Default template again
- Expected:
  - The template structure is the same as in TC-02 (taken before any edit)

## TC-12 The cloned website is an independent copy (AC3, DATA)
- Steps:
  1. Compare the clone record with the template
- Expected:
  - The clone is a separate record (id ≠ template id) and has its own pages[]
- Note: "Changes to the original template must not affect clones". This run does not edit the template, because of the read-only rule. Only the structural independence is checked here.

## TC-13 Cleanup: delete only our cloned website
- Steps:
  1. On our row, click Delete → confirm "Delete"
- Expected:
  - Toast "DELETE SUCCESS"; GET /api/white-label/websites no longer has our id; the other websites are unchanged

## Not covered
- AC2 "assign to partner" (the actual assign): no free test partner, see TC-07
- AC3 "Changes to the original template must not affect previously cloned websites": the template is not edited (read-only rule)
- AC3 "…must not affect … other cloned websites": only 1 clone per run (data rule)
- NOTE "All functional modules available on the Partner website must use External APIs": needs the storefront / BE, not this Admin screen
