// WL-GUIDE – read-only: texts in the default template that promise data never expires. GET only.
import fs from "node:fs";
import { test } from "@playwright/test";
import { adminSessionRetry as adminSession, api, tokenOf } from "../_support/whitelabel";

test("default template: no-expiry wording", async ({ browser }) => {
  test.setTimeout(240_000);
  const { page } = await adminSession(browser);
  const token = await tokenOf(page);
  const t = await api(token, "GET", "/api/white-label/templates");
  const tpls: any[] = (t.json?.data ?? t.json)?.templates ?? [];
  const hits: any[] = [];
  for (const tp of tpls) {
    const d = await api(token, "GET", `/api/white-label/templates/${tp.id}`);
    const data = d.json?.data ?? d.json;
    for (const p of data?.pages ?? []) for (const m of p.modules ?? []) {
      const walk = (o: any, path: string) => {
        if (typeof o === "string") { if (/expir|never run out|no waste/i.test(o)) hits.push({ page: p.name, module: m.type, field: path, text: o.slice(0, 160) }); return; }
        if (o && typeof o === "object") for (const [k, v] of Object.entries(o)) walk(v, path ? `${path}.${k}` : k);
      };
      walk(m.config ?? m.props ?? m.content ?? m.data ?? m, "");
    }
  }
  fs.writeFileSync("test-results/wl-guide-template-expiry.json", JSON.stringify(hits, null, 2));
});
