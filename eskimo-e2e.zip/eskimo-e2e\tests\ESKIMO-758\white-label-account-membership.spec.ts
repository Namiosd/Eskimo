// ESKIMO-758 / EP-6029 – White Label account, White Label Payment transaction and Membership search/filter (Admin).
// Test cases: testcases/ESKIMO-758/ESKIMO-758.md (expected results = the item's AC1–AC3):
//   TC-01 WL account stored like a Corporate Work Account (accountType 2 + Partner ID)        (AC1)
//   TC-02 WL account identified by Email + Partner ID (no duplicate pair)                     (AC1)
//   TC-03 WL account cannot log in to Eskimo Web                                              (AC1)
//   TC-06 Eskimo Sale: WHI… transaction has Type "White Label Payment"                        (AC2)
//   TC-07 Value = Application Fee (total × platformFeePercent)                                (AC2)
//   TC-08 Payment info kept to trace the Stripe payment (pi_…, WL order id, total, currency)  (AC2)
//   TC-09 Existing Eskimo Sale logic unchanged ("White Label Payment" ⇔ WHI…)                 (AC2)
//   TC-10 Membership Search by Email finds the WL account                                     (AC3)
//   TC-11 Account Type = White Label Account lists only WL accounts                          (AC3)
//   TC-12 Account Type = Personal Accounts does not list the WL account                      (AC3)
// Manual: TC-04 (Eskimo App login), TC-05 (Username NULL / role – DB only).
// Read-only: nothing bought, registered or reconfigured.
// Evidence: evidence/ESKIMO-758-white-label-account → npm run report:evidence -- ESKIMO-758 white-label-account
import { test, expect, type Browser, type BrowserContext, type Locator, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import { adminToken, membersByEmail } from "../_support/wellatsea";
import { api, readPartner } from "../_support/whitelabel";
import { ECOM_URL, bypassCaptcha } from "../_support/ecommerce";

const ID = "@ESKIMO-758";
const AC = "EP-6029";
const evidence = createEvidence("ESKIMO-758", "white-label-account");
const PARTNER_CODE = process.env.E2E_WL_PARTNER_CODE || "PN101609";
const WL_MEMBER_EMAIL = process.env.E2E_WL_MEMBER_EMAIL || "testwhitelabel168@yopmail.com";
const WL_TYPE = "White Label Payment";
const WL_ACCOUNT_TYPE = 2;
const isWhi = (id: string) => /^WHI/i.test(String(id ?? "").trim());

// ─── Stage API ───
const json = async (t: string, method: string, p: string, body?: unknown) => (await api(t, method, p, body)).json;
const saleSearch = (t: string, searchText: string, eskimoTransactionType: number | null = null, pageSize = 20) =>
  json(t, "POST", "/api/data-plan-sale-transaction/search", { pageIndex: 1, pageSize, type: 1, amountId: null, platformFilter: "", eskimoTransactionType, cashbackFilter: 0, paymentMethodFilter: null, searchText, searchPlanName: "", fromDate: null, toDate: null, sortBy: { fieldName: "PurchaseDate", ascending: false } }).then((r) => (r?.data?.data ?? []) as any[]);
const purchases = (t: string, memberId: string) =>
  json(t, "POST", "/api/membership/Details/DataPurchase", { pageIndex: 1, pageSize: 50, id: memberId, isAscending: false, searchText: "" }).then((r) => (r?.data?.data ?? []) as any[]);
const detailOf = (t: string, id: string) => json(t, "GET", `/api/membership/${id}`).then((r) => r?.data ?? null);

// ─── UI helpers ───
const spinnerGone = (page: Page) => page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
const mark = (l: Locator) => l.evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", background: "rgba(255,229,143,.95)" })).catch(() => {});

async function readTable(page: Page) {
  const table = page.locator(".ant-table:visible").filter({ has: page.locator(".ant-table-thead") }).first();
  await table.waitFor({ state: "visible", timeout: 60000 });
  await spinnerGone(page);
  const headers = (await table.locator(".ant-table-thead tr").last().locator("th").allInnerTexts()).map((h) => h.trim());
  const rows = table.locator(".ant-table-tbody tr.ant-table-row");
  const out: { row: Locator; cells: Record<string, string> }[] = [];
  for (let i = 0; i < (await rows.count()); i++) {
    const texts = (await rows.nth(i).locator("> td").allInnerTexts()).map((s) => s.replace(/\s+/g, " ").trim());
    out.push({ row: rows.nth(i), cells: Object.fromEntries(headers.map((h, j) => [h, texts[j] ?? ""])) });
  }
  return { headers, rows: out };
}
const cellOf = (row: { row: Locator }, headers: string[], header: string) => row.row.locator("> td").nth(headers.indexOf(header));

/** Admin › Membership with optional Account Type filter + Search by Email; returns the BE answer the table shows. */
async function membershipQuery(page: Page, opts: { accountType?: string; email?: string }) {
  await page.goto(`${ADMIN_URL}/#/membership`, { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
  await readTable(page);
  const last = () => page.waitForResponse((r) => r.url().includes("/api/membership/search") && r.request().method() === "POST" && r.request().postData()?.includes(`"pageSize":1,`) !== true, { timeout: 90000 });
  let resP: Promise<any> | null = null;
  if (opts.accountType) {
    resP = last();
    await page.locator(".ant-select").filter({ hasText: "Account Type" }).first().click();
    await page.locator(".ant-select-dropdown:visible .ant-select-item-option").filter({ hasText: new RegExp(`^\\s*${opts.accountType}\\s*$`) }).first().click();
  }
  if (opts.email) {
    if (resP) await resP.catch(() => null);
    await page.locator(".search-type-select").first().click();
    await page.locator(".ant-select-dropdown:visible .ant-select-item-option").filter({ hasText: /^\s*Email\s*$/ }).first().click();
    const box = page.getByPlaceholder("Search", { exact: true }).first();
    await box.fill(opts.email);
    resP = page.waitForResponse((r) => r.url().includes("/api/membership/search") && (r.request().postData() || "").includes(opts.email!), { timeout: 90000 });
    await box.press("Enter");
  }
  const res = resP ? await resP : null;
  const req = res ? JSON.parse(res.request().postData() || "{}") : {};
  const body = res ? await res.json().catch(() => null) : null;
  const list: any[] = body?.data?.data ?? [];
  await spinnerGone(page);
  const ui = await readTable(page);
  return { req, list, total: body?.data?.totalRecords ?? body?.data?.total ?? list.length, ui };
}

async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const kv = (rows: [string, unknown, boolean?][]) =>
  `<table>${rows.map(([k, v, ok]) => `<tr><th>${esc(k)}</th><td class="${ok === undefined ? "" : ok ? "ok" : "bad"}">${esc(typeof v === "string" ? v : JSON.stringify(v))}</td></tr>`).join("")}</table>`;

// ─── Shared session + data ───
let admin: { ctx: BrowserContext; page: Page };
let t = "";
let wl: { member: any; detail: any; tx: any };

test.describe.serial(`ESKIMO-758 White Label account, payment & membership ${ID}`, () => {
  test.describe.configure({ timeout: 240_000 }); // stage API is slow; TC-07 makes ~30 calls
  test.beforeAll(async ({ browser }) => {
    test.setTimeout(240_000);
    admin = await adminSession(browser);
    t = await adminToken(admin.page);
    const members = await membersByEmail(t, WL_MEMBER_EMAIL);
    const details = await Promise.all(members.map((m) => detailOf(t, m.id)));
    const i = details.findIndex((d) => d?.accountType === WL_ACCOUNT_TYPE);
    if (i < 0) throw new Error(`Environment: no White Label account for ${WL_MEMBER_EMAIL}`);
    const tx = (await purchases(t, members[i].id)).find((p) => isWhi(p.transactionID) && p.status === 1);
    if (!tx) throw new Error(`Environment: ${WL_MEMBER_EMAIL} has no successful WHI… purchase`);
    wl = { member: members[i], detail: details[i], tx };
  });
  test.afterAll(async () => { await admin?.ctx.close(); });

  // ─── AC1 ───
  test(`TC-01 WL account stored as a Work-type account with Partner ID ${ID}`, async ({}, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 WL account structure");
    const page = admin.page;
    const d = wl.detail;
    await test.step("Membership Detail of the WL member", async () => {
      await page.goto(`${ADMIN_URL}/#/membership?detail=${wl.member.id}`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await page.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
    });
    const drawer = page.locator(".ant-drawer-open .ant-drawer-content").first();
    await drawer.getByText("Data Purchase", { exact: true }).first().waitFor({ state: "visible", timeout: 60000 });
    await spinnerGone(page);
    const title = drawer.locator(".custom-title-membership-detail").filter({ hasText: /^\s*(.+ )?Account\s*$/ }).first();
    await mark(title);
    const titleText = (await title.innerText({ timeout: 10000 }).catch(() => "(missing)")).trim();
    const row = drawer.locator("tr").filter({ has: page.locator("td", { hasText: /^\s*White Label Partner\s*:?\s*$/ }) }).first();
    const rowText = (await row.innerText({ timeout: 5000 }).catch(() => "(missing)")).replace(/\s+/g, " ").trim();
    if (await row.count()) await mark(row);
    const okApi = d.accountType === WL_ACCOUNT_TYPE && d.workerAccountPartnerId === PARTNER_CODE;
    const okUi = titleText === "White Label Account" && rowText.includes(PARTNER_CODE);
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC1`, title: "TC-01 WL account in Membership Detail", steps: [`Member ${WL_MEMBER_EMAIL}`, `API accountType=${d.accountType}, workerAccountPartnerId=${d.workerAccountPartnerId}, isWorkAccount=${wl.member.isWorkAccount}`, `Section title "${titleText}"`, `Row "${rowText}"`], expected: ["Stored like a Corporate Work Account: accountType 2 (White Label) + Partner ID", `Title "White Label Account", White Label Partner ${PARTNER_CODE}`], status: okApi && okUi ? undefined : "failed" });
    expect(d.accountType, "accountType").toBe(WL_ACCOUNT_TYPE);
    expect(d.workerAccountPartnerId, "Partner ID of the WL account").toBe(PARTNER_CODE);
    expect(titleText).toBe("White Label Account");
    expect(rowText).toContain(PARTNER_CODE);
  });

  test(`TC-02 WL account unique by Email + Partner ID ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-02 Email + Partner ID");
    const members = await membersByEmail(t, WL_MEMBER_EMAIL);
    const rows = await Promise.all(members.map(async (m) => ({ id: m.id, ...(await detailOf(t, m.id)) })));
    const wlRows = rows.filter((r) => r.accountType === WL_ACCOUNT_TYPE);
    const keys = wlRows.map((r) => `${String(r.email).toLowerCase()}|${r.workerAccountPartnerId}`);
    const dup = keys.filter((k, i) => keys.indexOf(k) !== i);
    const noPartner = wlRows.filter((r) => !r.workerAccountPartnerId);
    const ok = !dup.length && !noPartner.length && wlRows.length > 0;
    await card(browser, testInfo, `TC-02 Accounts with e-mail ${WL_MEMBER_EMAIL}`,
      `<table><tr><th>Member id</th><th>accountType</th><th>Partner ID</th><th>Status</th></tr>${rows.map((r) => `<tr><td>${esc(r.id)}</td><td>${esc(r.accountType)}</td><td>${esc(r.workerAccountPartnerId ?? "—")}</td><td>${esc(r.status)}</td></tr>`).join("")}</table>`,
      { ac: `${AC} AC1`, title: "TC-02 Email + Partner ID", steps: [`Admin API search by email → ${rows.length} account(s), ${wlRows.length} White Label`, `Duplicate (email, Partner ID): ${dup.length ? dup.join(", ") : "none"}`], expected: ["Each WL account has a Partner ID", "No two WL accounts share Email + Partner ID"], status: ok ? undefined : "failed" });
    expect(wlRows.length).toBeGreaterThan(0);
    expect(noPartner, "WL accounts without Partner ID").toEqual([]);
    expect(dup, "duplicate Email + Partner ID").toEqual([]);
  });

  test(`TC-03 WL account cannot log in to Eskimo Web ${ID}`, async ({ browser }, testInfo) => {
    test.setTimeout(240_000);
    evidence.setCase("TC-03 Eskimo Web login blocked");
    const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await ctx.newPage();
    const calls: { url: string; status: number; body: any }[] = [];
    page.on("response", async (r) => {
      if (/GenrateOTP-Web|VerifyOTP-Web/i.test(r.url())) calls.push({ url: r.url().replace(/^.*\/api/, "/api"), status: r.status(), body: await r.json().catch(() => null) });
    });
    try {
      await bypassCaptcha(page);
      await test.step("Eskimo Web → Sign up / Log in", async () => {
        for (let i = 0; i < 3; i++) {
          await page.goto(`${ECOM_URL}/en/signup`, { waitUntil: "domcontentloaded", timeout: 90000 });
          if (await page.locator("input.email-input").first().waitFor({ state: "visible", timeout: 60000 }).then(() => true).catch(() => false)) break;
        }
      });
      await test.step(`Continue with Email ${WL_MEMBER_EMAIL} → Send OTP`, async () => {
        await page.locator("input.email-input").first().fill(WL_MEMBER_EMAIL);
        await page.evaluate(() => { const w = window as any; if (typeof w.onloadTurnstileCallback === "function") w.onloadTurnstileCallback(); });
        const genP = page.waitForResponse((r) => /GenrateOTP-Web/i.test(r.url()), { timeout: 90000 }).catch(() => null);
        await page.locator("button.email-send-otp:not([disabled])").click({ timeout: 30000 });
        await genP;
      });
      const otpInputs = page.locator(".otp_input input");
      const otpShown = await otpInputs.first().waitFor({ state: "visible", timeout: 20000 }).then(() => true).catch(() => false);
      if (otpShown) {
        await test.step("Enter OTP (STG bypass code)", async () => {
          const otp = process.env.E2E_ECOM_OTP || "4321";
          await page.waitForTimeout(3000); // STG registers the OTP session asynchronously
          const verP = page.waitForResponse((r) => /VerifyOTP-Web/i.test(r.url()), { timeout: 60000 }).catch(() => null);
          const n = await otpInputs.count();
          if (n >= 4) for (let i = 0; i < 4; i++) await otpInputs.nth(i).fill(otp[i]);
          else await otpInputs.first().fill(otp);
          const submit = page.locator("button.btn__btn_continue");
          if (await submit.isEnabled({ timeout: 2000 }).catch(() => false)) await submit.click().catch(() => {});
          await verP;
        });
        // A sign-up form means the e-mail is treated as a new user: stop there, never register.
        await Promise.race([
          page.waitForURL((u) => !u.pathname.includes("signup"), { timeout: 20000 }),
          page.locator(".personaldetail").waitFor({ state: "visible", timeout: 20000 }),
          page.locator(".error-message, .the-pop-up-social-warning").first().waitFor({ state: "visible", timeout: 20000 }),
        ]).catch(() => {});
      }
      const gen = calls.find((c) => /GenrateOTP/i.test(c.url));
      const ver = calls.find((c) => /VerifyOTP/i.test(c.url));
      const user = ver?.body?.user ?? ver?.body?.data?.user ?? null;
      const userId = String(user?.id ?? user?.Id ?? user?.userId ?? "");
      const token = await page.evaluate(() => localStorage.getItem("accessToken") || "").catch(() => "");
      const signupForm = await page.locator(".personaldetail").isVisible().catch(() => false);
      const errorText = (await page.locator(".error-message, .the-pop-up-social-warning").first().innerText({ timeout: 2000 }).catch(() => "")).replace(/\s+/g, " ").trim();
      const loggedIntoWl = !!token && (!!user && (userId === wl.member.id || String(user?.email ?? user?.Email ?? "").toLowerCase() === WL_MEMBER_EMAIL.toLowerCase()) && !signupForm);
      await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC1`, title: "TC-03 Eskimo Web login with WL e-mail", steps: [`E-mail ${WL_MEMBER_EMAIL} (WL account ${wl.member.id})`, `GenrateOTP-Web → HTTP ${gen?.status ?? "-"} isSignUp=${gen?.body?.isSignUp ?? gen?.body?.data?.isSignUp ?? "-"} msg="${gen?.body?.result?.message ?? ""}"`, `VerifyOTP-Web → HTTP ${ver?.status ?? "(not called)"} user=${userId || "-"} msg="${ver?.body?.result?.message ?? ""}"`, `Sign-up form: ${signupForm} · error shown: "${errorText}" · accessToken: ${token ? "yes" : "no"}`], expected: ["The White Label account is blocked: no session for the WL account"], status: loggedIntoWl ? "failed" : undefined });
      await card(browser, testInfo, "TC-03 Web auth API answers", kv(calls.map((c) => [`${c.url} (${c.status})`, JSON.stringify(c.body)?.slice(0, 600)])), { ac: `${AC} AC1`, title: "TC-03 Web auth API answers", steps: ["Responses of the e-mail OTP login calls"], expected: ["No login into the WL account"], status: loggedIntoWl ? "failed" : undefined });
      expect(gen, "GenrateOTP-Web was called").toBeTruthy();
      expect(loggedIntoWl, "Eskimo Web logged into the White Label account").toBe(false);
    } finally { await ctx.close(); }
  });

  // ─── AC2 ───
  test(`TC-06 Eskimo Sale: WL transaction has Type "White Label Payment" ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-06 Eskimo Sale type");
    const page = admin.page;
    const txId: string = wl.tx.transactionID;
    await test.step("Admin → Transactions › Eskimo Sales", async () => {
      await page.goto(`${ADMIN_URL}/#/transactions-eskimo-sale`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await readTable(page);
    });
    await test.step(`Search ${txId}`, async () => {
      const box = page.getByPlaceholder("Search", { exact: true }).first();
      await box.fill(txId);
      await box.press("Enter");
      await spinnerGone(page);
    });
    const { headers, rows } = await readTable(page);
    const hit = rows.find((r) => r.cells["Transaction ID"] === txId);
    const type = hit?.cells["Type"] ?? "(row not found)";
    if (hit) { await mark(cellOf(hit, headers, "Transaction ID")); await mark(cellOf(hit, headers, "Type")); }
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC2`, title: "TC-06 Eskimo Sale row", steps: [`Search "${txId}"`, `Row: ${hit ? Object.entries(hit.cells).filter(([k]) => k).map(([k, v]) => `${k}=${v}`).join(" · ") : "not found"}`], expected: ["Recorded in Eskimo Sale", `Type = "${WL_TYPE}"`], status: hit && type === WL_TYPE ? undefined : "failed" });
    expect(hit, `Eskimo Sale lists ${txId}`).toBeTruthy();
    expect(type).toBe(WL_TYPE);
  });

  test(`TC-07 Transaction Value = Application Fee ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-07 Value = Application Fee");
    const partner = await readPartner(t, { id: wl.detail.workerAccountOfPartnerId, code: PARTNER_CODE });
    const fee = Number(partner.fee);
    const feeSince = String(partner.stripe?.lastUpdatedDate ?? "");
    // WHI sales of this partner: Eskimo Sale rows → member Data Purchase (metadata.total of the WL order)
    const sales = (await saleSearch(t, "WHI", 4, 40)).filter((s) => s.status === 1 && isWhi(s.transactionId));
    const byMember = new Map<string, any[]>();
    const rows: { tx: string; date: string; value: number; total: number; order: string; ratio: number; expected: number | null; ok: boolean | null }[] = [];
    for (const s of sales) {
      if (!byMember.has(s.memberId)) byMember.set(s.memberId, await purchases(t, s.memberId));
      const p = byMember.get(s.memberId)!.find((x) => x.transactionID === s.transactionId);
      const meta = p?.relatedTransaction?.metadata;
      if (!meta || !String(meta.id).includes(PARTNER_CODE)) continue;
      const total = Number(meta.total);
      const after = !!feeSince && String(s.purchaseDate) >= feeSince;
      const expected = after ? Math.round(total * fee) / 100 : null;
      rows.push({ tx: s.transactionId, date: s.purchaseDate, value: Number(s.value), total, order: meta.id, ratio: Math.round((Number(s.value) / total) * 10000) / 100, expected, ok: after ? Math.abs(Number(s.value) - expected!) <= 0.011 : null });
    }
    const checked = rows.filter((r) => r.ok !== null);
    const bad = rows.filter((r) => r.ok === false);
    // Older rows: fee at purchase time unknown → value must still be a whole-percent share of the total
    // (Stripe fees are whole cents: a small total can give 10.95% for an 11% fee → allow 1 cent.)
    const oddOld = rows.filter((r) => r.ok === null && !Array.from({ length: 100 }, (_, p) => p + 1).some((p) => Math.abs((r.total * p) / 100 - r.value) <= 0.011));
    await card(browser, testInfo, `TC-07 ${PARTNER_CODE} WHI transactions vs Application Fee ${fee}% (since ${feeSince})`,
      `<table><tr><th>Transaction</th><th>Date</th><th>WL order</th><th>Order total</th><th>Value</th><th>Value/total %</th><th>Expected (fee ${fee}%)</th><th>Result</th></tr>${rows.map((r) => `<tr><td>${esc(r.tx)}</td><td>${esc(r.date)}</td><td>${esc(r.order)}</td><td>${r.total}</td><td>${r.value}</td><td>${r.ratio}</td><td>${r.expected ?? "(older than fee change)"}</td><td class="${r.ok === false ? "bad" : r.ok ? "ok" : ""}">${r.ok === null ? "info" : r.ok ? "OK" : "MISMATCH"}</td></tr>`).join("")}</table>`,
      { ac: `${AC} AC2`, title: "TC-07 Value vs Application Fee", steps: [`Application Fee of ${PARTNER_CODE} = ${fee}% (stripeConnect.platformFeePercent, updated ${feeSince})`, `WHI transactions of ${PARTNER_CODE}: ${rows.length} (checked against current fee: ${checked.length})`, `Mismatches: ${bad.length}; older rows with non-whole % share: ${oddOld.length}`], expected: ["Transaction Value = Application Fee received from the connected Stripe account = order total × fee%"], status: bad.length || oddOld.length ? "failed" : undefined });
    expect(rows.length, `WHI transactions of ${PARTNER_CODE} found`).toBeGreaterThan(0);
    expect(bad, "Value ≠ total × current fee").toEqual([]);
    expect(oddOld, "Value is not a fee-percentage of the order total").toEqual([]);
    if (!checked.length) test.info().annotations.push({ type: "note", description: `No WHI transaction of ${PARTNER_CODE} after the last fee change (${feeSince}); only the % share was checked.` });
  });

  test(`TC-08 Payment info kept to trace the Stripe payment ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-08 Stripe traceability");
    const tx = wl.tx;
    let sale: any;
    for (let i = 0; i < 3 && !sale; i++) sale = (await saleSearch(t, tx.transactionID)).find((s) => s.transactionId === tx.transactionID); // stage search sometimes answers empty
    const meta = tx.relatedTransaction?.metadata ?? {};
    const checks: [string, unknown, boolean][] = [
      ["Transaction ID", tx.transactionID, isWhi(tx.transactionID)],
      ["Stripe payment (stripeId)", tx.stripeId, /^(pi|ch|py)_/.test(String(tx.stripeId ?? ""))],
      ["Eskimo Sale stripeId", sale?.stripeId, String(sale?.stripeId ?? "") === String(tx.stripeId ?? "")],
      ["WL order id (relatedTransaction.metadata.id)", meta.id, String(meta.id ?? "").includes(PARTNER_CODE)],
      ["Order total", meta.total, Number(meta.total) > 0],
      ["Currency", meta.curency ?? meta.currency ?? sale?.currency, !!(meta.curency ?? meta.currency ?? sale?.currency)],
      ["Related type / status", `${tx.relatedTransaction?.type} / ${tx.relatedTransaction?.status}`, tx.relatedTransaction?.type === "WhiteLabel"],
      ["Value (application fee)", tx.value, Number(tx.value) > 0],
    ];
    const bad = checks.filter((c) => !c[2]);
    await card(browser, testInfo, `TC-08 ${tx.transactionID} – stored payment data`, kv(checks), { ac: `${AC} AC2`, title: "TC-08 Stored payment data", steps: [`Admin API Data Purchase + Eskimo Sale of ${tx.transactionID}`, `Missing: ${bad.map((b) => b[0]).join(", ") || "none"}`], expected: ["Complete payment information to trace and reconcile the original Stripe payment"], status: bad.length ? "failed" : undefined });
    expect(bad.map((b) => b[0])).toEqual([]);
  });

  test(`TC-09 Existing Eskimo Sale logic unchanged ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-09 Eskimo Sale regression");
    const page = admin.page;
    const checked: { id: string; type: string; ok: boolean }[] = [];
    await page.goto(`${ADMIN_URL}/#/transactions-eskimo-sale`, { waitUntil: "domcontentloaded", timeout: 90000 });
    await page.reload({ waitUntil: "domcontentloaded" });
    for (const q of ["", "WHI"]) {
      await test.step(q ? 'Search "WHI"' : "Page 1 without search", async () => {
        if (q) { const box = page.getByPlaceholder("Search", { exact: true }).first(); await box.fill(q); await box.press("Enter"); await spinnerGone(page); }
      });
      for (const r of (await readTable(page)).rows) {
        const id = r.cells["Transaction ID"] ?? "";
        const type = r.cells["Type"] ?? "";
        checked.push({ id, type, ok: isWhi(id) === (type === WL_TYPE) });
      }
    }
    // Page 1 can be all WHI… (many recent WL orders): add the latest non-WL payments by type from the same search API.
    const legacy: { id: string; type: string; ok: boolean }[] = [];
    for (const [code, label] of [[0, "Personal Account Payment"], [1, "Work Account Payment"]] as const) {
      for (const s of (await saleSearch(t, "", code, 10)).filter((x) => x.transactionId)) {
        legacy.push({ id: s.transactionId, type: `${label} (eskimoTransactionType ${s.eskimoTransactionType})`, ok: !isWhi(s.transactionId) && s.eskimoTransactionType === code });
      }
    }
    checked.push(...legacy);
    const bad = checked.filter((c) => !c.ok);
    const otherTypes = [...new Set(checked.filter((c) => !isWhi(c.id)).map((c) => c.type))];
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC2`, title: "TC-09 Eskimo Sale WHI search", steps: [`Rows checked: ${checked.length}`, `Non-WHI types seen: ${otherTypes.join(", ") || "-"}`, `Mismatches: ${bad.length}`], expected: [`"${WL_TYPE}" only for WHI… rows`, "Other transactions keep their existing Type"], status: bad.length ? "failed" : undefined });
    await card(browser, testInfo, "TC-09 Type vs Transaction ID", `<table><tr><th>Transaction ID</th><th>Type</th><th>Result</th></tr>${checked.map((c) => `<tr><td>${esc(c.id)}</td><td>${esc(c.type)}</td><td class="${c.ok ? "ok" : "bad"}">${c.ok ? "OK" : "MISMATCH"}</td></tr>`).join("")}</table>`, { ac: `${AC} AC2`, title: "TC-09 Type vs Transaction ID table", steps: ["Type column from the Eskimo Sale table"], expected: [`"${WL_TYPE}" ⇔ Transaction ID starts with WHI`], status: bad.length ? "failed" : undefined });
    expect(checked.some((c) => !isWhi(c.id)), "non-WHI rows present").toBe(true);
    expect(bad).toEqual([]);
  });

  // ─── AC3 ───
  test(`TC-10 Membership Search by Email finds the WL account ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-10 Search by Email");
    const page = admin.page;
    const r = await test.step(`Membership → Search by Email "${WL_MEMBER_EMAIL}"`, () => membershipQuery(page, { email: WL_MEMBER_EMAIL }));
    const found = r.list.some((m) => m.id === wl.member.id);
    const uiRow = r.ui.rows.find((x) => /QC WellAtSea|WellAtSea/i.test(Object.values(x.cells).join(" "))) ?? r.ui.rows[0];
    if (uiRow) await mark(uiRow.row);
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC3`, title: "TC-10 Search by Email", steps: [`Search by Email (searchType ${r.req.searchType}) "${WL_MEMBER_EMAIL}"`, `BE rows: ${r.list.length} (${r.list.map((m) => m.email).join(", ")}) · UI rows: ${r.ui.rows.length}`, `WL account ${wl.member.id} in result: ${found}`], expected: ["The White Label account is found by its e-mail"], status: found && r.ui.rows.length > 0 ? undefined : "failed" });
    expect(found, "WL account in search result").toBe(true);
    expect(r.ui.rows.length).toBeGreaterThan(0);
  });

  test(`TC-11 Filter Account Type = White Label Account ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-11 Filter White Label Account");
    const page = admin.page;
    const all = await test.step('Account Type = "White Label Account"', () => membershipQuery(page, { accountType: "White Label Account" }));
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC3`, title: "TC-11 Filter only", steps: [`Request accountType="${all.req.accountType}"`, `BE rows page 1: ${all.list.length}, total ${all.total}`], expected: ["Only White Label accounts"], status: all.list.length ? undefined : "failed" });
    const sample = all.list.slice(0, 15);
    const types = await Promise.all(sample.map(async (m) => ({ email: m.email, id: m.id, accountType: (await detailOf(t, m.id))?.accountType })));
    const notWl = types.filter((x) => x.accountType !== WL_ACCOUNT_TYPE);
    await card(browser, testInfo, "TC-11 Account type of the filtered rows", `<table><tr><th>Member</th><th>E-mail</th><th>accountType</th></tr>${types.map((x) => `<tr><td>${esc(x.id)}</td><td>${esc(x.email)}</td><td class="${x.accountType === WL_ACCOUNT_TYPE ? "ok" : "bad"}">${esc(x.accountType)}</td></tr>`).join("")}</table>`, { ac: `${AC} AC3`, title: "TC-11 Account type of filtered rows", steps: [`Detail API of the first ${sample.length} rows`, `Not White Label: ${notWl.length}`], expected: ["Every row is a White Label account (accountType 2)"], status: notWl.length ? "failed" : undefined });
    const withEmail = await test.step(`+ Search by Email "${WL_MEMBER_EMAIL}"`, () => membershipQuery(page, { accountType: "White Label Account", email: WL_MEMBER_EMAIL }));
    const found = withEmail.list.some((m) => m.id === wl.member.id);
    if (withEmail.ui.rows[0]) await mark(withEmail.ui.rows[0].row);
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC3`, title: "TC-11 Filter + Search by Email", steps: [`accountType="${withEmail.req.accountType}" + email "${WL_MEMBER_EMAIL}"`, `BE rows: ${withEmail.list.length}, UI rows: ${withEmail.ui.rows.length}`, `WL account in result: ${found}`], expected: ["The WL account matching the search + filter is listed"], status: found ? undefined : "failed" });
    expect(all.list.length, "White Label filter returns rows").toBeGreaterThan(0);
    expect(notWl, "rows that are not White Label").toEqual([]);
    expect(found, "WL account with search + filter").toBe(true);
  });

  // QC decision (2026-10-15): Personal / Work Account filters must never list White Label accounts.
  test(`TC-12 Other Account Type filters do not list WL accounts ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-12 Other filters");
    const page = admin.page;
    const results: { type: string; req: string; withEmail: boolean; sample: number; wlInPage: number }[] = [];
    for (const [type, expectedType] of [["Personal Accounts", 0], ["Work Account", 1]] as const) {
      const r = await test.step(`Account Type = "${type}" + Search by Email`, () => membershipQuery(page, { accountType: type, email: WL_MEMBER_EMAIL }));
      const withEmail = r.list.some((m) => m.id === wl.member.id);
      if (withEmail && r.ui.rows[0]) await mark(r.ui.rows[0].row);
      await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC3`, title: `TC-12 ${type} + WL e-mail`, steps: [`accountType="${r.req.accountType}" + email "${WL_MEMBER_EMAIL}"`, `BE rows: ${r.list.length} (${r.list.map((m) => m.id).join(", ") || "none"})`, `WL account ${wl.member.id} listed: ${withEmail}`], expected: ["The White Label account is NOT listed"], status: withEmail ? "failed" : undefined });
      // Page 1 of the filter alone: account type of every row (detail API)
      const all = await test.step(`Account Type = "${type}" (no search)`, () => membershipQuery(page, { accountType: type }));
      const types = await Promise.all(all.list.slice(0, 15).map(async (m) => ({ id: m.id, email: m.email, accountType: (await detailOf(t, m.id))?.accountType })));
      const wlRows = types.filter((x) => x.accountType === WL_ACCOUNT_TYPE);
      await card(browser, testInfo, `TC-12 "${type}" page 1 – account type per row`, `<table><tr><th>Member</th><th>E-mail</th><th>accountType</th></tr>${types.map((x) => `<tr><td>${esc(x.id)}</td><td>${esc(x.email)}</td><td class="${x.accountType === expectedType ? "ok" : "bad"}">${esc(x.accountType)}${x.accountType === WL_ACCOUNT_TYPE ? " (White Label)" : ""}</td></tr>`).join("")}</table>`, { ac: `${AC} AC3`, title: `TC-12 ${type} page 1 types`, steps: [`Request accountType="${all.req.accountType}"`, `First ${types.length} rows → White Label: ${wlRows.length}`], expected: [`Only accountType ${expectedType}; no White Label (2)`], status: wlRows.length ? "failed" : undefined });
      results.push({ type, req: String(r.req.accountType), withEmail, sample: types.length, wlInPage: wlRows.length });
    }
    for (const r of results) {
      expect(r.withEmail, `${r.type} (accountType "${r.req}") lists the WL account ${WL_MEMBER_EMAIL}`).toBe(false);
      expect(r.wlInPage, `${r.type}: White Label rows among the first ${r.sample}`).toBe(0);
    }
  });
});
