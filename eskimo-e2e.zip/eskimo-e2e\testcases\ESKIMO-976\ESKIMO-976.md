# ESKIMO-976 – [White label] Allow Corporation Type Selection During Initial Corporate Program Setup

Nguồn: AC1/AC2 của item ESKIMO-976 (đọc 2026-10-21) + bảng expected của QC.
Môi trường: STAGE – Admin https://app-eskimo-admin-stage-sea-001.azurewebsites.net, API stage.

| Trường hợp | Ô Type |
|---|---|
| Tạo partner mới | Chọn được |
| Sửa partner chưa từng có Corporate | Chọn được |
| Sửa partner đã lưu Corporate (Corporate, White label hay Reseller) | Khóa |

Dữ liệu: tạo 1 partner test mới "QC976 NoCorp <timestamp>" (QC đồng ý). Không sửa partner có sẵn (TC-05..07 chỉ xem).

## TC-01 New Partner: Type chọn được
- Steps: Partnership › Partners → New Partner → bật Corporate Program → mở dropdown Type. Không lưu.
- Expected: Type không bị khóa; chọn được Corporate / White label / Reseller.

## TC-02 (precondition) Tạo partner chưa có Corporate
- Steps: New Partner → Partner Name, Partner Email → Corporate Program tắt → Ok.
- Expected: tạo thành công; API hasCorporate=false, chưa có corporateStartDate.

## TC-08 (AC1) Sửa partner chưa từng lưu Corporate: bật → tắt → bật (chưa lưu), Type chọn được
- Expected QC (21/10): Corporate chưa từng được LƯU thì dù bật/tắt bao nhiêu lần, chưa bấm Ok, Type vẫn không khóa.
- Steps: Edit partner TC-02 → Corporate Status ON → OFF (Confirm) → ON → mở Type. Không lưu (chạy trước TC-03).
- Expected: Type không bị khóa; chọn được White label.

## TC-09 New Partner: bật → tắt → bật (chưa lưu), Type chọn được
- Steps: New Partner → Corporate Status ON → OFF (Confirm) → ON → mở Type. Không lưu.
- Expected: Type không bị khóa; chọn được White label.

## TC-03 (AC1) Sửa partner chưa từng có Corporate: Type chọn được, lưu White label
- Steps: Edit partner TC-02 → bật Corporate Program → Type → chọn White label → Start Date hôm nay → Ok.
- Expected: Type không bị khóa; lưu thành công; API hasCorporate=true, corporateType=1.

## TC-04 (AC2) Mở lại partner vừa lưu White label: Type khóa
- Steps: Edit lại partner TC-03 → Corporate Program.
- Expected: Type = White label, bị khóa.

## TC-05 (AC2) Partner đã lưu Corporate: Type khóa
- Steps: Edit partnerofduc (PN139647, corporateType 0) → Corporate Program. Chỉ xem.
- Expected: Type = Corporate, bị khóa.

## TC-06 (AC2) Partner đã lưu White label: Type khóa
- Steps: Edit white label test Dev (PN105327, corporateType 1). Chỉ xem.
- Expected: Type = White label, bị khóa.

## TC-07 (AC2) Partner đã lưu Reseller: Type khóa
- Steps: tìm qua API 1 partner isCorporate, corporateType 2 → Edit → Corporate Program. Chỉ xem.
- Expected: Type = Reseller, bị khóa. (Không có partner Reseller trên stage → blocked.)
