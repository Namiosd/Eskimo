// Shared Eskimo helpers (admin + partner portals, STG). Locators are the antd/CoreUI classes the
// portal actually renders (few roles/test ids exist); ported from eskimo_portal/e2e helpers.
import { expect, type Browser, type Locator, type Page } from "@playwright/test";

export const ADMIN_URL = (process.env.E2E_ADMIN_URL || process.env.E2E_BASE_URL || "").replace(/\/$/, "");
export const PARTNER_URL = (process.env.E2E_PARTNER_URL || "").replace(/\/$/, "");

const escapeRegex = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
export const money = (text: string | null | undefined): number | null => {
  const m = String(text ?? "").replace(/,/g, "").match(/-?\d+(?:\.\d+)?/g);
  return m ? Number(m[m.length - 1]) : null;
};
const spinnerGone = (page: Page, timeout = 20000) =>
  page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout }).catch(() => {});
const overlayGone = (page: Page, timeout = 90000) =>
  page.locator("[data-testid='overlay']").first().waitFor({ state: "hidden", timeout }).catch(() => {});

// ─── Login (STG: e-mail + OTP; the *_PASSWORD env var holds the OTP) ──────────────────────────
export async function login(page: Page, url: string, email: string | undefined, otp: string | undefined) {
  if (!email) throw new Error(`Missing e-mail env var for ${url}`);
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
  await page.locator("input[placeholder='Enter your email']").fill(email);
  await page.locator("span.btn-send-code").click();
  await page.locator("[data-testid='overlay']").waitFor({ state: "hidden", timeout: 15000 }).catch(() => {});
  // The code box can re-render (and clear) right after "Send code": refill until Login is enabled.
  const code = page.locator("input[placeholder='Enter code']");
  for (let i = 0; i < 3; i++) {
    await code.fill(otp || "1234");
    if (await expect(page.locator(".login-button")).toBeEnabled({ timeout: 5000 }).then(() => true).catch(() => false)) break;
  }
  await expect(page.locator(".login-button")).toBeEnabled({ timeout: 10000 });
  await page.locator(".login-button").click();
  await page.waitForURL((u) => !u.hash.includes("/login"), { timeout: 30000 });
}

export async function adminSession(browser: Browser) {
  const ctx = await browser.newContext({ baseURL: ADMIN_URL });
  const page = await ctx.newPage();
  await login(page, `${ADMIN_URL}/#/login`, process.env.E2E_ADMIN_EMAIL, process.env.E2E_ADMIN_PASSWORD);
  return { ctx, page };
}

export async function partnerSession(browser: Browser, email = process.env.E2E_PARTNER_EMAIL, otp = process.env.E2E_PARTNER_PASSWORD) {
  if (!PARTNER_URL) throw new Error("Set E2E_PARTNER_URL");
  const ctx = await browser.newContext({ baseURL: PARTNER_URL });
  const page = await ctx.newPage();
  await page.addInitScript(() => { window.confirm = () => false; });
  await login(page, `${PARTNER_URL}/#/login-partner`, email, otp);
  await dismissReminder(page);
  const name = await page.evaluate(() => localStorage.getItem("partnerName"));
  expect(name, "partnerName missing in localStorage after partner login").toBeTruthy();
  return { ctx, page, partnerName: String(name).trim() };
}

// Partner portal "Reminder! … payment method" modal (CoreUI) can cover the page: press Cancel.
export async function dismissReminder(page: Page) {
  const reminder = page.locator(".modal-dialog:visible, .modal.show").filter({ hasText: "Reminder" }).first();
  if (await reminder.waitFor({ state: "visible", timeout: 3000 }).then(() => true).catch(() => false)) {
    await reminder.locator("button.btn-secondary, button:has-text('Cancel')").first().click().catch(() => {});
    await reminder.waitFor({ state: "hidden", timeout: 5000 }).catch(() => {});
  }
}

// ─── Admin: partner drawer, Merchant Program rows ─────────────────────────────────────────────
export type MerchantPlan = { id?: string; dataPlanName?: string; discountType?: number; fixedDiscount?: number; discountPercent?: number };

export async function openPartnerDrawer(page: Page, partnerName: string) {
  // Same-hash goto does not remount the SPA (an old drawer/mask can stay): reload instead.
  if (page.url().includes("#/partnership-partners")) await page.reload({ waitUntil: "domcontentloaded" });
  else await page.goto(`${ADMIN_URL}/#/partnership-partners`, { waitUntil: "domcontentloaded" });
  await page.locator(".ant-table").first().waitFor({ state: "visible", timeout: 30000 });
  await spinnerGone(page);
  const search = page.locator("input[placeholder*='Search'], input[placeholder*='search']").first();
  await search.fill(partnerName);
  await search.press("Enter");
  await spinnerGone(page, 15000);
  const row = page.locator(".ant-table-tbody tr.ant-table-row").first();
  await row.waitFor({ state: "visible", timeout: 30000 });
  const detailP = page.waitForResponse((r) => /\/api\/partner\/v\d+\//.test(r.url()) && r.request().method() === "GET", { timeout: 90000 });
  const listP = page.waitForResponse((r) => r.url().includes("/api/data-plan/get-portal-dropdown-list"), { timeout: 90000 }).catch(() => null);
  await row.locator("button.btn-edit").first().click();
  const detail = (await (await detailP).json())?.data;
  await listP;
  // antd keeps closed drawers in the DOM: take the one on screen.
  const drawer = page.locator(".ant-drawer-content:visible").first();
  await drawer.waitFor({ state: "visible", timeout: 15000 });
  await spinnerGone(page);
  return { drawer, detail };
}

const merchantHeader = (drawer: Locator) =>
  drawer.locator(".header-member-view-detail").filter({
    has: drawer.page().locator(`.custom-title-membership-detail:text-is("Merchant Program")`),
  }).first();
const merchantBody = (drawer: Locator) => merchantHeader(drawer).locator("xpath=following-sibling::div[2]");
export const merchantRows = (drawer: Locator) => merchantBody(drawer).locator(".list-data-merchant .merchant-item");
// Short timeouts: a row whose select has no value shows only a placeholder (no selection item).
const rowLabel = async (row: Locator) =>
  (await row.locator(".ant-select").first().locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();
export const rowValueInput = (row: Locator) => row.locator("input[placeholder='insert number']").first();

export async function findMerchantRow(drawer: Locator, label: string): Promise<Locator | null> {
  const rows = merchantRows(drawer);
  // Saved rows show raw ids until the option list resolves: poll until the label appears.
  for (let i = 0; i < 20; i++) {
    const n = await rows.count();
    const labels: string[] = [];
    for (let k = 0; k < n; k++) labels.push(await rowLabel(rows.nth(k)));
    const idx = labels.indexOf(label);
    if (idx >= 0) return rows.nth(idx);
    if (!labels.some((l) => /^(null\/|[0-9a-f]{8}-)|\|/i.test(l))) return null;
    await drawer.page().waitForLoadState("networkidle").catch(() => {});
  }
  return null;
}

async function pickOption(page: Page, select: Locator, text: string) {
  // The merchant row re-renders continuously while discount warnings recompute, so the select is
  // never "stable": click its selector directly with force, and retry until the dropdown opens.
  const dropdown = page.locator(".ant-select-dropdown:visible").last();
  for (let i = 0; i < 3; i++) {
    await select.locator(".ant-select-selector").first().click({ force: true, timeout: 10000 });
    if (await dropdown.waitFor({ state: "visible", timeout: 5000 }).then(() => true).catch(() => false)) break;
  }
  await dropdown.waitFor({ state: "visible", timeout: 5000 });
  const input = select.locator("input").first();
  if (await input.isEditable().catch(() => false)) await input.fill(text);
  const option = dropdown.locator(".ant-select-item-option").filter({ hasText: new RegExp(`^\\s*${escapeRegex(text)}\\s*$`) }).first();
  // antd virtual list renders ~8 options: scroll until the exact one is rendered.
  const holder = dropdown.locator(".rc-virtual-list-holder").first();
  for (let i = 0; i < 40 && !(await option.isVisible().catch(() => false)); i++) {
    const moved = await holder.evaluate((el) => { const b = el.scrollTop; el.scrollTop = b + el.clientHeight * 0.8; return el.scrollTop !== b; }).catch(() => false);
    if (!moved) break;
  }
  await option.click({ force: true, timeout: 10000 });
  await dropdown.waitFor({ state: "hidden", timeout: 5000 }).catch(() => {});
}

export const readDiscountType = async (row: Locator) =>
  (await row.locator(".ant-select").nth(1).locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();

// Rows re-sort by priority when Apply to / Discount change, so every step re-finds the row by its
// Apply-to label instead of keeping a positional locator.
const rowByLabel = async (drawer: Locator, label: string) => {
  const row = await findMerchantRow(drawer, label);
  if (!row) throw new Error(`Merchant rule "${label}" not found in the drawer`);
  await row.scrollIntoViewIfNeeded();
  return row;
};

// typeLabel: "Fixed Discount ($US)" | "Percentage (%)" | "No Discount"
export async function setDiscount(drawer: Locator, label: string, typeLabel: string, value: number | string) {
  const page = drawer.page();
  let row = await rowByLabel(drawer, label);
  console.log(`[STEP] "${label}": discount type now "${await readDiscountType(row)}" → "${typeLabel}"`);
  if ((await readDiscountType(row)) !== typeLabel) {
    await pickOption(page, row.locator(".ant-select").nth(1), typeLabel);
    row = await rowByLabel(drawer, label);
  }
  await expect.poll(async () => readDiscountType(await rowByLabel(drawer, label))).toBe(typeLabel);
  if (typeLabel === "No Discount") return;
  const input = rowValueInput(await rowByLabel(drawer, label));
  await input.fill(String(value));
  await input.press("Tab");
  await expect.poll(async () => rowValueInput(await rowByLabel(drawer, label)).inputValue()).toBe(String(value));
}

export async function addMerchantRow(drawer: Locator, label: string) {
  const page = drawer.page();
  const add = merchantHeader(drawer).locator(".custom-button-add-gift-code", { hasText: "New Discount Benefit" });
  await add.scrollIntoViewIfNeeded();
  const before = await merchantRows(drawer).count();
  await add.click();
  await expect(merchantRows(drawer)).toHaveCount(before + 1);
  const row = merchantRows(drawer).last();
  await row.scrollIntoViewIfNeeded();
  await pickOption(page, row.locator(".ant-select").first(), label);
  await rowByLabel(drawer, label);
}

export async function deleteMerchantRow(row: Locator) {
  await row.locator(".merchant-item-delete button").first().click();
}

// Click Save and report what the BE did (the FE only warns; the BE decides whether it saves).
export async function savePartnerDrawer(drawer: Locator) {
  const page = drawer.page();
  const putP = page.waitForResponse((r) => /\/api\/partner\/v\d+/.test(r.url()) && r.request().method() === "PUT", { timeout: 180000 }).catch(() => null);
  // The app's global loading overlay covers the drawer while plan lists/warnings recompute.
  await overlayGone(page);
  await drawer.locator("button.btn-action-ok").first().click();
  const res = await putP;
  const raw = res ? await res.text().catch(() => "") : "";
  let body: any = null;
  try { body = raw ? JSON.parse(raw) : null; } catch { body = null; }
  const closed = await drawer.waitFor({ state: "hidden", timeout: 30000 }).then(() => true).catch(() => false);
  // 400s may carry { errors: {...} } (ASP.NET validation) or plain text: keep whatever the BE said.
  const fromBody = body?.message || (body?.errors ? JSON.stringify(body.errors) : "") || (body ? "" : raw);
  const message = fromBody || (await page.locator(".ant-notification-notice, .ant-message-notice, .ant-modal-body").first().innerText({ timeout: 2000 }).catch(() => ""));
  return { status: res?.status() ?? null, ok: !!res && res.ok() && body?.success !== false, closed, message: String(message ?? "").slice(0, 500) };
}

export const merchantPlansOf = (detail: any): MerchantPlan[] => detail?.configuration?.merchantSetting?.plans ?? [];

// ─── Partner: Vouchers / Purchase Voucher ─────────────────────────────────────────────────────
export async function openVouchers(page: Page) {
  await page.goto(`${PARTNER_URL}/#/merchant-vouchers`, { waitUntil: "domcontentloaded" });
  await dismissReminder(page);
  const btn = page.getByRole("button", { name: /Purchase Voucher/i }).first();
  await btn.waitFor({ state: "visible", timeout: 30000 });
  await spinnerGone(page);
  return btn;
}

export async function readRemainingCredits(page: Page): Promise<number | null> {
  const el = page.locator(".header-voucher").filter({ hasText: /Remaining/i }).first();
  if (!(await el.waitFor({ state: "visible", timeout: 15000 }).then(() => true).catch(() => false))) return null;
  return money(await el.innerText());
}

export type PurchasePlan = { id?: string; dataPlanName: string; price: number; discountPrice: number };

// Open Purchase Voucher and return the drawer plus the plan list the BE priced for this partner.
export async function openPurchaseVoucher(page: Page) {
  const btn = await openVouchers(page);
  await expect(btn, "Purchase Voucher disabled: is the partner's Merchant Program on?").toBeEnabled();
  const plansP = page.waitForResponse((r) => r.url().includes("/api/voucher/data-purchase") && r.request().method() === "GET", { timeout: 60000 });
  await btn.click();
  const drawer = page.locator(".partner-unique-gift-code").first();
  await drawer.waitFor({ state: "visible", timeout: 15000 });
  const plans: PurchasePlan[] = ((await (await plansP).json())?.data ?? []).map((p: any) => ({
    ...p, price: Number(p.price), discountPrice: Number(p.discountPrice),
  }));
  await spinnerGone(page);
  return { drawer, plans };
}

export async function selectVoucherPlan(drawer: Locator, planName: string) {
  await pickOption(drawer.page(), drawer.locator(".purchase-voucher-item .ant-select").first(), planName);
  const field = drawer.locator(".ant-form-item").filter({ hasText: "Discount Price" }).first();
  await expect(field).toContainText(/\d/);
  return money(await field.innerText());
}
