// ESKIMO-976 – Admin › Partner › Corporate Program: Type is selectable until the first Corporate Program is saved,
// locked afterwards. Test cases: testcases/ESKIMO-976/ESKIMO-976.md
//   TC-01 New Partner → Type selectable (not saved)
//   TC-02 precondition: create "QC976 NoCorp <ts>" without Corporate
//   TC-03 AC1: edit it → Type selectable → save White label
//   TC-04 AC2: reopen it → Type locked
//   TC-08 / TC-09 AC1: Corporate ON → OFF → ON without saving (existing never-saved partner / New Partner) → Type still selectable
//   TC-05/06/07 AC2: saved Corporate / White label / Reseller partner → Type locked (read-only)
// Writes on stage: only the new QC976 partner. Evidence: npm run report:evidence -- ESKIMO-976 corporate-type-first-setup
import { test, expect, type Browser, type BrowserContext, type Locator, type Page, type TestInfo } from "@playwright/test";
import { ADMIN_URL } from "../_support/eskimo";
import { adminSessionRetry, api, tokenOf, findPartner, openCorporate, corporate, formItem, isOn, focus, clickOk, stateFile } from "../_support/whitelabel";
import { createEvidence, esc, type EvidenceMeta } from "../_support/evidence";

const ID = "@ESKIMO-976";
const evidence = createEvidence("ESKIMO-976", "corporate-type-first-setup");
const state = stateFile("test-results/ESKIMO-976-state.json");
const TYPES = ["Corporate (applied to all existing corporate partner)", "White label", "Reseller"];

const mark = (l: Locator) => l.evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322" })).catch(() => {});

/** API data as a card on a scratch page (the app page stays untouched). */
async function card(ctx: BrowserContext, testInfo: TestInfo, data: unknown, meta: EvidenceMeta) {
  const scratch = await ctx.newPage();
  await evidence.saveDataCard(scratch, testInfo, meta.title, `<pre>${esc(JSON.stringify(data, null, 2))}</pre>`, meta);
  await scratch.close();
}

async function readType(page: Page, body: Locator) {
  const item = formItem(body, "Type");
  await item.waitFor({ state: "visible", timeout: 15000 });
  const locked = (await item.locator(".ant-select-disabled").count()) > 0;
  const value = (await item.locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();
  let options: string[] = [];
  if (!locked) {
    await item.locator(".ant-select-selector").first().click();
    const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
    await dd.waitFor({ state: "visible", timeout: 8000 });
    options = (await dd.locator(".ant-select-item-option:not(.ant-select-item-option-disabled) .ant-select-item-option-content").allInnerTexts()).map((t) => t.trim());
  }
  await mark(item);
  return { item, locked, value, options };
}

/** Open Corporate Program of an existing partner and check its Type is locked (read-only, nothing saved). */
async function lockedCase(browser: Browser, testInfo: TestInfo, tc: string, label: string, partner: { code: string; name: string }, want: RegExp) {
  evidence.setCase(`${tc} ${label}`);
  const { ctx, page } = await adminSessionRetry(browser);
  try {
    await page.setViewportSize({ width: 1600, height: 1000 });
    const { body, header } = await openCorporate(page, partner.code);
    await focus(header);
    const t = await readType(page, body);
    const ok = t.locked && want.test(t.value);
    await evidence.saveScreenshot(page, testInfo, {
      ac: "AC2", title: `${partner.code} ${partner.name}: Type = "${t.value}", locked=${t.locked}`,
      steps: ["Admin STAGE → Partnership › Partners", `Search ${partner.code} → Edit`, "Corporate Program → Type (read only, nothing saved)"],
      expected: [`Type = ${label}`, "Type is locked (cannot be changed)"],
      status: ok ? undefined : "failed",
    });
    expect(t.value, "saved Type").toMatch(want);
    expect(t.locked, "Type locked after Corporate Program saved").toBe(true);
  } finally { await ctx.close(); }
}

/** Corporate Status OFF → (confirm the warning) → ON again, without saving. */
async function toggleOffOn(page: Page, statusSwitch: Locator) {
  if (!(await isOn(statusSwitch))) await statusSwitch.click();
  await statusSwitch.click();
  const confirm = page.locator(".modal-dialog:visible").getByRole("button", { name: "Confirm" });
  if (await confirm.isVisible({ timeout: 3000 }).catch(() => false)) await confirm.click();
  await expect.poll(() => isOn(statusSwitch), { timeout: 5000 }).toBe(false);
  await statusSwitch.click();
  await expect.poll(() => isOn(statusSwitch), { timeout: 5000 }).toBe(true);
}

/** Never-saved Corporate: after ON → OFF → ON (not saved) the Type must still be selectable. */
async function toggleCase(page: Page, testInfo: TestInfo, drawer: Locator, who: string) {
  const c = corporate(drawer);
  await focus(c.header);
  await toggleOffOn(page, c.statusSwitch);
  const t = await readType(page, c.body);
  const ok = !t.locked && t.options.includes("White label");
  await evidence.saveScreenshot(page, testInfo, {
    ac: "AC1", title: `${who}: Corporate ON → OFF → ON (not saved): Type locked=${t.locked}, options: ${t.options.join(" / ")}`,
    steps: [who, "Corporate Program Status ON → OFF (Confirm) → ON, no Ok", "Open Type dropdown"],
    expected: ["Corporate never saved → Type not locked, White label selectable"],
    status: ok ? undefined : "failed",
  });
  await page.keyboard.press("Escape");
  expect(t.locked, "Type locked after toggling Corporate without saving").toBe(false);
  expect(t.options, "Type options").toContain("White label");
}

async function openNewPartner(page: Page) {
  await page.setViewportSize({ width: 1600, height: 1000 });
  await page.goto(`${ADMIN_URL}/#/partnership-partners`);
  await page.locator(".ant-table").first().waitFor({ timeout: 60000 });
  await page.getByRole("button", { name: "New Partner" }).click();
  const drawer = page.locator(".ant-drawer-content:visible").first();
  await drawer.waitFor({ timeout: 30000 });
  return drawer;
}

test.describe(`ESKIMO-976 Corporate Type selectable until first setup ${ID}`, () => {
  test.describe.configure({ timeout: 300_000 });

  test(`TC-01 New Partner: Type selectable ${ID}`, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 New Partner");
    const { ctx, page } = await adminSessionRetry(browser);
    try {
      const drawer = await openNewPartner(page);
      const c = corporate(drawer);
      await focus(c.header);
      await c.statusSwitch.click();
      const t = await readType(page, c.body);
      const ok = !t.locked && TYPES.every((x) => t.options.includes(x));
      await evidence.saveScreenshot(page, testInfo, {
        ac: "Create partner", title: `New Partner: Type locked=${t.locked}, options: ${t.options.join(" / ")}`,
        steps: ["Partnership › Partners → New Partner", "Corporate Program → Status ON", "Open Type dropdown (not saved)"],
        expected: ["Type not locked", `Selectable: ${TYPES.join(" / ")}`],
        status: ok ? undefined : "failed",
      });
      await page.keyboard.press("Escape");
      expect(t.locked, "Type locked on New Partner").toBe(false);
      for (const x of TYPES) expect(t.options, "Type options").toContain(x);
    } finally { await ctx.close(); }
  });

  test(`TC-09 New Partner: Corporate ON → OFF → ON (not saved), Type selectable ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-09 New Partner toggle");
    const { ctx, page } = await adminSessionRetry(browser);
    try {
      await toggleCase(page, testInfo, await openNewPartner(page), "New Partner");
    } finally { await ctx.close(); }
  });

  // Serial: TC-08/03/04 use the partner created by TC-02.
  test.describe.serial("new partner without Corporate", () => {
    test(`TC-02 precondition: create partner without Corporate ${ID}`, async ({ browser }, testInfo) => {
      evidence.setCase("TC-02 Create partner (no Corporate)");
      const ts = Date.now();
      const name = `QC976 NoCorp ${ts}`;
      const email = `qc976.${ts}@yopmail.com`;
      const { ctx, page } = await adminSessionRetry(browser);
      try {
        const drawer = await openNewPartner(page);
        await drawer.getByRole("textbox", { name: "Partner Name" }).fill(name);
        await drawer.getByRole("textbox", { name: "Partner Email" }).fill(email);
        const corpOn = await isOn(corporate(drawer).statusSwitch);
        await evidence.saveScreenshot(page, testInfo, {
          ac: "Precondition", title: `New Partner "${name}" (Corporate Program ${corpOn ? "ON" : "OFF"}) before Ok`,
          steps: ["New Partner", `Partner Name = ${name}`, `Partner Email = ${email}`, "Corporate Program left OFF → Ok"],
          expected: ["Partner created without Corporate Program"],
        });
        const res = await clickOk(page, drawer);
        await drawer.waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
        const token = await tokenOf(page);
        let p: Awaited<ReturnType<typeof findPartner>> = null;
        for (let i = 0; i < 10 && !p; i++) { p = await findPartner(token, name); if (!p) await page.waitForTimeout(2000); }
        const d = p ? await api(token, "GET", `/api/partner/v2/${p.id}`) : null;
        const cfg = d?.json?.data?.configuration ?? {};
        state.save({ ...p });
        const ok = !!p && !cfg.hasCorporate && !cfg.corporateSetting?.corporateStartDate;
        await card(ctx, testInfo, { partner: p, saveStatus: res.status, saveMessage: res.message, hasCorporate: cfg.hasCorporate, corporateType: cfg.corporateSetting?.corporateType ?? null, corporateStartDate: cfg.corporateSetting?.corporateStartDate ?? null }, {
          ac: "Precondition", title: `Created ${p?.code ?? "?"} "${name}"`,
          steps: [`Ok → ${res.status} ${res.message}`, `GET /api/partner/v2/${p?.id ?? "?"}`],
          expected: ["hasCorporate = false", "corporateStartDate = null"],
          status: ok ? undefined : "failed",
        });
        expect(p, "partner created").toBeTruthy();
        expect(!!cfg.hasCorporate, "hasCorporate").toBe(false);
        expect(cfg.corporateSetting?.corporateStartDate ?? null, "corporateStartDate").toBeNull();
      } finally { await ctx.close(); }
    });

    // Before TC-03 saves: the partner's Corporate is still never saved. Closing the context discards the form.
    test(`TC-08 AC1 edit partner without Corporate: ON → OFF → ON (not saved), Type selectable ${ID}`, async ({ browser }, testInfo) => {
      evidence.setCase("TC-08 AC1 toggle not saved");
      const p = state.load<any>();
      const { ctx, page } = await adminSessionRetry(browser);
      try {
        await page.setViewportSize({ width: 1600, height: 1000 });
        const { drawer } = await openCorporate(page, p.code);
        await toggleCase(page, testInfo, drawer, `Edit ${p.code} ${p.name} (Corporate never saved)`);
      } finally { await ctx.close(); }
    });

    test(`TC-03 AC1 edit partner without Corporate: Type selectable, save White label ${ID}`, async ({ browser }, testInfo) => {
      evidence.setCase("TC-03 AC1 first Corporate setup");
      const p = state.load<any>();
      const { ctx, page } = await adminSessionRetry(browser);
      try {
        await page.setViewportSize({ width: 1600, height: 1000 });
        const { drawer, body, header, statusSwitch } = await openCorporate(page, p.code);
        await focus(header);
        if (!(await isOn(statusSwitch))) await statusSwitch.click();
        const t = await readType(page, body);
        const selectable = !t.locked && t.options.includes("White label");
        await evidence.saveScreenshot(page, testInfo, {
          ac: "AC1", title: `${p.code} (no Corporate yet) → Status ON: Type locked=${t.locked}, options: ${t.options.join(" / ")}`,
          steps: [`Edit ${p.code} ${p.name}`, "Corporate Program → Status ON", "Open Type dropdown"],
          expected: ["Type not locked", "White label / Corporate selectable"],
          status: selectable ? undefined : "failed",
        });
        expect(t.locked, "Type locked when editing a partner without Corporate").toBe(false);
        expect(t.options, "Type options").toContain("White label");
        await page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last()
          .locator(".ant-select-item-option").filter({ hasText: /^\s*White label\s*$/ }).first().click();
        const now = new Date();
        const dd = `${String(now.getDate()).padStart(2, "0")}/${String(now.getMonth() + 1).padStart(2, "0")}/${now.getFullYear()}`;
        const start = body.locator("input#corporateStartDate");
        if (!(await start.inputValue())) {
          await start.click();
          await start.fill(dd);
          await start.press("Enter");
        }
        // End Date is required too: one year from today
        const end = body.locator("input#corporateEndDate");
        const ddEnd = `${String(now.getDate()).padStart(2, "0")}/${String(now.getMonth() + 1).padStart(2, "0")}/${now.getFullYear() + 1}`;
        if (!(await end.inputValue())) {
          await end.click();
          await end.fill(ddEnd);
          await end.press("Enter");
        }
        // Fee left empty = default fee (the partner has not started Stripe onboarding, an explicit fee is refused)
        await body.locator("input#defaultPercentCorporate").fill("").catch(() => {});
        await focus(header);
        const chosen = (await formItem(body, "Type").locator(".ant-select-selection-item").first().innerText()).trim();
        await evidence.saveScreenshot(page, testInfo, {
          ac: "AC1", title: `Type = "${chosen}", Start Date = ${await start.inputValue()} → Ok`,
          steps: ["Type → White label", `Start Date = ${dd}`, `End Date = ${ddEnd}`, "Application Fee empty (default)", "Ok"],
          expected: ["White label can be chosen on the first Corporate Program setup"],
        });
        const res = await clickOk(page, drawer);
        const token = await tokenOf(page);
        const d = await api(token, "GET", `/api/partner/v2/${p.id}`);
        const cfg = d.json?.data?.configuration ?? {};
        const ok = res.status === 200 && cfg.hasCorporate === true && cfg.corporateSetting?.corporateType === 1;
        await card(ctx, testInfo, {
          sentCorporateType: res.reqBody?.configuration?.corporateSetting?.corporateType ?? res.reqBody?.corporateSetting?.corporateType ?? null,
          savePut: `${res.status} ${res.message}`, feePut: res.fee ? `${res.fee.status} ${res.fee.message}` : "not sent", toasts: res.toasts,
          hasCorporate: cfg.hasCorporate, corporateType: cfg.corporateSetting?.corporateType, corporateStartDate: cfg.corporateSetting?.corporateStartDate,
        }, {
          ac: "AC1", title: `Saved: PUT ${res.status}; API hasCorporate=${cfg.hasCorporate}, corporateType=${cfg.corporateSetting?.corporateType}`,
          steps: ["Ok → PUT /api/partner/v2", `GET /api/partner/v2/${p.id}`],
          expected: ["Save succeeds", "hasCorporate = true", "corporateType = 1 (White label)"],
          status: ok ? undefined : "failed",
        });
        expect(res.status, `save: ${res.message}`).toBe(200);
        expect(cfg.hasCorporate, "hasCorporate").toBe(true);
        expect(cfg.corporateSetting?.corporateType, "corporateType").toBe(1);
      } finally { await ctx.close(); }
    });

    test(`TC-04 AC2 reopen the partner just saved: Type locked ${ID}`, async ({ browser }, testInfo) => {
      await lockedCase(browser, testInfo, "TC-04", "White label (just saved)", state.load<any>(), /^White label$/i);
    });
  });

  test(`TC-05 AC2 saved Corporate partner: Type locked ${ID}`, async ({ browser }, testInfo) => {
    await lockedCase(browser, testInfo, "TC-05", "Corporate", { code: "PN139647", name: "partnerofduc" }, /^Corporate/i);
  });

  test(`TC-06 AC2 saved White label partner: Type locked ${ID}`, async ({ browser }, testInfo) => {
    await lockedCase(browser, testInfo, "TC-06", "White label", { code: "PN105327", name: "white label test Dev" }, /^White label$/i);
  });

  test(`TC-07 AC2 saved Reseller partner: Type locked ${ID}`, async ({ browser }, testInfo) => {
    // find one saved Reseller (corporateType 2) through the search API
    const { ctx, page } = await adminSessionRetry(browser);
    let hit: any = null;
    try {
      const token = await tokenOf(page);
      for (let pi = 1; pi <= 10 && !hit; pi++) {
        const r = await api(token, "POST", "/api/partner/search", { pageIndex: pi, pageSize: 50, searchText: "", status: null, partnerType: null, type: null, sortBy: { fieldName: "CreatedOn", ascending: false } });
        const rows: any[] = r.json?.data?.data ?? [];
        if (!rows.length) break;
        hit = rows.find((x) => x.isCorporate && Number(x.corporateType) === 2) ?? null;
      }
    } finally { await ctx.close(); }
    test.skip(!hit, "BLOCKED: no saved Reseller partner (corporateType 2) on stage");
    await lockedCase(browser, testInfo, "TC-07", "Reseller", { code: hit.partnerID ?? hit.partnerId, name: hit.partnerName }, /^Reseller$/i);
  });
});
