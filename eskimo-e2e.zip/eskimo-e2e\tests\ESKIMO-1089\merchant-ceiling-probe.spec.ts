// ESKIMO-1089 follow-up: does the Merchant Program have the same save-validation gap as White Label / Corporate?
// Group rule (Any Fixed 1GB) vs specific plan (Vietnam 1GB, $3.90) around the "final bill < $1" limit.
// Partner: a merchant-only auto partner (no Corporate, no White Label) so nothing else in the body is validated.
//   M-01 snapshot (file) + no-change UI save → FE save body
//   M-02 UI: add the rule at 99% → FE warning + what Ok does (Vietnam 1GB, then Any Fixed 1GB)
//   M-03 API: one rule per PUT, GET after every PUT (a timed-out PUT may still have saved), 5xx retried
// afterAll restores the snapshot rules (id ""), falls back to original ids, verifies via GET.
// Run: npx playwright test tests/ESKIMO-1089/merchant-ceiling-probe.spec.ts --output test-results/ESKIMO-1089
import fs from "node:fs";
import { test, expect, type Browser, type Page, type TestInfo } from "@playwright/test";
import { createEvidence, esc } from "../_support/evidence";
import { openPartnerDrawer, savePartnerDrawer, merchantPlansOf, addMerchantRow, setDiscount, merchantRows } from "../_support/eskimo";
import { api, apiMessage, tokenOf, findPartner, adminSessionRetry as adminSess } from "../_support/whitelabel";

const evidence = createEvidence("ESKIMO-1089", "merchant-ceiling-probe");
const AC = "Merchant Program: save validation of group rule vs specific plan";
const NAME = process.env.E2E_1089_PARTNER || "Auto Partner 1779880338446";
const VN_1GB_ID = "733e74e8-076d-4c8a-0f21-08dbd475e39d";
const SNAP_FILE = "evidence/ESKIMO-1089-merchant-snapshot.json";
const PCT = "Percentage (%)";

type Snap = { p: { id: string; code: string; name: string }; plans: any[]; merchant: any; feBody?: any };
let snap: Snap | undefined;

const table = (head: string[], rows: unknown[][]) =>
  "<table><tr>" + head.map((h) => "<th>" + esc(h) + "</th>").join("") + "</tr>" + rows.map((r) => "<tr>" + r.map((c) => "<td>" + esc(c) + "</td>").join("") + "</tr>").join("") + "</table>";
async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const label = (p: any) => p.dataPlanId === VN_1GB_ID ? "Vietnam 1GB" : p.dataPlanId ? "plan " + String(p.dataPlanId).slice(0, 8) : p.dataPlanUnitValue ? "Any Fixed " + p.dataPlanUnitValue + "GB" : p.countryId ? "country " + String(p.countryId).slice(0, 8) : p.regionId ? "region " + String(p.regionId).slice(0, 8) : "tier " + p.dataPlanTierEnum;
const describe = (ps: any[]) => ps.length ? ps.map((p) => label(p) + " = " + (Number(p.priceDiscount) ? "$" + p.priceDiscount : Number(p.value) + "%")).join(" | ") : "(none)";
const key = (ps: any[]) => JSON.stringify(ps.map((p: any) => [p.dataPlanId, p.dataPlanUnitValue, p.countryId, p.regionId, p.dataPlanTierEnum, p.unlimitedDayCount, Number(p.value), Number(p.priceDiscount)]).sort());
const mk = (extra: any) => ({ id: "", dataPlanId: null, regionId: null, countryId: null, value: "0", priceDiscount: 0, networkPartnerCommissionPercentage: null, price: null, dataPlanTierEnum: null, unlimitedDayCount: null, dataPlanUnitValue: null, ...extra });
const withPlans = (feBody: any, plans: any[]) => {
  const b = JSON.parse(JSON.stringify(feBody));
  b.configuration.merchantSetting = { ...b.configuration.merchantSetting, plans };
  return b;
};
const stored = async (t: string) => merchantPlansOf((await api(t, "GET", `/api/partner/v2/${snap!.p.id}`)).json?.data);

/** PUT, retry 5xx/no-response (after checking the GET: a timed-out PUT may have saved), then GET what is stored. */
async function putRule(t: string, rule: any) {
  let last = { status: 0, msg: "" };
  for (let i = 1; i <= 4; i++) {
    const r = await api(t, "PUT", "/api/partner/v2", withPlans(snap!.feBody, [rule]), 1);
    last = { status: r.status, msg: apiMessage(r.json) || r.json?.message || "" };
    if (r.status && r.status < 500) break;
    await new Promise((res) => setTimeout(res, 15000));
    if (key(await stored(t)) === key([rule])) { last.msg += " (stored despite " + r.status + ")"; break; }
  }
  const now = await stored(t);
  return { ...last, saved: key(now) === key([rule]), now: describe(now) };
}

test.describe("ESKIMO-1089 Merchant ceiling probe", () => {
  test.describe.configure({ mode: "serial", timeout: 15 * 60 * 1000 });

  test.beforeAll(async ({ browser }) => {
    test.setTimeout(300000);
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const p = await findPartner(t, NAME);
      if (!p) throw new Error("Partner not found: " + NAME);
      const c = (await api(t, "GET", `/api/partner/v2/${p.id}`)).json?.data?.configuration;
      if (!c?.hasMerchant) throw new Error(NAME + " has no Merchant Program");
      if (c.hasCorporate) throw new Error(NAME + " also has Corporate - pick a merchant-only partner");
      snap = { p, plans: c.merchantSetting?.plans ?? [], merchant: c.merchantSetting };
      fs.writeFileSync(SNAP_FILE, JSON.stringify({ at: new Date().toISOString(), ...snap }, null, 2));
      console.log("[M1089] partner " + p.name + " (" + p.code + ") merchant rules: " + describe(snap.plans) + " → snapshot " + SNAP_FILE);
    } finally { await ctx.close(); }
  });

  test.afterAll(async ({ browser }) => {
    test.setTimeout(600000);
    if (!snap?.feBody) { console.log("[M1089] nothing saved - no restore needed"); return; }
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const variants = [snap.plans.map((p) => ({ ...p, id: "" })), snap.plans];
      for (let i = 0; i < 6; i++) {
        const plans = variants[i % 2];
        const r = await api(t, "PUT", "/api/partner/v2", withPlans(snap.feBody, plans), 1);
        await new Promise((res) => setTimeout(res, 3000));
        const now = await stored(t);
        const ok = key(now) === key(snap.plans);
        console.log(`[M1089] restore #${i + 1} (${i % 2 ? "original ids" : "id ''"}): PUT ${r.status} ${apiMessage(r.json)} → ${ok ? "OK" : "DIFF"} ${describe(now)}`);
        if (ok) return;
        if (r.status >= 500 || !r.status) await new Promise((res) => setTimeout(res, 15000));
      }
      console.log("[M1089] RESTORE FAILED — fix merchant rules of " + snap.p.name + " by hand from " + SNAP_FILE);
    } finally { await ctx.close(); }
  });

  test("M-01 capture the FE save body (no change)", async ({ browser }, testInfo) => {
    evidence.setCase("M-01 Capture save body");
    const { ctx, page } = await adminSess(browser);
    try {
      const { drawer } = await openPartnerDrawer(page, NAME);
      const reqP = page.waitForRequest((r) => /\/api\/partner\/v\d+/.test(r.url()) && r.method() === "PUT", { timeout: 180000 });
      const saved = await savePartnerDrawer(drawer);
      const body = (await reqP).postDataJSON();
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "M-01 No-change save of " + NAME + ": " + saved.status, steps: ["Admin → Partners → " + NAME + " → Ok (no change)", "Merchant rules: " + describe(snap!.plans)], expected: ["200, merchant rules unchanged"] });
      expect(saved.status).toBe(200);
      expect(body?.configuration?.merchantSetting, "merchantSetting missing in FE body").toBeTruthy();
      snap!.feBody = body;
      const t = await tokenOf(page);
      expect(key(await stored(t)), "no-change save changed the rules").toBe(key(snap!.plans));
    } finally { await ctx.close(); }
  });

  for (const [rule, fee] of [["Vietnam 1GB", 99], ["Any Fixed 1GB", 99]] as const) {
    test(`M-02 UI: ${rule} ${fee}% → warning + Ok`, async ({ browser }, testInfo) => {
      evidence.setCase(`M-02 UI ${rule} ${fee}%`);
      const { ctx, page } = await adminSess(browser);
      try {
        const { drawer } = await openPartnerDrawer(page, NAME);
        await addMerchantRow(drawer, rule);
        await setDiscount(drawer, rule, PCT, fee);
        await page.waitForTimeout(1500);
        const warn = (await merchantRows(drawer).locator(".warning-list").allInnerTexts().catch(() => [] as string[])).join("\n").split(/\n+/).map((x) => x.trim()).filter((x) => /final bill/i.test(x));
        const row = merchantRows(drawer).last();
        await row.scrollIntoViewIfNeeded().catch(() => {});
        await evidence.saveScreenshot(page, testInfo, { ac: AC, title: `M-02 ${rule} ${fee}%: ${warn.length} "final bill < 1" warnings`, steps: [`Merchant Program → New Discount Benefit → ${rule} → ${PCT} ${fee}`, ...warn.slice(0, 5).concat(warn.length > 5 ? ["… +" + (warn.length - 5)] : [])], expected: ["Warning shown for plans with final bill < $1"] });
        const saved = await savePartnerDrawer(drawer);
        const t = await tokenOf(page);
        const now = await stored(t);
        const has = now.some((p) => label(p) === rule && Number(p.value) === fee);
        await evidence.saveScreenshot(page, testInfo, { ac: AC, title: `M-02 ${rule} ${fee}% Ok → ${saved.status} ${saved.message}`.slice(0, 160), steps: ["Click Ok", `PUT ${saved.status} ${saved.message}`, "GET partner → merchant rules: " + describe(now), has ? "Rule STORED" : "Rule not stored"], expected: ["Same outcome for specific plan and group rule"] });
        console.log(`[M1089] UI ${rule} ${fee}%: warnings=${warn.length} PUT=${saved.status} ${saved.message} stored=${has} now=${describe(now)}`);
        // Put the snapshot back before the next case (the UI added a rule on top).
        if (has) { const r = await api(t, "PUT", "/api/partner/v2", withPlans(snap!.feBody, snap!.plans.map((p) => ({ ...p, id: "" }))), 2); console.log("[M1089] reset after UI: " + r.status + " → " + describe(await stored(t))); }
      } finally { await ctx.close(); }
    });
  }

  test("M-03 API: PUT one merchant rule per request", async ({ browser }, testInfo) => {
    evidence.setCase("M-03 API probe");
    const { ctx, page } = await adminSess(browser);
    const rows: unknown[][] = [];
    const cases: [string, string, any, any][] = [];
    for (const v of [74, 75, 80, 99]) cases.push([v + "%", "$" + (3.9 * (100 - v) / 100).toFixed(3), mk({ dataPlanId: VN_1GB_ID, value: String(v) }), mk({ type: 5, dataPlanUnitValue: 1, value: String(v) })]);
    for (const fd of [2.9, 2.95, 3.5]) cases.push(["fixed $" + fd, "$" + (3.9 - fd).toFixed(2), mk({ dataPlanId: VN_1GB_ID, priceDiscount: fd }), mk({ type: 5, dataPlanUnitValue: 1, priceDiscount: fd })]);
    try {
      const t = await tokenOf(page);
      for (const [disc, bill, specific, group] of cases) {
        const a = await putRule(t, specific);
        const b = await putRule(t, group);
        const fmt = (x: typeof a) => `${x.status} ${x.msg} · ${x.saved ? "STORED" : "not stored"}`;
        rows.push([disc, bill, fmt(a), fmt(b)]);
        console.log("[M1089] " + JSON.stringify(rows[rows.length - 1]));
      }
    } finally { await ctx.close(); }
    const outcome = (s: unknown) => String(s).includes("STORED") && !String(s).includes("not stored");
    const same = rows.every((r) => outcome(r[2]) === outcome(r[3]));
    const unsure = rows.some((r) => /^(0|5\d\d) /.test(String(r[2])) || /^(0|5\d\d) /.test(String(r[3])));
    await card(browser, testInfo, "M-03 Merchant – PUT /api/partner/v2, one rule per request, GET after each (" + NAME + ")",
      table(["Discount", "Final bill Vietnam 1GB ($3.90)", "Vietnam 1GB (specific plan)", "Any Fixed 1GB (group rule)"], rows),
      { ac: AC, title: "M-03 API probe", steps: ["merchantSetting.plans = [one rule], rest of body = FE no-change save body", "Result = PUT status + whether GET shows the rule stored"], expected: ["Specific plan and group rule validated the same way"], status: same ? undefined : "failed" });
    expect(unsure, "stage 5xx/no response in some cases - not conclusive").toBe(false);
    expect(same, "Specific plan and group rule are validated differently").toBe(true);
  });
});
