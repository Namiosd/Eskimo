// ESKIMO-910 AC1 "empty = default 10%" (2026-10-28): clear the base "Any Data Plan" fee, then buy plans no rule covers.
//   DF-01 UI: base fee emptied -> Ok -> API platformFeePercent + reopen (empty input, "default fee (10%)" hint).
//   DF-02 Purchases (testwhitelabeluat2): Vietnam 3GB, France 5GB, Global 10GB -> no rule -> Value = listed x 10%;
//         control Australia 1GB (user's specific rule 75%) -> the rule still wins over the default.
//   Each order: PUR, paid = listed, Eskimo Sales = Data Purchase, 1 receipt email (tests/ESKIMO-910/_orders.ts).
// Partner WhiteLabel Partner 2 (PN101609), STAGE. Base fee + rules read live first; base fee restored in afterAll.
import { test, expect, type Browser, type TestInfo } from "@playwright/test";
import { createEvidence, esc } from "../_support/evidence";
import { api, apiMessage, tokenOf, findPartner, readPartner, openCorporate, corporate, focus, clickOk, adminSessionRetry as adminSess } from "../_support/whitelabel";
import { CARD_OK, newShopper, pickPlan, goToCheckout, continueToPayment, payWithCard, readCompletePage, adminToken } from "../_support/wellatsea";
import { snapshotMailIds, verifyOrders, ordersTableHtml, type PaidOrder } from "./_orders";

const ID = "@ESKIMO-910";
const AC = "WL Application Fee - AC1 empty base fee = default 10%";
const evidence = createEvidence("ESKIMO-910", "default-fee");
const P2 = process.env.E2E_WL_PARTNER_NAME || "WhiteLabel Partner 2";
const MEMBER_EMAIL = process.env.E2E_910_PRIORITY_EMAIL || "testwhitelabeluat2@yopmail.com";
const DEFAULT_FEE = 10;
const BUYS = [
  { key: "Vietnam 3GB (no rule)", path: "/en/plans/vietnam-esim", area: /^Vietnam/i, data: "3GB", pct: DEFAULT_FEE, rule: "default (empty base)" },
  { key: "France 5GB (no rule)", path: "/en/plans/france-esim", area: /^France/i, data: "5GB", pct: DEFAULT_FEE, rule: "default (empty base)" },
  { key: "Global 10GB (no rule)", path: "/en/plans/japan-esim", area: /^Global/i, data: "10GB", pct: DEFAULT_FEE, rule: "default (empty base)" },
  { key: "Australia 1GB (user rule 75%)", path: "/en/plans/australia-esim", area: /^Australia/i, data: "1GB", pct: 75, rule: "Australia 1GB (specific)" },
];

let snap: { p: { id: string; code: string; name: string }; fee: number | null; plans: any[] } | null = null;
async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const baseFeeInput = (drawer: any) => corporate(drawer).body.locator("input#defaultPercentCorporate").first();

test.describe("ESKIMO-910 default fee " + ID, () => {
  test.describe.configure({ mode: "serial", timeout: 10 * 60 * 1000 });

  test.beforeAll(async ({ browser }) => {
    test.setTimeout(300000);
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const p = await findPartner(t, P2);
      if (!p) throw new Error("Partner not found");
      const now = await readPartner(t, p);
      snap = { p, fee: now.fee, plans: now.detail?.configuration?.whiteLabelSetting?.plans ?? [] };
      console.log("[DF] user config: base=" + now.fee + " rules=" + snap.plans.length);
    } finally { await ctx.close(); }
  });

  test.afterAll(async ({ browser }, testInfo) => {
    test.setTimeout(300000);
    if (!snap) return;
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      let now = await readPartner(t, snap.p);
      const notes: string[] = [];
      if (now.fee !== snap.fee) {
        const payload = snap.fee === null ? { clearOverride: true } : { platformFeePercent: snap.fee, clearOverride: false };
        const r = await api(t, "PUT", "/api/payment/connect/partners/" + snap.p.code + "/fee", payload, 2);
        notes.push("PUT fee " + JSON.stringify(payload) + " -> " + r.status + " " + apiMessage(r.json));
        now = await readPartner(t, snap.p);
      }
      const key = (ps: any[]) => JSON.stringify(ps.map((p: any) => [p.dataPlanId, p.countryId, p.dataPlanTierEnum, Number(p.value)]));
      const ok = now.fee === snap.fee && key(now.detail?.configuration?.whiteLabelSetting?.plans ?? []) === key(snap.plans);
      evidence.setCase("Cleanup - restore");
      await card(browser, testInfo, "Restore - base fee back to " + snap.fee + "%", "<p>" + esc((notes.join(" ; ") || "nothing to restore") + " ; base now " + now.fee) + "</p>",
        { ac: AC, title: "Restore (cleanup)", steps: notes.length ? notes : ["Already equal"], expected: ["Base " + snap.fee + "%, rules unchanged"], status: ok ? undefined : "failed" });
      console.log("[DF] restore " + (ok ? "OK (verified)" : "NOT VERIFIED - restore manually!") + " " + notes.join(" ; "));
    } finally { await ctx.close(); }
  });

  test("DF-01 UI: empty base fee -> default 10% " + ID, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("DF-01 empty base fee");
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const o = await openCorporate(page, P2);
      const input = baseFeeInput(o.drawer);
      const was = await input.inputValue();
      await input.fill("");
      await focus(input);
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "DF-01 Base fee emptied before Ok", steps: ["Base Any Data Plan fee: \"" + was + "\" -> \"\" (empty)"], expected: ["Empty = default 10%"] });
      const saved = await clickOk(page, o.drawer);
      const now = await readPartner(t, snap!.p);
      const o2 = await openCorporate(page, P2);
      const shown = await baseFeeInput(o2.drawer).inputValue();
      const placeholder = (await baseFeeInput(o2.drawer).getAttribute("placeholder")) ?? "";
      const hint = /default fee \(?10%\)?/i.test((await corporate(o2.drawer).body.innerText()).replace(/\s+/g, " "));
      await baseFeeInput(o2.drawer).scrollIntoViewIfNeeded().catch(() => {});
      // API keeps no override (platformFeePercent null) = default; the 10% itself is checked on real orders in DF-02
      const ok = saved.status === 200 && (now.fee === DEFAULT_FEE || now.fee === null) && shown === "";
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "DF-01 Reopened after save", steps: ["PUT /api/partner/v2 -> " + saved.status + " " + saved.message + (saved.fee ? " ; fee PUT " + saved.fee.req + " -> " + saved.fee.status + " " + saved.fee.message : ""), "API platformFeePercent: " + now.fee, "Reopened input: \"" + shown + "\" placeholder \"" + placeholder + "\"", "Hint 'default fee (10%)' shown: " + hint], expected: ["Saved; effective fee 10% (default); input empty with the default hint"], status: ok ? undefined : "failed" });
      console.log("[DF] DF-01 save=" + saved.status + " feePUT=" + (saved.fee ? saved.fee.req + "->" + saved.fee.status : "-") + " apiFee=" + now.fee + " shown='" + shown + "' hint=" + hint);
      expect(saved.status).toBe(200);
      expect.soft(shown, "base input stays empty").toBe("");
    } finally { await ctx.close(); }
  });

  test("DF-02 Purchases: plans without a rule pay the default 10% " + ID, async ({ browser }, testInfo) => {
    test.setTimeout(30 * 60 * 1000);
    evidence.setCase("DF-02 purchases");
    const seen = await snapshotMailIds(MEMBER_EMAIL);
    const orders: PaidOrder[] = [];
    for (const b of BUYS) {
      const { ctx, page } = await newShopper(browser);
      let r: any;
      try {
        const plan = await pickPlan(page, { countryPath: b.path, area: b.area, data: b.data });
        const tile = page.locator(".wl-coverage-area-card").filter({ hasText: b.area }).first().locator(".day-card")
          .filter({ has: page.locator(".day-card__value", { hasText: new RegExp("^\\s*" + b.data.replace(/GB$/i, "") + "\\s*$") }) }).filter({ hasText: /GB/i }).first();
        const listedPrice = Number(((await tile.innerText({ timeout: 10000 }).catch(() => "")).match(/\$\s*([\d.,]+)/) ?? [])[1]?.replace(/,/g, "") ?? NaN);
        await goToCheckout(page);
        let pay = await continueToPayment(page, "E2e910 DF", MEMBER_EMAIL);
        if (pay.outcome !== "card" && /try again/i.test(pay.errors.join(" "))) { await page.waitForTimeout(5000); pay = await continueToPayment(page, "E2e910 DF", MEMBER_EMAIL); }
        if (pay.outcome !== "card") throw new Error("Checkout did not reach the card step (" + pay.outcome + "): " + pay.errors.join("; "));
        const res = await payWithCard(page, CARD_OK);
        if (res.outcome !== "complete") throw new Error("Payment did not complete (" + res.outcome + "): " + res.error);
        r = { plan, listedPrice, orderNumber: (await readCompletePage(page)).orderNumber };
      } catch (e) { r = { error: String(e).split("\n")[0] }; } finally { await ctx.close(); }
      orders.push({ key: b.key, orderNumber: r.orderNumber ?? "", listedPrice: Number(r.listedPrice), expectedPct: b.pct, expectedRule: b.rule, areaRe: b.area, data: b.data, error: r.error });
      await card(browser, testInfo, "DF-02 buy " + b.key, "<p>" + esc(r.error ? "FAILED: " + r.error : "Plan: " + r.plan + " ; listed US$ " + r.listedPrice + " ; order " + r.orderNumber) + "</p>",
        { ac: AC, title: "DF-02 buy " + b.key, steps: ["Storefront " + b.path + " -> " + b.data, r.error ? r.error : "Order " + r.orderNumber], expected: ["Fee " + b.pct + "% (" + b.rule + ")"], status: r.error ? "failed" : undefined });
    }
    const t = await (async () => { const { ctx, page } = await adminSess(browser); try { return await adminToken(page); } finally { await ctx.close(); } })();
    const checks = await verifyOrders(t, MEMBER_EMAIL, orders, seen,
      (page, title, steps, expected, ok) => evidence.saveScreenshot(page, testInfo, { ac: AC, title: "DF-02 " + title, steps, expected, status: ok ? undefined : "failed" }));
    await card(browser, testInfo, "DF-02 - per order: PUR, paid, Value (default 10% / rule), Eskimo Sales, receipt email", ordersTableHtml(checks, esc),
      { ac: AC, title: "DF-02 DATA orders", steps: checks.map((c) => c.key + ": " + c.orderNumber + " / " + (c.whi || "no WHI") + " ; paid $" + c.paid + "/" + c.listed + " ; Value $" + c.value + " (" + c.appliedPct + "%, exp " + c.expectedPct + "% = $" + c.expectedFee + ") ; Eskimo Sales " + (c.sale.found ? "$" + c.sale.value : "NOT FOUND") + " ; email " + c.mail.status + " -> " + (c.ok ? "PASS" : "FAIL")),
        expected: ["No rule -> Value = listed x 10% (default)", "Australia 1GB -> its rule 75%", "Customer pays the listed price; Eskimo Sales = Data Purchase; 1 receipt per order"], status: checks.every((c) => c.ok) ? undefined : "failed" });
    console.log("[DF] DF-02 " + checks.map((c) => c.key + " " + c.orderNumber + " paid " + c.paid + "/" + c.listed + " value " + c.value + " (" + c.appliedPct + "%, exp " + c.expectedPct + ") sale " + (c.sale.found ? c.sale.value : "-") + " mail " + c.mail.status + " " + (c.ok ? "PASS" : "FAIL")).join(" ;; "));
    for (const c of checks) for (const [k, v] of Object.entries(c.checks)) if (!(k.startsWith("receipt") && c.mail.status === "blocked")) expect.soft(v, c.key + ": " + k).toBe(true);
  });
});
