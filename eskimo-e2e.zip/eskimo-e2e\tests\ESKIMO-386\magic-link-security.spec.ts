// ESKIMO-386 / EP-6059 – WellAtSea Magic Link: click-tracking wrapping + reusable/no-OTP login.
// Test cases: testcases/ESKIMO-386/ESKIMO-386.md. Read only (no purchase, no OTP), and only our own
// test account's links — never the real-customer token from the bug description.
//   TC-01 email magic-link hrefs are DIRECT (no ct.sendgrid.net) — the valid fix
//   TC-02 magic link opens the wallet with no OTP, on two fresh browsers (reusable = by design per AC3/AC4)
//   TC-03 record which description lines conflict with EP-5965 AC3/AC4
// Evidence: evidence/ESKIMO-386-magic-link → npm run report:evidence -- ESKIMO-386 magic-link
import fs from "node:fs";
import { test, expect, type TestInfo } from "@playwright/test";
import { createEvidence, esc } from "../_support/evidence";
import { WL_URL, newShopper } from "../_support/wellatsea";

const ID = "@ESKIMO-386";
const AC = "EP-6059";
const evidence = createEvidence("ESKIMO-386", "magic-link");
const EMAIL = process.env.E2E_WL_CUSTOMER_EMAIL || "";
// The journey run that produced the delivered emails (magic link + raw hrefs).
const RUNSTATE = process.env.E2E_WL_RUNSTATE || "D:/eskimo_portal/e2e/.tmp-wellatsea-run-state.json";
const SENDGRID = /ct\.sendgrid\.net|\/ls\/click/i;

function readRun(): any {
  try { const s = JSON.parse(fs.readFileSync(RUNSTATE, "utf8")); return s.v || s; } catch { return {}; }
}
// Every delivered-email link href (sanitized: token hidden) with its wrapping status.
function emailLinks(run: any): { field: string; host: string; wrapped: boolean }[] {
  const out: { field: string; host: string; wrapped: boolean }[] = [];
  const seen = new Set<string>();
  const walk = (o: any, path: string) => {
    if (!o) return;
    if (typeof o === "string") {
      if (/https?:\/\//.test(o) && /token=|data-balance|sendgrid/i.test(o)) {
        const key = o.replace(/token=[^&]+/i, "token=<hidden>");
        if (!seen.has(key)) { seen.add(key); out.push({ field: path, host: (o.match(/^https?:\/\/[^/]+/) || ["?"])[0], wrapped: SENDGRID.test(o) }); }
      }
      return;
    }
    if (typeof o === "object") for (const k of Object.keys(o)) walk(o[k], path ? `${path}.${k}` : k);
  };
  walk(run, "");
  return out;
}

test.describe(`ESKIMO-386 Magic link security ${ID}`, () => {
  test.setTimeout(240_000);
  const run = readRun();
  const MAGIC_LINK = process.env.E2E_WL_MAGIC_LINK || run.magicLink || "";

  test(`TC-01 Email magic-link hrefs are direct (no click-tracking) ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 No click-tracking wrapping");
    const links = emailLinks(run);
    const wrapped = links.filter((l) => l.wrapped);
    const ctx = await browser.newContext();
    const scratch = await ctx.newPage();
    await evidence.saveDataCard(scratch, testInfo, "Magic-link hrefs in the delivered emails",
      `<p>Source: journey run emails for ${esc(EMAIL || run.email || "the test account")} (tokens hidden).</p>` +
      `<table><tr><th>Field</th><th>Destination host</th><th>Click-tracking?</th></tr>${links.map((l) =>
        `<tr><td>${esc(l.field)}</td><td>${esc(l.host)}</td><td class="${l.wrapped ? "bad" : "ok"}">${l.wrapped ? "WRAPPED (ct.sendgrid.net)" : "direct"}</td></tr>`).join("") || "<tr><td colspan=3>no link captured</td></tr>"}</table>` +
      `<h3 class="${!wrapped.length && links.length ? "ok" : "bad"}">${!wrapped.length && links.length ? `FIXED — ${links.length} link(s), none wrapped by click-tracking` : links.length ? `${wrapped.length} link(s) still wrapped` : "no links captured from run-state"}</h3>`,
      { ac: AC, title: "TC-01 Email links — click-tracking disabled", steps: [`${links.length} link(s) checked`, `Wrapped by ct.sendgrid.net: ${wrapped.length}`], expected: ["All token links direct to wellatsea.eskimo.travel, none via ct.sendgrid.net"], status: links.length && !wrapped.length ? undefined : "failed" });
    await ctx.close();
    expect(links.length, "magic-link href captured from the run").toBeGreaterThan(0);
    expect(wrapped.map((l) => l.field), "links wrapped by click-tracking (must be none)").toEqual([]);
  });

  test(`TC-02 Magic link opens wallet without OTP, reusable (by design) ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.setCase("TC-02 Reusable quick-login");
    test.skip(!MAGIC_LINK, "No magic link available (set E2E_WL_MAGIC_LINK)");
    const results: boolean[] = [];
    for (const visit of [1, 2]) {
      const { ctx, page } = await newShopper(browser); // fresh context = no prior session/cookie
      try {
        await page.goto(MAGIC_LINK, { waitUntil: "commit", timeout: 75000 });
        const signedIn = await page.locator(".wl-wallet-account").first().waitFor({ state: "visible", timeout: 90000 }).then(() => true).catch(() => false);
        const shownEmail = (await page.locator(".wl-wallet-account__email").first().innerText().catch(() => "")).trim();
        results.push(signedIn);
        await evidence.saveScreenshot(page, testInfo, {
          ac: AC, title: `TC-02.${visit} Magic link visit #${visit} (fresh browser, no OTP)`,
          steps: [`${WL_URL}/en/data-balance?token=… (token hidden)`, `Signed in: ${signedIn ? "yes" : "no"}`, `Wallet email: ${shownEmail || "—"}`, visit === 2 ? "Reusable: same link logs in a second time → by design (AC3 no-expiry, AC4 quick login)" : "Instant GET login, no OTP → by design (AC4 quick login)"],
          expected: ["Opens the wallet with no OTP (quick login per AC4)"], status: signedIn ? undefined : "failed",
        });
      } finally {
        await ctx.close();
      }
    }
    expect(results.filter(Boolean).length, "magic link logs in on both fresh visits (reusable by design)").toBe(2);
  });

  test(`TC-03 Description vs EP-5965 AC3/AC4 (recorded) ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.setCase("TC-03 Description corrections");
    const rows = [
      ["\"expires on a time basis (spec: 1 day, per AC3 EP-5965)\"", "AC3 actually = \"The Magic Link no expires.\" — no 1-day rule", "Remove the 1-day claim"],
      ["\"Not single-use / reusable\" treated as a defect", "FE: valid 730 days, reusable; AC4 allows magic-link quick login", "Not a defect vs spec; a single-use change needs AC3/AC4 updated first"],
      ["Expected: add a confirm button instead of GET-login", "Contradicts AC4 \"quick login\"", "Keep only as optional hardening, not a pass/fail criterion"],
      ["Actual: URL wrapped by SendGrid click-tracking", "Current emails: links are direct (TC-01)", "Click-tracking already disabled — update to FIXED"],
    ];
    const ctx = await browser.newContext();
    const scratch = await ctx.newPage();
    await evidence.saveDataCard(scratch, testInfo, "EP-6059 description vs EP-5965 AC3/AC4",
      `<table><tr><th>Description says</th><th>Why it conflicts</th><th>Suggested fix</th></tr>${rows.map((r) =>
        `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td><td>${esc(r[2])}</td></tr>`).join("")}</table>` +
      `<p>Verdict: the valid defect (click-tracking) is fixed; the reusable/expiry items are design-as-intended per EP-5965.</p>`,
      { ac: AC, title: "TC-03 Description corrections (recorded)", steps: ["4 description points reconciled against the parent spec"], expected: ["Recorded for the team to amend the ticket"] });
    await ctx.close();
    testInfo.annotations.push({ type: "recorded", description: "description expiry/single-use items conflict with EP-5965 AC3/AC4" });
  });
});
