# ESKIMO-850 – [EP-6074] [Admin Eskimo Sales] Search returns no result for White Label transactions

Nguồn: Steps/Expected của bug ESKIMO-850 (Jira EP-6074). Bản nháp QC 2026-10-15.
Môi trường: STAGE – Admin https://app-eskimo-admin-stage-sea-001.azurewebsites.net, API https://app-eskimo-api-stage-sea-001.azurewebsites.net
Partner White Label: PN101609 "WhiteLabel Partner 2", storefront https://wellatsea.eskimo.travel
Khách WL: E2E_WL_MEMBER_EMAIL (testwhitelabel168@yopmail.com)

Quyết định QC:
- Chỉ đọc (read-only): không mua mới, không refund.
- Giao dịch WHI / DPE tham chiếu lấy động qua API (giao dịch Success mới nhất; WHI = eskimoTransactionType 4, của E2E_WL_MEMBER_EMAIL nếu có), vì dữ liệu STG đổi trong ngày. Không còn giao dịch WHI nào → blocked (env).
- Expected lấy từ ticket: "Searching by Transaction ID (full or partial) or member name returns the matching White Label transaction, the same as for regular transactions."

Trang: Admin → Transactions › Eskimo Sales (#/transactions-eskimo-sale), ô "Search" + Enter.

## TC-01 Search Transaction ID WHI đầy đủ
- Steps: nhập Transaction ID WHI-YYMMDD-xxxxxxx → Enter
- Expected: bảng có dòng với đúng Transaction ID đó; (DATA) POST /api/data-plan-sale-transaction/search trả về giao dịch đó

## TC-02 Search Transaction ID WHI một phần (7 số cuối)
- Steps: nhập phần số cuối của ID (vd 2718888) → Enter
- Expected: bảng có dòng WHI đó

## TC-03 Search theo Member Name của giao dịch WHI
- Steps: nhập Member Name của giao dịch WHI → Enter
- Expected: bảng có dòng WHI đó (hoặc, nếu nhiều hơn 1 trang, mọi dòng đều thuộc member đó và API trả về giao dịch WHI)

## TC-04 Search theo email khách WL
- Steps: nhập E2E_WL_MEMBER_EMAIL → Enter
- Expected: có ít nhất 1 giao dịch WHI của khách đó
- Ghi chú: ticket không nhắc email; chỉ chạy kỳ vọng nếu search email trả được giao dịch thường (đối chứng ở TC-05)

## TC-05 Giao dịch thường không bị ảnh hưởng
- Steps: lấy 1 giao dịch thường (không WHI) Success; search ID đầy đủ, ID một phần, Member Name (và email nếu có)
- Expected: cả 3 lần đều trả về giao dịch đó (như trước)

## TC-06 Kết quả search được làm mới (không giữ dòng cũ)
- Steps: search ID giao dịch thường → rồi search ID WHI
- Expected: bảng chỉ hiển thị dòng WHI, không còn dòng của lần search trước

## TC-07 Search chuỗi không tồn tại
- Steps: search "WHI-000000-0000000"
- Expected: "No data" (không có dòng nào)
