# ESKIMO-384 – [EP-6057] WellAtSea: thanh toán thất bại tạo account Active thay vì Pending

Môi trường: STG — storefront https://wellatsea.eskimo.travel/en (BE stage, Stripe test mode), Admin = E2E_ADMIN_URL
Partner hiện tại của domain: PN101609 (White Label 2) — item ghi PN105327 (partner cũ)
Plan dùng để test: Japan 1GB
Email: mỗi lần chạy 1 email mới `qa384-<timestamp>@yopmail.com` (+ `qa384c-<timestamp>@yopmail.com` cho TC-06)

Quyết định QC (2026-10-13):
- Chạy hết TC-01 → TC-06, kể cả TC-04/05 (mua thật bằng thẻ test 4242 → assign 1 eSIM từ pool).
- Mỗi lần chạy để lại 1–2 account Pending + record Failed trong Eskimo Sales (không xoá được qua UI).
- Expected lấy từ item (AC1 của EP-5965): thanh toán fail/huỷ → account **Pending**, không eSIM, không Data Plan; thanh toán thành công sau đó → dùng lại account, không tạo trùng.

## TC-01 Storefront: thẻ bị từ chối
- Preconditions: email chưa từng có account
- Steps:
  1. wellatsea → Japan → 1GB → Checkout
  2. Nhập First name + email mới → Continue to payment
  3. Thẻ 4000 0000 0000 0002, exp 12/30, CVC 123 → Pay
- Expected: Hiện "Your card has been declined", thanh toán không hoàn tất (không sang /checkout/complete)

## TC-02 Admin: Membership list sau thẻ bị từ chối
- Preconditions: TC-01
- Steps: Admin → Membership → Search by Email = email TC-01
- Expected: Đúng 1 account; Account Status = **Pending**; eSIM Status = No eSIM

## TC-03 Admin: Member Detail sau thẻ bị từ chối
- Preconditions: TC-02
- Steps: View Detail → Personal Account
- Expected: Field "Status" = **Pending**; Data Wallet / Singtel eSIM = "No Data"

## TC-04 Storefront: thanh toán lại bằng thẻ hợp lệ, cùng email
- Preconditions: TC-01
- Steps: Checkout lại cùng email (Japan 1GB), thẻ 4242 4242 4242 4242 → Pay
- Expected: Sang trang hoàn tất, có Order number

## TC-05 Admin: account sau khi thanh toán thành công
- Preconditions: TC-04
- Steps: Admin → Membership → Search by Email → View Detail
- Expected: Vẫn đúng 1 account (dùng lại, không tạo trùng); Status = **Active**
- Ghi chú (QC 2026-10-13): eSIM assign chỉ GHI NHẬN, không tính pass/fail — pool eSIM STG đang hết nên mọi đơn WL mới đều không có eSIM (vấn đề môi trường, không phải bug của EP-6057).

## TC-06 Khách huỷ thanh toán (không trả)
- Preconditions: email mới khác
- Steps:
  1. wellatsea → Japan → 1GB → Checkout → nhập First name + email → Continue to payment (order được tạo, form thẻ hiện)
  2. Không nhập thẻ, đóng trang (bỏ thanh toán)
  3. Admin → Membership → Search by Email
- Expected: Account Status = **Pending**, không eSIM (AC1: "fails or is cancelled")
- Ghi chú: item không định nghĩa "cancelled" ở storefront (không có nút Cancel). Bỏ trang là cách duy nhất khách huỷ; nếu không có account nào được tạo → báo CLARIFY cho BA.
