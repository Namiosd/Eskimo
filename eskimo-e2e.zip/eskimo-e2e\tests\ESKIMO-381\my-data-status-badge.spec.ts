// ESKIMO-381 / EP-6053 – WellAtSea My Data: plan badge used to show the literal "Unknown".
// Test cases: testcases/ESKIMO-381/ESKIMO-381.md. Read only (no purchase, no OTP).
// Agreed expected (QC + BA 2026-10-14): behaviour matches eskimo.travel/data-balance —
//   a plan card carries only a PLAN-TYPE badge ("Unlimited N days"); fixed-GB plans carry
//   none; no status badge is shown; "Unknown" is gone. So:
//   TC-01 no "Unknown"/placeholder on any card   TC-02 only plan-type badge (no status word)
//   TC-03 badge ↔ Admin Member Detail › Data Wallet status (recorded)
// My Data is opened with the customer's magic link (E2E_WL_MAGIC_LINK) instead of e-mail OTP.
// Evidence: evidence/ESKIMO-381-my-data-badge → npm run report:evidence -- ESKIMO-381 my-data-badge
import fs from "node:fs";
import path from "node:path";
import { test, expect, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import { WL_URL, newShopper, searchMembership, openMemberDetail } from "../_support/wellatsea";

const ID = "@ESKIMO-381";
const AC = "EP-6053";
const evidence = createEvidence("ESKIMO-381", "my-data-badge");
const EMAIL = process.env.E2E_WL_CUSTOMER_EMAIL || "";
const MAGIC_LINK = process.env.E2E_WL_MAGIC_LINK || "";
// Placeholder / technical strings a customer must never see as a status.
const PLACEHOLDER = /^(unknown|null|undefined|nan|n\/a|-+|—|\d+|status|[a-z]+_[a-z_]+)$/i;

type Card = { name: string; badges: string[] };
// "Unlimited N days" (commit 0afa49f) names the plan type, not its status.
const PLAN_TYPE = /unlimited/i;
// A status word that must NOT appear on a card (the fix drops these, per eskimo.travel).
const STATUS_WORD = /^(active|inactive|not activated|pending|in use|processing|unknown)$/i;

// Status badge = an element inside the card whose class names a badge/chip/tag/status.
async function readCards(page: Page): Promise<Card[]> {
  return page.$$eval(".db-card.wl-wallet-card", (cards) =>
    cards.map((c) => {
      const badgeEls = [...c.querySelectorAll("[class*='badge'], [class*='chip'], [class*='tag'], [class*='status']")]
        .filter((el) => !el.querySelector("[class*='badge'], [class*='chip'], [class*='tag'], [class*='status']"));
      badgeEls.forEach((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", outlineOffset: "2px" }));
      const name = c.querySelector(".db-card-name, [class*='card-name'], h3, h4") as HTMLElement | null;
      if (name) Object.assign(name.style, { background: "rgba(255,229,143,.9)" });
      return {
        name: ((name?.innerText || (c as HTMLElement).innerText.split("\n")[0]) || "").replace(/\s+/g, " ").trim(),
        badges: badgeEls.map((el) => ((el as HTMLElement).innerText || "").replace(/\s+/g, " ").trim()),
      };
    }),
  );
}

// A failed test restarts the worker: TC-01's cards are kept in a file so TC-02/03 still run.
const CARDS = path.join(evidence.SCREENSHOT_DIR, "cards.json");
const loadCards = (): Card[] => { try { return JSON.parse(fs.readFileSync(CARDS, "utf8")); } catch { return []; } };

test.describe(`ESKIMO-381 My Data plan status badge ${ID}`, () => {
  test.setTimeout(300_000);

  test(`TC-01 No plan card shows "Unknown" / placeholder ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 No Unknown / placeholder badge");
    expect(EMAIL, "Set E2E_WL_CUSTOMER_EMAIL").toBeTruthy();
    expect(MAGIC_LINK, "Set E2E_WL_MAGIC_LINK (customer's My Data link)").toBeTruthy();
    const { ctx, page } = await newShopper(browser);
    try {
      let shownEmail = "";
      await test.step("1. Open the magic link → My Data", async () => {
        await page.goto(MAGIC_LINK, { waitUntil: "commit", timeout: 75000 });
        const signedIn = await page.locator(".wl-wallet-account").first().waitFor({ state: "visible", timeout: 90000 }).then(() => true).catch(() => false);
        shownEmail = (await page.locator(".wl-wallet-account__email").first().innerText().catch(() => "")).trim();
        if (!signedIn) {
          await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "TC-01 My Data via magic link – not signed in", steps: [`${WL_URL}/en/data-balance?token=…`], expected: ["Wallet of the customer"], status: "failed" });
        }
        expect(signedIn, "Magic link no longer signs in (blocked: log in with e-mail OTP by hand, TC-04)").toBe(true);
        expect(shownEmail.toLowerCase()).toBe(EMAIL.toLowerCase());
      });
      await test.step("2. Badge next to each plan name (My Plans)", async () => {
        await page.locator(".db-card.wl-wallet-card").first().waitFor({ state: "visible", timeout: 30000 });
        const cards = await readCards(page);
        fs.mkdirSync(evidence.SCREENSHOT_DIR, { recursive: true });
        fs.writeFileSync(CARDS, JSON.stringify(cards, null, 2));
        const placeholders = cards.flatMap((c) => c.badges.filter((b) => PLACEHOLDER.test(b)).map((b) => `${c.name}: "${b}"`));
        await page.locator(".db-card.wl-wallet-card").first().scrollIntoViewIfNeeded().catch(() => {});
        await evidence.saveScreenshot(page, testInfo, {
          ac: AC, title: 'TC-01 My Data – no "Unknown" / placeholder on any plan card',
          steps: [`Signed in as ${shownEmail} via magic link`, `${cards.length} plan card(s)`, ...cards.map((c, i) => `#${i + 1} ${c.name} → badge: ${c.badges.filter(Boolean).map((b) => `"${b}"${PLAN_TYPE.test(b) ? " (plan type)" : ""}`).join(", ") || "NONE"}`)],
          expected: ['No "Unknown", empty or technical placeholder on any card'], status: cards.length && !placeholders.length ? undefined : "failed",
        });
        expect(cards.length, "plan cards").toBeGreaterThan(0);
        expect(placeholders, 'badges that are "Unknown" / placeholder').toEqual([]);
      });
    } finally {
      await ctx.close();
    }
  });

  test(`TC-02 Only plan-type badge, no status badge (like eskimo.travel) ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.setCase("TC-02 Plan-type badge only");
    const cards = loadCards();
    test.skip(!cards.length, "No plan cards read in TC-01");
    // Classify each badge: plan type ("Unlimited N days") is allowed; a status word is not.
    const rows = cards.flatMap((c) => c.badges.filter(Boolean).map((b) => ({ plan: c.name, badge: b, kind: PLAN_TYPE.test(b) ? "plan type" : STATUS_WORD.test(b) || PLACEHOLDER.test(b) ? "STATUS/placeholder" : "other" })));
    const statusBadges = rows.filter((r) => r.kind === "STATUS/placeholder");
    const planTypeBadges = rows.filter((r) => r.kind === "plan type");
    const ctx = await browser.newContext();
    const scratch = await ctx.newPage();
    await evidence.saveDataCard(scratch, testInfo, "Badges on My Data – plan type vs status",
      `<table><tr><th>Plan card</th><th>Badge</th><th>Kind</th></tr>${rows.map((r) =>
        `<tr><td>${esc(r.plan)}</td><td>${esc(r.badge)}</td><td class="${r.kind === "plan type" ? "ok" : r.kind === "other" ? "" : "bad"}">${esc(r.kind)}</td></tr>`).join("") || "<tr><td colspan=3>no badge on any card</td></tr>"}</table>` +
      `<p>Cards with no badge are fixed-GB plans (expected, as on eskimo.travel).</p>`,
      { ac: AC, title: "TC-02 Plan-type badge only – no status badge", steps: [`${cards.length} card(s): ${planTypeBadges.length} plan-type badge(s), ${statusBadges.length} status/placeholder badge(s)`], expected: ["Only plan-type badge shown", "No status badge", 'Unlimited plan shows "Unlimited N days"'], status: !statusBadges.length && planTypeBadges.length ? undefined : "failed" });
    await ctx.close();
    expect(statusBadges.map((r) => `${r.plan}: "${r.badge}"`), "status / placeholder badges (must be none)").toEqual([]);
    expect(planTypeBadges.length, "at least one plan-type badge (Unlimited plan)").toBeGreaterThan(0);
  });

  test(`TC-03 Badge vs Admin Data Wallet status (recorded) ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.setCase("TC-03 Badge vs Admin status (recorded)");
    const cards = loadCards();
    const admin = await adminSession(browser);
    try {
      await admin.page.setViewportSize({ width: 1600, height: 900 });
      const ui = await searchMembership(admin.page, EMAIL);
      expect(ui.rowCount, `member ${EMAIL} in Admin`).toBeGreaterThan(0);
      await openMemberDetail(admin.page, ui.row);
      const panel = admin.page.getByText(/^\s*Data Wallet\s*$/).first().locator("xpath=ancestor::div[.//table][1]");
      await panel.locator(".ant-table-tbody tr").first().waitFor({ state: "visible", timeout: 20000 }).catch(() => {});
      const headers = (await panel.locator(".ant-table-thead th").allInnerTexts().catch(() => [])).map((h) => h.trim());
      const rows = await panel.locator(".ant-table-tbody tr.ant-table-row").evaluateAll((trs) =>
        trs.map((tr) => [...tr.querySelectorAll("td")].map((td) => (td as HTMLElement).innerText.replace(/\s+/g, " ").trim())));
      await panel.scrollIntoViewIfNeeded().catch(() => {});
      await panel.evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322" })).catch(() => {});
      // The Data Wallet table has no header row: cells are amount | subscription | status | plan title.
      const STATUS_CELL = /^(active|inactive|expired|used|cancel|pending|suspend)/i;
      const pairs = rows.map((r) => {
        const status = r.find((x) => STATUS_CELL.test(x)) ?? "?";
        const title = r.slice(r.indexOf(status) + 1).find(Boolean) ?? r.join(" | ");
        return `${title} (${r[0]}, subscription ${r[1] || "--"}) → Admin status "${status}"`;
      });
      void headers;
      await evidence.saveScreenshot(admin.page, testInfo, {
        ac: AC, title: "TC-03 Admin Member Detail – Data Wallet status (recorded)",
        steps: [`${ADMIN_URL}/#/membership · ${EMAIL} · View Detail`, ...pairs,
          `Storefront badges: ${cards.map((c) => `${c.name} = ${c.badges.filter(Boolean).join("/") || "NONE"}`).join("; ") || "—"}`],
        expected: ["Recorded only: mapping badge ↔ status not defined in the item (BA)"],
      });
      testInfo.annotations.push({ type: "recorded", description: pairs.join(" ; ") });
    } finally {
      await admin.ctx.close();
    }
  });
});
