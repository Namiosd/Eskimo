# ESKIMO-758 – [EP-6029] [Admin] Update Account, Payment Transaction and Membership Logic for white label account

Nguồn: AC1–AC3 của item ESKIMO-758 (BE: ESKIMO-726 / EA-4344). Bản nháp QC 2026-10-15.
Môi trường: STAGE — Admin https://app-eskimo-admin-stage-sea-001.azurewebsites.net, API https://app-eskimo-api-stage-sea-001.azurewebsites.net,
Eskimo Web https://app-eskimo-www-stage-sea-001.azurewebsites.net
Partner White Label: PN101609 "WhiteLabel Partner 2" (storefront wellatsea)
Khách WL: testwhitelabel168@yopmail.com (E2E_WL_MEMBER_EMAIL) — đã mua trên wellatsea 2026-10-14

Quyết định QC: chỉ đọc (read-only) — không mua, không đăng ký user mới, không đổi config. Expected lấy từ AC.

## AC1 – White Label Account & Login Flow

### TC-01 Account WL lưu như Corporate Work Account
- Steps: Admin → Membership → Detail của E2E_WL_MEMBER_EMAIL
- Expected:
  - (DATA) GET /api/membership/{id}: accountType = 2 (White Label), workerAccountPartnerId = PN101609
  - UI: section "White Label Account", dòng "White Label Partner" có PN101609

### TC-02 Account WL được định danh bằng Email + Partner ID
- Steps: Admin API search membership theo email E2E_WL_MEMBER_EMAIL, đọc detail từng account
- Expected: không có 2 account White Label trùng (email, Partner ID); account WL có Partner ID

### TC-03 Account WL không đăng nhập được Eskimo Web
- Steps: Eskimo Web (stage) → Sign up / Log in → Continue with Email = E2E_WL_MEMBER_EMAIL → Send OTP → nhập OTP
- Expected: không đăng nhập được vào account WL (bị chặn / báo lỗi); KHÔNG có session của account WL đó.
  Nếu web coi là user mới (form sign-up) → dừng, không đăng ký.

### TC-04 Account WL không đăng nhập được Eskimo App (luồng login Corporate) — MANUAL
- Cần app trên thiết bị thật.

### TC-05 Username = NULL, role White Label — MANUAL / cần DB
- API admin không trả username/role → dev/DB xác nhận.

## AC2 – White Label Payment Transaction

### TC-06 Eskimo Sale ghi nhận giao dịch WL với Type "White Label Payment"
- Steps: Admin → Transactions › Eskimo Sales → search Transaction ID WHI… của E2E_WL_MEMBER_EMAIL
- Expected: dòng có Type = "White Label Payment"

### TC-07 Transaction Value = Application Fee
- Steps: lấy các giao dịch WHI của PN101609 (Eskimo Sale + Data Purchase metadata.total), fee = stripeConnect.platformFeePercent
- Expected: với giao dịch tạo sau lần đổi fee gần nhất: Value = total × fee% (làm tròn 0.01).
  Giao dịch cũ hơn: Value / total = một tỷ lệ % hợp lệ (fee tại thời điểm mua) — chỉ ghi nhận.

### TC-08 Lưu đủ thông tin để truy vết thanh toán Stripe gốc
- Expected (DATA): giao dịch WHI có stripeId (pi_…), mã đơn WL (PUR-PN101609-…), total, currency.
  Đối soát trên Stripe dashboard: manual.

### TC-09 Logic Eskimo Sale cũ không đổi
- Steps: Eskimo Sale trang 1 không filter + search "WHI"
- Expected: "White Label Payment" ⇔ Transaction ID bắt đầu WHI; dòng không phải WHI giữ Type cũ.

## AC3 – Membership Management

### TC-10 Search by Email tìm được account WL
- Steps: Admin → Membership → Search by = Email, nhập E2E_WL_MEMBER_EMAIL
- Expected: kết quả có account WL đó

### TC-11 Filter Account Type = White Label Account
- Steps: Membership → Account Type = "White Label Account" (có và không có search email)
- Expected: mọi dòng là account WL (accountType 2); có E2E_WL_MEMBER_EMAIL khi search email

### TC-12 Filter Personal / Work Account không trả account WL
- Steps: Account Type = Personal Accounts / Work Account (+ search email WL, và trang 1 không search)
- Expected (QC chốt 2026-10-15): account WL KHÔNG xuất hiện ở cả 2 filter; mọi dòng đúng accountType 0 / 1

## Cần làm rõ
- Q1 (AC1): "Chặn login" = báo lỗi hay coi như email mới cho sign-up?
- Q2 (AC3): Filter "Work Account" có bao gồm account WL không?
- Q3 (AC2): Value theo fee tại thời điểm mua (fee PN101609 đổi 10% → 11% ngày 15/10)?

## Kết quả chạy 2026-10-15 (STAGE): 10/10 auto PASS sau retest TC-12, TC-04/TC-05 manual
- TC-12 retest (~07:50): PASS — Worker filter trang 1 = 25/25 accountType 1, không còn WL (BE đã sửa).
- TC-12 lần chạy trước FAIL (BE): filter Work Account (accountType "Worker") trả cả account WL — trang 1: 3 Work + 22 White Label; search email WL + Work → ra account WL aec6932a. Nguyên nhân: BE lọc Worker theo isWorkAccount=true, account WL cũng có isWorkAccount=true → phải lọc accountType = 1.
- TC-03: Send OTP trên Web với email WL → BE coi là user mới (isSignUp=true) và TẠO account Personal f28aae09 (status 4) cùng email lúc 07:32:48. OTP bypass 4321 không dùng được cho email.
- TC-07: fee PN101609 = 11%; Stripe fee làm tròn xuống cent (19.9 × 11% → 2.18).
- TC-09: 100 dòng mới nhất Eskimo Sale đều WHI → bổ sung Personal/Work qua API.
