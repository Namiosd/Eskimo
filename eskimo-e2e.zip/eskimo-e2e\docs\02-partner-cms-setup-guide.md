# Hướng dẫn thiết lập White Label: Chỉnh nội dung và thương hiệu website (Partner CMS)

| | |
|---|---|
| **Người thực hiện** | Partner (đối tác White Label) trên **Partner Portal** |
| **Màn hình** | Menu **My Website** |
| **Kết quả** | Website của partner mang thương hiệu riêng (tên, logo, màu) và nội dung riêng (chữ, hình, liên kết) trên tất cả các trang. |
| **Cập nhật** | 16/10/2026 (ticket ESKIMO-752 / EP-5964) |

> Đây là **file 2 trong bộ 4 file** hướng dẫn White Label:
> 1. *Tạo website và quản lý cấu trúc* (Admin)
> 2. **Chỉnh nội dung và thương hiệu (Partner CMS)**, tài liệu này
> 3. *Cấu hình tên miền, email gửi và thanh toán*
> 4. *Customer Journey: khách mua và dùng eSIM*

---

## 1. Tính năng chính

Partner CMS cho phép partner **tự quản lý website** ngay trên Partner Portal, không cần lập trình:

| Tính năng | Mô tả |
|---|---|
| **Thương hiệu** | Đặt tên thương hiệu, tải logo, chọn màu chính và màu phụ. Áp dụng cho toàn website. |
| **Nội dung từng module** | Sửa chữ, hình ảnh, liên kết, biểu tượng của từng khối nội dung (Banner, FAQ, Footer...) trên cả 5 trang. |
| **Xem trước tức thì** | Mọi thay đổi hiển thị ngay trong khung xem trước trước khi lưu. |
| **Tải ảnh trực tiếp** | Nút **Upload** cho logo và hình ảnh, hệ thống tự lưu trữ và điền đường dẫn. |
| **Từ khoá tự động** | `{brand}` tự thay bằng tên thương hiệu, `{country}` tự thay bằng tên quốc gia. |
| **Dữ liệu thật** | Gói data, giá, danh sách quốc gia và ví "My Data" luôn hiển thị dữ liệu thật từ hệ thống. |
| **Thanh toán** | Xem trạng thái kết nối Stripe ngay trên cùng màn hình. |
| **Bảo mật theo partner** | Mỗi partner chỉ xem và chỉnh website của chính mình. |

---

## 2. Khái niệm

| Khái niệm | Ý nghĩa |
|---|---|
| **Brand identity** | Bốn thông tin thương hiệu: **Brand name**, **Logo**, **Primary color**, **Secondary color**. |
| **Page (trang)** | Website có 5 trang: **Home**, **Plan Detail**, **Checkout**, **Data Balance**, **Install eSIM**. |
| **Module** | Một khối nội dung trong trang, ví dụ Header, Banner, FAQ, Footer. |
| **Khung xem trước** | Phần giữa màn hình, hiển thị trang gần giống website thật. |
| **`{brand}`** | Từ khoá tự thay bằng Brand name. Ví dụ `Why {brand}?` hiển thị thành *Why Your Brand?*. |

> **Phân chia trách nhiệm**
> - **Admin** quyết định **cấu trúc**: trang có những module nào, theo thứ tự nào (file 01).
> - **Partner** quyết định **nội dung và thương hiệu** bên trong từng module (tài liệu này).

---

## 3. Chuẩn bị

1. Website đã được Admin tạo và gán cho tài khoản partner.
2. Tài khoản đăng nhập **Partner Portal** (email + mã OTP gửi về email).
3. Tài liệu thương hiệu:
   - **Logo**: PNG hoặc JPEG, dưới 1 MB.
   - **Mã màu** chính và phụ (dạng hex, ví dụ `#1957F5`).
   - **Hình ảnh** cho banner và hướng dẫn cài eSIM: PNG hoặc JPEG, dưới 5 MB mỗi file.
   - **Nội dung**: tiêu đề, giới thiệu, câu hỏi thường gặp, email hỗ trợ, liên kết mạng xã hội.

---

## 4. Quy trình cấu hình

```
Bước 1  Mở My Website           Đăng nhập Partner Portal → menu My Website
   ▼
Bước 2  Thương hiệu             Brand name, Logo, Primary, Secondary
   ▼
Bước 3  Header & Footer         Menu đầu trang, chân trang, email hỗ trợ, mạng xã hội
   ▼
Bước 4  Trang Home              Banner, giới thiệu, bảng so sánh, đánh giá, FAQ...
   ▼
Bước 5  Trang Plan Detail       Tiêu đề trang gói, thẻ tính năng, nút Checkout
   ▼
Bước 6  Trang Install eSIM      Các bước cài eSIM cho iOS / Android, kèm hình
   ▼
Bước 7  Trang Data Balance      Màn hình "My Data" và thông tin gói
   ▼
Bước 8  Lưu và kiểm tra         Save Page → mở website kiểm tra
```

---

## 5. Màn hình làm việc

Đăng nhập Partner Portal, bấm **My Website** trên menu trái. Màn hình **Edit Website Content** mở ra.

![Màn hình Partner CMS](images/partner-cms/01-cms-workspace.png)

| Vùng | Chức năng |
|---|---|
| **Thanh chọn trang** | Chuyển giữa 5 trang. Số trong ngoặc là số module của trang. |
| **Brand identity** | Tên, logo, màu thương hiệu. |
| **Stripe payments** | Trạng thái kết nối thanh toán (xem file 03). |
| **Khung xem trước** | Trang đang chọn, gồm các module xếp từ trên xuống. |
| **Nút bút chì** | Trên thanh tiêu đề mỗi module, mở cửa sổ chỉnh sửa module đó. |
| **Save Page** | Lưu thay đổi lên website. Khi đã sửa nhiều trang, nút hiện **Save All (N pages)** để lưu tất cả một lần. |

---

## 6. Cách chỉnh một module

1. Chọn trang trên thanh chọn trang.
2. Bấm **nút bút chì** trên module cần sửa. Cửa sổ **Configure &lt;tên module&gt;** mở ra với nội dung hiện tại.
3. Sửa nội dung, bấm **Save** trong cửa sổ. Khung xem trước cập nhật ngay.
4. Tiếp tục với các module khác, ở trang này hoặc trang khác.
5. Bấm **Save Page / Save All** ở góc phải dưới để lưu lên website. Thông báo `Saved: "<tên trang>"` xác nhận đã lưu.

> Nút **Save** trong cửa sổ module cập nhật khung xem trước. Nút **Save Page** lưu lên website. Hãy bấm **Save Page** trước khi rời màn hình.

**Các loại ô nhập**

| Loại ô | Cách dùng |
|---|---|
| **Chữ một dòng / nhiều dòng** | Tiêu đề, mô tả. Với ô ghi *"one per line"*, mỗi dòng hiển thị thành một gạch đầu dòng. |
| **Liên kết (URL)** | Đường dẫn trong website (ví dụ `/esim`) hoặc đầy đủ (`https://...`). Xem mục 8. |
| **Hình ảnh** | Bấm **Upload** để chọn file từ máy, hoặc dán đường dẫn ảnh `https://`. |
| **Biểu tượng** | Chọn trong thư viện biểu tượng có sẵn (wifi, globe, shield...), có ô tìm kiếm. |
| **Danh sách** | **+ Add** thêm một dòng, **Remove** xoá dòng. |
| **Ô chọn ✓ / ! / ✕** | Dùng cho bảng so sánh: `✓ Yes`, `! Partly`, `✕ No`. |
| **Show my text exactly as entered** | Tick để website hiển thị đúng nguyên văn chữ bạn đã nhập trong module. |

---

## 7. Hướng dẫn từng bước

### Bước 1: Mở My Website

1. Đăng nhập Partner Portal bằng email và mã OTP.
2. Bấm **My Website** trên menu trái. Trang **Home** được chọn sẵn.

### Bước 2: Thương hiệu (Brand identity)

![Brand identity](images/partner-cms/02-brand-identity.png)

| Ô | Hiển thị trên website |
|---|---|
| **Brand name** | Tiêu đề tab trình duyệt, dòng bản quyền, và mọi chỗ có `{brand}` |
| **Logo URL** + **Upload** | Đầu trang và chân trang của mọi trang |
| **Primary** | Nút bấm, tiêu đề nhấn, liên kết, nút thanh toán |
| **Secondary** | Các khối và thẻ nền tối |

1. Nhập **Brand name**.
2. Bấm **Upload** để tải logo (PNG/JPEG, dưới 1 MB). Logo hiện ngay trong khung xem trước.
3. Chọn màu **Primary** và **Secondary** bằng bảng màu, hoặc gõ mã hex vào ô bên cạnh.
4. Bấm **Save Page**. Thông báo `Branding saved` xác nhận đã lưu.

### Bước 3: Header và Footer

Mỗi trang có Header và Footer riêng. Hãy cấu hình giống nhau trên cả 5 trang để website đồng nhất, rồi bấm **Save All**.

**Header: menu đầu trang**

![Configure Header](images/partner-cms/06-configure-header.png)

| Ô | Mô tả |
|---|---|
| **Navigation links** | Các mục menu, mỗi mục gồm *Label* (tên hiển thị) và *URL*. Ví dụ `Travel eSIM` → `/esim`, `Install eSIM` → `/install-esim`. |

Logo trên Header lấy từ Brand identity. Nút **My Data** luôn có sẵn ở góc phải để khách mở ví dữ liệu.

**Footer: chân trang**

![Configure Footer](images/partner-cms/07-configure-footer.png)

| Ô | Mô tả |
|---|---|
| **Support email** | Email hỗ trợ, hiển thị ở dòng *Need help?* |
| **Column 1 / 2 / 3 title** + **links** | Tiêu đề và các liên kết của 3 cột chân trang |
| **Social links** | Biểu tượng (facebook, instagram, youtube-play, tiktok...) và đường dẫn trang mạng xã hội |
| **Locale/currency label** | Nhãn ngôn ngữ / tiền tệ, ví dụ `EN • USD — $` |
| **Copyright text** | Dòng bản quyền, ví dụ `© 2026 {brand}` |

Liên kết có URL để trống sẽ không hiển thị. Cột có mọi liên kết để trống sẽ được ẩn.

### Bước 4: Trang Home

| Module | Nội dung chỉnh được |
|---|---|
| **Header** | Bước 3 |
| **Banner** | Ảnh nền, tiêu đề, mô tả, ô tìm quốc gia, nút kêu gọi, điểm đánh giá |
| **Data Plan Section** | Tiêu đề, dòng nhấn, mô tả. Danh sách khu vực và số quốc gia hiển thị tự động. |
| **Transfer Data** | Nhãn nhỏ, tiêu đề, mô tả, 1–4 tính năng (icon, tiêu đề, mô tả), 1–4 ô nổi bật (tiêu đề, mô tả, hình) |
| **More Reasons Grid** | Tiêu đề, 3–9 lý do (icon, tiêu đề, mô tả) |
| **Video Section** | Đường dẫn video (YouTube hoặc `.mp4`), 2 dòng chữ trên video |
| **Comparison Table** | Tiêu đề, mô tả, tên 4 cột, 1–12 dòng so sánh (✓ / ! / ✕) |
| **Install Steps** | Tiêu đề, mô tả, 3–8 bước tóm tắt |
| **Reviews** | Tiêu đề, 3–9 đánh giá (tên, ngày, nội dung) |
| **FAQ** | Tiêu đề, mô tả, 1–9 câu hỏi và trả lời |
| **Recommendations** | Tiêu đề, tên 3 tab, liên kết hướng dẫn ở tab 3. Tab 1 (quốc gia phổ biến) và tab 2 (khu vực) hiển thị tự động. |
| **Footer** | Bước 3 |

**Banner**

![Configure Banner](images/partner-cms/04-configure-banner.png)

| Ô | Mô tả |
|---|---|
| **Background image** | Ảnh nền banner, bấm **Upload** để tải ảnh |
| **Title / Subtitle** | Tiêu đề lớn và câu mô tả |
| **Search label / Search placeholder** | Nhãn và chữ gợi ý của ô tìm quốc gia. Để trống placeholder thì hiển thị *"Search N+ countries"* theo số quốc gia thật. |
| **CTA button text / CTA link** | Chữ và đường dẫn của nút kêu gọi. Để trống chữ thì banner không có nút. |
| **Rating value / Rating note** | Điểm đánh giá và câu đi kèm |

**FAQ**

![Configure FAQ](images/partner-cms/05-configure-faq.png)

Mỗi dòng gồm *Question* và *Answer*. Bấm **+ Add Question** để thêm câu hỏi.

### Bước 5: Trang Plan Detail

Trang chi tiết gói của từng quốc gia / khu vực, ví dụ `/plans/japan-esim`.

![Configure Plan Detail Hero](images/partner-cms/08-configure-plan-detail-hero.png)

| Module | Nội dung chỉnh được |
|---|---|
| **Plan Detail Hero** | Tiêu đề trang (dùng `{country}`: `{country} eSIM` hiển thị thành *Japan eSIM*), điểm đánh giá, 2 tab loại gói (tên, nhãn, danh sách tính năng), 3–4 thẻ tính năng |
| **Sticky Checkout Bar** | Chữ trên nút thanh toán. Tên gói và giá hiển thị tự động theo gói khách chọn. |

### Bước 6: Trang Install eSIM

Trang hướng dẫn cài eSIM, gồm 2 tab **iOS** và **Android**.

![Configure Install eSIM Guide](images/partner-cms/09-configure-install-guide.png)

| Ô | Mô tả |
|---|---|
| **Heading / Subtext** | Tiêu đề và mô tả đầu trang |
| **iOS tab label / Android tab label** | Tên hai tab |
| **Step label** | Chữ đứng trước số bước, ví dụ `Step` → *Step 1, Step 2…* |
| **iOS steps / Android steps** | 1–8 bước cho mỗi hệ điều hành. Mỗi bước gồm tiêu đề, gạch đầu dòng (mỗi dòng một ý) và tối đa 4 hình minh hoạ |

### Bước 7: Trang Data Balance

Trang "My Data", nơi khách xem gói và dung lượng còn lại.

![Configure Data Balance Screen](images/partner-cms/10-configure-data-balance.png)

| Module | Nội dung chỉnh được |
|---|---|
| **Data Balance Screen** | Tên trang, tên tab *My Plans* / *History*, nội dung khi khách chưa có gói, chữ liên kết *How to install eSIM*, chữ nút *Buy more data*. Gói, dung lượng và lịch sử của khách hiển thị tự động. |
| **Data & eSIM Information** | Tiêu đề, danh sách quyền lợi gói Fixed (3–8) và gói Unlimited (3–8) |

### Bước 8: Lưu và kiểm tra

1. Bấm **Save Page / Save All (N pages)**, chờ thông báo `Saved: …`.
2. Mở website và tải lại trang. Nội dung mới hiển thị sau khoảng 1 phút.

![Website sau khi cấu hình](images/partner-cms/13-storefront-home.png)

---

## 8. Liên kết trong website

| Đường dẫn | Trang |
|---|---|
| `/` | Trang chủ |
| `/esim` | Danh sách gói theo quốc gia / khu vực |
| `/plans/<quốc-gia>-esim` | Chi tiết gói, ví dụ `/plans/japan-esim`, `/plans/global-esim` |
| `/checkout` | Thanh toán |
| `/data-balance` | Ví dữ liệu "My Data" |
| `/install-esim` | Hướng dẫn cài eSIM. Thêm `?platform=ios` hoặc `?platform=android` để mở sẵn tab. |

- Liên kết tới website khác: nhập đường dẫn đầy đủ `https://...`. Có thể dùng `mailto:` và `tel:`.
- Khi nhập một đường dẫn nội bộ không có trong bảng trên, CMS hiển thị gợi ý màu cam ngay dưới ô.

---

## 9. Hình ảnh

| Loại | Định dạng | Dung lượng tối đa |
|---|---|---|
| Logo | PNG, JPEG | 1 MB |
| Hình trong module (banner, ô nổi bật, hướng dẫn cài) | PNG, JPEG | 5 MB |

Ảnh tải lên qua nút **Upload** được lưu trữ riêng cho website của bạn.

---

## 10. Dữ liệu hiển thị tự động

Các phần sau luôn lấy **dữ liệu thật** từ hệ thống, để khách thấy đúng giá và đúng tình trạng gói:

- Danh sách quốc gia, khu vực và số quốc gia
- Gói data, dung lượng, giá
- Quốc gia phổ biến và khu vực trong **Recommendations**
- Tên gói và giá trên thanh thanh toán
- Gói, dung lượng và lịch sử trong **My Data**

---

## 11. Phạm vi và bảo mật

- Mỗi partner chỉ xem và chỉnh **website của chính mình**.
- Chỉnh sửa của partner không ảnh hưởng tới website của partner khác hay template gốc.
- Thêm, xoá hoặc đổi thứ tự module do Admin thực hiện (file 01).

---

## 12. Checklist hoàn tất

- [ ] Brand name, logo, màu chính / phụ đã đúng bộ nhận diện
- [ ] Header và Footer đồng nhất trên cả 5 trang
- [ ] Email hỗ trợ và liên kết mạng xã hội là của thương hiệu bạn
- [ ] Nội dung trang Home (banner, giới thiệu, đánh giá, FAQ) đã cập nhật
- [ ] Trang Plan Detail, Install eSIM, Data Balance đã cập nhật
- [ ] Đã bấm **Save Page / Save All** và thấy thông báo `Saved: …`
- [ ] Đã mở website trên máy tính và điện thoại, kiểm tra 5 trang và các liên kết

---

## Phụ lục: Module theo trang

| Trang | Module (theo thứ tự hiển thị) |
|---|---|
| **Home** | Header → Banner → Data Plan Section → Transfer Data → More Reasons Grid → Video Section → Comparison Table → Install Steps → Reviews → FAQ → Recommendations → Footer |
| **Plan Detail** | Header → Plan Detail Hero → Sticky Checkout Bar → Footer |
| **Checkout** | Header → Footer (form thanh toán do hệ thống cung cấp) |
| **Data Balance** | Header → Data Balance Screen → Data & eSIM Information → Footer |
| **Install eSIM** | Header → Install eSIM Guide (iOS / Android) → Footer |
