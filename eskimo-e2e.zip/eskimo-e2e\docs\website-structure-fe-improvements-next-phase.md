# Website Structure (Admin): đề xuất cải thiện FE cho phase sau

| | |
|---|---|
| **Gửi** | Team FE (Admin Portal `eskimo_portal`) |
| **Nguồn** | QC ticket ESKIMO-751 / EP-5963 (retest 15/10/2026, 14/14 pass trên Admin QA) và quá trình viết guideline cho khách (`01-website-structure-setup-guide.md`) |
| **Phiên bản kiểm tra** | Admin QA `main.2f97a0b4` / editor `11.49faa268`, Admin staging `main.94dcccdd` / editor `11.e3bedc99` (16/10/2026), source `develop` 13/10/2026 |
| **Ngày** | 16/10/2026 |

Mức ưu tiên:
- **P1**: admin dễ mất dữ liệu, hoặc website của partner hiển thị sai.
- **P2**: gây nhầm, phải giải thích dài trong guideline.
- **P3**: tiện ích, nên có.

Các mục bên dưới là những chỗ guideline cho khách đã **bỏ qua hoặc diễn đạt né đi**, vì guideline chỉ trình bày tính năng. Sửa xong mục nào thì cập nhật guideline mục đó.

---

## Tóm tắt

| ID | Ưu tiên | Vấn đề | Đề xuất ngắn |
|---|---|---|---|
| WS-01 | P1 | Close / X khi chưa lưu là mất hết thay đổi, không hỏi lại | Hộp xác nhận khi còn thay đổi chưa lưu |
| WS-02 | P1 | Footer vẫn kéo thả được, có thể nằm giữa trang | Khoá Footer ở cuối trang giống Header |
| WS-03 | P2 | Module mới thêm vào **dưới Footer** | Chèn module mới ngay **trên Footer** |
| WS-04 | P2 | Nút Clone tạo bản nháp ngay, không xác nhận; bấm nhiều lần thì ra nhiều bản | Modal xác nhận khi Clone, khoá nút khi đang gửi |
| WS-05 | P2 | Template System Default lưu được mà không cảnh báo | Template chỉ xem, hoặc xác nhận trước khi lưu |
| WS-06 | P2 | Modal Assign ẩn partner không hợp lệ mà không nói lý do | Ghi chú điều kiện ngay trong modal |
| WS-07 | P2 | Xoá website chỉ có popconfirm nhỏ, dù mất cả nội dung partner | Xác nhận mạnh hơn, nêu rõ partner bị ảnh hưởng |
| WS-08 | P2 | Module `downloadApp` đã ngưng dùng vẫn còn trong template và các website | Migrate xoá khỏi template + website hiện có |
| WS-09 | P3 | Tên module trong thư viện chưa khớp với AC / còn chữ "Eskimo" | Thống nhất nhãn |
| WS-10 | P3 | Canvas đôi khi trống khi API trả rỗng | Trạng thái lỗi + nút thử lại |
| WS-11 | P3 | Website mới luôn Inactive, UI không gợi ý bước bật | Tooltip / nhắc trên dòng website |
| OPS-01 | P2 | Admin QA và staging chạy hai bản khác nhau | Deploy cùng phiên bản trước khi giao guideline |

---

## Chi tiết

### WS-01 (P1): Đóng editor khi chưa lưu là mất thay đổi

- **Hiện tại:**
  - Nút **Close** và dấu **X** gọi thẳng `onClose`, không kiểm tra thay đổi chưa lưu.
  - Admin chỉnh nhiều trang (thêm, xoá, kéo thả) rồi lỡ bấm Close là mất hết, không có hộp xác nhận.
- **Ảnh hưởng:** guideline phải cảnh báo "lưu trước khi đóng". Thao tác cấu trúc trên 5 trang dễ mất công làm lại.
- **Đề xuất:**
  - Khi còn trang dirty, Close / X / bấm mask hiện xác nhận: "You have unsaved changes on N page(s). Close without saving?"
  - Dùng chung cơ chế với CMS-01 (Partner CMS) vì cùng component.
- **Code:** [WebsiteStructureEditor.js](../../eskimo_portal/src/pages/WhiteLabel/StructureEditor/WebsiteStructureEditor.js) dòng 253 (`onClose` của Drawer), dòng 259 (nút Close).

### WS-02 (P1): Footer vẫn kéo thả được

- **Hiện tại:**
  - Bản staging (`11.e3bedc99`) đã khoá **Header**: `isDragDisabled` khi `type === "header"`, và sau mỗi lần kéo luôn đưa Header lên đầu.
  - **Footer** chưa được khoá. Admin có thể kéo Footer lên giữa trang, hoặc kéo module khác xuống dưới Footer.
  - Bản QA (`11.49faa268`) chưa khoá cả Header lẫn Footer.
- **Ảnh hưởng:** website partner có Footer nằm giữa trang. Guideline phải thêm bước kiểm tra "Footer ở cuối mỗi trang".
- **Đề xuất:**
  - Khoá Footer giống Header: `isDragDisabled` khi `type === "footer"`.
  - Sau mỗi lần kéo thả, sắp lại theo thứ tự `header` → module khác → `footer`.
  - Đồng bộ lên bản QA.
- **Code:** `onDragEnd` WebsiteStructureEditor.js dòng 136. Trong bundle staging, logic khoá Header là hàm `he` / `je`.

### WS-03 (P2): Module mới thêm vào dưới Footer

- **Hiện tại:** `handleAddModule` nối module mới vào **cuối** danh sách (`[...activePage.modules, newModule]`), tức là nằm dưới Footer. Admin luôn phải kéo lên.
- **Đề xuất:** chèn trước module `footer` nếu có, giống cách hàm chèn module bắt buộc theo trang đang làm (`findIndex(type === "footer")`).
- **Code:** WebsiteStructureEditor.js dòng 110–113.

### WS-04 (P2): Clone tạo bản nháp ngay, không xác nhận

- **Hiện tại:**
  - Nút **Clone** gọi `cloneTemplateToWebsiteDraft` ngay khi bấm. Không có modal, nút không khoá trong lúc gửi request.
  - Bấm 2 lần thì tạo 2 bản nháp.
  - Nút Clone luôn clone template **System Default**, kể cả khi sau này có thêm template khác.
- **Đề xuất:**
  - Modal "Create website" để chọn template nguồn và partner (không bắt buộc, gộp bước Assign), có nút xác nhận.
  - Khoá nút trong lúc request chạy.
- **Code:** [WhiteLabelTemplates.js](../../eskimo_portal/src/pages/WhiteLabel/Templates/WhiteLabelTemplates.js) dòng 53–55 (`handleClone`), dòng 136.

### WS-05 (P2): Template System Default lưu được mà không cảnh báo

- **Hiện tại:**
  - **Edit Structure** trên template mở cùng editor, có nút Save Page như website.
  - Lưu sẽ đổi cấu trúc cho mọi website **clone sau này**, nhưng UI không báo gì.
  - Guideline phải khuyến nghị "chỉ xem, không lưu".
- **Đề xuất (chọn 1):**
  - (a) Template mở ở chế độ chỉ xem. Muốn sửa template thì cần quyền riêng.
  - (b) Giữ quyền sửa, nhưng hiện banner "You are editing the System Default template — changes apply to websites created from now on", kèm xác nhận khi Save.

### WS-06 (P2): Modal Assign không nói vì sao thiếu partner

- **Hiện tại:**
  - Ô Partner chỉ tìm partner `partnerType: 4` (Corporate Program bật) và bỏ các partner đã có website.
  - Partner không thoả điều kiện bị ẩn hoàn toàn. Ô chỉ báo *No available partner*.
  - QC từng mất thời gian vì partner test có Corporate Program bị tắt.
- **Đề xuất:**
  - Dòng ghi chú dưới ô: "Only partners with Corporate Program (White label) ON and without a website are listed."
  - Khi tìm theo tên mà khớp một partner không hợp lệ, hiện mờ (disabled) kèm lý do ("Corporate Program is off" / "Already has a website").
- **Code:**
  - [WhiteLabelAssignPartnerModal.js](../../eskimo_portal/src/pages/WhiteLabel/Templates/WhiteLabelAssignPartnerModal.js) dòng 51, 65, 121;
  - [whiteLabelApi.js](../../eskimo_portal/src/pages/WhiteLabel/whiteLabelApi.js) dòng 28.

### WS-07 (P2): Xoá website chỉ có popconfirm nhỏ

- **Hiện tại:**
  - Popconfirm `Delete "<name>"?`.
  - Xoá là mất luôn toàn bộ nội dung và branding partner đã nhập trên Partner CMS. Partner Portal của họ báo *No website has been assigned to you yet*.
  - Không hoàn tác được.
- **Đề xuất:**
  - Modal xác nhận nêu rõ partner bị ảnh hưởng ("Partner X will lose their website and all CMS content").
  - Bắt gõ lại tên website, hoặc ít nhất là nút danger thứ hai.
  - Cân nhắc soft-delete hoặc chuyển về Inactive trước.
- **Code:** WhiteLabelTemplates.js dòng 152–159.

### WS-08 (P2): Module `downloadApp` đã ngưng dùng vẫn còn

- **Hiện tại:**
  - Template System Default (và mọi website clone từ nó) vẫn có module `downloadApp` trên trang Home.
  - Module này không có trong thư viện, và storefront không hiển thị.
  - Bản QA / staging hiện nhãn thô `downloadApp`. Source `develop` đã có ghi chú "This section type is no longer used… Remove it."
  - Số module Admin và Partner lệch nhau: Home 13 với 12 (xem CMS-17).
- **Đề xuất:** migrate phía BE để xoá `downloadApp` khỏi template và các website hiện có. Sau đó bỏ cả nhánh hiển thị retired.
- **Code:** WebsiteStructureEditor.js dòng 227, 352 (`RETIRED_MODULE_TYPES`).

### WS-09 (P3): Nhãn module chưa thống nhất

- **Hiện tại:**
  - AC1 ví dụ "Product section", nhưng thư viện không có module tên này. Phần sản phẩm là *Data Plan Section (Global + Regions)* và *Plan Detail Hero*.
  - Nhãn *Transfer Data (Why Eskimo eSIM)* còn chữ "Eskimo" (trùng CMS-10).
- **Đề xuất:**
  - Nhãn trung tính, kèm mô tả ngắn trong menu + Add Section, ví dụ "Data Plan Section — product list by country/region".
  - Cập nhật AC hoặc guideline cho khớp.
- **Code:** [ModuleTypes.js](../../eskimo_portal/src/pages/WhiteLabel/StructureEditor/ModuleTypes.js).

### WS-10 (P3): Canvas trống khi API trả rỗng

- **Hiện tại:**
  - Stage API đôi khi trả HTTP 200 với body rỗng (đo được trên endpoint detail lớn).
  - Editor khi đó hiện canvas trống, không báo lỗi. Admin phải đóng, F5, mở lại.
  - Spec e2e phải tự retry.
- **Đề xuất:** khi detail không có `pages`, hiện trạng thái lỗi "Couldn't load the website structure" kèm nút **Retry**. Không render editor rỗng.

### WS-11 (P3): Website mới luôn Inactive

- **Hiện tại:**
  - Website clone mặc định `Inactive`. Admin phải tự nhớ gạt Active sau khi dựng xong.
  - UI không giải thích Inactive nghĩa là gì: storefront không phục vụ công khai.
- **Đề xuất:** tooltip trên công tắc Status ("Inactive: the partner's storefront is not live"), và badge "Draft — not live" trên dòng website mới.

---

## Ngoài phạm vi FE

### OPS-01 (P2): Admin QA và staging chạy hai bản khác nhau

- **Hiện tại (16/10/2026):**

  | | Admin QA (`11.49faa268`) | Admin staging (`11.e3bedc99`) |
  |---|---|---|
  | Khoá kéo thả Header | chưa | có |
  | Nút **Config** (Custom domain, Email sender) | có | có |
  | Modal Assign có ô tìm theo tên | có | có |

  Staging đang **mới hơn** QA về editor. Guideline mô tả theo bản staging.

- **Ảnh hưởng:** guideline phải chọn mô tả theo một bản. Khách dùng bản còn lại sẽ thấy giao diện khác tài liệu.
- **Đề xuất:** deploy cùng phiên bản lên QA và staging trước khi giao guideline cho khách. Kiểm tra lại guideline sau khi deploy.
