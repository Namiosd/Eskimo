// ESKIMO-910 shared post-purchase checks (retest 2026-10-27): for every storefront order
//   1) order number PUR-PN… on the complete page, 2) customer paid = listed price,
//   3) member Data Purchase: WHI linked to the PUR order, 4) Eskimo Sales (eskimoTransactionType 4): the WHI record
//      (member, plan, status, Value = listed x rule %), 5) receipt email on yopmail: one "... Data Plan Purchase" mail
//      per WHI, with the plan and Total Amount = paid.
import type { Page, TestInfo } from "@playwright/test";
import { api } from "../_support/whitelabel";
import { membersByEmail } from "../_support/wellatsea";
import { openInbox, listMails, readMail, refreshInbox, yopmailBrowser } from "../_support/yopmail";

export type PaidOrder = { key: string; orderNumber: string; listedPrice: number; expectedPct: number; expectedRule: string; areaRe: RegExp; data: string; error?: string };
export type OrderCheck = {
  key: string; orderNumber: string; whi: string; listed: number; paid: number; value: number; expectedPct: number; expectedRule: string; expectedFee: number;
  appliedPct: number; sale: { found: boolean; value?: number; member?: string; plan?: string; status?: number; type?: number };
  mail: { status: "ok" | "missing" | "blocked" | "mismatch"; count: number; subject?: string; total?: number; plan?: string; note?: string };
  checks: Record<string, boolean>; ok: boolean; error?: string;
};

const r2 = (n: number) => Math.round(n * 100) / 100;
const orderOf = (x: any) => String(x.relatedTransaction?.metadata?.id ?? "");

/** Ids of the mails already in the inbox (call BEFORE the purchases). */
export async function snapshotMailIds(email: string) {
  const b = await yopmailBrowser();
  try {
    const p = await openInbox(await b.newContext(), email);
    return (await listMails(p)).map((m) => m.id);
  } catch (e) { console.log("[ESKIMO-910 mail] snapshot failed: " + String(e).split("\n")[0]); return null; } finally { await b.close(); }
}

/** Wait for every paid order's WHI, read Eskimo Sales + receipt emails, return one check per order. */
export async function verifyOrders(token: string, email: string, orders: PaidOrder[], seenMailIds: string[] | null,
  shot?: (page: Page, title: string, steps: string[], expected: string[], ok: boolean) => Promise<unknown>): Promise<OrderCheck[]> {
  const member = (await membersByEmail(token, email))[0];
  if (!member) throw new Error("Environment: member " + email + " not found");
  const paid = orders.filter((o) => !o.error && o.orderNumber);
  // 1) member Data Purchase -> WHI per PUR order
  let dp: any[] = [];
  for (const deadline = Date.now() + 300000; Date.now() < deadline;) {
    const r = await api(token, "POST", "/api/membership/Details/DataPurchase", { pageIndex: 1, pageSize: 100, id: member.id, isAscending: false, searchText: "" });
    dp = r.json?.data?.data ?? [];
    if (paid.every((o) => dp.some((w) => orderOf(w) === o.orderNumber))) break;
    await new Promise((res) => setTimeout(res, 10000));
  }
  // 2) receipt emails (new since the snapshot), keyed by the WHI found in the body
  const receipts = new Map<string, { subject: string; total: number; plan: string; text: string }[]>();
  let mailBlocked = "";
  if (seenMailIds) {
    const b = await yopmailBrowser();
    try {
      const page = await openInbox(await b.newContext(), email);
      const seen = new Set(seenMailIds);
      // receipt "Transaction ID" = PUR order number (since 2026-10-26; older template printed WHI) -> key receipts by PUR
      const wanted = paid.map((o) => o.orderNumber);
      const keyOf = (id: string) => (/^WHI-/.test(id) ? orderOf(dp.find((w) => w.transactionID === id) ?? {}) || id : id);
      const read = new Set<string>();
      for (const deadline = Date.now() + 420000; Date.now() < deadline;) {
        for (const m of (await listMails(page)).filter((m) => !seen.has(m.id) && !read.has(m.id) && /Data Plan Purchase/i.test(m.subject))) {
          read.add(m.id);
          const c = await readMail(page, m.id);
          const txRef = (c.text.match(/PUR-PN\d+-\d+-\d+|WHI-\d{6}-\d+/) ?? [])[0] ?? "";
          const key = txRef ? keyOf(txRef) : "";
          const total = Number((c.text.match(/Total Amount[^\d]*([\d.,]+)/i) ?? [])[1]?.replace(/,/g, "") ?? NaN);
          const plan = ((c.text.match(/Data Plan\s*:?\s*\n?\s*([^\n]+)/i) ?? [])[1] ?? "").trim();
          if (key) receipts.set(key, [...(receipts.get(key) ?? []), { subject: m.subject, total, plan, text: c.text }]);
          if (shot && key && wanted.includes(key)) await shot(page, "Receipt email " + txRef, ["Subject: " + m.subject, "Transaction ID: " + txRef, "Data Plan: " + plan, "Total Amount: " + total], ["One receipt per order: plan + Total Amount = paid"], true);
        }
        if (wanted.every((w) => receipts.has(w))) break;
        await page.waitForTimeout(15000);
        await refreshInbox(page);
      }
    } catch (e) { mailBlocked = String(e).split("\n")[0]; } finally { await b.close(); }
  } else mailBlocked = "inbox snapshot failed before the purchases";

  // 3) per order: Data Purchase + Eskimo Sales + email
  const out: OrderCheck[] = [];
  for (const o of orders) {
    const w = o.error ? undefined : dp.find((x) => orderOf(x) === o.orderNumber);
    const whi = w?.transactionID ?? "";
    const paidAmt = w ? Number(w.relatedTransaction?.metadata?.total) : NaN;
    const value = w ? Number(w.value) : NaN;
    const expectedFee = r2((o.listedPrice * o.expectedPct) / 100);
    const appliedPct = Number.isFinite(value) && o.listedPrice > 0 ? Math.round((value / o.listedPrice) * 1000) / 10 : NaN;
    let sale: OrderCheck["sale"] = { found: false };
    if (whi) {
      const s = await api(token, "POST", "/api/data-plan-sale-transaction/search", { pageIndex: 1, pageSize: 10, type: 1, amountId: null, platformFilter: "", eskimoTransactionType: 4, cashbackFilter: 0, paymentMethodFilter: null, searchText: whi, searchPlanName: "", fromDate: null, toDate: null, sortBy: { fieldName: "PurchaseDate", ascending: false } });
      const rec = (s.json?.data?.data ?? []).find((x: any) => x.transactionId === whi);
      if (rec) sale = { found: true, value: Number(rec.value), member: rec.memberName + " / " + rec.memberId, plan: rec.dataPlanName, status: rec.status, type: rec.eskimoTransactionType };
    }
    const mails = o.orderNumber ? receipts.get(o.orderNumber) ?? [] : [];
    const mail: OrderCheck["mail"] = mailBlocked && !mails.length ? { status: "blocked", count: 0, note: mailBlocked }
      : !mails.length ? { status: "missing", count: 0 }
      : { status: Math.abs(mails[0].total - paidAmt) <= 0.01 && mails.length === 1 ? "ok" : "mismatch", count: mails.length, subject: mails[0].subject, total: mails[0].total, plan: mails[0].plan };
    const checks: Record<string, boolean> = {
      "order PUR-PN…": /^PUR-PN\d+-/.test(o.orderNumber),
      "WHI linked to order": !!whi,
      "paid = listed price": Math.abs(paidAmt - o.listedPrice) <= 0.01,
      "Value = listed x rule %": Math.abs(value - expectedFee) <= 0.02,
      "Eskimo Sales record (type 4, success, same member)": sale.found && sale.type === 4 && sale.status === 1 && String(sale.member).includes(String(member.id)),
      "Eskimo Sales Value = Data Purchase Value": sale.found && Math.abs((sale.value ?? NaN) - value) <= 0.01,
      "receipt email (1, total = paid)": mail.status === "ok",
    };
    const ok = !o.error && Object.entries(checks).every(([k, v]) => v || (k.startsWith("receipt") && mail.status === "blocked"));
    out.push({ key: o.key, orderNumber: o.orderNumber, whi, listed: o.listedPrice, paid: paidAmt, value, expectedPct: o.expectedPct, expectedRule: o.expectedRule, expectedFee, appliedPct, sale, mail, checks, ok, error: o.error });
  }
  return out;
}

export function ordersTableHtml(rows: OrderCheck[], esc: (s: unknown) => string) {
  const head = ["Order", "PUR", "WHI", "Listed", "Paid", "Expected rule", "Value / expected", "Eskimo Sales", "Receipt email", "Result"];
  const cell = (c: OrderCheck) => [c.key, c.orderNumber || c.error || "-", c.whi || "-", "$" + c.listed, "$" + c.paid,
    c.expectedRule + " " + c.expectedPct + "%", "$" + c.value + " (" + c.appliedPct + "%) / $" + c.expectedFee,
    c.sale.found ? "$" + c.sale.value + " · " + c.sale.plan + " · status " + c.sale.status : "NOT FOUND",
    c.mail.status + (c.mail.count ? " ×" + c.mail.count + " · $" + c.mail.total + " · " + (c.mail.subject ?? "") : c.mail.note ? " (" + c.mail.note + ")" : ""),
    c.ok ? "PASS" : "FAIL: " + Object.entries(c.checks).filter(([, v]) => !v).map(([k]) => k).join(", ")];
  return "<table><tr>" + head.map((h) => "<th>" + esc(h) + "</th>").join("") + "</tr>" + rows.map((r) => "<tr>" + cell(r).map((x) => "<td>" + esc(x) + "</td>").join("") + "</tr>").join("") + "</table>";
}
