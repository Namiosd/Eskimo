# Hướng dẫn thiết lập White Label: Cấu hình Corporate Program cho partner

| | |
|---|---|
| **Người thực hiện** | Admin trên Admin Portal (riêng bước kết nối Stripe do Partner làm trên Partner Portal) |
| **Màn hình** | Menu **Partnership** → **Partners** → Edit partner → mục **Corporate Program** |
| **Kết quả** | Partner được bật chương trình **White Label**: có thời hạn hoạt động, phí ứng dụng (Application Fee) của Eskimo, phương thức thanh toán, thời hạn data và chế độ gửi email cho khách. Đây là điều kiện bắt buộc để tạo website White Label cho partner. |
| **Cập nhật** | 19/10/2026 (ticket ESKIMO-757 / EP-5991) |

> Đây là **bước đầu tiên** của bộ hướng dẫn White Label. Phải làm **trước** các tài liệu còn lại:
> 0. **Cấu hình Corporate Program (White Label) cho partner** (Admin), tài liệu này
> 1. *Tạo website và quản lý cấu trúc* (Admin)
> 2. *Chỉnh nội dung và thương hiệu (Partner CMS)* (Partner)
> 3. *Cấu hình tên miền, email gửi và thanh toán*
> 4. *Customer Journey: khách mua và dùng eSIM*

---

## 1. Khái niệm cần biết

| Khái niệm | Ý nghĩa |
|---|---|
| **Partner** | Đối tác bán eSIM dưới thương hiệu riêng của họ (White Label). Mỗi partner có một **Partner ID** dạng `PNxxxxxx`. |
| **Corporate Program** | Chương trình hợp tác gắn với partner. Có 3 loại (**Type**): *Corporate*, *White label*, *Reseller*. Tài liệu này chỉ nói về **White label**. |
| **Thời hạn chương trình** | Khoảng **Start Date → End Date**. Ngoài khoảng này, chương trình tự ngưng. |
| **Application Fee** | Phần trăm trên **giá gói data** mà **Eskimo** nhận cho mỗi đơn hàng. Phần còn lại là lợi nhuận của partner (Partner Benefit). |
| **Stripe Connect** | Tài khoản Stripe riêng của partner, kết nối với Eskimo. Tiền khách trả đi vào tài khoản này (Direct Charge); Eskimo nhận Application Fee. |
| **Eskimo Email Notification** | Quy định **ai** gửi email cho khách (xác nhận mua hàng, mã QR eSIM…): Eskimo hay partner. |

> **Phân chia trách nhiệm**
> - **Admin** (tài liệu này): bật chương trình, đặt thời hạn, phí, phương thức thanh toán, thời hạn data, chế độ email.
> - **Partner**: tự kết nối **Stripe** trên Partner Portal (mục 7). Admin chỉ **xem** trạng thái, không kết nối thay được.

---

## 2. Điều kiện trước khi bắt đầu

1. Tài khoản Admin có quyền vào **Partnership › Partners**.
2. Đã có thông tin partner: tên, email đăng nhập Partner Portal, mã giới thiệu (Referral Code), người phụ trách (Assigned To), nguồn khách (Source Of Lead).
3. Đã thống nhất với partner: **thời hạn** hợp tác, **Application Fee (%)**, ai gửi **email** cho khách.

---

## 3. Tổng quan quy trình

```
Bước 1  Tạo partner (nếu chưa có)     Partners › New Partner → điền thông tin → Ok → Confirm
   │
   ▼
Bước 2  Bật Corporate Program         Status ON → Type = White label → Start / End Date
   │                                  → Eskimo Email Notification → Lifetime Account Limit
   │                                  → Payment method = Direct Charge → (Data Expiry cố định 2 Years) → Ok
   ▼
Bước 3  Partner kết nối Stripe        Partner Portal › My Website → Connect Stripe → hoàn tất trên Stripe
   │                                  (Admin thấy Stripe Connect Status: Not Connected → … → Verified)
   ▼
Bước 4  Đặt Application Fee           Edit partner → Application Fee Percentage → Ok
   │                                  (chỉ lưu được SAU khi partner đã bắt đầu kết nối Stripe)
   ▼
Bước 5  Kiểm tra                      Mở lại partner, đối chiếu từng giá trị (mục 10)
   │
   ▼
Tiếp theo                             Tạo website cho partner (file 1)
```

> **Vì sao Application Fee làm sau Stripe?** Hệ thống chỉ lưu phí khi partner **đã bắt đầu** kết nối Stripe. Nếu đặt phí trước, partner vẫn được lưu nhưng phí thì không, kèm thông báo: *"Partner saved, but the Application Fee was not: Stripe onboarding has not been started for this partner"*. Xem mục 8.4.

---

## 4. Bước 1: Tạo partner mới (bỏ qua nếu partner đã có)

1. Vào **Partnership › Partners**, bấm **New Partner** (góc phải trên).
2. Cửa sổ **New Partner** mở ra. **Partner ID** được hệ thống cấp sẵn (ví dụ `PN539084`).
3. Điền phần **Partner Configuration**:

| Trường | Bắt buộc | Ghi chú |
|---|---|---|
| **Referral Code** | Có | Chỉ chữ và số, **không có khoảng trắng**. **Không sửa được sau khi tạo.** |
| **Status** | — | Mặc định *Pending*. Chọn **Active** để partner dùng được. Khi Status khác *Pending*, các trường có dấu * trở thành bắt buộc. |
| **Partner Name** | Có | Tối đa 50 ký tự. |
| **Partner Email** | Có | Email partner dùng để đăng nhập **Partner Portal**. |
| **Assigned To** | Có | Người phụ trách partner (chọn được nhiều). |
| **Source Of Lead** | Có | Nguồn khách hàng. |

4. Cuộn sang mục **Corporate Program** và làm tiếp **Bước 2** ngay trong cửa sổ này (có thể bật luôn khi tạo).
5. Bấm **Ok**. Hộp cảnh báo hiện ra: *"Once created, partner's referral code can not be changed. Are you sure want to continue?"*. Bấm **Confirm**.
6. Thông báo **CREATE SUCCESS**, partner xuất hiện trong danh sách.

![Tạo partner mới, Corporate Program Type = White label](images/corporate-program/01-new-partner-white-label.png)

---

## 5. Bước 2: Bật Corporate Program với Type = White label

Mở partner: **Partnership › Partners** → tìm theo tên → bấm nút **Edit** (bút chì) trên dòng partner → cửa sổ **Partner Detail** → cuộn tới mục **Corporate Program** (cột phải).

![Corporate Program của một partner White Label đã cấu hình xong](images/corporate-program/02-corporate-program-verified.png)

### 5.1 Status

Gạt công tắc **Status** sang **ON**. Các trường cấu hình bên dưới hiện ra.

### 5.2 Type

Chọn **White label** trong ô **Type**.

> ⚠️ **Type không đổi được sau khi lưu.** Ô Type sẽ bị khoá (màu xám), với ghi chú *"Type can not be edited after corporate program confirmed"*. Kiểm tra kỹ trước khi bấm Ok.

Khi chọn **White label**, form tự đổi so với loại *Corporate*:
- Hiện thêm **Eskimo Email Notification**, **Stripe Connect Status**, **Payment method**, **Data Expiry**.
- Mục *Discount Benefit* đổi thành **Application Fee Percentage**.
- **Network Partner Commission (%) không hiển thị**, vì không áp dụng cho White Label.

### 5.3 Start Date và End Date

| Trường | Quy tắc |
|---|---|
| **Start Date** | Bắt buộc, định dạng `DD/MM/YYYY`. Sau khi chương trình đã bắt đầu, ô này bị **khoá**. |
| **End Date** | Bắt buộc. Phải **sau Start Date** và **không chọn được ngày trong quá khứ**. Có thể gia hạn bất cứ lúc nào. |

> Chương trình chỉ hoạt động trong khoảng **Start Date → End Date** (xem mục 9).

### 5.4 Eskimo Email Notification

Công tắc **True / False**, **mặc định OFF (False)**.

| Giá trị | Ai gửi email cho khách | Email gồm |
|---|---|---|
| **ON (True)** | **Eskimo** | Xác nhận mua hàng (receipt), mã QR eSIM / hướng dẫn cài đặt, các email liên quan khác |
| **OFF (False)** | **Partner tự gửi** | Eskimo **không** gửi bất kỳ email nào cho khách của chương trình White Label này |

> Nếu để **OFF**, partner phải tự có quy trình gửi QR eSIM và xác nhận đơn cho khách. Nếu không, khách mua xong sẽ không nhận được gì qua email.

### 5.5 Lifetime Account Limit

Hiển thị dạng **`<đã dùng> / <tối đa>`**, ví dụ `0 / 100`.
- Nhập **số tài khoản tối đa** (Max Lifetime Accounts): số nguyên dương, nhỏ hơn 100.000. Bắt buộc.

### 5.6 Payment method

Phase 1 chỉ có một lựa chọn: **Direct Charge**.

| Lựa chọn | Ý nghĩa | Phase 1 |
|---|---|---|
| **Direct Charge** | Khách thanh toán qua **tài khoản Stripe Connect của partner**. Eskimo nhận phần Application Fee. | ✅ Dùng |
| *Eskimo Stripe Pay* | Khách thanh toán qua tài khoản Stripe của Eskimo | Ẩn ở phase 1 |

Chọn **Direct Charge**.

![Payment method = Direct Charge](images/corporate-program/05-payment-method-direct-charge.png)

### 5.7 Data Expiry

Phase 1 chỉ có một lựa chọn: **2 Years**.

| Lựa chọn | Ý nghĩa | Phase 1 |
|---|---|---|
| **2 Years** | Data của khách hết hạn sau **2 năm kể từ ngày mua** | ✅ Dùng, **cố định** |
| *No Expiry* | Data không hết hạn | Hiện màu xám, **không chọn được** ở phase 1 |

Ô **Data Expiry** luôn hiện **2 Years** và không cần thao tác gì thêm.

![Data Expiry: 2 Years cố định, No Expiry màu xám](images/corporate-program/08-data-expiry.png)

### 5.8 Lưu

Bấm **Ok**. Thông báo **UPDATE SUCCESS** (hoặc **CREATE SUCCESS** nếu đang tạo mới). Mở lại partner để kiểm tra các giá trị đã lưu đúng.

> Ở bước này **chưa cần** nhập Application Fee: để trống ô **Fee** (sẽ làm ở Bước 4, sau khi partner kết nối Stripe).

---

## 6. Màn hình Corporate Program (White Label): tóm tắt các trường

| Trường | Ai chỉnh | Giá trị / quy tắc |
|---|---|---|
| Status | Admin | ON / OFF |
| Type | Admin | **White label**. Khoá sau khi lưu |
| Start Date | Admin | Bắt buộc. Khoá khi chương trình đã bắt đầu |
| End Date | Admin | Bắt buộc. Sau Start Date, không chọn ngày quá khứ |
| Eskimo Email Notification | Admin | ON / OFF, mặc định OFF |
| Stripe Connect Status | **Chỉ xem** | Do partner kết nối trên Partner Portal (mục 7) |
| Application Fee Percentage | Admin | 0 ≤ phí < 100, tối đa 2 chữ số thập phân. Để trống = mặc định 10% |
| Lifetime Account Limit | Admin | Số nguyên dương < 100.000 |
| Payment method | Admin | **Direct Charge** (phase 1) |
| Data Expiry | — | **2 Years**, cố định ở phase 1 (No Expiry hiện xám, không chọn được) |
| Network Partner Commission (%) | — | Không áp dụng, không hiển thị |

---

## 7. Bước 3: Partner kết nối Stripe (làm trên Partner Portal)

Admin **không** kết nối Stripe thay partner được. Dòng **Stripe Connect Status** trong Admin luôn có ghi chú *"The partner connects Stripe from the Partner portal (My Website)."*

**Partner thực hiện:**
1. Đăng nhập **Partner Portal** bằng Partner Email đã khai báo ở Bước 1.
2. Vào **My Website**, bấm **Connect Stripe**.
3. Hệ thống chuyển sang trang của **Stripe**. Partner khai báo thông tin doanh nghiệp, tài khoản nhận tiền và hoàn tất xác minh.
4. Nếu làm dở, quay lại **My Website** và bấm **Continue setup** để tiếp tục.

**Admin theo dõi** trạng thái ở **Stripe Connect Status**:

| Hiển thị | Ý nghĩa | Cần làm |
|---|---|---|
| **Not Connected** hoặc **—** | Partner chưa kết nối Stripe (**—** nghĩa là partner chưa từng bắt đầu kết nối) | Nhắc partner làm bước 1–3 ở trên |
| **Setup incomplete** | Partner đã bắt đầu nhưng chưa khai báo xong | Partner bấm **Continue setup** |
| **Pending verification** | Đã khai báo xong, Stripe đang xác minh | Chờ Stripe. Nếu Stripe yêu cầu thêm, partner bấm **Continue setup** |
| **Verified** | Tài khoản Stripe đã xác minh, **sẵn sàng nhận thanh toán** | Hoàn tất |
| **Disconnected** | Tài khoản Stripe đã bị ngắt khỏi Eskimo | Partner kết nối lại (**Reconnect Stripe**) |

![Stripe Connect Status = Pending verification](images/corporate-program/03-stripe-pending-verification.png)

> Trạng thái có thể mất vài phút để cập nhật sau khi Stripe xác minh xong. Mở lại partner để xem trạng thái mới nhất.

---

## 8. Bước 4: Đặt Application Fee Percentage

### 8.1 Cách nhập

1. Mở partner (Edit) → mục **Corporate Program** → phần **Application Fee Percentage**.
2. **Apply To** = *Any Data Plan* (cố định, phí áp dụng cho mọi gói data).
3. **Fee** = *Percentage (%)* (lựa chọn duy nhất).
4. Nhập phần trăm vào ô bên dưới (placeholder *"10 (default)"*).
5. Bấm **Ok**.

### 8.2 Quy tắc nhập

| Nhập | Kết quả |
|---|---|
| Từ `0` đến dưới `100`, tối đa 2 chữ số thập phân (ví dụ `20`, `12.5`, `99.99`) | Hợp lệ |
| `100` trở lên | Báo lỗi *"Fee must be at least 0 and less than 100"* |
| Nhiều hơn 2 chữ số thập phân (ví dụ `12.345`) | Báo lỗi *"Value should contain just number"* |
| Chữ hoặc số âm (ví dụ `abc`, `-5`) | Báo lỗi *"Value should contain just number"* |
| **Để trống** | Dùng phí **mặc định 10%** (*"Leave empty to use the default fee (10%)."*) |

> ⚠️ **Partner mới:** ô phí có thể được điền sẵn **0**. Nếu giữ 0, Eskimo sẽ **không thu phí**. Xoá trống (để dùng mặc định 10%) hoặc nhập đúng mức phí đã thoả thuận.

### 8.3 Cách tính

```
Application Fee (Eskimo nhận) = Giá gói data × Application Fee %
Partner Benefit (partner nhận) = Giá gói data × (100% − Application Fee %)
```

| Giá gói | Application Fee | Eskimo nhận | Partner nhận |
|---|---|---|---|
| USD 100 | 90% | USD 90 | USD 10 |
| USD 100 | 10% (mặc định) | USD 10 | USD 90 |
| USD 3.90 | 20% | USD 0.78 | USD 3.12 |

**Cảnh báo "final bill < 1":** khi nhập mức phí cao, form có thể hiện danh sách cảnh báo màu đỏ (ví dụ *"Africa 1GB final bill < 1"*).
- Hệ thống tính **giá gói × (100% − Application Fee %)**, tức **phần partner nhận (Partner Benefit)** của gói đó, và cảnh báo khi số này **dưới 1 USD**.
- Ví dụ: phí 90%, gói 4.50 USD → partner nhận 0.45 USD → gói đó hiện trong danh sách cảnh báo.
- **Khách vẫn trả đủ giá gói.** Application Fee không làm giảm giá bán. Cảnh báo chỉ nhắc Admin rằng với các gói này, phần partner nhận rất nhỏ.
- Cảnh báo **không chặn** việc lưu.

![Nhập Application Fee 90% và cảnh báo final bill < 1](images/corporate-program/04-application-fee-warning.png)

### 8.4 Thông báo thường gặp khi lưu phí

| Thông báo | Nguyên nhân | Cách xử lý |
|---|---|---|
| *"Partner saved, but the Application Fee was not: Stripe onboarding has not been started for this partner"* | Partner **chưa bắt đầu** kết nối Stripe (Stripe Connect Status = *Not Connected*) | Nhờ partner bấm **Connect Stripe** (mục 7), sau đó nhập lại phí và bấm Ok |
| **UPDATE SUCCESS** | Đã lưu cả thông tin partner và phí | Mở lại partner, kiểm tra ô phí hiện đúng giá trị |

---

## 9. Tạm ngưng và bật lại chương trình

### 9.1 Khi nào chương trình White Label **không hoạt động**

| Trường hợp | Cách xảy ra |
|---|---|
| **Status = OFF** | Admin gạt công tắc Status sang OFF |
| **Chưa tới Start Date** | Ngày hiện tại sớm hơn Start Date |
| **Đã qua End Date** | Ngày hiện tại muộn hơn End Date |

### 9.2 Điều xảy ra khi chương trình không hoạt động

- Website White Label của partner hiển thị trang **"THIS STORE ISN'T AVAILABLE — Please check back later."**
- Khách **không xem được gói data** và **không mua được**.
- Thay đổi có hiệu lực trên website trong khoảng **vài phút** (website có bộ nhớ đệm khoảng 5 phút).

![Website khi chương trình không hoạt động](images/corporate-program/07-store-unavailable.png)

### 9.3 Tạm ngưng (Disable)

1. Mở partner → **Corporate Program** → gạt **Status** sang **OFF**.
2. Hộp cảnh báo **Warning** hiện ra. Bấm **Confirm**.
3. Bấm **Ok** để lưu.

![Gạt Status sang OFF](images/corporate-program/06-status-off.png)

### 9.4 Bật lại (Re-enable)

1. Mở partner → gạt **Status** sang **ON**.
2. Bấm **Ok**. **Không cần nhập lại gì**: Type, Start Date, End Date, Application Fee, Email Notification, Payment method, Data Expiry, Lifetime Account Limit đều **giữ nguyên** như trước khi tạm ngưng.
3. Website hoạt động trở lại gần như ngay (vài giây đến vài phút).

> Muốn **gia hạn** chương trình đã hết hạn: mở partner, đổi **End Date** sang ngày mới trong tương lai rồi bấm **Ok**. Các cấu hình khác giữ nguyên.

---

## 10. Kiểm tra sau khi cấu hình

### 10.1 Trên Admin Portal

Mở lại partner (**Partnership › Partners** → Edit) và đối chiếu:

- [ ] **Status** = ON, **Type** = White label (ô Type bị khoá)
- [ ] **Start Date / End Date** đúng thời hạn hợp đồng
- [ ] **Eskimo Email Notification** đúng thoả thuận (ON = Eskimo gửi, OFF = partner tự gửi)
- [ ] **Stripe Connect Status** = **Verified**
- [ ] **Application Fee Percentage** hiện đúng mức phí (để trống = 10% mặc định)
- [ ] **Lifetime Account Limit** đúng số tối đa
- [ ] **Payment method** = Direct Charge
- [ ] **Data Expiry** = 2 Years
- [ ] **Không** có mục Network Partner Commission (%)

### 10.2 Sau đơn hàng đầu tiên (tuỳ chọn)

Khi website đã hoạt động (file 1–3) và có đơn hàng thật:
- **Admin › Transactions › Eskimo Sale**: có giao dịch mã **WHI-…** với giá trị = **giá đơn × Application Fee %**. Ví dụ phí 10%, đơn US$3.90 → giá trị **0.39**.
- Trang xác nhận của khách hiện mã đơn của partner dạng **PUR-PN…**. Hai mã PUR (đơn của partner) và WHI (phí của Eskimo) khác nhau là đúng thiết kế.
- **Email Notification = ON**: khách nhận email xác nhận mua hàng và email mã QR eSIM. **OFF**: khách không nhận email nào từ Eskimo.

---

## 11. Câu hỏi thường gặp

| Câu hỏi | Trả lời |
|---|---|
| Không đổi được **Type** | Type bị khoá sau khi lưu lần đầu. Kiểm tra kỹ trước khi bấm Ok. Nếu chọn nhầm, liên hệ đội kỹ thuật Eskimo. |
| Không sửa được **Start Date** | Start Date bị khoá khi chương trình đã bắt đầu. Chỉ **End Date** còn sửa được. |
| Không chọn được End Date trong quá khứ | Đúng thiết kế. Muốn ngưng chương trình ngay, gạt **Status = OFF**. |
| Lưu xong mà phí không được ghi nhận | Partner chưa bắt đầu kết nối Stripe (mục 8.4). Nhờ partner bấm **Connect Stripe** rồi lưu lại phí. |
| Stripe Connect Status mãi là **Not Connected** | Partner chưa vào **Partner Portal › My Website** bấm **Connect Stripe**. Admin không kết nối thay được. |
| Không thấy **Network Partner Commission (%)** | Đúng thiết kế, không áp dụng cho White Label. |
| Không thấy **Eskimo Stripe Pay**, hoặc **No Expiry** bị xám | Chưa dùng ở phase 1. Dùng **Direct Charge**; Data Expiry cố định **2 Years**. |
| Khách vẫn thấy website ngay sau khi tắt chương trình | Website có bộ nhớ đệm khoảng 5 phút. Chờ vài phút rồi tải lại. |
| Bật lại có phải cấu hình lại không | Không. Toàn bộ cấu hình được giữ nguyên. |
| Không thấy partner khi gán website (file 1) | Partner phải **bật Corporate Program với Type White label** (tài liệu này) và chưa có website nào khác. |

---

## 12. Checklist hoàn tất

- [ ] Partner đã tạo, **Status = Active**, Partner Email đúng (để partner đăng nhập Partner Portal)
- [ ] **Corporate Program** bật, **Type = White label**
- [ ] **Start Date / End Date** đúng thời hạn
- [ ] **Eskimo Email Notification** đã chọn theo thoả thuận
- [ ] **Lifetime Account Limit** đã nhập
- [ ] **Payment method = Direct Charge**, **Data Expiry = 2 Years**
- [ ] Partner đã **Connect Stripe**, **Stripe Connect Status = Verified**
- [ ] **Application Fee Percentage** đã lưu và hiển thị đúng khi mở lại
- [ ] Chuyển sang **file 1**: tạo website và gán cho partner
