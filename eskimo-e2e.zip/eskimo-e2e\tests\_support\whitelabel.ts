// White Label (Corporate Program Type = White label) helpers — EP-5991 family (ESKIMO-757, …).
// Ported from eskimo_portal e2e/admin/EP-5991-helpers.js. Selectors verified against the deployed form:
//   Corporate Program = header ".header-member-view-detail" + 2 sibling divs (switch, body);
//   fields: Type select, input#corporateStartDate / #corporateEndDate, "Eskimo Email Notification" switch,
//   "Application Fee Percentage" (input#defaultPercentCorporate), "Payment method" select, "Stripe Connect" tag.
// The effective fee is the WL website's stripeConnect.platformFeePercent (saved by PUT …/payment/connect/partners/{code}/fee).
import fs from "node:fs";
import path from "node:path";
import { expect, type Browser, type Locator, type Page } from "@playwright/test";
import { openPartnerDrawer, adminSession, PARTNER_URL } from "./eskimo";
import { WL_URL, API_URL } from "./wellatsea";

// ─── Stage API (empty-200 flakiness → retry until JSON) ───
export async function api(token: string, method: string, p: string, body?: unknown, tries = 6) {
  let last = { status: 0, json: null as any };
  for (let i = 0; i < tries; i++) {
    // Timeout: a hung stage request must not eat the whole test timeout (ESKIMO-757 TC-04, 2026-10-15)
    const r = await fetch(`${API_URL}${p}`, { method, signal: AbortSignal.timeout(30000), headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: body === undefined ? undefined : JSON.stringify(body) }).catch(() => null);
    const text = r ? await r.text().catch(() => "") : "";
    let json: any = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* not JSON */ }
    last = { status: r?.status ?? 0, json };
    if (json || (r && [401, 403, 404].includes(r.status))) return last;
    await new Promise((res) => setTimeout(res, 1000));
  }
  return last;
}
export const tokenOf = (page: Page) => page.evaluate(() => localStorage.getItem("accessToken") || "");
export const apiMessage = (j: any) => (j?.messages ?? []).map((m: any) => m.content).join("; ");

export async function findPartner(token: string, name: string) {
  const r = await api(token, "POST", "/api/partner/search", { pageIndex: 1, pageSize: 50, searchText: name, status: null, partnerType: null, type: null, sortBy: { fieldName: "CreatedOn", ascending: false } });
  const rows: any[] = r.json?.data?.data ?? [];
  const hit = rows.find((x) => String(x.partnerName).trim().toLowerCase() === name.toLowerCase());
  return hit ? { id: hit.id as string, code: (hit.partnerID ?? hit.partnerId) as string, name: hit.partnerName as string } : null;
}

export async function websites(token: string): Promise<any[]> {
  const l = await api(token, "GET", "/api/white-label/websites");
  return Array.isArray(l.json?.data) ? l.json.data : l.json?.data?.websites ?? [];
}

// ─── Corporate snapshot / diff / restore ───
export type Snap = Record<string, unknown>;
export const CORP_KEYS = ["corporateType", "corporateStartDate", "corporateEndDate", "isEskimoEmailNotificationEnabled", "paymentMethod", "maxLifetimeAccounts", "percentCorporateDiscount", "networkPartnerCommissionPercentage"];
export function snapOf(detail: any): Snap {
  const c = detail?.configuration ?? {};
  const s = c.corporateSetting ?? {};
  const extra = Object.keys(s).filter((k) => /expir/i.test(k)); // Data Expiry once the BE has it
  return Object.fromEntries([["hasCorporate", !!c.hasCorporate], ...[...CORP_KEYS, ...extra].map((k) => [k, s[k] ?? null])]);
}
export const diff = (a: Snap, b: Snap) => Object.keys(a).map((k) => ({ k, a: a[k], b: b?.[k], same: JSON.stringify(a[k] ?? null) === JSON.stringify(b?.[k] ?? null) }));

export async function readPartner(token: string, partner: { id: string; code: string }) {
  const d = await api(token, "GET", `/api/partner/v2/${partner.id}`);
  const site = (await websites(token)).find((w) => w.partnerId === partner.code);
  const det = site ? await api(token, "GET", `/api/white-label/websites/${site.id}`) : null;
  const sc = det?.json?.data?.stripeConnect ?? null;
  return { detail: d.json?.data, snap: snapOf(d.json?.data), fee: (sc?.platformFeePercent ?? null) as number | null, stripe: sc, websiteId: site?.id as string | undefined };
}

/** FE-shaped PUT body (captured from a UI save of THIS partner) with the corporate part replaced. */
export function corporateBody(feBody: any, hasCorporate: boolean, setting: any) {
  const body = JSON.parse(JSON.stringify(feBody));
  body.configuration = body.configuration || {};
  body.configuration.hasCorporate = hasCorporate;
  body.configuration.corporateSetting = JSON.parse(JSON.stringify(setting));
  return body;
}

export type PartnerState = { id: string; code: string; name: string; snapshot: Snap; setting: any; fee: number | null; feBody?: any; restored?: boolean };

/** Put the partner back to its snapshot (partner PUT + fee PUT), verified via GET; ×3. */
export async function restorePartner(token: string, s: PartnerState) {
  const notes: string[] = [];
  let now = await readPartner(token, s);
  const equal = () => diff(s.snapshot, now.snap).every((x) => x.same) && now.fee === s.fee;
  for (let i = 1; i <= 3 && !equal(); i++) {
    if (s.feBody) {
      const r = await api(token, "PUT", "/api/partner/v2", corporateBody(s.feBody, !!s.snapshot.hasCorporate, s.setting), 2);
      notes.push(`#${i} PUT partner → ${r.status} ${apiMessage(r.json)}`);
    }
    if (now.fee !== s.fee) {
      const payload = s.fee === null ? { clearOverride: true } : { platformFeePercent: s.fee, clearOverride: false };
      const r = await api(token, "PUT", `/api/payment/connect/partners/${s.code}/fee`, payload, 2);
      notes.push(`#${i} PUT fee ${JSON.stringify(payload)} → ${r.status} ${apiMessage(r.json)}`);
    }
    now = await readPartner(token, s);
  }
  return { ok: equal(), notes, now };
}

// ─── Admin drawer: Corporate Program ───
export function corporate(drawer: Locator) {
  const header = drawer.locator(".header-member-view-detail").filter({ hasText: "Corporate Program" }).first();
  return { header, statusSwitch: header.locator("xpath=following-sibling::div[1]").locator(".ant-switch").first(), body: header.locator("xpath=following-sibling::div[2]") };
}
export const isOn = (sw: Locator) => sw.evaluate((el) => el.classList.contains("ant-switch-checked"));
export const formItem = (scope: Locator, label: string) =>
  scope.locator(".ant-form-item").filter({ has: scope.page().locator(".ant-form-item-label label", { hasText: new RegExp(`^\\s*${label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*$`, "i") }) }).first();

export async function openCorporate(page: Page, partnerName: string) {
  // Staging partner list can take >30s under load → retry the whole open (reload) up to 3 times
  let opened: Awaited<ReturnType<typeof openPartnerDrawer>> | null = null;
  for (let i = 1; i <= 3 && !opened; i++) {
    opened = await openPartnerDrawer(page, partnerName).catch((e) => { if (i === 3) throw e; return null; });
  }
  const { drawer, detail } = opened!;
  const c = corporate(drawer);
  await focus(c.header);
  // The fee input is filled from stripeConnect after the "Stripe Connect" card stops loading
  await expect(drawer.getByText("Loading…")).toHaveCount(0, { timeout: 30000 }).catch(() => {});
  return { drawer, detail, ...c };
}

/** Bring a part of the drawer to the top of the viewport before an evidence shot. */
export async function focus(target: Locator) {
  await target.evaluate((el) => el.scrollIntoView({ block: "start", behavior: "instant" as ScrollBehavior }), undefined, { timeout: 5000 }).catch(() => {});
  await target.page().waitForTimeout(300);
}

export async function selectOptions(page: Page, item: Locator) {
  await item.locator(".ant-select").first().click();
  const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ state: "visible", timeout: 8000 });
  const opts = (await dd.locator(".ant-select-item-option-content").allInnerTexts()).map((t) => t.trim());
  await page.keyboard.press("Escape");
  return opts;
}
export async function choose(page: Page, item: Locator, text: string) {
  await item.locator(".ant-select").first().click();
  const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ state: "visible", timeout: 8000 });
  await dd.locator(".ant-select-item-option").filter({ hasText: new RegExp(`^\\s*${text}\\s*$`, "i") }).first().click();
}
export const selected = async (item: Locator) => (await item.locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();

export async function readCorporateForm(drawer: Locator) {
  const { body, statusSwitch } = corporate(drawer);
  const text = (await body.innerText({ timeout: 5000 }).catch(() => "")).replace(/\s+/g, " ");
  return {
    status: await isOn(statusSwitch).catch(() => null),
    type: await selected(formItem(body, "Type")),
    start: await body.locator("input#corporateStartDate").inputValue({ timeout: 2000 }).catch(() => ""),
    end: await body.locator("input#corporateEndDate").inputValue({ timeout: 2000 }).catch(() => ""),
    email: await formItem(body, "Eskimo Email Notification").locator(".ant-switch").first().evaluate((el) => el.classList.contains("ant-switch-checked"), undefined, { timeout: 2000 }).catch(() => null),
    fee: await body.locator("input#defaultPercentCorporate").inputValue({ timeout: 2000 }).catch(() => ""),
    payment: await selected(formItem(body, "Payment method")),
    dataExpiry: await selected(formItem(body, "Data Expiry")),
    // label "Stripe Connect Status"; value = first span of the vertical space (class stt-*), not an antd Tag
    stripe: (await formItem(body, "Stripe Connect Status").locator(".ant-space-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim(),
    limit: await body.locator("input#maxLifetimeAccounts").inputValue({ timeout: 2000 }).catch(() => ""),
    text,
  };
}

/** Click Ok; capture the partner PUT (+ fee PUT) and the toasts. */
export async function clickOk(page: Page, drawer: Locator) {
  const putP = page.waitForResponse((r) => /\/api\/partner\/v2(\?|$)/.test(r.url()) && ["PUT", "POST"].includes(r.request().method()), { timeout: 120000 }).catch(() => null);
  const feeP = page.waitForResponse((r) => /\/api\/payment\/connect\/partners\/.+\/fee/.test(r.url()) && r.request().method() === "PUT", { timeout: 20000 }).catch(() => null);
  await drawer.locator("button.btn-action-ok").first().click();
  const confirm = page.locator(".modal-dialog:visible").filter({ hasText: "Warning" }).getByRole("button", { name: "Confirm" });
  if (await confirm.isVisible({ timeout: 2000 }).catch(() => false)) await confirm.click();
  const put = await putP;
  const fee = await feeP;
  const toasts = await page.locator(".Toastify__toast").allInnerTexts().catch(() => [] as string[]);
  let reqBody: any = null;
  try { reqBody = JSON.parse(put?.request().postData() || "null"); } catch { /* none */ }
  const resBody = put ? await put.json().catch(() => null) : null;
  return {
    status: put?.status() ?? 0, reqBody, message: apiMessage(resBody),
    fee: fee ? { status: fee.status(), req: fee.request().postData() || "", message: apiMessage(await fee.json().catch(() => null)) } : null,
    toasts: toasts.map((t) => t.trim()).filter(Boolean),
  };
}

// ─── Storefront (fresh context + no-cache + unique query = never served from cache) ───
export const PLAN_PAGES = ["japan-esim", "united-states-esim", "europe-esim"];
export const POLL_MS = Number(process.env.E2E_WL_CACHE_POLL_MS || 10 * 60 * 1000);

export async function storefrontPage(browser: Browser, slug: string) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, extraHTTPHeaders: { "Cache-Control": "no-cache", Pragma: "no-cache" } });
  const page = await ctx.newPage();
  const res = await page.goto(`${WL_URL}/en${slug ? `/plans/${slug}` : ""}?nocache=${Date.now()}`, { waitUntil: "commit", timeout: 90000 }).catch(() => null);
  const plans = await page.locator(".day-card").first().waitFor({ state: "visible", timeout: 45000 }).then(() => page.locator(".day-card").count()).catch(() => 0);
  return { ctx, page, status: res?.status() ?? 0, plans };
}

/** Poll one plan page every 60s until want(plans) or POLL_MS. */
export async function pollPlans(browser: Browser, want: (n: number) => boolean) {
  const t0 = Date.now();
  const timeline: string[] = [];
  for (;;) {
    const p = await storefrontPage(browser, PLAN_PAGES[0]);
    await p.ctx.close();
    const t = Math.round((Date.now() - t0) / 1000);
    timeline.push(`+${t}s: HTTP ${p.status}, ${p.plans} plans`);
    if (want(p.plans)) return { reached: t as number | null, timeline };
    if (Date.now() - t0 > POLL_MS) return { reached: null as number | null, timeline };
    await new Promise((res) => setTimeout(res, 60000));
  }
}

// ─── Partner portal login → partner JWT ───
export async function partnerToken(browser: Browser, email: string, otp: string) {
  const ctx = await browser.newContext({ baseURL: PARTNER_URL });
  const page = await ctx.newPage();
  try {
    await page.goto(`${PARTNER_URL}/#/login-partner`, { waitUntil: "domcontentloaded", timeout: 120000 });
    await page.locator("input[placeholder='Enter your email']").fill(email);
    await page.locator("span.btn-send-code").click();
    const code = page.locator("input[placeholder='Enter code']");
    for (let i = 0; i < 3; i++) {
      await code.fill(otp);
      if (await expect(page.locator(".login-button")).toBeEnabled({ timeout: 5000 }).then(() => true).catch(() => false)) break;
    }
    await page.locator(".login-button").click();
    await page.waitForURL((u) => !u.hash.includes("/login"), { timeout: 60000 });
    return await page.evaluate(() => localStorage.getItem("accessToken") || "");
  } finally {
    await ctx.close();
  }
}

// ─── Small JSON state file (survives worker restarts and evidence resets) ───
export function stateFile(file: string) {
  return {
    load: <T>(): T => { try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return {} as T; } },
    save: (v: unknown) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(v, null, 1)); },
  };
}

/** adminSession with retries: the staging login page sometimes never navigates (waitForURL 30s). */
export async function adminSessionRetry(browser: Browser) {
  let last: unknown;
  for (let i = 1; i <= 3; i++) {
    try { return await adminSession(browser); } catch (e) { last = e; }
  }
  throw last;
}

/** Every key matching `re` anywhere in an object → "path = value" (e.g. where the FE puts dataExpiry*). */
export function findKeys(obj: unknown, re: RegExp, base = ""): string[] {
  if (!obj || typeof obj !== "object") return [];
  return Object.entries(obj as Record<string, unknown>).flatMap(([k, v]) => {
    const p = base ? `${base}.${k}` : k;
    return [...(re.test(k) ? [`${p} = ${JSON.stringify(v)}`] : []), ...findKeys(v, re, p)];
  });
}
