# Admin Guide: Setting Up a White Label Partner

| | |
|---|---|
| **For** | Eskimo Admins on the Admin Portal |
| **Scope** | Enable the Corporate Program (White label) for the partner → create the website and its structure → set the Application Fee → configure domain and email sender → go-live → operations |
| **Last updated** | 26 Oct 2026 |

---

## 1. Overview

### 1.1 What Admins and Partners do

| Role | Where | Responsibilities |
|---|---|---|
| **Eskimo Admin** (this guide) | Admin Portal | Enable the Corporate Program, create the website and own its **structure** (pages, modules, order), set the Application Fee, configure domain and email sender, switch the website on/off |
| **Partner** | Partner Portal → **My Website** | Connect **Stripe**, edit **content and branding** inside each module, add to their own domain the **DNS records** (website and email sender) that the Admin sends. **Cannot** add, remove or reorder modules |

> Partners follow their own guide, *"Partner Guide: Managing Your Website on the Partner Portal"*. Send it to the partner once the website is assigned (Step 2).

### 1.2 Flow

```
LANES
```

### 1.3 Dependency chain

| To be able to… | You first need… |
|---|---|
| Assign a partner in **Assign Partner** | The partner has Corporate Program **ON** (Type White label) and **no other website** |
| Save the **Application Fee** | The partner has **started** Connect Stripe (Stripe Connect Status is not *Not Connected* / *—*) |
| Let customers **pay** | Stripe Connect Status = **Verified** |
| Have the website **visible and selling** | Corporate Program **active** (Status ON and today within Start → End Date) **and** website **Status = Active**. The Admin only activates the website once the partner's Stripe is **Verified** |
| Have customers **receive the eSIM QR + Magic Link email from Eskimo** | **Eskimo Email Notification = ON** **and** the Email sender (the partner's email domain) is **Verified** (6.2) |
| Let the partner **edit content** in My Website | The website has been created and **assigned** to the partner |

---

## 2. Prerequisites

1. An Admin account with access to **Partnership › Partners** and the **White Label** menu.
2. The partner already exists in the system, and its **Partner Email** is the email the partner uses to sign in to the Partner Portal.
3. Agreed with the partner:
    - Program **term** (Start / End Date).
    - **Application Fee (%)**.
    - **Who emails customers** (Eskimo or the partner).
    - **Maximum number of accounts** (Lifetime Account Limit). If not agreed, use the **maximum (99999)**.
    - The partner has sent the website **subdomain** (e.g. `esim.partner.com`).
    - **Who emails customers:** if the partner wants Eskimo to send, they also send the **email sender details** on their own email domain (Sender name, From address, Reply-to). If the partner sends from its own system, these are not needed.

---

## 3. Step 1 — Enable the Corporate Program

**Screen:** **Partnership › Partners** → find the partner → **Edit** → **Corporate Program** section (right column).

### 3.1 Configure the Corporate Program

![A fully configured White Label Corporate Program](images/corporate-program/02-corporate-program-verified.png)

| # | Field | Action / rule |
|---|---|---|
| 1 | **Status** | Switch **ON**. The fields below appear |
| 2 | **Type** | Select **White label**. ⚠️ **Locked after saving** |
| 3 | **Start Date** | Required, `DD/MM/YYYY`. **Locked** once the start day has passed (still editable on the start day itself) |
| 4 | **End Date** | Required, **after Start Date**; today and past dates cannot be picked (earliest is tomorrow). Can be extended any time |
| 5 | **Eskimo Email Notification** | **ON** when the partner gives Eskimo an **email domain** to configure: Eskimo sends the purchase confirmation, the eSIM QR email (with LPA code) and the Magic Link to My Data from the partner's email address (Email sender, 6.2). **OFF** (default) when the partner does not provide an email domain: the partner **handles** sending the order confirmation, the eSIM QR code and the My Data sign-in OTP to customers itself via the **External API**; Eskimo sends **no emails**, skip 6.2. With no partner email domain, Eskimo sends no emails |
| 6 | **Lifetime Account Limit** | Shown as `<used> / <max>`. Enter a positive integer **< 100000** (max 99999), required. If not agreed with the partner, enter **99999** |
| 7 | **Payment method** | **Direct Charge** (the only option) |
| 8 | **Data Expiry** | **2 Years** (data expires 2 years from purchase) |
| 9 | **Application Fee Percentage** | **Do not enter it yet.** The fee is only saved once the partner has started Stripe onboarding; set it in Step 3 |
| 10 | **Stripe Connect Status** | Read-only. The partner connects Stripe on the Partner Portal |

Click **Ok** → **UPDATE SUCCESS**. Reopen the partner to verify.

![Payment method = Direct Charge](images/corporate-program/05-payment-method-direct-charge.png)

---

## 4. Step 2 — Create the website and edit its structure

**Screen:** **White Label** menu → **Website Templates**.

### 4.1 Website Templates screen

![Website Templates screen](images/website-structure/01-website-templates-after-clone.png)

| Column | Content |
|---|---|
| **Name** | Template / website name |
| **Type** | `System Default` (template) or `Partner Website` |
| **Partner** | Owning partner, "—" if unassigned or a template |
| **Pages** | Number of pages |
| **Status** | **Active / Inactive** switch (websites only) |
| **Created Date** | Creation date |
| **Actions** | Template: **Edit Structure**, **Clone**. Website: **Edit Structure**, **Config**, **Assign Partner** / **Reassign Partner**, **Delete** |

### 4.2 Clone a website from the template

1. On the **Eskimo eCommerce (Default)** row click **Clone** → toast **"Website draft created"**.
2. New row: Name **Untitled Website Draft**, Type **Partner Website**, Partner **—**, Status **Inactive**, Pages **5**.
3. The new website copies the **template's full structure as of cloning** (Appendix A). Each Clone creates **one** website.

### 4.3 Assign the partner

1. On the new website row click **Assign Partner**.
2. Type the partner's name in the **Partner** field (*"Search a partner by name"*), pick the right partner → **Assign**. Leaving it empty shows *"Please select a partner"*.
3. Result: toast **"Untitled Website Draft" assigned**; the Partner column shows the name; the website is renamed **"Website Template for partner &lt;partner name&gt;"**.

![Website after assigning a partner](images/website-structure/02-assigned-partner.png)

> If you see **"No available partner"** → re-check Step 1, or the partner already has another website.
>
> **Reassign Partner**: for an assigned website, pick another (also eligible) partner → **Assign**.

Once assigned, the partner sees the website under Partner Portal → **My Website**. Send them the Partner Portal guide.

### 4.4 Edit Structure

Click **Edit Structure** → the **"Edit Structure — &lt;website name&gt;"** dialog has:
- **Page tabs**: `Home (12)`, `Plan Detail (4)`, `Checkout (2)`, `Install eSIM (3)`, `Data Balance (4)` (number = module count).
- A **canvas** previewing modules top to bottom.
- **Footer bar**: **Close** and **Save Page**.

Each module has a title bar: a **≡** drag handle (not on Header), the module name, and a **red bin** button.

| Action | How |
|---|---|
| **Add a module** | Select the page → scroll to the bottom of the canvas → **+ Add Section** → pick a module (Appendix B). It is **added at the end of the page** → drag it into place (usually **above the Footer**) |
| **Remove a module** | Click the bin → *"Remove this module?"* → **Remove** |
| **Reorder** | Hold **≡**, drag up/down, drop |
| **Move a module to another page** | Not possible by dragging across pages: remove it from the old page → **+ Add Section** on the new page |
| **Save** | **Save Page** (one changed page) or **Save All (N pages)**. Disabled when nothing changed. Success: **Saved: "Home"** |

![A newly added module at the end of the page](images/website-structure/03-editor-add-section.png)

> ⚠️ **The Header always stays at the top** and cannot be dragged. **The Footer can be dragged**: after adding or reordering modules, check the Footer is still **last** before saving.
>
> ⚠️ Click **Save Page / Save All before Close.** Close gives **no warning** about unsaved changes; they are simply lost.

>
> 💡 **Coordinate with the partner:** once the partner has entered content, **removing** a module takes that content off the website. Agree with the partner first.

### 4.5 Template ↔ website independence

| Situation | Result |
|---|---|
| Edit partner A's website structure | **No** effect on the template or other partners' websites |
| Edit the System Default template | **No** effect on existing websites; only websites **cloned afterwards** get the new structure |
| Clone a new website | Gets the template structure as of cloning, then is fully independent |

---

## 5. Step 3 — Follow Stripe and set the Application Fee

### 5.1 The partner connects Stripe (Admin follows up)

Admins **cannot** connect Stripe for the partner. The partner goes to Partner Portal → **My Website** → **Stripe payments** → **Connect Stripe**, then completes the Stripe onboarding.

| Shown | Meaning | Next action |
|---|---|---|
| **Not Connected** / **—** | Not connected (**—** = never started) | Remind the partner to click **Connect Stripe** |
| **Pending verification** | Stripe is verifying | Wait; if Stripe asks for more, the partner clicks **Continue setup** |
| **Verified** | Ready to accept payments | Done |

![Stripe Connect Status = Pending verification](images/corporate-program/03-stripe-pending-verification.png)

> The status can take **a few minutes** to update after Stripe finishes verification. Reopen the partner to see the latest.

### 5.2 Set the Application Fee Percentage

> **Why after Stripe?** The fee is only saved once the partner has **started** Stripe onboarding (status no longer *Not Connected* / *—*). If set earlier, the partner is saved but the fee is not, with the message *"Partner saved, but the Application Fee was not: Stripe onboarding has not been started for this partner"*.

1. Edit partner → **Corporate Program** → **Application Fee Percentage**.
2. The **base rule** is the first row, **Apply To = Any Data Plan**: always first, Apply To cannot be changed, cannot be deleted. **Fee** = *Percentage (%)*. Enter the % (placeholder *"10 (default)"*).
3. **Rules for groups of plans** (only if agreed): click **+ Add Application Fee** → choose **Apply To** (type to filter, e.g. `Any Fixed 1GB`, `Any Japan Plan`, or a specific plan) → enter the %. To edit, change the % on that row; to remove, click the row's delete button.
4. Click **Ok**.

**Which rule a plan uses:** the matching rule with the **highest priority**; if no rule matches, the base rule.

| Priority | Apply To |
|---|---|
| 1 (highest) | A specific plan (e.g. Japan 1GB) |
| 2 | Any {Global / region / country} Plan (e.g. Any Japan Plan) |
| 3 | Any {data amount} (e.g. Any Fixed 1GB) |
| 4 | Any {plan type} (Any Fixed / Any Unlimited) |
| 5 | Any Data Plan (base rule) |

> Rule changes only apply to new orders; **existing orders keep their fee**. Rules are kept when the program is switched off and on again.

| Input | Result |
|---|---|
| `0` ≤ fee < `100`, up to 2 decimals (`20`, `12.5`) | Valid, within the plan group's maximum (see below) |
| `100` or more | *"Fee must be at least 0 and less than 100"* |
| More than 2 decimals (`12.345`), letters, negatives | *"Value should contain just number"* |
| **Empty** | Uses the **10% default** (*"Leave empty to use the default fee (10%)."*) |

> The field shows the **saved fee**; if none is set it is empty (the 10% default). Entering `0` means Eskimo **collects no fee**; only enter it if that was agreed.
>
> No order can miss the fee between Step 1 and Step 3: customers cannot pay until the partner's Stripe is **Verified**.

**The maximum fee depends on the plan group.** For plan-group rules (**Any …**), the partner's share (**plan price × (100% − fee)**) must be **at least USD 1** for **every plan** in the group, so the cheapest plan in the group sets the maximum. Above it, **Ok** shows *"White label discount is invalid. Please check again."* and **nothing is saved** (the error does not name the rule; lower the % of the rule you just added/changed and save again). The form may show a *"… final bill < 1"* warning (e.g. *"Africa 1GB final bill < 1"*) listing the plans below USD 1.

| Apply To | Cheapest plan | Maximum fee |
|---|---|---|
| Any Fixed 1GB / Any Fixed | US$3.90 | **74%** |
| Any Fixed 3GB | US$7.90 | **87%** |
| Any Fixed 5GB | US$10.90 | **90%** |
| Any Fixed 10GB | US$17.90 | **94%** |
| Any Unlimited | US$5.00 | **80%** |

> The maximum follows **current plan prices** (measured on stage 27/10/2026); if prices change, so does the maximum. **Customers always pay the full plan price**; the fee only splits it between Eskimo and the partner.

![Application Fee 90% with the final bill < 1 warning](images/corporate-program/04-application-fee-warning.png)

### 5.3 Calculation

```
Application Fee (Eskimo receives)  = Plan price × Application Fee %
Partner Benefit (partner receives) = Plan price × (100% − Application Fee %) − Stripe fees
```

**Application Fee %** is the % of the rule that applies to that plan (5.2). For an order with several plans, **order fee = sum of each plan's fee**.

> **Stripe processing fees are paid by the partner.** Customers pay into the partner's Stripe account, and Stripe deducts its processing fee there. Eskimo's Application Fee is calculated on the **plan price** and is not reduced by Stripe fees.

> **Amounts are rounded down to the cent:** 3.90 × 74% = 2.886 → **US$2.88**; 8.90 × 75% = 6.675 → **US$6.67**.

| Plan price | Application Fee | Eskimo receives | Partner receives (before Stripe fees) |
|---|---|---|---|
| USD 100 | 90% | USD 90 | USD 10 |
| USD 100 | 10% (default) | USD 10 | USD 90 |
| USD 3.90 | 20% | USD 0.78 | USD 3.12 |

---

## 6. Step 4 — Configure domain and email sender

The partner sends Eskimo the website **subdomain** and, if Email Notification = ON, the **email sender details**. The Admin enters them in Config, then sends the partner the **DNS records** to add to their domain.

On the website row in **Website Templates**, click **Config** (*"Custom domain and website settings"*). The **"Config — &lt;website name&gt;"** dialog has two parts.

### 6.1 Custom domain

1. Enter the subdomain the partner sent, e.g. `esim.yourdomain.com` (root domains such as `yourdomain.com` are not accepted).
2. Click **Validate**. Result: *Available*, *Already in use*, *Saved for this website*, *DNS pointed correctly* or *DNS not pointed yet*.
3. Click **Save** (enabled only after a valid result for exactly the typed value) → *"Custom domain saved: &lt;host&gt;"*.
4. Send the partner the 2 **CNAME** records in the **"DNS records to give the partner"** table (with copy buttons), and remind them to set **DNS only, not proxied**:

| Record | Used for |
|---|---|
| CNAME **&lt;domain&gt;** → Eskimo storefront | Routes the website so it opens on the partner's domain |
| CNAME **_acme-challenge.&lt;domain&gt;** | Issues and auto-renews the HTTPS certificate. ⚠️ **Never remove it**: without it the website stops opening at the next renewal (months later) |

5. When the partner confirms, type the domain again and **Validate** until it shows *DNS pointed correctly*.

> If the partner needs help adding DNS records, hand it to the **Eskimo business team**.

> A domain saved earlier is **not shown again** in the field. To see its state, type it again and click **Validate**.

### 6.2 Email sender

> Only when **Eskimo Email Notification = ON**. The partner must have its own **email domain**; without one, skip this and Eskimo sends no emails.

1. Fill in all three fields: **Sender name** (e.g. *Klook eSIM*), **From address** (e.g. *noreply@klook.com*), **Reply-to** (e.g. *support@klook.com*) → **Save** → *"Email sender saved"*.
2. Under **Domain authentication**: **save the From address first**, then click **Create / get records**. Send the DNS records (Type / Host / Value) to the partner and remind them to set **DNS only, not proxied**.
3. When the partner confirms, click **Check again** until the status is **Verified**. Other statuses: *Pending DNS*, *Not set up*.
4. **Sender name** and **Reply-to** apply immediately. A **From address** on a new domain only takes effect once that domain is verified (*"… is waiting on DNS"*).

---

## 7. Step 5 — Go-live

### 7.1 Activate the website

- New websites are always **Inactive**. When structure and content are ready, switch the **Status** column to **Active**. It saves immediately, no Save needed.
- ⚠️ **Only switch to Active when Stripe Connect Status = Verified.** If the partner has not finished connecting Stripe, keep the website **Inactive**, even if the domain and DNS are already set up.

> **Two different switches — both must be on:**
> - **Corporate Program Status** (Partnership › Partners): the partnership program.
> - **Website Status** (White Label › Website Templates): the website.

### 7.2 Pre-launch check

1. Stripe Connect Status = **Verified**, and the Application Fee shows correctly when you reopen the partner.
2. Custom domain *DNS pointed correctly*; Domain authentication **Verified** (if Email Notification = ON).
3. Open the website on desktop and mobile; check all 5 pages and links.
4. Place one test order: payment succeeds → confirmation page shows **Order number** `PUR-PN…` → eSIM QR and Magic Link emails (if Email Notification = ON) → My Data shows the plan.
5. **Admin › Transactions › Eskimo Sale** shows a **WHI-…** transaction worth **order price × Application Fee %** (e.g. 10% fee, US$3.90 order → **0.39**).

> The two IDs differ by design: **PUR-PN…** is the partner's order (customer-facing), **WHI-…** is Eskimo's fee (Admin only).

---

## 8. Operations

### 8.1 When the website stops selling

| Case | Cause |
|---|---|
| Corporate Program **Status = OFF** | Admin switched the program off |
| Website **Status = Inactive** | Admin switched the website off, or has not switched it on because the partner's Stripe is not **Verified** yet |
| **Before Start Date** / **after End Date** | Outside the program term |

The website then shows **"This store isn't available — Please check back later."**; customers **cannot see plans or buy**. Takes effect within **a few minutes**.

![Website when the program is inactive](images/corporate-program/07-store-unavailable.png)

### 8.2 Actions

| Goal | How | Result / notes |
|---|---|---|
| **Stop the program** (pause or stop now) | Edit partner → **Status OFF** → **Warning** dialog → **Confirm** → **Ok** | The website stops selling within a few minutes. This is the only way to stop **immediately**: End Date cannot be set in the past |
| **Re-enable the program** | Edit partner → **Status ON** → **Ok** | **Nothing to re-enter**: all settings are kept |
| **Extend** | Edit partner → change **End Date** to a future date → **Ok** | Other settings unchanged |
| **Switch off the website only** (program stays on) | Website Templates → **Status Inactive** | The website stops selling; switch back with **Status Active** |
| **Delete the website** | **Delete** → confirm → **"DELETE SUCCESS"** | ⚠️ **Irreversible.** The partner loses the website **and all content they edited**; the Partner Portal shows *"No website has been assigned to you yet. Please contact your account manager."* |
| **Refund** a White Label order | — | **Not available yet**: the feature is in development. This guide will be updated when it is |

![Switching Status OFF](images/corporate-program/06-status-off.png)

---

## 9. Troubleshooting

| Issue | Cause / fix |
|---|---|
| Cannot change **Type** | Locked after the first save. Wrong choice → contact the Eskimo tech team |
| Cannot edit **Start Date** | Locked once the start day has passed; only End Date is editable |
| Saved but **fee not recorded** | The partner has not started Connect Stripe. Ask them to connect, then save the fee again |
| Stripe stuck on **Not Connected** / **—** | The partner has not done **My Website → Connect Stripe**. Admins cannot do it for them |
| Partner missing in **Assign** / **"No available partner"** | Corporate Program not enabled, partner already has a website, or the search text doesn't match |
| Changes lost after closing Edit Structure | Close gives no unsaved-changes warning. Always **Save Page / Save All** first |
| Which module shows **products** | **Data Plan Section (Global + Regions)** (Home), **Plan Detail Hero** (Plan Detail) |
| A saved domain is not shown in Config | Expected. Type the domain again and **Validate** to see its state |
| Website still visible after disabling the program | Wait a few minutes and reload |

---

## Appendices

### Appendix A — Default structure of "Eskimo eCommerce (Default)"

| Page | Modules | Modules (in order) |
|---|---|---|
| **Home** | 12 | Header → Banner → Data Plan Section (Global + Regions) → Transfer Data (Why Eskimo eSIM) → More Reasons Grid → Video Section → Comparison Table → Install Steps → Reviews → FAQ → Recommendations → Footer |
| **Plan Detail** | 4 | Header → Plan Detail Hero → Sticky Checkout Bar → Footer |
| **Checkout** | 2 | Header → Footer (payment form provided by the system) |
| **Install eSIM** | 3 | Header → Install eSIM Guide (iOS / Android, manual) → Footer |
| **Data Balance** | 4 | Header → Data Balance Screen → Data & eSIM Information → Footer |

### Appendix B — Module library (+ Add Section)

| Module | Used for |
|---|---|
| Header | Logo, top menu |
| Banner | Hero image, heading, description, call to action |
| Feature Section | Key highlights |
| Data Plan Section (Global + Regions) | Plan list by country / region (products) |
| Transfer Data (Why Eskimo eSIM) | Why choose the service |
| More Reasons Grid | Grid of benefits |
| Video Section | Intro video |
| Comparison Table | Comparison table |
| Install Steps | eSIM install steps (summary) |
| Reviews | Customer reviews |
| FAQ | Frequently asked questions |
| Recommendations | Suggested plans / destinations |
| Footer | Links, social media, copyright |
| Plan Detail Hero | Top of the plan detail page |
| Sticky Checkout Bar | Fixed checkout bar |
| Data & eSIM Information | Data and eSIM information |
| Data Balance Screen | Remaining data screen |
| Install eSIM Guide (iOS / Android, manual) | Detailed per-device install guide |
