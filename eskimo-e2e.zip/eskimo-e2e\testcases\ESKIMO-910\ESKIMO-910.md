# ESKIMO-910 – [Admin] White Label – Multiple Application Fee rules

Nguồn: Docmost "[Admin] White Label – Multiple Application Fee rules" (lam.nguyen).
Related: EA-4281 (discount "Apply to" rules), EP-4399 (commission hierarchy & payout),
ESKIMO-757 / EP-5991 (Configure White Label under Corporate Program — AC3).
Môi trường: STAGE — Admin = E2E_ADMIN_URL (https://app-eskimo-admin-stage-sea-001.azurewebsites.net),
API = E2E_API_URL (stage), storefront = E2E_WL_URL (https://wellatsea.eskimo.travel → WhiteLabel Partner 2 / PN101609).
Khách WL mua: testwhitelabel300@yopmail.com (E2E_WL_MEMBER_EMAIL).

Tóm tắt yêu cầu:
- Hôm nay 1 White Label partner có 1 Application Fee % cho mọi gói ("Any Data Plan").
- Admin cần thêm nhiều Application Fee rules, mỗi rule cho 1 nhóm gói. Rule + priority giống hệt EA-4281
  ("Apply to" options, priority level, cách chọn rule khớp). Chỉ khác: ở đây set Application Fee %,
  thay vì discount/commission %.
- Application Fee = Original Data Plan Price × Application Fee %.
- Partner Benefit = Original Data Plan Price × (100% − Application Fee %).

Apply To priority (EA-4281, cao → thấp):
Specific data plan > Any {Global/Region/Single country} Plan > Any {data amount} > Any {type} > Any Data Plan.

Quyết định QC:
- Partner dùng: WhiteLabel Partner 2 (PN101609) — partner duy nhất có storefront. Snapshot trước, restore sau.
- Mua thật trên storefront (Stripe test mode, CARD_OK 4242…). Email testwhitelabel300@yopmail.com.
- Fee config: base "Any Data Plan" = 10%, "Any Japan Plan" = 30%, "Japan 1GB" (specific) = 50%, "Any Vietnam Plan" = 40%.
- Gói mua + fee kỳ vọng:
  - Japan 1GB → SPECIFIC_PLAN (Japan 1GB) → 50%
  - Vietnam 1GB → ANY_LOCATION (Any Vietnam Plan) → 40%
  - United States 1GB → base Any Data Plan → 10%
- Transaction WHI "Value" (Application Fee) = total × fee% (làm tròn cent, theo ESKIMO-758 TC-07).

## AC1 — Base rule "Any Data Plan"

### TC-01 Base rule luôn đầu, Apply To locked, không xóa; empty = default 10%
- Steps: Admin → Partnership › Partners → Edit Partner 2 → Corporate Program (Type = White label)
- Expected:
  - Row "Any Data Plan" luôn hiện đầu tiên; Apply To không đổi được; row không có nút xóa.
  - Giá trị rỗng = default fee (10%).

## AC2 — Add more Application Fee rules

### TC-02 Add 3 rules + base, save, verify (API + reopen)
- Steps:
  - Set base "Any Data Plan" = 10.
  - Click "+ Add Application Fee" → rule "Any Japan Plan" = 30.
  - Click "+ Add Application Fee" → rule "Japan 1GB" (specific) = 50.
  - Click "+ Add Application Fee" → rule "Any Vietnam Plan" = 40.
  - Ok.
- Expected:
  - (DATA) GET /api/partner/v2/{id}: configuration.whiteLabelSetting.plans có 3 rule đúng (Any Japan 30, Japan 1GB 50, Any Vietnam 40).
  - stripeConnect.platformFeePercent = 10 (base fee).
  - Reopen form: 3 rule hiển thị đúng Apply To + Fee.

### TC-02b Edit 1 rule fee, save, verify
- Steps: mở lại → sửa fee rule "Any Japan Plan" 30 → 25 → Ok → mở lại
- Expected: API whiteLabelSetting.plans: Any Japan = 25; 2 rule kia không đổi.

### TC-02c Delete 1 rule, save, verify
- Steps: mở lại → xóa rule "Any Vietnam Plan" → Ok → mở lại → thêm lại "Any Vietnam Plan" = 40 → Ok
- Expected: sau xóa API còn 2 rule; sau thêm lại có 3 rule (Any Vietnam 40).

## AC3 — Which fee is applied

### TC-03 Mua 3 gói + Admin validate fee từng gói
- Steps:
  - Storefront: mua Japan 1GB, Vietnam 1GB, United States 1GB bằng testwhitelabel300@yopmail.com, CARD_OK.
  - Admin: Eskimo Sale search 3 WHI… transaction (eskimoTransactionType = 4) mới của khách.
- Expected (mỗi gói dùng rule khớp priority cao nhất):
  - Japan 1GB: Value ≈ total × 50%.
  - Vietnam 1GB: Value ≈ total × 40%.
  - United States 1GB: Value ≈ total × 10%.
  - Membership Detail › Data Purchase: mỗi WHI có "Transaction Partner ID" = PN101609 + "Transaction Price" = total.
- Ghi chú: storefront 1 gói/checkout → "order nhiều gói" (AC3 sum) = out-of-scope/GAP (BE concept).

### TC-04 Order đã tạo giữ fee khi Admin đổi rule
- Steps: đổi base "Any Data Plan" 10 → 20 → Ok; đọc lại 3 WHI của TC-03
- Expected: Value của 3 WHI cũ không đổi (order giữ fee lúc mua).

## AC4 — Keep rules when program disabled/enabled

### TC-05 Disable → Enable, rules giữ nguyên
- Steps: Partner 2 → Status OFF → Ok → Status ON → Ok (không sửa rule)
- Expected: configuration.whiteLabelSetting.plans + platformFeePercent giữ nguyên sau disable/enable.

## Hai version spec

Cùng chung helpers/partner PN101609/email testwhitelabel300@yopmail.com, mỗi file có state file riêng (chạy riêng để không xung đột config PN101609).

### Version A — `application-fee-per-plan.spec.ts` (rule theo QUỐC GIA + gói cụ thể)
- Base = 10%, Any Japan Plan = 30%, Japan 1GB (specific) = 50%, Any Vietnam Plan = 40%.
- TC-02b: Any Japan 30 → 25. TC-02c: xóa + thêm lại Any Vietnam = 40.
- Mua: Japan 1GB (→50%), Vietnam 1GB (→40%), US 1GB (→10%).

### Version B — `application-fee-by-data-amount.spec.ts` (rule theo DUNG LƯỢNG DATA, EA-4281 "Any {data amount}" = ANY_FIXED_UNIT) — config hiện hành (cập nhật 2026-10-26)
- Base "Any Data Plan" = 10%, Any Fixed 1GB = **74%** (env `E2E_910_FEE_1GB`), Any Fixed 3GB = 75%, Any Fixed 5GB = 80%, Any Fixed 10GB = 88%, Any Fixed 30GB = 88%.
- Vì sao 1GB = 74 (không phải 75): BE hiện chặn Any Fixed 1GB ≥ 75% (400 "White label discount is invalid"). Trần đo trên stage 26/10:
  1GB ≤ 74%, 3GB ≤ 87%, 5GB ≤ 90%, 10GB ≤ 94%, 30GB ≤ 96%. Đã báo BE: `reports/ESKIMO-910-api-bug-report.md`.
  **Khi BE sửa:** chạy lại với `E2E_910_FEE_1GB=75` (chỉ đổi config 1GB) và verify lại.
- Mỗi rule khớp MỌI gói có dung lượng đó, bất kể nước/vùng.
- TC-02: thêm 5 rule trên + base 10 → API whiteLabelSetting.plans có đủ 5 rule đúng fee; platformFeePercent = 10.
- TC-02b: sửa Any Fixed 5GB 80 → 70 → API Any Fixed 5GB = 70, 4 rule kia không đổi.
- TC-02c: xóa Any Fixed 30GB → API còn 4 rule; thêm lại Any Fixed 30GB = 88 → API đủ 5 rule.
- TC-03: mua 5 gói ở các nước/vùng KHÁC NHAU → Admin Eskimo Sale: WHI Value = total × fee%:

  | Gói mua (storefront) | Rule khớp | Fee kỳ vọng |
  |---|---|---|
  | Vietnam 1GB (trang Vietnam, card Vietnam) | Any Fixed 1GB | 74% (= E2E_910_FEE_1GB) |
  | United States 3GB (card United States) | Any Fixed 3GB | 75% |
  | France 5GB (card France) | Any Fixed 5GB (đã sửa ở TC-02b) | 70% |
  | Thailand 10GB (card Thailand) | Any Fixed 10GB | 88% |
  | North America 30GB (trang US, card vùng North America) | Any Fixed 30GB | 88% |
  - Card từng nước trên storefront chỉ có 1/3/5/10GB → 30GB phải mua gói vùng (Global / Asia Pacific / North America / Europe).
- TC-04: đổi base 10 → 20 → Value của 5 WHI ở TC-03 không đổi.
- TC-05: disable → enable → 5 rule + platformFeePercent giữ nguyên.
- findRule nhánh ANY_FIXED_UNIT: không dataPlanId + dataPlanUnitValue = amount.
- UI: option Apply To tên "Any Fixed {n}GB"; dropdown là virtual list → gõ "Any Fixed 1GB" để lọc rồi chọn (không bấm Escape — Escape đóng drawer Edit Partner).
- Restore: rule trong snapshot gửi lại với id rỗng (id cũ đã bị xóa → BE 400 "Not found white label discount").

## Kết quả stage 2026-10-26 (Version B)
- TC-01, TC-02, TC-02b, TC-02c, TC-04, TC-05: PASS.
- TC-03: **FAIL (product)** — rule % bị áp thành GIẢM GIÁ cho khách: khách trả giá × (100 − fee%), Application Fee (WHI Value) = base 10% của số đã giảm. Rule vẫn khớp đúng gói theo dung lượng ở mọi nước/vùng.
  Ví dụ Vietnam 1GB $3.90, rule 74% → khách trả $1.01, Value $0.10 (kỳ vọng: trả $3.90, fee $2.89). Chi tiết: reports/ESKIMO-910-api-bug-report.md.
- Trần fee theo gói khi lưu (1GB ≤ 74%) là hệ quả của cùng lỗi (BE coi là discount).
- Môi trường: US 3GB lượt 2 bị "This purchase cannot be completed right now" (lượt 1 mua được); Vietnam 1GB lượt 2 WHI status -2 (hết eSIM stage) — không phải bug.

## Cleanup
- afterAll: restore Partner 2 về snapshot (base fee gốc + whiteLabelSetting.plans gốc), verify bằng GET.

## Application Fee 0% (2026-10-29, STAGE) — `tests/ESKIMO-910/zero-fee.spec.ts` → 2/2 PASS

| Case | Expected | Result |
|---|---|---|
| ZF-01 Base "Any Data Plan" = 0 | Saved as explicit 0 (API `platformFeePercent` 0, not null = default 10%); reopen shows "0" | PASS. UI Ok sent no request because FE blocks the existing Vietnam 1GB 99% rule ("Max fee for Vietnam 1GB is 74%"); base 0 set with the same request FE sends for it (`PUT /api/payment/connect/partners/PN101609/fee {platformFeePercent:0}` → 200) |
| ZF-02 Vietnam 3GB / France 5GB / Global 10GB (no rule) | Value = $0 (0%), Eskimo Sales $0, paid = listed, 1 receipt | PASS (PUR-PN101609-261029-3775382 / -4778376 / -2008343) |
| ZF-02 control Vietnam 1GB (specific rule 99%) | Rule wins over base 0% → Value $3.86 | PASS (PUR-PN101609-261029-8689489) |

Base fee restored to 20 after the run. Evidence: `reports/ESKIMO-910_2026-10-29_stage_zero-fee.pdf`.
