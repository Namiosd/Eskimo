// ESKIMO-910 - [Admin] White Label Multiple Application Fee rules.
// Spec: testcases/ESKIMO-910/ESKIMO-910.md. Source: Docmost "[Admin] White Label - Multiple Application Fee rules".
//   AC1 TC-01 base rule "Any Data Plan" (first, locked, no delete; empty = default 10%)
//   AC2 TC-02 add 3 rules (Any Japan 30, Japan 1GB 50, Any Vietnam 40) + base 10, save, verify API+reopen
//        TC-02b edit a rule fee, save, verify ; TC-02c delete + re-add a rule, save, verify
//   AC3 TC-03 purchase Japan 1GB (50%), Vietnam 1GB (40%), US 1GB (10%) -> Admin Eskimo Sale Value = total x fee%
//        TC-04 change base fee -> old WHI keep their fee
//   AC4 TC-05 disable -> enable, rules retained
// Partner: WhiteLabel Partner 2 (PN101609, storefront wellatsea). Snapshot before, restore after (afterAll).
// Customer: testwhitelabel300@yopmail.com. Stripe test card CARD_OK. STAGE only.
// Evidence: evidence/ESKIMO-910-application-fee-per-plan -> npm run report:evidence -- ESKIMO-910 application-fee-per-plan
import path from "node:path";
import { test, expect, type Browser, type BrowserContext, type Locator, type Page, type TestInfo } from "@playwright/test";
import { ADMIN_URL, adminSession } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import {
  api, tokenOf, apiMessage, findPartner, websites, readPartner, corporateBody, diff, snapOf,
  openCorporate, corporate, formItem, focus, clickOk, partnerToken, stateFile,
  adminSessionRetry as adminSess, PLAN_PAGES, type PartnerState,
} from "../_support/whitelabel";
import {
  WL_URL, API_URL, CARD_OK, newShopper, pickPlan, goToCheckout, continueToPayment, payWithCard, readCompletePage,
  adminToken, membersByEmail, memberDetail, pollMembers,
} from "../_support/wellatsea";

const ID = "@ESKIMO-910";
const AC = "WL Multiple Application Fee rules";
const evidence = createEvidence("ESKIMO-910", "application-fee-per-plan");
const P2 = process.env.E2E_WL_PARTNER_NAME || "WhiteLabel Partner 2";
const P2_CODE = process.env.E2E_WL_PARTNER_CODE || "PN101609";
const P2_EMAIL = process.env.E2E_WL_PARTNER_EMAIL || "wlb@yopmail.com";
const P2_OTP = process.env.E2E_WL_PARTNER_OTP || "1234";
const MEMBER_EMAIL = process.env.E2E_WL_MEMBER_EMAIL || "testwhitelabel300@yopmail.com";

const BASE_FEE = 10;
const RULES = [
  { label: "Any Japan Plan", pick: /Any Japan/i, fallback: /Japan/i, fee: 30, kind: "ANY_LOCATION" },
  { label: "Japan 1GB", pick: /Japan\s*1\s*GB/i, fallback: /Japan\s*1/i, fee: 50, kind: "SPECIFIC_PLAN" },
  { label: "Any Vietnam Plan", pick: /Any Vietnam/i, fallback: /Vietnam/i, fee: 40, kind: "ANY_LOCATION" },
] as const;

type State = { p2?: PartnerState & { plans?: any[]; existingWhi?: string[] }; completed?: string[] };
const st = stateFile(path.join(path.dirname(evidence.SCREENSHOT_DIR), "ESKIMO-910-state.json"));
const load = () => st.load<State>();
const save = (s: State) => st.save(s);

const shot = (page: Page, testInfo: TestInfo, title: string, steps: string[], expected: string[], ok = true) =>
  evidence.saveScreenshot(page, testInfo, { ac: AC, title, steps, expected, status: ok ? undefined : "failed" });
const table = (head: string[], rows: unknown[][]) =>
  "<table><tr>" + head.map((h) => "<th>" + esc(h) + "</th>").join("") + "</tr>" + rows.map((r) => "<tr>" + r.map((c) => "<td>" + esc(c) + "</td>").join("") + "</tr>").join("") + "</table>";
async function card(browser: Browser, testInfo: TestInfo | undefined, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const savedLine = (x: Awaited<ReturnType<typeof clickOk>>) =>
  "PUT /api/partner/v2 -> " + x.status + " " + x.message + (x.fee ? " ; fee PUT " + x.fee.req + " -> " + x.fee.status + " " + x.fee.message : "") + (x.toasts.length ? " ; toast: " + x.toasts.join(" | ") : "");/** Remember the FE PUT body (restore template) after a successful UI save; clear restored flag. */
function remember(saved: Awaited<ReturnType<typeof clickOk>>) {
  const s = load();
  if (!s.p2) return;
  s.p2.restored = false;
  if (saved.status === 200 && saved.reqBody?.configuration?.hasCorporate) s.p2.feBody = saved.reqBody;
  save(s);
}
const plansOf = (detail: any) => detail?.configuration?.whiteLabelSetting?.plans ?? [];
function restoreBody(feBody: any, hasCorporate: boolean, setting: any, plans: any[]) {
  const body = corporateBody(feBody, hasCorporate, setting);
  body.configuration.whiteLabelSetting = { plans: Array.isArray(plans) ? plans : [] };
  return body;
}
async function restoreAll(browser: Browser, testInfo: TestInfo | undefined) {
  const s = load();
  if (!s.p2 || s.p2.restored) return true;
  const { ctx, page } = await adminSess(browser);
  let all = true;
  try {
    const token = await tokenOf(page);
    evidence.setCase("Cleanup - restore Partner 2");
    let now = await readPartner(token, s.p2);
    const plansEqual = (a: any[], b: any[]) => JSON.stringify(a ?? []) === JSON.stringify(b ?? []);
    const equal = () => diff(s.p2!.snapshot, now.snap).every((x) => x.same) && now.fee === s.p2!.fee && plansEqual(plansOf(now.detail), s.p2!.plans ?? []);
    const notes: string[] = [];
    for (let i = 1; i <= 3 && !equal(); i++) {
      if (s.p2.feBody) {
        const r = await api(token, "PUT", "/api/partner/v2", restoreBody(s.p2.feBody, !!s.p2!.snapshot.hasCorporate, s.p2!.setting, s.p2!.plans ?? []), 2);
        notes.push("#" + i + " PUT partner -> " + r.status + " " + apiMessage(r.json));
      }
      if (now.fee !== s.p2.fee) {
        const payload = s.p2.fee === null ? { clearOverride: true } : { platformFeePercent: s.p2.fee, clearOverride: false };
        const r = await api(token, "PUT", "/api/payment/connect/partners/" + s.p2.code + "/fee", payload, 2);
        notes.push("#" + i + " PUT fee " + JSON.stringify(payload) + " -> " + r.status + " " + apiMessage(r.json));
      }
      now = await readPartner(token, s.p2);
    }
    s.p2.restored = equal();
    all = s.p2.restored;
    save(s);
    await card(browser, testInfo, "Restore - Partner 2 back to the snapshot",
      table(["Field", "Snapshot", "Now", "Result"], [...diff(s.p2.snapshot, now.snap).map((x) => [x.k, JSON.stringify(x.a), JSON.stringify(x.b), x.same ? "same" : "DIFF"]), ["Application Fee", s.p2.fee, now.fee, now.fee === s.p2.fee ? "same" : "DIFF"], ["Fee rules (whiteLabelSetting.plans)", (s.p2.plans ?? []).length, plansOf(now.detail).length, plansEqual(plansOf(now.detail), s.p2.plans ?? []) ? "same" : "DIFF"]]) + "<p>" + esc(notes.join(" ; ") || "nothing to restore") + "</p>",
      { ac: AC, title: "Restore Partner 2 (cleanup)", steps: notes.length ? notes : ["Already equal to the snapshot"], expected: ["Equal to the snapshot taken in TC-01"], status: all ? undefined : "failed" });
    console.log("[ESKIMO-910] restore " + s.p2.name + ": " + (all ? "OK (verified)" : "NOT VERIFIED - restore manually!") + " " + notes.join(" ; "));
  } finally { await ctx.close(); }
  return all;
}

// --- Corporate Program fee-rule UI helpers ---
const addBtn = (page: Page) => page.locator(".custom-button-add-gift-code").filter({ hasText: /Add Application Fee|New Application Fee/i }).first();
const feeRows = (drawer: Locator) => corporate(drawer).body.locator(".list-data-merchant .merchant-item");
const baseFeeInput = (drawer: Locator) => corporate(drawer).body.locator("input#defaultPercentCorporate").first();

async function openRowSelect(page: Page, sel: Locator) {
  await sel.scrollIntoViewIfNeeded().catch(() => {});
  await sel.locator(".ant-select-selector").first().click();
  const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ state: "visible", timeout: 15000 });
  await page.waitForTimeout(500);
  const opts = (await dd.locator(".ant-select-item-option-content").allInnerTexts()).map((t) => t.trim());
  return { dd, opts };
}
async function pickOption(page: Page, dd: Locator, pick: RegExp, fallback: RegExp) {
  let chosen = "";
  let target = dd.locator(".ant-select-item-option").filter({ hasText: pick }).first();
  if (!(await target.count())) target = dd.locator(".ant-select-item-option").filter({ hasText: fallback }).first();
  if (await target.count()) { chosen = (await target.innerText()).trim(); await target.click(); }
  else await page.keyboard.press("Escape");
  return chosen;
}
async function addFeeRule(page: Page, drawer: Locator, rule: { pick: RegExp; fallback: RegExp; fee: number }) {
  await addBtn(page).click();
  await page.waitForTimeout(900);
  const row = feeRows(drawer).last();
  await row.waitFor({ state: "visible", timeout: 10000 });
  const { dd, opts } = await openRowSelect(page, row.locator(".ant-select").first());
  const chosen = await pickOption(page, dd, rule.pick, rule.fallback);
  const typeSel = row.locator(".ant-select").nth(1);
  const typeShown = (await typeSel.locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();
  if (chosen && !/percentage/i.test(typeShown)) {
    await typeSel.locator(".ant-select-selector").first().click();
    const dd2 = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
    await dd2.waitFor({ state: "visible", timeout: 8000 });
    await dd2.locator(".ant-select-item-option").filter({ hasText: /Percentage/i }).first().click();
  } else if (chosen) {
    await page.keyboard.press("Escape");
  }
  if (chosen) {
    const feeInput = row.locator("input.ant-input").first();
    await feeInput.fill(String(rule.fee));
    await focus(feeInput);
  }
  return { chosen, opts, row };
}
async function readFeeRulesUI(drawer: Locator) {
  const rows = feeRows(drawer);
  const n = await rows.count();
  const out: { applyTo: string; fee: string }[] = [];
  for (let i = 0; i < n; i++) {
    const r = rows.nth(i);
    const applyTo = (await r.locator(".ant-select").first().locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();
    const fee = (await r.locator("input.ant-input").first().inputValue({ timeout: 2000 }).catch(() => "")).trim();
    out.push({ applyTo, fee });
  }
  return out;
}
async function deleteFeeRule(page: Page, drawer: Locator, applyToRegex: RegExp) {
  const rows = feeRows(drawer);
  const n = await rows.count();
  for (let i = 0; i < n; i++) {
    const r = rows.nth(i);
    const applyTo = (await r.locator(".ant-select").first().locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();
    if (applyToRegex.test(applyTo)) {
      await r.locator(".merchant-item-delete button").first().click();
      const confirm = page.locator(".ant-modal-confirm:visible, .ant-popover:visible").getByRole("button", { name: /OK|Confirm|Yes/i }).first();
      if (await confirm.isVisible({ timeout: 3000 }).catch(() => false)) await confirm.click();
      return applyTo;
    }
  }
  return "";
}
async function deleteAllFeeRules(page: Page, drawer: Locator) {
  let removed = 0;
  for (;;) {
    const n = await feeRows(drawer).count();
    if (!n) break;
    await feeRows(drawer).first().locator(".merchant-item-delete button").first().click();
    const confirm = page.locator(".ant-modal-confirm:visible, .ant-popover:visible").getByRole("button", { name: /OK|Confirm|Yes/i }).first();
    if (await confirm.isVisible({ timeout: 3000 }).catch(() => false)) await confirm.click();
    await page.waitForTimeout(400);
    removed++;
    if (removed > 20) break;
  }
  return removed;
}
async function saveDiagnostics(page: Page, drawer: Locator) {
  const errs = (await drawer.locator(".ant-form-item-explain-error").allInnerTexts().catch(() => [])).map((t) => t.trim()).filter(Boolean);
  const toasts = (await page.locator(".ant-notification-notice, .ant-message-notice").allInnerTexts().catch(() => [])).map((t) => t.replace(/\s+/g, " ").trim()).filter(Boolean);
  const okVisible = await drawer.locator("button.btn-action-ok:visible").first().isVisible({ timeout: 1000 }).catch(() => false);
  return { errs, toasts, okVisible };
}
const describePlans = (plans: any[]) =>
  (plans ?? []).map((p) => (p.dataPlanName ?? p.countryName ?? p.regionName ?? "(rule)") + " = " + p.value + "% (id:" + (p.dataPlanId ?? "-") + ", country:" + (p.countryId ?? "-") + ", region:" + (p.regionId ?? "-") + ", tier:" + (p.dataPlanTierEnum ?? "-") + ")");
const findRule = (plans: any[], r: { kind: string; pick: RegExp; fallback: RegExp }) =>
  (plans ?? []).find((p) => {
    const name = (p.dataPlanName ?? "") + " " + (p.countryName ?? "") + " " + (p.regionName ?? "");
    const hasId = !!(p.dataPlanId && String(p.dataPlanId).trim());
    return r.kind === "SPECIFIC_PLAN" ? hasId && r.fallback.test(name) : !hasId && r.fallback.test(name);
  });
// --- Admin API: Eskimo Sale search + member Data Purchase ---
const isWhi = (id: string) => /^WHI/i.test(String(id || "").trim());
const saleSearch = (t: string, searchText: string, eskimoTransactionType: number | null = 4, pageSize = 50) =>
  api(t, "POST", "/api/data-plan-sale-transaction/search", { pageIndex: 1, pageSize, type: 1, amountId: null, platformFilter: "", eskimoTransactionType, cashbackFilter: 0, paymentMethodFilter: null, searchText, searchPlanName: "", fromDate: null, toDate: null, sortBy: { fieldName: "PurchaseDate", ascending: false } }).then((r) => (r?.data?.data ?? []) as any[]);
const purchases = (t: string, memberId: string) =>
  api(t, "POST", "/api/membership/Details/DataPurchase", { pageIndex: 1, pageSize: 50, id: memberId, isAscending: false, searchText: "" }).then((r) => (r?.data?.data ?? []) as any[]);

async function wlMember(token: string, email: string, timeoutMs = 180000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const ms = await membersByEmail(token, email);
    const hit = ms.find((m) => Number(m.accountType) === 2 || String(m.workerAccountPartnerId || m.partnerId || "") === P2_CODE);
    if (hit) return hit;
    if (ms.length) return ms[0];
    await new Promise((r) => setTimeout(r, 10000));
  }
  return null;
}
async function whiPurchases(token: string, memberId: string, exclude: Set<string>) {
  const all = await purchases(token, memberId);
  return all.filter((p) => isWhi(p.transactionID || p.transactionId || "") && (p.status === 1 || p.statusName === "Success") && !exclude.has(p.transactionID || p.transactionId || ""));
}
const feeAmount = (tx: any) => Number(tx.value ?? tx.amount ?? tx.relatedTransaction?.metadata?.applicationFee ?? NaN);
const totalPrice = (tx: any) => Number(tx.relatedTransaction?.metadata?.total ?? tx.total ?? NaN);
const txId = (tx: any) => tx.transactionID || tx.transactionId || "";
const planName = (tx: any) => String(tx.dataPlanName || tx.relatedTransaction?.metadata?.dataPlanName || tx.planName || "").trim();

async function buyPlan(browser: Browser, opts: { countryPath: string; area: RegExp; data: string; firstName: string }) {
  const { ctx, page } = await newShopper(browser);
  try {
    const plan = await pickPlan(page, { countryPath: opts.countryPath, area: opts.area, data: opts.data });
    await goToCheckout(page);
    const pay = await continueToPayment(page, opts.firstName, MEMBER_EMAIL);
    if (pay.outcome !== "card") throw new Error("Checkout did not reach the card step (" + pay.outcome + "): " + pay.errors.join("; "));
    const res = await payWithCard(page, CARD_OK);
    if (res.outcome !== "complete") throw new Error("Payment did not complete (" + res.outcome + "): " + res.error);
    const complete = await readCompletePage(page);
    return { plan, orderNumber: complete.orderNumber, rows: complete.rows };
  } finally { await ctx.close(); }
}

async function snapshotP2(token: string): Promise<PartnerState & { plans: any[]; existingWhi: string[] }> {
  const p = await findPartner(token, P2);
  if (!p) throw new Error("Partner " + P2 + " not found");
  const now = await readPartner(token, p);
  const plans = plansOf(now.detail);
  const existing = new Set<string>();
  const mem = await wlMember(token, MEMBER_EMAIL, 60000).catch(() => null);
  if (mem) (await whiPurchases(token, mem.id, new Set())).forEach((x) => existing.add(txId(x)));
  return { id: p.id, code: p.code, name: p.name, snapshot: now.snap, setting: now.detail?.configuration?.corporateSetting, fee: now.fee, feBody: undefined, restored: false, plans, existingWhi: [...existing] };
}

// --- Shared session + state (re-created after a worker restart) ---
let admin: { ctx: BrowserContext; page: Page };
let t = "";
test.describe("ESKIMO-910 White Label Multiple Application Fee rules " + ID, () => {
  test.beforeAll(async ({ browser }) => {
    test.setTimeout(300000);
    admin = await adminSess(browser);
    t = await adminToken(admin.page);
    const s = load();
    if (!s.p2 || !s.p2.feBody) {
      s.p2 = await snapshotP2(t);
      save(s);
    }
    console.log("[ESKIMO-910] snapshot P2: fee=" + s.p2.fee + ", plans=" + (s.p2.plans ?? []).length + ", existing WHI=" + (s.p2.existingWhi ?? []).length);
  });

  test.afterAll(async ({ browser }, testInfo) => {
    await restoreAll(browser, testInfo);
  });
  // --- AC1 ---
  test("TC-01 Base rule Any Data Plan: first, locked, no delete; empty = default 10% " + ID, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 AC1 base rule");
    const { ctx, page } = await adminSess(browser);
    try {
      const { drawer } = await openCorporate(page, P2);
      const c = corporate(drawer);
      const baseSelect = c.body.locator(".ant-select").filter({ hasText: /Any Data Plan/i }).first();
      const baseDisabled = await baseSelect.locator(".ant-select-selector").first().evaluate((el) => el.classList.contains("ant-select-disabled") || (el.querySelector("input") as HTMLInputElement | null)?.disabled === true).catch(() => false);
      const fee = await baseFeeInput(drawer).inputValue({ timeout: 3000 }).catch(() => "");
      const placeholder = await baseFeeInput(drawer).getAttribute("placeholder").catch(() => "");
      const baseHasDelete = await c.body.locator(".ant-select").filter({ hasText: /Any Data Plan/i }).first().locator("xpath=ancestor::div[contains(@class,'merchant-item')]").filter({ has: page.locator(".merchant-item-delete") }).count().catch(() => 0);
      const bodyText = (await c.body.innerText({ timeout: 3000 }).catch(() => "")).replace(/\s+/g, " ");
      const defaultHint = /default fee \(?10%\)?/i.test(bodyText) || /10 \(default\)/i.test(String(placeholder)) || /default/i.test(String(placeholder));
      await focus(baseFeeInput(drawer));
      await shot(page, testInfo, "TC-01 Base rule Any Data Plan", [
        "Apply To Any Data Plan select disabled: " + baseDisabled,
        "Base Fee value: \"" + fee + "\" (current config; empty = default 10% is the behaviour)",
        "Base Fee placeholder: \"" + placeholder + "\"",
        "Default-fee hint shown: " + defaultHint,
        "Base row has a delete button: " + (baseHasDelete > 0 ? "YES (should NOT)" : "no"),
        "Existing added rules: " + (await feeRows(drawer).count()),
      ], ["Base rule always first; Apply To locked; row cannot be deleted; empty value = default fee (10%)"], baseDisabled && baseHasDelete === 0 && defaultHint);
      expect(baseDisabled, "Apply To of the base rule is locked").toBe(true);
      expect(baseHasDelete, "base rule has no delete button").toBe(0);
      expect(defaultHint, "default-fee hint (placeholder " + placeholder + ")").toBe(true);
    } finally { await ctx.close(); }
  });

  // --- AC2 ---
  test("TC-02 Add 3 Application Fee rules + base, save, verify " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("TC-02 AC2 add rules");
    const { ctx, page } = await adminSess(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const o = await openCorporate(page, P2);
      const cleared = await deleteAllFeeRules(page, o.drawer);
      await baseFeeInput(o.drawer).fill(String(BASE_FEE));
      await focus(baseFeeInput(o.drawer));
      const added: { label: string; chosen: string; opts: string[]; fee: number }[] = [];
      for (const r of RULES) {
        const res = await addFeeRule(page, o.drawer, r);
        added.push({ label: r.label, chosen: res.chosen, opts: res.opts, fee: r.fee });
        await page.waitForTimeout(400);
      }
      const uiRows = await readFeeRulesUI(o.drawer);
      await shot(page, testInfo, "TC-02 Rules before Ok (base 10 + 3 rules)", [
        "Cleared existing rules: " + cleared,
        "Base fee: " + BASE_FEE + "%",
        ...added.map((a) => "Add \"" + a.label + "\" -> chosen \"" + a.chosen + "\" (fee " + a.fee + "%) ; Apply To options: " + a.opts.slice(0, 12).join(" / ") + (a.opts.length > 12 ? " ..." : "")),
        "UI rows: " + uiRows.map((r) => r.applyTo + "=" + r.fee).join(" | "),
      ], ["3 rules added (Any Japan 30, Japan 1GB 50, Any Vietnam 40) + base 10"], added.every((a) => a.chosen));
      const saved = await clickOk(page, o.drawer);
      remember(saved);
      const diag = saved.status !== 200 ? await saveDiagnostics(page, o.drawer) : { errs: [], toasts: [], okVisible: false };
      const now = await readPartner(token, s.p2!);
      const plans = plansOf(now.detail);
      const okFee = now.fee === BASE_FEE;
      const okCount = plans.length === RULES.length;
      await card(browser, testInfo, "TC-02 - saved whiteLabelSetting.plans (API)",
        table(["#", "Apply To (API)", "Fee %", "dataPlanId", "countryId", "regionId", "tier"], plans.map((p, i) => [String(i + 1), p.dataPlanName ?? p.countryName ?? p.regionName ?? "(rule)", p.value, p.dataPlanId ?? "-", p.countryId ?? "-", p.regionId ?? "-", p.dataPlanTierEnum ?? "-"])) + "<p>" + savedLine(saved) + "</p><p>Effective platformFeePercent = " + now.fee + "</p>" + (diag.errs.length || diag.toasts.length ? "<p>[WARN] Save blocked - validation errors: " + (diag.errs.join(" | ") || "(none)") + " ; toasts: " + (diag.toasts.join(" | ") || "(none)") + " ; Ok still visible: " + diag.okVisible + "</p>" : ""),
        { ac: AC, title: "TC-02 DATA saved rules + base fee", steps: [savedLine(saved), ...describePlans(plans), ...(diag.errs.length ? ["validation errors: " + diag.errs.join(" | ")] : []), ...(diag.toasts.length ? ["toasts: " + diag.toasts.join(" | ")] : []), "UI rows before Ok: " + uiRows.map((r) => r.applyTo + "=" + r.fee).join(" | "), "Apply To options offered: " + added.map((a) => a.label + "->" + a.chosen).join(" ; "), "Ok still visible after click: " + diag.okVisible], expected: ["platformFeePercent = " + BASE_FEE, RULES.length + " rules saved", "If GAP: the FE does not save multiple fee rules (Apply To Any* options missing or save blocked) -> flag and report"], status: okFee && okCount ? undefined : "failed" });
      if (saved.status !== 200) console.log("[ESKIMO-910] TC-02 save blocked: status=" + saved.status + " validation=[" + diag.errs.join(" | ") + "] toasts=[" + diag.toasts.join(" | ") + "] okStillVisible=" + diag.okVisible + " added=" + added.map((a) => a.label + "->" + a.chosen + "=" + a.fee + "%").join(" ; ") + " uiRows=" + uiRows.map((r) => r.applyTo + "=" + r.fee).join(" | "));
      expect(saved.status, "save: " + savedLine(saved)).toBe(200);
      expect(okFee, "base fee effective").toBe(true);
      expect(okCount, "3 rules saved").toBe(true);
      const r = await openCorporate(page, P2);
      const uiAfter = await readFeeRulesUI(r.drawer);
      const feeAfter = await baseFeeInput(r.drawer).inputValue().catch(() => "");
      await shot(page, testInfo, "TC-02 Reopened: rules + base fee", [
        "Reopened base fee: \"" + feeAfter + "\"",
        "Reopened rows: " + uiAfter.map((u) => u.applyTo + "=" + u.fee).join(" | "),
      ], ["Rules + base fee persisted after reopen"], feeAfter === String(BASE_FEE) && uiAfter.length === RULES.length);
      expect(uiAfter.length, "rules shown after reopen").toBe(RULES.length);
    } finally { await ctx.close(); }
  });
  test("TC-02b Edit a rule fee, save, verify " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("TC-02b AC2 edit rule");
    const { ctx, page } = await adminSess(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const o = await openCorporate(page, P2);
      const rows = feeRows(o.drawer);
      const n = await rows.count();
      let edited = false;
      for (let i = 0; i < n; i++) {
        const r = rows.nth(i);
        const applyTo = (await r.locator(".ant-select").first().locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();
        if (/Any Japan/i.test(applyTo)) {
          await r.locator("input.ant-input").first().fill("25");
          await focus(r.locator("input.ant-input").first());
          edited = true;
          break;
        }
      }
      await shot(page, testInfo, "TC-02b Any Japan fee 30 -> 25 before Ok", ["Rule found & edited: " + edited], ["Any Japan fee saved as 25"], edited);
      const saved = await clickOk(page, o.drawer);
      remember(saved);
      const now = await readPartner(token, s.p2!);
      const plans = plansOf(now.detail);
      const japan = findRule(plans, RULES[0]);
      const ok = japan && Number(japan.value) === 25;
      await card(browser, testInfo, "TC-02b - Any Japan fee after edit (API)", table(["Apply To", "Fee %"], plans.map((p) => [p.dataPlanName ?? p.countryName ?? p.regionName ?? "(rule)", p.value])) + "<p>" + savedLine(saved) + "</p>", { ac: AC, title: "TC-02b DATA Any Japan = 25", steps: [savedLine(saved), ...describePlans(plans)], expected: ["Any Japan Plan = 25; other rules unchanged"], status: ok ? undefined : "failed" });
      expect(edited, "Any Japan rule row found to edit").toBe(true);
      expect(Number(japan?.value), "Any Japan fee = 25").toBe(25);
    } finally { await ctx.close(); }
  });

  test("TC-02c Delete a rule then re-add, save, verify " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("TC-02c AC2 delete + re-add");
    const { ctx, page } = await adminSess(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      let o = await openCorporate(page, P2);
      const deleted = await deleteFeeRule(page, o.drawer, /Any Vietnam/i);
      await shot(page, testInfo, "TC-02c Delete Any Vietnam before Ok", ["Deleted row: \"" + deleted + "\""], ["Any Vietnam rule removed"], !!deleted);
      let saved = await clickOk(page, o.drawer);
      remember(saved);
      let now = await readPartner(token, s.p2!);
      let plans = plansOf(now.detail);
      const afterDelete = plans.length === RULES.length - 1 && !findRule(plans, RULES[2]);
      await card(browser, testInfo, "TC-02c - after delete (API)", table(["Apply To", "Fee %"], plans.map((p) => [p.dataPlanName ?? p.countryName ?? p.regionName ?? "(rule)", p.value])) + "<p>" + savedLine(saved) + "</p>", { ac: AC, title: "TC-02c DATA after delete", steps: [savedLine(saved), ...describePlans(plans)], expected: [RULES.length - 1 + " rules (Any Vietnam removed)"], status: afterDelete ? undefined : "failed" });
      expect(afterDelete, "Any Vietnam removed, 2 rules left").toBe(true);
      o = await openCorporate(page, P2);
      const res = await addFeeRule(page, o.drawer, RULES[2]);
      await shot(page, testInfo, "TC-02c Re-add Any Vietnam = 40 before Ok", ["Chosen: \"" + res.chosen + "\"", "Options: " + res.opts.slice(0, 12).join(" / ")], ["Any Vietnam rule re-added = 40"], !!res.chosen);
      saved = await clickOk(page, o.drawer);
      remember(saved);
      now = await readPartner(token, s.p2!);
      plans = plansOf(now.detail);
      const vietnam = findRule(plans, RULES[2]);
      const ok = plans.length === RULES.length && vietnam && Number(vietnam.value) === 40;
      await card(browser, testInfo, "TC-02c - after re-add (API)", table(["Apply To", "Fee %"], plans.map((p) => [p.dataPlanName ?? p.countryName ?? p.regionName ?? "(rule)", p.value])) + "<p>" + savedLine(saved) + "</p>", { ac: AC, title: "TC-02c DATA after re-add", steps: [savedLine(saved), ...describePlans(plans)], expected: ["3 rules again (Any Vietnam = 40)"], status: ok ? undefined : "failed" });
      expect(plans.length, "3 rules after re-add").toBe(RULES.length);
      expect(Number(vietnam?.value), "Any Vietnam fee = 40").toBe(40);
    } finally { await ctx.close(); }
  });
  // --- AC3 ---
  test("TC-03 Purchase 3 plans -> Admin validate Application Fee per plan " + ID, async ({ browser }, testInfo) => {
    test.setTimeout(30 * 60 * 1000);
    evidence.setCase("TC-03 AC3 fee per plan");
    const token = t;
    const s = load();
    const exclude = new Set<string>(s.p2!.existingWhi ?? []);
    const buys = [
      { key: "Japan 1GB", fee: 50, countryPath: "/en/plans/japan-esim", area: /^Japan/i, data: "1GB", firstName: "E2e910 Jp" },
      { key: "Vietnam 1GB", fee: 40, countryPath: "/en/plans/vietnam-esim", area: /^Vietnam/i, data: "1GB", firstName: "E2e910 Vn" },
      { key: "United States 1GB", fee: 10, countryPath: "/en/plans/united-states-esim", area: /^United States|^US/i, data: "1GB", firstName: "E2e910 Us" },
    ] as const;
    const orders: { key: string; fee: number; plan: string; orderNumber: string; error?: string }[] = [];
    for (const b of buys) {
      const r = await buyPlan(browser, b).catch((e) => ({ plan: "", orderNumber: "", rows: {} as Record<string, string>, error: String(e) }) as any);
      orders.push({ key: b.key, fee: b.fee, plan: r.plan ?? "", orderNumber: r.orderNumber ?? "", error: r.error });
      await card(browser, testInfo, "TC-03 purchase " + b.key + " (expected fee " + b.fee + "%)", "<p>" + esc(r.error ? "FAILED: " + r.error : "Plan: " + r.plan + " ; Order: " + r.orderNumber) + "</p>", { ac: AC + " AC3", title: "TC-03 buy " + b.key, steps: ["Storefront " + b.countryPath + " -> " + b.data + " -> checkout -> CARD_OK", r.error ? r.error : "Order " + r.orderNumber], expected: ["Payment complete; Application Fee " + b.fee + "%"], status: r.error ? "failed" : undefined });
      if (!r.error) await new Promise((res) => setTimeout(res, 2000));
    }
    const member = await wlMember(token, MEMBER_EMAIL, 240000);
    if (!member) throw new Error("Environment: WL member " + MEMBER_EMAIL + " not found after purchases");
    let newWhi: any[] = [];
    const deadline = Date.now() + 240000;
    while (Date.now() < deadline && newWhi.length < orders.filter((o) => !o.error).length) {
      newWhi = await whiPurchases(token, member.id, exclude);
      if (newWhi.length < orders.filter((o) => !o.error).length) await new Promise((r) => setTimeout(r, 10000));
    }
    const rows: unknown[][] = [];
    const results: { key: string; tx: string; plan: string; total: number; fee$: number; feePct: number; expectedPct: number; ok: boolean }[] = [];
    for (const o of orders) {
      if (o.error) { results.push({ key: o.key, tx: "", plan: "", total: NaN, fee$: NaN, feePct: NaN, expectedPct: o.fee, ok: false }); continue; }
      const tx = newWhi.find((x) => {
        const pn = planName(x);
        const country = o.key.split(" ")[0];
        return (pn && new RegExp(country, "i").test(pn)) || String(x.relatedTransaction?.metadata?.id ?? x.relatedTransaction?.metadata?.orderId ?? "").includes(o.orderNumber);
      }) ?? newWhi.find((x) => !results.some((r) => r.tx === txId(x)));
      const total = tx ? totalPrice(tx) : NaN;
      const fee$ = tx ? feeAmount(tx) : NaN;
      const feePct = Number.isFinite(total) && total > 0 ? Math.round((fee$ / total) * 1000) / 10 : NaN;
      const ok = tx != null && Number.isFinite(total) && Math.abs(feePct - o.fee) <= 0.6;
      results.push({ key: o.key, tx: tx ? txId(tx) : "(not found)", plan: tx ? planName(tx) : "", total, fee$: fee$, feePct, expectedPct: o.fee, ok });
      rows.push([o.key, tx ? txId(tx) : "(not found)", tx ? planName(tx) : "", total, fee$, feePct, o.fee + "%", ok ? "PASS" : "FAIL"]);
    }
    const allOk = results.filter((r) => r.tx !== "(not found)").length === orders.filter((o) => !o.error).length && results.every((r) => r.ok);
    await card(browser, testInfo, "TC-03 - Application Fee per plan (Admin Eskimo Sale)", table(["Plan bought", "WHI Transaction", "Data plan", "Total", "Value (fee $)", "Fee %", "Expected", "Result"], rows), { ac: AC + " AC3", title: "TC-03 DATA fee per plan", steps: ["Member: " + MEMBER_EMAIL + " (" + member.id + ")", "Existing WHI excluded: " + exclude.size, "New WHI found: " + newWhi.length, ...results.map((r) => r.key + ": tx " + r.tx + ", total " + r.total + ", fee $" + r.fee$ + " = " + r.feePct + "% (expected " + r.expectedPct + "%) -> " + (r.ok ? "PASS" : "FAIL"))], expected: ["Japan 1GB -> 50%", "Vietnam 1GB -> 40%", "US 1GB -> 10%", "Value = total x fee% (plus/minus cent rounding)"], status: allOk ? undefined : "failed" });
    s.p2!.existingWhi = [...exclude, ...newWhi.map(txId)];
    save(s);
    if (!allOk) console.log("[ESKIMO-910] TC-03 fee per plan: " + results.map((r) => r.key + " " + r.feePct + "% (exp " + r.expectedPct + "%) " + (r.ok ? "PASS" : "FAIL")).join(" ; "));
    expect(newWhi.length, "new WHI transactions found after purchases").toBeGreaterThan(0);
    expect(allOk, "every purchased plan fee matches its rule").toBe(true);
  });
  test("TC-04 Orders keep their fee after Admin changes a rule " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("TC-04 AC3 keep fee");
    const token = t;
    const s = load();
    const member = await wlMember(token, MEMBER_EMAIL, 60000).catch(() => null);
    const beforeSet = new Set<string>((s.p2!.existingWhi ?? []));
    const before = member ? await whiPurchases(token, member.id, new Set()) : [];
    const tracked = before.filter((x) => beforeSet.has(txId(x))).map((x) => ({ tx: txId(x), total: totalPrice(x), fee$: feeAmount(x) }));
    const { ctx, page } = await adminSess(browser);
    try {
      const o = await openCorporate(page, P2);
      await baseFeeInput(o.drawer).fill("20");
      await focus(baseFeeInput(o.drawer));
      await shot(page, testInfo, "TC-04 Base fee 10 -> 20 before Ok", ["Tracked old WHI: " + tracked.map((x) => x.tx + "=$" + x.fee$).join(", ")], ["Old orders keep their fee"], true);
      const saved = await clickOk(page, o.drawer);
      remember(saved);
      const nowFee = (await readPartner(token, s.p2!)).fee;
      const after = member ? await whiPurchases(token, member.id, new Set()) : [];
      const afterMap = new Map(after.map((x) => [txId(x), x]));
      const rows = tracked.map((x) => { const ax = afterMap.get(x.tx); const aFee = ax ? feeAmount(ax) : NaN; return [x.tx, x.fee$, aFee, x.fee$ === aFee ? "same" : "CHANGED"]; });
      const ok = tracked.length > 0 && tracked.every((x) => { const ax = afterMap.get(x.tx); return ax && feeAmount(ax) === x.fee$; });
      await card(browser, testInfo, "TC-04 - old WHI value before vs after base fee change", table(["WHI", "Value before", "Value after", "Result"], rows) + "<p>" + savedLine(saved) + " ; effective fee now " + nowFee + "</p>", { ac: AC + " AC3", title: "TC-04 DATA orders keep fee", steps: [savedLine(saved), "Base fee now " + nowFee, ...rows.map((r) => r.join(" | "))], expected: ["Each old WHI Value unchanged after the rule change"], status: ok ? undefined : "failed" });
      expect(tracked.length, "WHI transactions from TC-03 to check").toBeGreaterThan(0);
      expect(ok, "old orders kept their fee").toBe(true);
    } finally { await ctx.close(); }
  });

  // --- AC4 ---
  test("TC-05 Disable -> Enable keeps all Application Fee rules " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("TC-05 AC4 disable/enable");
    const { ctx, page } = await adminSess(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const before = await readPartner(token, s.p2!);
      const beforePlans = plansOf(before.detail);
      const beforeFee = before.fee;
      let o = await openCorporate(page, P2);
      if (!(await corporate(o.drawer).statusSwitch.evaluate((el) => el.classList.contains("ant-switch-checked")))) {
        await o.statusSwitch.click();
        const w = page.locator(".modal-dialog:visible").filter({ hasText: /Warning/i }).getByRole("button", { name: /Confirm/i }).first();
        if (await w.isVisible({ timeout: 4000 }).catch(() => false)) await w.click();
        await clickOk(page, o.drawer);
      }
      o = await openCorporate(page, P2);
      await o.statusSwitch.click();
      const warn = page.locator(".modal-dialog:visible").filter({ hasText: /Warning/i }).getByRole("button", { name: /Confirm/i }).first();
      if (await warn.isVisible({ timeout: 4000 }).catch(() => false)) await warn.click();
      await shot(page, testInfo, "TC-05 Status OFF before Ok", ["Status -> OFF"], ["Program Disabled (rules must be kept)"], true);
      let saved = await clickOk(page, o.drawer);
      remember(saved);
      o = await openCorporate(page, P2);
      await o.statusSwitch.click();
      await shot(page, testInfo, "TC-05 Status ON before Ok", ["Status -> ON (no rule edit)"], ["Program re-enabled; rules retained"], true);
      saved = await clickOk(page, o.drawer);
      remember(saved);
      const after = await readPartner(token, s.p2!);
      const afterPlans = plansOf(after.detail);
      const plansEqual = JSON.stringify(afterPlans) === JSON.stringify(beforePlans);
      const ok = after.fee === beforeFee && plansEqual && after.snap.hasCorporate === true;
      await card(browser, testInfo, "TC-05 - rules retained after disable/enable", table(["Item", "Before", "After", "Result"], [["hasCorporate", before.snap.hasCorporate, after.snap.hasCorporate, after.snap.hasCorporate === true ? "ON" : "DIFF"], ["Application Fee", beforeFee, after.fee, after.fee === beforeFee ? "same" : "DIFF"], ["Fee rules count", beforePlans.length, afterPlans.length, beforePlans.length === afterPlans.length ? "same" : "DIFF"], ["Fee rules equal", "", "", plansEqual ? "same" : "DIFF"]]) + "<p>OFF save: " + savedLine(saved) + "</p>", { ac: AC + " AC4", title: "TC-05 DATA rules retained", steps: ["Before: fee " + beforeFee + ", " + beforePlans.length + " rules", "After: fee " + after.fee + ", " + afterPlans.length + " rules", "Rules equal: " + plansEqual, ...describePlans(afterPlans)], expected: ["All Application Fee rules + base fee retained after disable -> enable"], status: ok ? undefined : "failed" });
      expect(after.snap.hasCorporate, "program re-enabled").toBe(true);
      expect(after.fee, "base fee retained").toBe(beforeFee);
      expect(plansEqual, "fee rules retained").toBe(true);
    } finally { await ctx.close(); }
  });
});
