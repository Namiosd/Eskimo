# ESKIMO-383 – [EP-6055] [Admin Corporate Program] White Label config missing required AC fields

Nguồn: mô tả bug ESKIMO-383; Expected = AC1 của EP-5991 / ESKIMO-757 (bản AC đã sửa, phase 1). Cập nhật QC 2026-10-19.
Môi trường: Admin Portal STAGE = E2E_ADMIN_URL (app-eskimo-admin-stage-sea-001), API stage = E2E_API_URL
Test data: Partner PN105327 "white label test Dev" (Corporate Program Type = White label), chưa kết nối Stripe.

Thay đổi AC gốc (EP-5991, phase 1) so với lúc bug được tạo:
- Payment Method: Direct Charge; "Eskimo Stripe Pay" ẩn ở phase 1
- Data Expiry: 2 Years; "No Expiry" ẩn ở phase 1
- Stripe Connect Status: chưa kết nối → "Not Connected"; đã verify → "Verified" (không còn "Onboarding Link")
- Network Partner Commission (%) không áp dụng cho White Label
- Application Fee Percentage hiển thị khi Type = White Label (AC3)

Quyết định QC:
- Chỉ đọc: mở form, đọc field, mở dropdown; không Save.
- Expected lấy từ AC, không lấy từ app.
- "Ẩn ở phase 1" chấp nhận ẩn HOẶC disable: chỉ cần phase 1 không chọn được (QC thống nhất 2026-10-19).

## TC-01 Form Corporate Program (Type = White label) mở được cho PN105327 (precondition)
- Steps: Admin → Partnership › Partners → search PN105327 → Edit → section Corporate Program
- Expected: Section hiển thị; có Status, Type = "White label" (disabled), Start Date, End Date

## TC-02 Data Expiry dropdown – phase 1 chỉ "2 Years" (AC1)
- Steps: Tìm field "Data Expiry", mở dropdown
- Expected: Field hiển thị; chọn được "2 Years"; KHÔNG chọn được "No Expiry" (ẩn hoặc disable đều đạt – phase 1)

## TC-03 Eskimo Email Notification là toggle True/False (AC1, AC2)
- Steps: Tìm field "Eskimo Email Notification"
- Expected: Hiển thị dạng toggle (switch)
- Ghi chú: "Default: False" chỉ kiểm được khi tạo partner WL mới → chưa cover (read-only)

## TC-04 Payment Method – phase 1 chỉ "Direct Charge" (AC1)
- Steps: Mở dropdown "Payment method"
- Expected: Chọn được "Direct Charge"; KHÔNG chọn được "Eskimo Stripe Pay" (ẩn hoặc disable đều đạt – phase 1); KHÔNG có "Direct Credit Top Up" (logic cũ)

## TC-05 Stripe Connect Status – partner chưa kết nối hiển thị "Not Connected" (AC1)
- Steps: Xem field "Stripe Connect Status" (PN105327 chưa kết nối Stripe)
- Expected: Field hiển thị, giá trị "Not Connected" (đã verify thì "Verified")
- Chấp nhận (QC thống nhất 2026-10-19): partner CHƯA từng thực hiện connect → chưa có status nào → hiển thị "—" kèm gợi ý "The partner connects Stripe from the Partner portal (My Website)." = PASS

## TC-06 Không có Network Partner Commission (%) cho White Label (AC1)
- Expected: Section Corporate Program không có field "Network Partner Commission"

## TC-07 Hiển thị Application Fee Percentage khi Type = White Label (AC3)
- Expected: Có section "Application Fee Percentage" (thay cho Discount Benefit)

## Chưa cover
- Default Email Notification = False (cần tạo partner WL mới)
- Trạng thái "Verified" (cần partner đã verify Stripe)
- Regression form Corporate/Reseller thường
