// ESKIMO-763 / EP-6072 – White Label transactions + accounts in Admin (Eskimo Sale, Membership Detail) and
// Partner Portal (Corporate › Top Up History, Corporate › Accounts).
// Test cases: testcases/ESKIMO-763/ESKIMO-763.md (expected results = the item's AC1–AC4):
//   TC-01 Eskimo Sale: WHI… transaction, Type "White Label Payment"                     (AC1.1)
//   TC-02 Eskimo Sale: "White Label Payment" ⇔ Transaction ID starts with WHI            (AC1)
//   TC-03 Membership Detail › Data Purchase lists the WHI… transaction                   (AC1.2)
//   TC-04 Partner WL › Corporate › Top Up History: WHI…, Transaction Type "White Label Payment" (AC1.3)
//   TC-05 Partner WL › Corporate › Accounts lists the White Label account                (AC2)
//   TC-06 Accounts unaffected: WL partner list loads; a normal corporate partner does not see the WL account (AC2)
//   TC-07 WHI… detail shows "Transaction Partner ID" + "Transaction Price"               (AC3)
//   TC-08 non-WHI detail has neither field                                               (AC3)
//   TC-09 WL account: title "White Label Account" + row "White Label Partner" (PN101609) (AC4)
//   TC-10 Personal / Work account: title unchanged, no "White Label Partner" row        (AC4)
// Read-only: existing transactions of wlb2 = PN101609 "WhiteLabel Partner 2" (wlb@yopmail.com); nothing bought or refunded.
// Evidence: evidence/ESKIMO-763-white-label-transactions → npm run report:evidence -- ESKIMO-763 white-label-transactions
import { test, expect, type Browser, type BrowserContext, type Locator, type Page, type TestInfo } from "@playwright/test";
import { adminSession, partnerSession, ADMIN_URL, PARTNER_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import { API_URL, adminToken, memberDetail, membersByEmail } from "../_support/wellatsea";

const ID = "@ESKIMO-763";
const AC = "EP-6072";
const evidence = createEvidence("ESKIMO-763", "white-label-transactions");
const PARTNER_CODE = process.env.E2E_WL_PARTNER_CODE || "PN101609";
const WL_MEMBER_EMAIL = process.env.E2E_WL_MEMBER_EMAIL || "testwhitelabel168@yopmail.com";
const WL_TYPE = "White Label Payment";
const isWhi = (id: string) => /^WHI/i.test(id.trim());

// ─── Stage API (it sometimes answers 200 with an empty body → retry until JSON) ───
async function api(token: string, method: string, p: string, body?: unknown) {
  for (let i = 0; i < 6; i++) {
    const r = await fetch(`${API_URL}${p}`, { method, headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: body === undefined ? undefined : JSON.stringify(body) }).catch(() => null);
    const text = r ? await r.text().catch(() => "") : "";
    try { if (text) return JSON.parse(text); } catch { /* not JSON */ }
    await new Promise((res) => setTimeout(res, 1000));
  }
  return null;
}
const pageToken = (page: Page) => page.evaluate(() => localStorage.getItem("accessToken") || "");
const saleSearch = (t: string, searchText: string, eskimoTransactionType: number | null = null, pageSize = 20) =>
  api(t, "POST", "/api/data-plan-sale-transaction/search", { pageIndex: 1, pageSize, type: 1, amountId: null, platformFilter: "", eskimoTransactionType, cashbackFilter: 0, paymentMethodFilter: null, searchText, searchPlanName: "", fromDate: null, toDate: null, sortBy: { fieldName: "PurchaseDate", ascending: false } }).then((r) => (r?.data?.data ?? []) as any[]);
const purchases = (t: string, memberId: string) =>
  api(t, "POST", "/api/membership/Details/DataPurchase", { pageIndex: 1, pageSize: 20, id: memberId, isAscending: false, searchText: "" }).then((r) => (r?.data?.data ?? []) as any[]);
const accountSearch = (t: string, searchText: string) =>
  api(t, "POST", "/api/partner/worker-management/search", { pageIndex: 1, pageSize: 20, searchText, accountStatus: null, isFilterEsimStatus: false, esimStatus: null, sortBy: { fieldName: "CreatedOn", ascending: false } }).then((r) => (r?.data?.data ?? []) as any[]);
const topUpSearch = (t: string, searchByTransactionId: string) =>
  api(t, "POST", "/api/partner/corporate/search-top-up-histories", { pageIndex: 1, pageSize: 20, searchByTransactionId, searchByPlanName: "", searchByMember: "", fromDate: null, toDate: null, transactionType: 0, sortBy: null }).then((r) => (r?.data?.data ?? []) as any[]);

// ─── UI helpers (antd tables; few roles/test ids exist in the portal) ───
const spinnerGone = (page: Page) => page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
const mark = (l: Locator) => l.evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", background: "rgba(255,229,143,.95)" })).catch(() => {});

/** Rows of the first visible antd table with a header, as {header: cell text} + the row locator. */
async function readTable(page: Page, root: Locator = page.locator("body")) {
  const table = root.locator(".ant-table:visible").filter({ has: page.locator(".ant-table-thead") }).first();
  await table.waitFor({ state: "visible", timeout: 60000 });
  await spinnerGone(page);
  const headers = (await table.locator(".ant-table-thead tr").last().locator("th").allInnerTexts()).map((h) => h.trim());
  const rows = table.locator(".ant-table-tbody tr.ant-table-row");
  const out: { row: Locator; cells: Record<string, string> }[] = [];
  for (let i = 0; i < (await rows.count()); i++) {
    const texts = (await rows.nth(i).locator("> td").allInnerTexts()).map((t) => t.replace(/\s+/g, " ").trim());
    out.push({ row: rows.nth(i), cells: Object.fromEntries(headers.map((h, j) => [h, texts[j] ?? ""])) });
  }
  return { headers, rows: out };
}
const cellOf = (row: { row: Locator }, headers: string[], header: string) => row.row.locator("> td").nth(headers.indexOf(header));

async function searchBox(page: Page, placeholder: string, text: string) {
  const box = page.getByPlaceholder(placeholder, { exact: true }).first();
  await box.fill(text);
  await box.press("Enter");
  await spinnerGone(page);
}

/** Admin Membership Detail drawer (#/membership?detail=<id>). */
async function openMemberDetail(page: Page, memberId: string) {
  // A hash-only change keeps the previous member's drawer open → reload so ?detail= is read again
  await page.goto(`${ADMIN_URL}/#/membership?detail=${memberId}`, { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
  const drawer = page.locator(".ant-drawer-open .ant-drawer-content").first();
  await drawer.getByText("Data Purchase", { exact: true }).first().waitFor({ state: "visible", timeout: 60000 });
  await spinnerGone(page);
  return drawer;
}
const accountTitle = async (drawer: Locator) => {
  // MemberAccount header: "Personal Account" / "Work Account" / "Account" (/ "White Label Account" per AC4)
  const h = drawer.locator(".custom-title-membership-detail").filter({ hasText: /^\s*(.+ )?Account\s*$/ }).first();
  await h.waitFor({ state: "visible", timeout: 20000 }).catch(() => {});
  await mark(h);
  return (await h.innerText().catch(() => "(missing)")).trim();
};
const accountRow = (drawer: Locator, label: string) => drawer.locator("tr").filter({ has: drawer.page().locator("td", { hasText: new RegExp(`^\\s*${label}\\s*:?\\s*$`) }) }).first();

/** Data Purchase: expand the row of `transactionId`; returns the expanded detail panel. */
async function expandPurchase(drawer: Locator, transactionId: string) {
  const section = drawer.locator(".my-custom-data-wallet").filter({ hasText: "Data Purchase" }).first();
  const row = section.locator("tr.ant-table-row").filter({ hasText: transactionId }).first();
  await row.waitFor({ state: "visible", timeout: 30000 });
  await row.locator(".anticon-right").first().click();
  const detail = row.locator("xpath=following-sibling::tr[contains(@class,'ant-table-expanded-row')][1]");
  await detail.waitFor({ state: "visible", timeout: 15000 });
  await row.scrollIntoViewIfNeeded();
  await mark(detail);
  return { row, detail };
}
const formItem = (detail: Locator, label: string) => detail.locator(".ant-form-item").filter({ has: detail.page().locator(".ant-form-item-label", { hasText: new RegExp(`^\\s*${label}\\s*:?\\s*$`, "i") }) }).first();

async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const kv = (rows: [string, unknown, boolean?][]) =>
  `<table>${rows.map(([k, v, ok]) => `<tr><th>${esc(k)}</th><td class="${ok === undefined ? "" : ok ? "ok" : "bad"}">${esc(v)}</td></tr>`).join("")}</table>`;

// ─── Shared sessions + test data (re-created after a worker restart) ───
let admin: { ctx: BrowserContext; page: Page };
let wlPartner: { ctx: BrowserContext; page: Page; partnerName: string };
let t = "";
type Data = { wlMemberId: string; wlTx: any; personal?: { memberId: string; tx: string }; work?: { memberId: string; tx: string } };
let data: Data;

// Not serial: a product failure (e.g. TC-05.2) must not skip the remaining cases. Tests of one file still run
// in order in one worker; after a failure the worker restarts and beforeAll logs in again.
test.describe(`ESKIMO-763 White Label transactions & accounts ${ID}`, () => {
  test.beforeAll(async ({ browser }) => {
    test.setTimeout(240_000);
    admin = await adminSession(browser);
    t = await adminToken(admin.page);
    const members = await membersByEmail(t, WL_MEMBER_EMAIL);
    if (!members.length) throw new Error(`Environment: White Label member ${WL_MEMBER_EMAIL} not found`);
    // The e-mail can have several accounts (seen 2026-10-15) → use the one holding the WHI… purchases.
    // Stage sometimes answers the purchase list empty for a while → retry up to ~60s before calling it an env problem
    let wlTx: any;
    let member = members[0];
    for (let i = 0; i < 6 && !wlTx; i++) {
      for (const m of members) {
        wlTx = (await purchases(t, m.id)).find((p) => isWhi(p.transactionID || "") && p.status === 1);
        if (wlTx) { member = m; break; }
      }
      if (!wlTx) await new Promise((r) => setTimeout(r, 10000));
    }
    if (!wlTx) throw new Error(`Environment: ${WL_MEMBER_EMAIL} has no successful WHI… purchase`);
    // Non-WL references for the negative cases: latest successful Personal (0) / Work (1) payment
    const ref = async (type: number) => {
      const r = (await saleSearch(t, "", type)).find((x) => x.status === 1 && x.memberId && !isWhi(x.transactionId || ""));
      return r ? { memberId: r.memberId as string, tx: r.transactionId as string } : undefined;
    };
    data = { wlMemberId: member.id, wlTx, personal: await ref(0), work: await ref(1) };
    wlPartner = await partnerSession(browser, process.env.E2E_WL_PARTNER_EMAIL, process.env.E2E_WL_PARTNER_OTP);
  });
  test.beforeEach(() => test.setTimeout(150_000)); // stage drawers + reloads are slow
  test.afterAll(async () => { await admin?.ctx.close(); await wlPartner?.ctx.close(); });

  test(`TC-01 Eskimo Sale shows the White Label transaction ${ID}`, async ({}, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Eskimo Sale – WHI transaction");
    const page = admin.page;
    const txId: string = data.wlTx.transactionID;
    await test.step("Admin → Transactions › Eskimo Sales", async () => {
      await page.goto(`${ADMIN_URL}/#/transactions-eskimo-sale`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await readTable(page);
    });
    await test.step(`Search ${txId}`, async () => {
      await searchBox(page, "Search", txId);
      await page.locator(".ant-table-tbody tr.ant-table-row").filter({ hasText: txId }).first().waitFor({ state: "visible", timeout: 45000 }).catch(() => {});
    });
    const { headers, rows } = await readTable(page);
    const hit = rows.find((r) => r.cells["Transaction ID"] === txId);
    const type = hit?.cells["Type"] ?? "(row not found)";
    if (hit) { await mark(cellOf(hit, headers, "Transaction ID")); await mark(cellOf(hit, headers, "Type")); }
    const apiRow = (await saleSearch(t, txId)).find((x) => x.transactionId === txId);
    const ok = !!hit && type === WL_TYPE;
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC1`, title: "TC-01 Eskimo Sale row", steps: [`Search "${txId}" (member ${WL_MEMBER_EMAIL})`, `Row found: ${!!hit}`, `Type column: "${type}"`, `API eskimoTransactionType = ${apiRow?.eskimoTransactionType}`], expected: ["Transaction ID starts with WHI", `Type = "${WL_TYPE}"`], status: ok ? undefined : "failed" });
    expect(apiRow, "API search returns the WHI transaction").toBeTruthy();
    expect(hit, `Eskimo Sale lists ${txId}`).toBeTruthy();
    expect(type, "Type column of a WHI transaction").toBe(WL_TYPE);
  });

  test(`TC-02 "White Label Payment" only for WHI transactions ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-02 Eskimo Sale – type ⇔ WHI");
    const page = admin.page;
    const checked: { id: string; type: string; ok: boolean }[] = [];
    await test.step("Eskimo Sales, page 1 without filter", async () => {
      await page.goto(`${ADMIN_URL}/#/transactions-eskimo-sale`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await page.reload({ waitUntil: "domcontentloaded" });
    });
    for (const q of ["", "WHI"]) {
      await test.step(q ? 'Search "WHI"' : "No search", async () => { if (q) await searchBox(page, "Search", q); });
      const { rows } = await readTable(page);
      for (const r of rows) {
        const id = r.cells["Transaction ID"] ?? "";
        const type = r.cells["Type"] ?? "";
        checked.push({ id, type, ok: isWhi(id) === (type === WL_TYPE) });
      }
    }
    const bad = checked.filter((c) => !c.ok);
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC1`, title: "TC-02 Eskimo Sale WHI search", steps: [`Rows checked: ${checked.length} (page 1 unfiltered + search "WHI")`, `Mismatches: ${bad.length}`], expected: [`Every WHI… row has Type "${WL_TYPE}"`, `No non-WHI row has Type "${WL_TYPE}"`], status: bad.length ? "failed" : undefined });
    await card(page.context().browser()!, testInfo, "TC-02 Type vs Transaction ID", `<table><tr><th>Transaction ID</th><th>Type</th><th>Result</th></tr>${checked.map((c) => `<tr><td>${esc(c.id)}</td><td>${esc(c.type)}</td><td class="${c.ok ? "ok" : "bad"}">${c.ok ? "OK" : "MISMATCH"}</td></tr>`).join("")}</table>`, { ac: `${AC} AC1`, title: "TC-02 Type vs Transaction ID table", steps: ["Type column read from the Eskimo Sale table"], expected: [`"${WL_TYPE}" ⇔ Transaction ID starts with WHI`], status: bad.length ? "failed" : undefined });
    expect(checked.some((c) => isWhi(c.id)), "at least one WHI… row on screen").toBe(true);
    expect(bad, "rows where Type and WHI prefix disagree").toEqual([]);
  });

  test(`TC-03 Membership Detail lists the White Label transaction ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-03 Membership Detail – Data Purchase");
    const page = admin.page;
    const txId: string = data.wlTx.transactionID;
    const drawer = await test.step(`Open Membership Detail of ${WL_MEMBER_EMAIL}`, () => openMemberDetail(page, data.wlMemberId));
    const row = drawer.locator(".my-custom-data-wallet").filter({ hasText: "Data Purchase" }).locator("tr.ant-table-row").filter({ hasText: txId }).first();
    const shown = await row.waitFor({ state: "visible", timeout: 30000 }).then(() => true).catch(() => false);
    if (shown) { await row.scrollIntoViewIfNeeded(); await mark(row); }
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC1`, title: "TC-03 Data Purchase row", steps: [`Membership Detail ${WL_MEMBER_EMAIL}`, `Data Purchase row ${txId}: ${shown ? "shown" : "NOT shown"}`], expected: ["The WHI… transaction is listed in Data Purchase"], status: shown ? undefined : "failed" });
    expect(shown, `Data Purchase lists ${txId}`).toBe(true);
  });

  test(`TC-04 Partner Top Up History shows White Label Payment ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-04 Partner Top Up History");
    const page = wlPartner.page;
    const pt = await pageToken(page);
    const apiRows = await topUpSearch(pt, "WHI");
    const txId: string = apiRows[0]?.transactionNo ?? data.wlTx.transactionID;
    await test.step("Partner wlb2 → Corporate › Top Up History", async () => {
      await page.goto(`${PARTNER_URL}/#/corporate-top-up-history`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await readTable(page);
    });
    await test.step(`Search by Transaction ID ${txId}`, async () => {
      await searchBox(page, "Search by Transaction ID", txId);
      await page.locator(".ant-table-tbody tr.ant-table-row").filter({ hasText: txId }).first().waitFor({ state: "visible", timeout: 45000 }).catch(() => {});
    });
    const { headers, rows } = await readTable(page);
    const hit = rows.find((r) => r.cells["Transaction ID"] === txId);
    const type = hit?.cells["Transaction Type"] ?? "(row not found)";
    if (hit) { await mark(cellOf(hit, headers, "Transaction ID")); await mark(cellOf(hit, headers, "Transaction Type")); }
    const ok = !!hit && type === WL_TYPE;
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC1`, title: "TC-04 Top Up History row", steps: [`Partner ${wlPartner.partnerName} (${PARTNER_CODE})`, `Search by Transaction ID "${txId}"`, `Row: ${hit ? Object.entries(hit.cells).map(([k, v]) => `${k}=${v}`).join(" · ") : "not found"}`, `API transactionType = ${apiRows[0]?.transactionType}`], expected: ["Transaction ID starts with WHI", `Transaction Type = "${WL_TYPE}"`, "Other columns filled"], status: ok ? undefined : "failed" });
    expect(apiRows.length, "API returns WHI… top-up histories for the WL partner").toBeGreaterThan(0);
    expect(hit, `Top Up History lists ${txId}`).toBeTruthy();
    expect(type, "Transaction Type of a WHI transaction").toBe(WL_TYPE);
    for (const h of ["Created Date", "Member Name", "Email Address", "Data Plan Name"]) expect(hit!.cells[h], `${h} filled`).not.toBe("");
  });

  test(`TC-05 Partner Corporate Accounts lists the White Label account ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-05 Partner Accounts – WL account");
    const page = wlPartner.page;
    const apiRows = await accountSearch(await pageToken(page), WL_MEMBER_EMAIL);
    await test.step("Partner wlb2 → Corporate › Accounts", async () => {
      await page.goto(`${PARTNER_URL}/#/corporate-accounts`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await readTable(page);
    });
    await test.step(`Search ${WL_MEMBER_EMAIL}`, async () => {
      // Stage search can hang > 1 min: wait for the searched response (90s), press Enter once more if none came
      const box = page.getByPlaceholder("Search by Account info", { exact: true }).first();
      await box.fill(WL_MEMBER_EMAIL);
      for (let attempt = 0; attempt < 2; attempt++) {
        const searched = page.waitForResponse((r) => r.url().includes("/worker-management/search") && (r.request().postData() ?? "").includes(WL_MEMBER_EMAIL), { timeout: 90000 }).then(() => true).catch(() => false);
        await box.press("Enter");
        if (await searched) break;
      }
      await spinnerGone(page);
      await page.locator(".ant-table-tbody tr.ant-table-row").filter({ hasText: WL_MEMBER_EMAIL }).first().waitFor({ state: "visible", timeout: 30000 }).catch(() => {});
    });
    const { headers, rows } = await readTable(page);
    const hit = rows.find((r) => (r.cells["Email Address"] || "").toLowerCase() === WL_MEMBER_EMAIL.toLowerCase());
    if (hit) await mark(hit.row);
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC2`, title: "TC-05 Accounts row", steps: [`Search "${WL_MEMBER_EMAIL}"`, `Row: ${hit ? Object.entries(hit.cells).filter(([k]) => k).map(([k, v]) => `${k}=${v}`).join(" · ") : "not found"}`, `API rows: ${apiRows.length}`], expected: ["White Label account listed with the existing columns"], status: hit ? undefined : "failed" });
    expect(apiRows.some((a) => String(a.email).toLowerCase() === WL_MEMBER_EMAIL.toLowerCase()), "API lists the WL account").toBe(true);
    expect(hit, "Accounts lists the WL account").toBeTruthy();
    for (const h of ["Email Address", "Account Status", "eSIM Status"]) expect(headers, `column ${h}`).toContain(h);

    // TC-05.2 View Detail: the detail shows the same account as the row (expected = row + Admin Membership data)
    // QC 2026-10-15: Top Up is intentionally hidden for White Label accounts (the row's action column with it).
    // A missing action column is therefore not a failure; a Top Up button still shown is only a WARNING.
    const warnings: string[] = [];
    const topUp = (root: Locator) => root.locator("button:visible", { hasText: /^\s*Top Up\s*$/ });
    if (await topUp(hit!.row).count()) warnings.push("Top Up button still shown in the account row");
    // QC 2026-10-15: when the detail is reachable only through the deep link (no View Detail button for a real
    // user), wrong detail fields are a WARNING (known BE issue), not a failure. Reachable by the button → FAIL.
    let viaLink = false;
    const detail = await test.step("View Detail of the WL account", async () => {
      const btn = hit!.row.locator("button", { hasText: "View Detail" }).first();
      if (await btn.waitFor({ state: "visible", timeout: 10000 }).then(() => true).catch(() => false)) {
        await btn.click();
      } else {
        viaLink = true;
        // Action column hidden (Top Up hidden for WL) → open the same detail through the page's ?detail=<id> deep link.
        const id = apiRows.find((a) => String(a.email).toLowerCase() === WL_MEMBER_EMAIL.toLowerCase())?.id;
        await page.goto(`${PARTNER_URL}/#/corporate-accounts?key=${encodeURIComponent(WL_MEMBER_EMAIL)}?detail=${id}`, { waitUntil: "domcontentloaded", timeout: 90000 });
        await page.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
      }
      const drawer = page.locator(".ant-drawer-open .ant-drawer-content").first();
      const items = drawer.locator(".account-detail-infor-item");
      await items.first().waitFor({ state: "visible", timeout: 30000 });
      await spinnerGone(page);
      // One pass in the page: some items (credit section) have no label/value pair → would block innerText()
      const fields: Record<string, string> = await drawer.evaluate((root) => {
        const out: Record<string, string> = {};
        // Only the Account block (Sign Up Email … Reference Phone); the eSIM block also has a "Status"
        const blocks = Array.from(root.querySelectorAll(".account-detail-infor"));
        const account = blocks.find((b) => /Sign Up Email/.test((b as HTMLElement).innerText)) ?? root;
        account.querySelectorAll(".account-detail-infor-item").forEach((it) => {
          const label = (it.querySelector(".account-detail-infor-item-label") as HTMLElement | null)?.innerText.trim();
          const value = (it.querySelector(".account-detail-infor-item-value") as HTMLElement | null)?.innerText.replace(/\s+/g, " ").trim() ?? "";
          if (label && !(label in out)) out[label] = value;
        });
        return out;
      });
      const accountBlock = drawer.locator(".account-detail-infor").filter({ hasText: "Sign Up Email" }).first();
      await accountBlock.scrollIntoViewIfNeeded().catch(() => {});
      await mark(accountBlock);
      if (await topUp(drawer).count()) warnings.push("Top Up button still shown in View Detail");
      return { drawer, fields };
    });
    for (const w of warnings) testInfo.annotations.push({ type: "warning", description: `TC-05.2 ${w} (Top Up should be hidden for White Label accounts)` });
    const member: any = (await memberDetail(t, data.wlMemberId)) ?? {};
    const workerId = apiRows.find((a) => String(a.email).toLowerCase() === WL_MEMBER_EMAIL.toLowerCase())?.id;
    const profile = workerId ? (await api(await pageToken(page), "GET", `/api/partner/worker-management/users/${workerId}/profile`))?.data ?? {} : {};
    const checks: [string, string, string][] = [
      ["Sign Up Email", detail.fields["Sign Up Email"] ?? "(missing)", WL_MEMBER_EMAIL],
      ["First Name", detail.fields["First Name"] ?? "(missing)", String(member.firstName ?? "").trim() || "--"],
      ["Last Name", detail.fields["Last Name"] ?? "(missing)", String(member.lastName ?? "").trim() || "--"],
      ["Status", detail.fields["Status"] ?? "(missing)", hit!.cells["Account Status"]],
    ];
    const norm = (s: string) => (s.trim() === "--" ? "" : s.trim().toLowerCase()); // "" and "--" both mean empty
    const same = (a: string, b: string) => norm(a) === norm(b);
    const bad = checks.filter(([, shown, exp]) => !same(shown, exp));
    const mismatch = bad.map(([k, shown, exp]) => `${k}: shown "${shown}", expected "${exp}"`);
    if (viaLink) for (const m of mismatch) { warnings.push(`${m} (only reachable via ?detail= link; BE profile API)`); testInfo.annotations.push({ type: "warning", description: `TC-05.2 ${m} — View Detail reachable only via link; BE /users/{id}/profile` }); }
    const failNow = !viaLink && bad.length > 0;
    const verdict = (ok: boolean) => (ok ? "OK" : viaLink ? "WARNING" : "MISMATCH");
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC2`, title: "TC-05.2 Account View Detail", steps: [viaLink ? `Row "${WL_MEMBER_EMAIL}": no View Detail button (action column hidden) → opened via ?detail= link` : `Row "${WL_MEMBER_EMAIL}" → View Detail`, warnings.length ? `⚠ WARNING: ${warnings.join("; ")}` : "Top Up hidden for the WL account (row + detail)", ...Object.entries(detail.fields).map(([k, v]) => `${k}: ${v}`), `Profile API: signUpEmail=${profile.signUpEmail ?? "—"} · firstName=${profile.firstName ?? "—"} · lastName=${profile.lastName ?? "—"}`], expected: checks.map(([k, , exp]) => `${k} = ${exp}`), status: failNow ? "failed" : undefined });
    await card(page.context().browser()!, testInfo, "TC-05.2 View Detail vs expected", `<table><tr><th>Field</th><th>Shown in detail</th><th>Expected (row / Admin Membership)</th><th>Result</th></tr>${checks.map(([k, shown, exp]) => `<tr><td>${esc(k)}</td><td>${esc(shown)}</td><td>${esc(exp)}</td><td class="${same(shown, exp) ? "ok" : "bad"}">${verdict(same(shown, exp))}</td></tr>`).join("")}</table>`, { ac: `${AC} AC2`, title: "TC-05.2 View Detail comparison", steps: ["Detail fields compared with the list row and Admin › Membership Detail", ...(viaLink && bad.length ? [`⚠ WARNING (not failed): mismatch only reachable via link — BE profile API returns it`] : [])], expected: ["Every field matches"], status: failNow ? "failed" : undefined });
    await page.keyboard.press("Escape").catch(() => {});
    if (!viaLink) expect(mismatch, "View Detail fields that differ from the account").toEqual([]);
  });

  test(`TC-06 Accounts unaffected for other partners ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-06 Accounts – regression");
    test.skip(!process.env.E2E_PARTNER_EMAIL, "E2E_PARTNER_EMAIL (normal corporate partner) not set");
    const page = wlPartner.page;
    await test.step("WL partner: Accounts page 1 without search", async () => {
      await page.goto(`${PARTNER_URL}/#/corporate-accounts`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await page.reload({ waitUntil: "domcontentloaded" });
    });
    const own = await readTable(page);
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC2`, title: "TC-06 WL partner Accounts page 1", steps: [`Rows: ${own.rows.length}`, `Columns: ${own.headers.filter(Boolean).join(", ")}`], expected: ["List loads with the existing columns"], status: own.rows.length ? undefined : "failed" });
    const other = await partnerSession(browser);
    try {
      const rows = await accountSearch(await pageToken(other.page), WL_MEMBER_EMAIL);
      await other.page.goto(`${PARTNER_URL}/#/corporate-accounts`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await readTable(other.page);
      await searchBox(other.page, "Search by Account info", WL_MEMBER_EMAIL);
      const ui = await readTable(other.page);
      const leaked = rows.length > 0 || ui.rows.some((r) => (r.cells["Email Address"] || "").toLowerCase() === WL_MEMBER_EMAIL.toLowerCase());
      await evidence.saveScreenshot(other.page, testInfo, { ac: `${AC} AC2`, title: "TC-06 Other partner search WL account", steps: [`Partner ${other.partnerName}`, `Search "${WL_MEMBER_EMAIL}" → API ${rows.length} rows, UI ${ui.rows.length} rows`], expected: [`The WL account of ${PARTNER_CODE} is NOT listed`], status: leaked ? "failed" : undefined });
      expect(leaked, "another partner sees the WL account").toBe(false);
    } finally { await other.ctx.close(); }
    expect(own.rows.length, "WL partner Accounts list loads").toBeGreaterThan(0);
  });

  test(`TC-07 WHI detail shows Transaction Partner ID + Transaction Price ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-07 Membership Detail – WHI detail");
    const page = admin.page;
    const tx = data.wlTx;
    const meta = tx.relatedTransaction?.metadata ?? {};
    const drawer = await openMemberDetail(page, data.wlMemberId);
    const { detail } = await test.step(`Expand ${tx.transactionID}`, () => expandPurchase(drawer, tx.transactionID));
    const partnerId = (await formItem(detail, "Transaction Partner ID").locator(".ant-form-item-control").innerText({ timeout: 5000 }).catch(() => "(missing)")).trim();
    const priceText = (await formItem(detail, String.raw`Transaction Price(\s*\(\$US\))?`).locator(".ant-form-item-control").innerText({ timeout: 5000 }).catch(() => "(missing)")).trim();
    const price = Number((priceText.replace(/,/g, "").match(/-?\d+(?:\.\d+)?/) ?? [NaN])[0]);
    // Q2/Q3 (BA): exact format not specified → the Partner ID must contain the partner code, the price must equal
    // the original White Label transaction's total (relatedTransaction.metadata.total).
    const okId = partnerId.includes(PARTNER_CODE);
    const okPrice = price === Number(meta.total);
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC3`, title: "TC-07 WHI transaction detail", steps: [`Transaction ${tx.transactionID} (Value $${tx.value})`, `Transaction Partner ID: "${partnerId}"`, `Transaction Price: "${priceText}"`, `Original WL transaction (API): ${meta.id} · total ${meta.total} ${meta.curency ?? ""}`], expected: [`Transaction Partner ID = ${PARTNER_CODE}`, `Transaction Price = ${meta.total} (original WL price)`], status: okId && okPrice ? undefined : "failed" });
    expect(partnerId, "Transaction Partner ID").toContain(PARTNER_CODE);
    expect(price, "Transaction Price = original White Label price").toBe(Number(meta.total));
  });

  test(`TC-08 non-WHI detail has no White Label fields ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-08 Membership Detail – non-WHI detail");
    test.skip(!data.personal, "Environment: no successful Personal Account Payment found in Eskimo Sale");
    const page = admin.page;
    const drawer = await openMemberDetail(page, data.personal!.memberId);
    const { detail } = await test.step(`Expand ${data.personal!.tx}`, () => expandPurchase(drawer, data.personal!.tx));
    const labels = (await detail.locator(".ant-form-item-label").allInnerTexts()).map((s) => s.trim());
    const leaked = labels.filter((l) => /Transaction Partner ID|Transaction Price/i.test(l));
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC3`, title: "TC-08 Non-WHI transaction detail", steps: [`Transaction ${data.personal!.tx}`, `Detail labels: ${labels.join(" · ")}`], expected: ["No Transaction Partner ID / Transaction Price"], status: leaked.length ? "failed" : undefined });
    expect(leaked).toEqual([]);
  });

  test(`TC-09 White Label account title + White Label Partner row ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-09 Membership Detail – WL account");
    const page = admin.page;
    const drawer = await openMemberDetail(page, data.wlMemberId);
    const title = await accountTitle(drawer);
    const row = accountRow(drawer, "White Label Partner");
    const rowText = (await row.innerText({ timeout: 5000 }).catch(() => "(missing)")).replace(/\s+/g, " ").trim();
    if (await row.count()) { await row.scrollIntoViewIfNeeded(); await mark(row); }
    const ok = title === "White Label Account" && rowText.includes(PARTNER_CODE);
    await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC4`, title: "TC-09 WL account section", steps: [`Member ${WL_MEMBER_EMAIL} (API accountType 2, partner ${PARTNER_CODE})`, `Section title: "${title}"`, `White Label Partner row: "${rowText}"`], expected: ['Title "White Label Account"', `Row "White Label Partner" with ${PARTNER_CODE}`], status: ok ? undefined : "failed" });
    expect(title, "account section title").toBe("White Label Account");
    expect(rowText, "White Label Partner row").toContain(PARTNER_CODE);
  });

  test(`TC-10 Personal / Work account unchanged ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-10 Membership Detail – non-WL accounts");
    const page = admin.page;
    const cases = [["Personal Account", data.personal], ["Work Account", data.work]] as const;
    const results: { expected: string; title: string; wlRow: boolean }[] = [];
    for (const [expected, ref] of cases) {
      if (!ref) continue;
      const drawer = await openMemberDetail(page, ref.memberId);
      const title = await accountTitle(drawer);
      const wlRow = (await accountRow(drawer, "White Label Partner").count()) > 0;
      results.push({ expected, title, wlRow });
      await evidence.saveScreenshot(page, testInfo, { ac: `${AC} AC4`, title: `TC-10 ${expected}`, steps: [`Member of ${ref.tx}`, `Title "${title}"`, `White Label Partner row: ${wlRow ? "present" : "absent"}`], expected: [`Title "${expected}"`, "No White Label Partner row"], status: title === expected && !wlRow ? undefined : "failed" });
    }
    test.skip(!results.length, "Environment: no Personal/Work reference member found");
    for (const r of results) {
      expect(r.title, `${r.expected} title`).toBe(r.expected);
      expect(r.wlRow, `${r.expected}: White Label Partner row`).toBe(false);
    }
  });
});
