# Góp ý: hạn chế của skill **qa-auto** (đã đối chiếu file nguồn)

> Đã đọc `pg4-ai-workflow-main/claude/commands/qa-auto.md`, `docs/qc-automation.md`, và
> `qa/playwright-starter/`. Tổng hợp từ thực tế chạy ESKIMO-381/382/384/385/386/753 (White Label).
>
> **Lưu ý phạm vi (quan trọng):** `qa/playwright-starter` chỉ có `package.json` + `playwright.config.ts`.
> Hệ **evidence + report HTML** (`tests/_support/evidence.ts`, `generate-report.mjs`, `reports/*-e2e-report.html`)
> **không nằm trong skill lẫn starter** — đó là đồ **tự thêm trong `d:\eskimo-e2e`** (port từ repo portal).
> Tài liệu chia 2 phần: **A = hạn chế của chính skill qa-auto**, **B = hạn chế của add-on evidence
> (eskimo-e2e), không phải skill.**

---

# PHẦN A — Hạn chế của chính skill qa-auto

## A1. Skill không có "evidence artifact" để đính ticket (gốc của chuyện "không đính file")
**Trong skill:** đầu ra của QC chỉ gồm — HTML tạm `npx playwright show-report` (step 7), **bảng trong
chat** (step 7), và **comment plain-text** lên Plane (step 8). Step 9 chỉ *"nhắc người tự move item"*.
Skill **không có bước tạo file bằng chứng theo ticket, cũng không có bước đính file lên ticket**.

**Ví dụ thật:** đúng vì vậy mà dự án eskimo-e2e phải tự bổ sung `evidence.ts` + `generate-report.mjs`
để có `reports/<ID>-*-e2e-report.html` nộp Jira/Plane — thứ skill không cung cấp.

**Vì sao cản QC:** QC cần một **file bằng chứng bền, chia sẻ được, đính lên ticket**. Skill dừng ở
"show-report + bảng chat + comment chữ" → không có gì để nộp, phải tự chế.

**Đề xuất:** skill nên (1) sinh một **report theo ticket** (input/output mỗi case, như qc-automation
mong muốn), (2) **xuất PDF** (headless Chromium có sẵn), (3) **đính vào ticket** ở step 8/9 — thay vì
chỉ nhắc đính tay.

## A2. Ngốn test case đầu vào còn thủ công; thiếu chế độ "suy ra từ AC"
**Trong skill:** step 1 — *thiếu file test case → stop*. Step 3 — `.xlsx` phải **convert tay**, `.docx`
phải **xin export**; không đọc được attachment của ticket.

**Ví dụ thật:** 5 bug ticket (381/382/384/385/386) **không có file test case**; mình phải tự viết
`testcases/<ID>/<ID>.md` từ AC — trong khi skill bảo "thiếu file thì dừng".

**Vì sao cản QC:** phần lớn ticket hoặc đính xlsx/docx, hoặc không có test case sẵn. Flow đứng ngay
khâu đầu vào.

**Đề xuất:** (1) chế độ **derive-from-AC** chính thức: sinh draft `testcases/<ID>.md` từ mô tả cho QC
duyệt, thay vì stop; (2) parser xlsx/docx; (3) đọc được attachment test case từ ticket.

## A3. OTP email / captcha / thẻ test bị xếp cứng là "manual" — không có bán tự động
**Trong skill:** step 4 phân **auto / manual / unclear**; OTP, captcha, real payment → **manual** (bỏ
khỏi tự động hoá). Không có khái niệm "bot chạy, người tick captcha, bot chạy tiếp".

**Ví dụ thật:** flow White Label cần đọc OTP qua yopmail + **tick Cloudflare captcha tay** + thẻ test
Stripe. Skill coi là manual → mình phải mượn nguyên bộ helper portal (`waitIfCaptcha`, yopmail reader,
run-state) mới chạy auto được phần lớn hành trình.

**Vì sao cản QC:** rất nhiều luồng thật (OTP, captcha) không fully-auto nhưng cũng không nên bỏ sang
manual hoàn toàn — phần lớn vẫn tự động được nếu có "pause-for-human".

**Đề xuất:** thêm hạng **semi-auto / pause-for-human** chính thức + helper chuẩn cho OTP email
(yopmail/mailinator) để tái dùng giữa project.

## A4. "Chạy được dù chậm" vẫn bị coi là fail (thiếu ngữ nghĩa slow≠stuck)
**Trong skill:** step 6.4 phân lỗi thành **test problem / product failure / environment problem** —
*(điểm tốt: đã tách env vs product)*. Nhưng không có mức **"slow-but-passed"**: timeout = fail để phân
loại.

**Ví dụ thật:** ESKIMO-753 S5 kẹt "mở home" 60s do Azure stage cold-start → tính FAILED; chạy lại là
PASS. QC coi: **chạy được dù chậm = PASS, chỉ STUCK mới FAIL.**

**Đề xuất:** thêm trạng thái **slow-but-passed** (ghi nhận độ trễ, không fail) và chuẩn "retry các step
chậm/tạm lỗi như khách" trong step 6.

## A5. Dữ liệu test tạo ra: có yêu cầu cleanup nhưng thiếu "sổ công bố"
**Trong skill:** step 6.2 — *"data created gets a unique suffix and is cleaned up when the UI/API allows"*
*(điểm tốt)*. Nhưng với luồng **real payment** không xoá được (account Pending, record Failed, eSIM
thật), skill không có **ledger công bố "run này tạo ra gì"**.

**Ví dụ thật:** test White Label để lại account Pending + record Failed + order Stripe test + eSIM thật
mỗi email; mình phải **tự ghi mã order/WHI** để disclose.

**Đề xuất:** xuất kèm report một **ledger dữ liệu tạo ra** (order, account, eSIM, email) để QC disclose/
cleanup; chuẩn sinh định danh mới mỗi run (email mới) cho nhánh "new customer".

---

# PHẦN B — Hạn chế của add-on evidence trong eskimo-e2e (KHÔNG thuộc skill)

> Nếu team muốn đưa hệ evidence này vào starter chính thức thì các điểm sau cần vá.

- **B1. Manifest ghi append, không dọn khi chạy lại:** chạy lại 1 TC (vd. ESKIMO-384 TC-05, ESKIMO-381)
  phải **tự xoá entry cũ + sắp lại theo số TC** trong `manifest.json`. → cần "ghi-đè-theo-case" + sort
  theo mã TC khi render.
- **B2. Danh tính report gắn cứng với tên folder ảnh:** `generate-report.js` buộc output = `${ticket}-${feature}`;
  ESKIMO-753 phải **copy folder ảnh** `EP-5965-…` → `ESKIMO-753-…` rồi regenerate. → tách ticket-id khỏi
  thư mục nguồn (`--ticket --from --title`).
- **B3. Report HTML chỉ pass/fail nhị phân:** eSIM pool hết (env) và branding default (WARNING) hiện
  **đỏ như bug**; `testInfo.annotations` bị report bỏ qua. → đọc annotations, thêm thang
  PASS/GAP/CLARIFY/WARNING/BLOCKED (gap report của spec portal đã làm được — nên hợp nhất chuẩn).

---

## Những thứ skill ĐANG làm tốt (giữ)
- Step 7: bảng kết quả chat có **5 mức** (pass / fail-product / blocked-env / manual / unclear) — không
  nhị phân.
- Step 6.4: tách **product vs environment failure** rõ ràng.
- Rules + step 8: **cấm ghi Plane trước khi user confirm** (đúng nguyên tắc; đây là chỗ tôi đã làm sai).
- Step 6.2: yêu cầu **unique suffix + cleanup**; step 1: `--rerun` chạy lại regression.

## Tóm tắt ưu tiên (chỉ skill — phần A)
1. **A1 — sinh evidence artifact theo ticket + PDF + đính ticket** (gốc của "không đính file được").
2. **A2 — derive test case từ AC + đọc xlsx/docx/attachment.**
3. **A3 — bước pause-for-human cho OTP/captcha.**
4. A4 (slow≠fail) · A5 (ledger test data).

*Có thể bổ sung log/ảnh/comment_id cụ thể cho từng mục nếu team cần dẫn chứng.*
