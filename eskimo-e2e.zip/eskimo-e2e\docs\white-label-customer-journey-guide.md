# Hướng dẫn mua & dùng eSIM trên website White Label (Customer Journey)

> Tài liệu này tóm tắt toàn bộ hành trình khách hàng trên website eSIM White Label
> (ví dụ: `https://wellatsea.eskimo.travel/en`): mua gói data chuẩn, nhận eSIM, truy cập
> "My Data", mua thêm (top-up), và **toàn bộ các thông báo lỗi** khi nhập sai ở từng bước.
> Mọi câu chữ in `như thế này` là nội dung hiển thị đúng nguyên văn trên màn hình.
>
> Đây là **1 trong 4 file** của bộ hướng dẫn tổng hợp. Phạm vi file này: *Customer Journey — mua chuẩn & xử lý lỗi nhập sai.*

---

## 1. Tổng quan hành trình

Một khách hàng đi qua 5 giai đoạn:

| # | Giai đoạn | Khách làm gì | Kết quả mong đợi |
|---|---|---|---|
| 1 | **Browse** | Mở website → chọn gói data | Thấy đúng danh sách gói của thương hiệu đó |
| 2 | **Checkout** | Nhập Email + First name → thanh toán thẻ | Thanh toán thành công |
| 3 | **Nhận eSIM** | (tự động) | Email chứa **QR code** + **Magic Link** |
| 4 | **My Data** | Mở ví dữ liệu bằng Magic Link hoặc Email + OTP | Xem gói, dung lượng, lịch sử |
| 5 | **Top-up** | Mua thêm gói | Gói mới cộng vào cùng tài khoản/eSIM |

Nguyên tắc quan trọng:
- **Tài khoản tách theo thương hiệu (Partner).** Cùng một email dùng ở 2 website khác nhau sẽ tạo **2 tài khoản riêng**, không gộp gói/dung lượng/lịch sử.
- **Chỉ khách đã mua** mới đăng nhập được "My Data". Email chưa từng mua sẽ không nhận được mã OTP.
- eSIM và gói chỉ được tạo **sau khi thanh toán thành công**. Thanh toán thất bại → không có eSIM.

---

## 2. Flow mua chuẩn (happy path)

### Bước 1 — Chọn gói data
1. Mở website (ví dụ `https://wellatsea.eskimo.travel/en`).
2. Chọn quốc gia/khu vực → chọn 1 gói (ví dụ **Japan 1 GB**).
3. Bấm nút **`Checkout`** để sang trang thanh toán.

> Thanh toán trực tiếp không chọn gói: nếu mở thẳng trang `/checkout` mà chưa chọn gói, hệ thống hiển thị `No plan selected` và yêu cầu quay lại chọn gói trước.

### Bước 2 — Nhập thông tin
Tại trang Checkout, điền:
- **First name** (tên)
- **Email** — đây là email dùng để nhận eSIM và đăng nhập "My Data" về sau, hãy nhập **email thật và đúng chính tả**.

Bấm **`Continue to payment`**.

### Bước 3 — Thanh toán
1. Màn hình hiện khung nhập thẻ (Stripe). Email vừa nhập được chuyển sẵn sang bước thanh toán.
2. Nhập số thẻ, ngày hết hạn, CVC.
3. Bấm nút **`Pay US$ …`**.
4. Trong lúc xử lý sẽ hiện `Processing payment…`.

### Bước 4 — Trang xác nhận
Thanh toán thành công → chuyển sang trang hoàn tất, hiển thị:
- **Order number** (ví dụ `PUR-PN…-…`)
- Gói đã mua, tổng tiền
- Email nhận eSIM
- Dòng trạng thái: `Payment received — we're preparing your eSIM`

### Bước 5 — Nhận email (QR + Magic Link)
Hệ thống gửi email tới địa chỉ đã nhập, gồm:
- **Email QR code**: mã QR để cài eSIM (có mã LPA kèm theo).
- **Magic Link**: liên kết mở thẳng ví "My Data" **không cần OTP**.

Email mang **thương hiệu của Partner** (tên người gửi, logo), không phải thương hiệu Eskimo mặc định.

> Lưu ý thời gian: ngay sau khi trả tiền, hệ thống cần một chút thời gian để tạo tài khoản + eSIM.
> Nếu bạn mở "My Data" **quá sớm**, có thể tạm thời chưa đăng nhập được (xem mục lỗi bên dưới). Chờ ~30–60 giây rồi thử lại.

---

## 3. Truy cập "My Data" (ví dữ liệu)

Có **2 cách** đăng nhập ví của Partner:

### Cách A — Magic Link (nhanh nhất)
- Mở **Magic Link** trong email đã nhận → vào **thẳng ví**, không cần nhập mã.
- Link này dùng lại được nhiều lần.

### Cách B — Email + OTP
1. Vào trang `/en/data-balance` (hoặc bấm **`My Data`** trên đầu trang).
2. Nhập đúng email đã mua → bấm **`Send code`**.
   > Màn hình chuyển sang `Enter your code`, kèm dòng *"Enter the email you used at checkout and we'll send you a code."*
3. Mở email lấy **mã 4 chữ số**, nhập vào ô code.
4. Bấm **`View my data`** → vào ví.

Trong ví bạn xem được:
- Danh sách gói (tab **My Plans**) với tên quốc gia + dung lượng còn lại; gói không giới hạn hiện nhãn loại gói ví dụ `Unlimited 30 days`.
- **History** — lịch sử mua/nạp (ngày, tên gói, trạng thái).

---

## 4. Mua thêm (Top-up)
- Mua thêm 1 gói bằng **cùng email** (cùng Partner) → gói mới được cộng vào **cùng tài khoản/eSIM**, không tạo tài khoản hay eSIM trùng.

---

## 5. Các thông báo lỗi khi nhập sai (tra cứu nhanh)

### 5.1 Lúc Checkout

| Tình huống nhập sai | Thông báo hiển thị | Nên làm gì |
|---|---|---|
| Để trống tên | `Enter your first name.` | Nhập First name |
| Email sai định dạng / để trống | `Enter a valid email address.` | Nhập email đúng định dạng |
| Mở `/checkout` khi chưa chọn gói | `No plan selected` | Quay lại chọn gói trước |
| Bấm thanh toán quá nhiều lần liên tục | `Too many checkout attempts. Please wait a few minutes and try again.` | Chờ vài phút rồi thử lại |

### 5.2 Lúc thanh toán (thẻ)

| Tình huống | Thông báo hiển thị | Ý nghĩa / nên làm gì |
|---|---|---|
| Thẻ bị từ chối | `Your card has been declined.` | Giao dịch **không thành công**, chưa bị trừ tiền. Thử lại bằng thẻ khác. Có thể bấm thanh toán lại bình thường. |
| Không khởi tạo được thanh toán | `We couldn't start your payment. Please try again in a moment.` | Thử lại sau giây lát |
| Thanh toán không qua | `Your payment didn't go through. Please try again.` | `You haven't been charged. You can try again with the same or a different card.` — chưa bị trừ tiền, thử lại |
| Ngân hàng đang xác nhận (3‑D Secure / chậm) | `Your bank is still confirming the payment. We'll email your eSIM as soon as it goes through — no need to pay again.` | **Không trả lại lần nữa**; chờ email eSIM |
| Không xác nhận được kết quả | `We couldn't confirm your payment` + `Please check your email before trying again — if the payment went through, your eSIM is on its way.` | Kiểm tra email trước khi thử lại, tránh trả trùng |

> **Quan trọng về thẻ bị từ chối:** khi thẻ declined, hệ thống tạo một tài khoản ở trạng thái **chờ (Pending)**, **không** có eSIM, **không** gán gói. Khách vẫn **thanh toán lại bình thường bằng thẻ hợp lệ** trên **cùng email**, hệ thống dùng lại tài khoản đó (không tạo trùng) và hoàn tất đơn.

### 5.3 Lúc đăng nhập "My Data" (Email + OTP)

| Tình huống nhập sai | Thông báo hiển thị | Nên làm gì |
|---|---|---|
| Nhập email **chưa từng mua** | `We're unable to process your request yet. Please purchase a data plan with this email to get started.` | Chỉ email đã mua mới có mã. Mua gói trước, hoặc kiểm tra đã nhập đúng email lúc checkout. |
| Vừa trả tiền xong, xin mã **quá sớm** | (cùng câu trên) | Chờ ~30–60 giây để hệ thống tạo tài khoản/eSIM rồi bấm `Send code` lại |
| Nhập **sai mã** / mã đã dùng / mã cũ | `Invalid OTP` hoặc `That code isn't valid any more. Request a new one.` | Nhập lại đúng mã mới nhất trong email, hoặc xin mã mới |
| **Nhập sai nhiều lần** liên tiếp | `Too many invalid attempts. Please request a new OTP and try again in a few minutes.` | Tài khoản tạm khoá nhập mã. Chờ vài phút, bấm xin mã mới rồi thử lại |
| Bấm **xin mã quá nhiều lần** | `Too many codes requested. Please wait a few minutes and try again.` | Chờ vài phút rồi xin lại |
| Không gửi được mã | `We couldn't send your code right now. Please try again.` | Thử lại |

### 5.4 Lúc dùng Magic Link

| Tình huống | Hiển thị | Nên làm gì |
|---|---|---|
| Link còn hiệu lực | Vào thẳng ví, **không hỏi mã** | — |
| Link hỏng/hết hạn | Quay về màn nhập email kèm: `That link has expired. Enter the email you used at checkout and we'll send you a code.` | Nhập email → `Send code` → nhập mã như mục 3B |

---

## 6. Những điểm khách hay nhầm (FAQ nhanh)

- **"Tôi trả tiền rồi mà không đăng nhập được 'My Data'."**
  → Thường do mở quá sớm. Chờ 30–60 giây cho hệ thống tạo tài khoản/eSIM, rồi `Send code` lại. Nếu vẫn báo *"purchase a data plan with this email…"* sau vài phút, kiểm tra email đã nhập lúc checkout có đúng không.

- **"Thẻ báo declined thì tôi có bị trừ tiền không?"**
  → Không. Giao dịch không thành công, chưa bị trừ. Thanh toán lại bằng thẻ khác trên cùng email là được; không tạo tài khoản trùng.

- **"Tôi nhập sai mã OTP vài lần thì bị khoá?"**
  → Nhập sai nhiều lần sẽ bị tạm khoá nhập mã (`Too many invalid attempts…`). Chờ vài phút, xin mã mới rồi thử lại.

- **"Tôi dùng email này ở website khác thì dữ liệu có chung không?"**
  → Không. Mỗi website (Partner) là một tài khoản riêng. Gói, dung lượng, lịch sử không gộp giữa các website.

---

*Hết phần Customer Journey. Ghép file này theo đúng trình tự trong bộ hướng dẫn tổng hợp.*
