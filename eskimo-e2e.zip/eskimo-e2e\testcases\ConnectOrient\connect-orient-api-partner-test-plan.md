# Test plan – Connect Orient (Proto Douglas Ltd): partner chỉ dùng API

> Bản nháp QC, 29/10/2026. Nguồn: yêu cầu của client (thread Farah / Nhu / Hoang), tài liệu External API trên Docmost (Index, Authentication, Account Management, Top Up eSIM, View Data Wallet, Listing Data Plan, cập nhật 26–28/10), và code Admin `eskimo_portal`.
> Chưa chạy. Phần 0 cần BA/BE trả lời trước. Phần chạy trên PROD phải có người được phép duyệt.

## Client cần gì

| # | Yêu cầu của client | API / tính năng Eskimo tương ứng |
|---|---|---|
| R1 | Tích hợp hoàn toàn bằng API trong platform riêng (connectorient.world), không dùng website Eskimo | External API (AppID + chữ ký HMAC) |
| R2 | Tạo đơn | `POST /users` (tạo account cho khách) → `POST /esim/top-up` |
| R3 | Lấy QR / LPA để tự hiển thị trong app (**Eskimo send email = false**) | `POST /esim/data-wallet`, `POST /users/search` → `esimInstallation` (`lpaString`, `smdpAddress`, `activationCode`, `iosInstallUrl`) |
| R4 | Trạng thái tồn kho / gói | `GET /all-data-plan` (catalog), `POST /esim/data-wallet` (data còn lại). **Không có API tồn kho eSIM** |
| R5 | Gói theo nước + gói khu vực/Global: Nigeria, South Africa, Kenya, Ghana, Egypt, UK, Schengen/Europe, US, Canada, UAE, China, Singapore, Vietnam; Africa / Europe Regional, Global | `all-data-plan?coverageType&coverageCode` |
| R6 | 200–500 lượt kích hoạt/tháng, tăng nhanh sau đó | Rate limit 100 req/phút/partner; Lifetime Account Limit |
| R7 | Ký "Wholesale Partnership Agreement", partner tự thu tiền khách | Cách tính tiền: credit + discount (Corporate) hay Application Fee (White Label)? |
| R8 | Chỉ dùng điện thoại có eUICC sẵn, không cần phần cứng | Không test phần cứng |

## 0. Cần BA/BE chốt trước khi test

| # | Câu hỏi | Vì sao |
|---|---|---|
| Q1 | Connect Orient dùng **type nào**: White label (như sales đề xuất) hay Corporate / Reseller? | Từ EP-5962, type White label = Application Fee + Stripe Connect (gắn website) + payment method chỉ có Direct Charge. Partner không có website thì không kết nối được Stripe, không có fee. Corporate dùng credit + discount, hợp với "wholesale" hơn |
| Q2 | Partner type White label, payment method "Not set" (như PN149531 trên PROD) gọi `esim/top-up` thì **bị tính tiền thế nào**, hay bị chặn `EXT_PARTNER_PAYMENT_METHOD_MISSING`? | Tài liệu top-up có lỗi payment method / credit insufficient |
| Q3 | Thread nói *"QR is not returned via API"*, nhưng tài liệu 26/10 đã có `esimInstallation.lpaString` trong data-wallet và users/search. Đã deploy chưa (stage / PROD)? | Client cần LPA vì đã tắt email |
| Q4 | Sau khi top-up, bao lâu thì có eSIM / LPA? Partner có phải poll data-wallet không? Có webhook không? | Top-up chỉ trả "request created" |
| Q5 | Mỗi khách cuối = 1 account (1 eSIM / ICCID)? Lifetime Account Limit cho partner này là bao nhiêu? | 500+/tháng sẽ nhanh chạm giới hạn |
| Q6 | Giá trả về từ `all-data-plan` là giá lẻ hay **giá wholesale của partner** (sau discount)? `firstPurchasePromo` có áp dụng cho partner không? | Client cần biết giá vốn |
| Q7 | Đơn qua API hiện ở đâu trong Admin: Top Up History, Eskimo Sales hay Transactions? Đối soát / hoá đơn thế nào? | Ở ESKIMO-763/910, Eskimo Sales chỉ có đơn WHI của storefront |
| Q8 | Sandbox: stage hết pool eSIM (thread: "UAT has no eSIM"). Có cấp được eSIM cho stage không, hay test cấp eSIM thật bắt buộc trên PROD? | Quy định QC: không chạy trên PROD nếu chưa được duyệt |
| Q9 | Bộ tài liệu "internal only" thì gửi client bản nào? | Index ghi "Do not share these links with external partners" |

## 1. Môi trường và dữ liệu test

- **Stage:** admin `app-eskimo-admin-stage-sea-001`, API `app-eskimo-api-stage-sea-001`.
- Partner test mới **QC-CO-API**, cấu hình giống Connect Orient: Corporate Program ON; type theo Q1, nếu chưa chốt thì chạy cả 2 biến thể (A = White label, B = Corporate); Eskimo Email Notification **OFF**; External APIs **ON**; có 1 owner/admin active; Lifetime limit nhỏ (vd 3) để test chạm giới hạn; credit/payment theo Q2.
- Khách cuối: email yopmail `qcco-<n>@yopmail.com`, để kiểm tra **không có email** nào được gửi.
- Công cụ: Playwright API spec `tests/CONNECT-ORIENT/` (tự ký HMAC, lấy AppID/Key qua `process.env`, không in key ra log).
- **Không đụng** Connect Orient PN149531 trên PROD.

## 2. Test case

### TC-A – Cấu hình Admin và Partner portal (stage, UI)
| ID | Bước | Kỳ vọng |
|---|---|---|
| A-01 | Tạo partner theo mục 1 (biến thể A và B) | Lưu được. Biến thể A: Stripe Connect "—", Payment method "Not set" |
| A-02 | Partner portal › API Configuration | Có App ID + API Key (che, chỉ hiện 3 ký tự cuối), copy được |
| A-03 | Đổi key (change key) | Key cũ → 401, key mới chạy được |
| A-04 | Partner tự tắt API / Admin tắt API (`change-status-by-admin`) | Request → 401 "Request no longer supported. Please contact Eskimo administrator." |

### TC-B – Xác thực và rate limit (stage, API)
| ID | Bước | Kỳ vọng |
|---|---|---|
| B-01 | Header đúng | 200 |
| B-02 | Sai Signature / thiếu AppID / thiếu Timestamp | 401 |
| B-03 | Timestamp lệch > 5 phút | 401 |
| B-04 | Dùng lại cùng Timestamp | 401 (tài liệu ghi "must be unique per request") |
| B-05 | 101 request trong 1 phút | Request thứ 101 → 429 "Rate limit exceeded…", bị khoá 1 phút |
| B-06 | Partner không phải Corporate gọi `users` / `top-up` | 400 `EXT_PARTNER_NOT_CORPORATE` |
| B-07 | Partner không có owner/admin active | 400 `EXT_PARTNER_NO_ACTIVE_ADMIN` |

### TC-C – Catalog cho các khu vực ưu tiên (stage + PROD chỉ đọc)
| ID | Bước | Kỳ vọng |
|---|---|---|
| C-01 | `all-data-plan?coverageType=3&coverageCode=NG,ZA,KE,GH,EG` | Có gói cho từng nước; ghi lại nước nào **không có gói** |
| C-02 | GB, US, CA, AE, CN, SG, VN (coverageType 3) | Như trên |
| C-03 | `coverageType=1` (Region): Africa, Europe | Có Africa Regional / Europe Regional; `coverages[]` có các nước Schengen |
| C-04 | `coverageType=0` (Global) | Có gói Global |
| C-05 | `planType=1` / `2` | Lọc đúng Fixed / Unlimited |
| C-06 | So `prices.USD` với giá trong Admin / giá wholesale theo Q6 | Khớp với cách tính đã chốt |
| C-07 | Response là mảng JSON, không có wrapper | Đúng tài liệu |

### TC-D – Account (stage, API)
| ID | Bước | Kỳ vọng |
|---|---|---|
| D-01 | `POST /users` email hợp lệ | 200, có accountId; **không có email mời** (Email OFF) |
| D-02 | Email trùng (khác hoa/thường, có khoảng trắng) | Bị từ chối (unique, trimmed, case-insensitive) |
| D-03 | Email sai định dạng / > 200 ký tự | 400 `EXT_ACCOUNT_EMAIL_INVALID` |
| D-04 | Tạo vượt Lifetime Account Limit | Bị từ chối, có lý do |
| D-05 | `PUT /users` đổi email; `POST /users/search` theo id / email / searchKey / ICCID, phân trang | Đúng tài liệu |
| D-06 | `DELETE /users/{id}` (suspend) | Thông báo "eSIM Suspension in process…"; top-up sau đó → `EXT_WORKER_TERMINATED` |
| D-07 | Partner X dùng accountId của partner Y | `EXT_WORKER_NOT_FOUND` (dữ liệu tách theo partner) |

### TC-E – Tạo đơn (top-up) và tính tiền (stage, API)
| ID | Bước | Kỳ vọng |
|---|---|---|
| E-01 | Top-up gói rẻ nhất, có clientRefId | 200, có topUpId |
| E-02 | Dùng lại clientRefId / clientRefId > 150 ký tự | `EXT_CLIENT_REF_ALREADY_EXISTS` / `EXT_CLIENT_REF_TOO_LONG` |
| E-03 | planId sai / thiếu | `EXT_TOPUP_PLAN_LIST_INVALID` / `EXT_PLAN_ID_REQUIRED` |
| E-04 | Hết credit / chưa có payment method | `EXT_PARTNER_CREDIT_INSUFFICIENT` / `EXT_PARTNER_PAYMENT_METHOD_MISSING` |
| E-05 | Program đã hết hạn (End Date) | `EXT_PARTNER_PROGRAM_INVALID` |
| E-06 | **Tiền**: so credit / số tiền trước và sau E-01 | = giá × (100 − discount)% (biến thể B) hoặc theo cách đã chốt ở Q1/Q2 (biến thể A) |
| E-07 | **Ghi nhận**: Admin › Top Up History, Transactions, Eskimo Sales, Partner portal | Đơn hiện đúng chỗ đã chốt ở Q7, đúng partner, đúng gói, đúng tiền |
| E-08 | Top-up lần 2 cho cùng account | Gói thêm vào cùng eSIM (ICCID không đổi) |

### TC-F – Cấp eSIM / LPA khi Email OFF (stage nếu có pool, nếu không thì PROD có duyệt)
| ID | Bước | Kỳ vọng |
|---|---|---|
| F-01 | Ngay sau top-up gọi data-wallet | Ghi nhận: chưa có eSIM thì `EXT_DATA_PLAN_NOT_FOUND` hoặc `esimInstallation=null` |
| F-02 | Poll đến khi có eSIM (ghi lại thời gian) | `accountIccid`, `esimInstallation.lpaString` = `LPA:1$<smdp>$<code>`, `iosInstallUrl` đúng định dạng |
| F-03 | `users/search` | Trả cùng `esimInstallation` |
| F-04 | Hộp thư yopmail của khách | **Không có** email mua hàng / QR / Magic Link |
| F-05 | (PROD, có duyệt) Cài eSIM trên điện thoại eUICC bằng LPA / QR tự tạo; dùng iosInstallUrl trên iPhone | Cài được, kết nối mạng, data trừ dần |
| F-06 | data-wallet sau khi dùng; lọc status 2 / 3 / 4 | `currentValue` giảm; lọc đúng |

### TC-G – Volume (stage)
| ID | Bước | Kỳ vọng |
|---|---|---|
| G-01 | 50 lần tạo account + top-up liên tiếp, ≤ 100 req/phút | Không lỗi, không trùng, thời gian phản hồi được ghi lại |

## 3. Môi trường và thứ tự chạy

1. Gửi Q1–Q9 cho BA/BE, chờ trả lời.
2. Stage: TC-A, B, C, D, E, G; TC-F nếu stage có eSIM.
3. PROD chỉ đọc: TC-C, để xác nhận gói thật cho các nước ưu tiên.
4. PROD có ghi (1 đơn thật, F-05): chỉ khi BA/PM duyệt và có partner / credit test riêng.

## 4. Rủi ro đã thấy

- **Type White label** cho partner không có website: không có Stripe Connect, không có fee, payment method "Not set" → top-up có thể bị chặn hoặc tính tiền không rõ (Q1/Q2).
- **Thông tin QR mâu thuẫn**: thread nói không trả QR, tài liệu mới có `lpaString` (Q3).
- **Không có API tồn kho**: client hỏi "inventory status" nhưng chỉ có catalog.
- **Stage không có eSIM**: phần cấp eSIM thật chỉ test được trên PROD (Q8).
- **Tài liệu "internal only"**: cần bản để gửi partner (Q9).
