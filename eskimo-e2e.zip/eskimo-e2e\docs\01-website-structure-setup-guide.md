# Hướng dẫn thiết lập White Label: Tạo website và quản lý cấu trúc (Website Structure)

| | |
|---|---|
| **Người thực hiện** | Admin trên Admin Portal |
| **Màn hình** | Menu **White Label** → **Website Templates** |
| **Kết quả** | Mỗi partner White Label có một website riêng. Website được tạo từ template mặc định, gán cho partner, sắp xếp các trang và module theo nhu cầu, rồi bật hoạt động. |
| **Cập nhật** | 16/10/2026 (ticket ESKIMO-751 / EP-5963) |

> Đây là **file 1 trong bộ 4 file** hướng dẫn White Label:
> 1. **Tạo website và quản lý cấu trúc** (Admin), tài liệu này
> 2. *Chỉnh nội dung và thương hiệu (Partner CMS)*
> 3. *Cấu hình tên miền, email gửi và thanh toán*
> 4. *Customer Journey: khách mua và dùng eSIM*

---

## 1. Khái niệm cần biết

| Khái niệm | Ý nghĩa |
|---|---|
| **Template** | Bộ khung website dùng lại được. Hệ thống có sẵn template **System Default** tên **"Eskimo eCommerce (Default)"**, được dựng từ website eCommerce hiện tại của Eskimo. |
| **Website (Partner Website)** | Một bản sao độc lập của template, dành riêng cho một partner. Mỗi partner chỉ có **một** website. |
| **Page (trang)** | Các trang của website. Template mặc định có 5 trang: Home, Plan Detail, Checkout, Install eSIM, Data Balance. |
| **Module / Section** | Một khối nội dung độc lập trong trang (Header, Banner, FAQ, Footer...). Cùng một loại module có thể dùng ở nhiều trang và nhiều website. |

> **Phân chia trách nhiệm**
> - **Admin** (tài liệu này) quyết định **cấu trúc**: website có những trang nào, mỗi trang có module nào và theo thứ tự nào.
> - **Partner** tự chỉnh **nội dung và thương hiệu** (tên thương hiệu, logo, màu, chữ, hình ảnh trong từng module) trên Partner Portal (file 2). Partner không thêm, xoá hay sắp xếp module được.

---

## 2. Điều kiện trước khi bắt đầu

1. Tài khoản Admin có quyền vào menu **White Label**.
2. Partner sẽ nhận website phải thoả **cả hai** điều kiện sau. Nếu thiếu, partner sẽ **không xuất hiện** trong danh sách lúc gán (xem Bước 2).
   - **Corporate Program** của partner đang **bật (ON)** với Type **White label**. Bật tại **Partnership › Partners** → Edit partner → mục *Corporate Program*.
   - Partner **chưa có website nào khác**.

---

## 3. Tổng quan quy trình

```
Bước 1  Tạo website       Clone từ template "Eskimo eCommerce (Default)"
   │                      → dòng mới "Untitled Website Draft" (Inactive)
   ▼
Bước 2  Gán partner       Assign Partner → chọn partner → Assign
   │                      → tên đổi thành "Website Template for partner <tên partner>"
   ▼
Bước 3  Chỉnh cấu trúc    Edit Structure → chọn trang → thêm / xoá / sắp xếp module
   │                      → Save Page (hoặc Save All)
   ▼
Bước 4  Bật hoạt động     Status: Inactive → Active
   │
   ▼
Tiếp theo                 Partner chỉnh nội dung và thương hiệu (file 2),
                          Config tên miền, email gửi và thanh toán (file 3)
```

---

## 4. Màn hình Website Templates

Vào **White Label** trên menu trái. Màn hình **Website Templates** hiển thị chung trong một bảng cả template và các website của partner.

![Màn hình Website Templates](images/website-structure/01-website-templates-after-clone.png)

| Cột | Nội dung |
|---|---|
| **Name** | Tên template hoặc website |
| **Type** | `System Default` (template) hoặc `Partner Website` (website của partner) |
| **Partner** | Partner đang sở hữu website. Hiện "—" nếu chưa gán hoặc nếu dòng là template. |
| **Pages** | Số trang |
| **Status** | Công tắc **Active / Inactive**, chỉ có ở website |
| **Created Date** | Ngày tạo |
| **Actions** | Các nút thao tác, khác nhau theo loại dòng (bảng dưới) |

| Loại dòng | Nút có sẵn |
|---|---|
| **System Default** (template) | **Edit Structure**, **Clone** |
| **Partner Website** | **Edit Structure**, **Config**, **Assign Partner** (hoặc **Reassign Partner** nếu đã gán), **Delete** |

---

## 5. Bước 1: Tạo website mới từ template mặc định

1. Trên dòng **Eskimo eCommerce (Default)** (Type = *System Default*), bấm **Clone**.
2. Thông báo **"Website draft created"** hiện ở góc phải trên.
3. Bảng xuất hiện một dòng mới:
   - Name: **Untitled Website Draft**
   - Type: **Partner Website**
   - Partner: **—** (chưa gán)
   - Status: **Inactive**
   - Pages: **5**

Website mới **sao chép toàn bộ cấu trúc** của template tại thời điểm Clone: cùng 5 trang, cùng các module, cùng thứ tự (xem Phụ lục A).

> **Lưu ý**
> - Mỗi lần bấm Clone tạo **một** website mới.
> - Tên website do hệ thống đặt tự động, và tự cập nhật theo tên partner khi gán ở Bước 2.

---

## 6. Bước 2: Gán website cho partner

1. Trên dòng **Untitled Website Draft** vừa tạo, bấm **Assign Partner**.
2. Cửa sổ **"Assign Partner — Untitled Website Draft"** mở ra, có ô bắt buộc **Partner**.
3. Bấm vào ô **Partner** rồi **gõ tên partner** để tìm (placeholder *"Search a partner by name"*). Danh sách lọc theo tên khi bạn gõ.
4. Chọn đúng partner trong danh sách.
5. Bấm **Assign**.
6. Kết quả:
   - Thông báo **"Untitled Website Draft" assigned**.
   - Cột **Partner** hiện tên partner.
   - Tên website tự đổi thành **"Website Template for partner <tên partner>"**.

![Website sau khi gán partner](images/website-structure/02-assigned-partner.png)

> **Danh sách partner chỉ hiện những partner hợp lệ**, tức là partner đang **bật Corporate Program (White label)** **và** **chưa có website khác**.
> Nếu không tìm thấy partner, hoặc ô báo **"No available partner"**, hãy kiểm tra lại 2 điều kiện ở mục 2.

**Đổi partner (Reassign Partner):** với website đã gán, nút đổi thành **Reassign Partner**. Mở ra, chọn partner khác (cũng phải hợp lệ) rồi bấm **Assign**.

---

## 7. Bước 3: Chỉnh cấu trúc website (Edit Structure)

### 7.1 Mở trình chỉnh sửa

1. Trên dòng website của partner, bấm **Edit Structure**.
2. Cửa sổ **"Edit Structure — <tên website>"** mở ra, gồm 3 phần:
   - **Thanh chọn trang** ở trên cùng: `Home (13)`, `Plan Detail (4)`, `Checkout (2)`, `Install eSIM (3)`, `Data Balance (4)`. Số trong ngoặc là số module của trang đó. Trang **Home** được chọn sẵn.
   - **Khung xem trước (canvas)**: hiển thị từng module của trang theo thứ tự từ trên xuống, giống website thật.
   - **Chân cửa sổ**: nút **Close** và **Save Page**.
3. Mỗi module có một **thanh tiêu đề** gồm:
   - Biểu tượng **≡** ở bên trái để kéo đổi vị trí. Riêng **Header** không có biểu tượng này, vì luôn cố định ở đầu trang.
   - **Tên module**, ví dụ *Header*, *More Reasons Grid*.
   - Nút **thùng rác đỏ** ở bên phải để xoá module.

### 7.2 Thêm module vào trang

1. Chọn trang cần thêm trên thanh chọn trang.
2. Cuộn xuống cuối khung xem trước, bấm **+ Add Section**.
3. Danh sách module mở ra (18 loại, xem Phụ lục B). Chọn module cần thêm.
4. Module mới được **thêm vào cuối trang**. Số module trên thanh chọn trang tăng 1, ví dụ `Home (13)` thành `Home (14)`.
5. **Kéo module mới lên đúng vị trí** (mục 7.4). Thường sẽ kéo lên trên **Footer**.

![Module vừa thêm ở cuối trang](images/website-structure/03-editor-add-section.png)

### 7.3 Xoá module khỏi trang

1. Trên thanh tiêu đề của module cần xoá, bấm nút **thùng rác đỏ**.
2. Hộp xác nhận **"Remove this module?"** hiện ra. Bấm **Remove** để xoá, hoặc **Cancel** để huỷ.
3. Module biến mất khỏi khung xem trước, số module của trang giảm 1.

### 7.4 Sắp xếp lại thứ tự module

> **Header không kéo thả được** và luôn nằm ở **đầu** trang. Dù kéo module khác lên trên, Header vẫn tự quay về vị trí đầu tiên. Mọi module còn lại, kể cả Footer, đều đổi được thứ tự.

**Cách 1, kéo thả bằng chuột:** giữ chuột vào biểu tượng **≡** trên thanh tiêu đề module, kéo lên hoặc xuống tới vị trí mong muốn rồi thả.

**Cách 2, dùng bàn phím** (tiện khi trang dài):
1. Bấm phím Tab cho tới khi biểu tượng **≡** của module được chọn.
2. Nhấn **Space** để "nhấc" module lên.
3. Nhấn **↑** / **↓** để di chuyển.
4. Nhấn **Space** lần nữa để thả.

> Chỉ sắp xếp được trong **cùng một trang**. Muốn đưa một module sang trang khác: xoá ở trang cũ, rồi dùng **+ Add Section** ở trang mới.

### 7.5 Lưu thay đổi

1. Nút lưu ở góc phải dưới thay đổi theo số trang có chỉnh sửa:
   - **Save Page**: chỉ 1 trang có thay đổi.
   - **Save All (N pages)**: bạn đã sửa N trang. Bấm một lần để lưu tất cả.
   - Nút **bị mờ** khi chưa có thay đổi nào.
2. Lưu thành công sẽ hiện thông báo **Saved: "Home"** (hoặc tên các trang đã lưu).
3. Bấm **Close** để đóng cửa sổ.

> Bấm **Save Page / Save All** trước khi **Close**. Thay đổi chỉ được ghi lại sau khi lưu.

---

## 8. Bước 4: Bật hoạt động website (Status)

- Website mới tạo luôn ở trạng thái **Inactive**.
- Khi cấu trúc đã sẵn sàng, gạt công tắc ở cột **Status** sang **Active**. Thay đổi được lưu ngay, không cần bấm Save.
- Muốn tạm ngưng website, gạt lại về **Inactive**.

---

## 9. Các thao tác khác

### 9.1 Bước tiếp theo sau khi dựng cấu trúc

- **Config** (trên dòng website): cấu hình **Custom domain** (tên miền riêng của partner) và **Email sender** (tên và địa chỉ gửi email cho khách). Xem file 3.
- **Nội dung và thương hiệu**: partner đăng nhập **Partner Portal** → **My Website** để chỉnh logo, màu, chữ, hình ảnh. Xem file 2.

### 9.2 Xoá website

1. Trên dòng website, bấm **Delete**.
2. Hộp xác nhận **Delete "<tên website>"?** hiện ra. Bấm **Delete**.
3. Thông báo **"DELETE SUCCESS"**, dòng website biến mất.

> ⚠️ Không hoàn tác được. Partner sẽ mất website, kèm toàn bộ nội dung đã chỉnh trên Partner Portal. Partner Portal của họ sẽ báo *"No website has been assigned to you yet"*. Template **System Default** không có nút Delete.

### 9.3 Xem template mặc định

Bấm **Edit Structure** trên dòng **Eskimo eCommerce (Default)** để xem cấu trúc gốc và thư viện module.

> Thay đổi lưu trên template System Default chỉ áp dụng cho các website **tạo sau đó** (mục 10). Các website đã có không bị ảnh hưởng.

---

## 10. Quy tắc độc lập giữa template và website

| Tình huống | Kết quả |
|---|---|
| Sửa cấu trúc **website** của partner A | **Không** ảnh hưởng template và **không** ảnh hưởng website của partner khác |
| Sửa **template** System Default | **Không** ảnh hưởng các website đã tạo trước đó. Chỉ các website **Clone sau** mới nhận cấu trúc mới. |
| **Clone** một website mới | Website mới nhận nguyên cấu trúc của template **tại thời điểm Clone**. Sau đó hai bên hoàn toàn tách biệt. |

---

## 11. Câu hỏi thường gặp

| Câu hỏi | Trả lời |
|---|---|
| Không thấy partner trong ô **Partner** khi Assign | Partner chưa bật **Corporate Program (White label)**, hoặc đã có website khác. Bật Corporate Program tại *Partnership › Partners*, hoặc xoá / gán lại website cũ. |
| Ô Partner báo **"No available partner"** | Không có partner nào thoả điều kiện, hoặc từ khoá tìm kiếm không khớp. Gõ lại một phần tên partner. |
| Nút **Save Page** bị mờ | Chưa có thay đổi nào trên trang. |
| Không kéo được **Header** | Header luôn cố định ở đầu trang. Các module khác, kể cả Footer, kéo thả được. |
| Tìm module hiển thị **sản phẩm** (danh sách gói data) | Dùng module **Data Plan Section (Global + Regions)** trên trang Home, và **Plan Detail Hero** trên trang Plan Detail. |

---

## 12. Checklist hoàn tất

- [ ] Partner đã bật **Corporate Program = White label** và chưa có website khác
- [ ] Đã **Clone** từ *Eskimo eCommerce (Default)*, thấy dòng *Untitled Website Draft*
- [ ] Đã **Assign Partner**, cột Partner hiện đúng tên, website đổi tên theo partner
- [ ] Đã chỉnh cấu trúc từng trang (thêm / xoá / sắp xếp) và **Save** (thấy thông báo *Saved: ...*)
- [ ] Mở lại **Edit Structure** để kiểm tra cấu trúc đã được lưu đúng: Header ở đầu, **Footer ở cuối** mỗi trang
- [ ] Đã gạt **Status = Active**
- [ ] Đã chuyển sang bước Config (tên miền, email) và Partner CMS

---

## Phụ lục A: Cấu trúc mặc định của template "Eskimo eCommerce (Default)"

Template có 5 trang, 26 module. Thứ tự từ trên xuống:

| Trang | Số module | Module (theo thứ tự) |
|---|---|---|
| **Home** | 13 | Header → Banner → Data Plan Section (Global + Regions) → Transfer Data (Why Eskimo eSIM) → More Reasons Grid → downloadApp → Video Section → Comparison Table → Install Steps → Reviews → FAQ → Recommendations → Footer |
| **Plan Detail** | 4 | Header → Plan Detail Hero → Sticky Checkout Bar → Footer |
| **Checkout** | 2 | Header → Footer |
| **Install eSIM** | 3 | Header → Install eSIM Guide (iOS / Android, manual) → Footer |
| **Data Balance** | 4 | Header → Data Balance Screen → Data & eSIM Information → Footer |

*Header* và *Footer* dùng chung trên cả 5 trang, *Header* luôn cố định ở đầu trang (không kéo thả được). *Footer* nằm cuối trang theo mặc định nhưng vẫn kéo thả được.

## Phụ lục B: Thư viện module (+ Add Section)

| Module | Dùng cho |
|---|---|
| Header | Thanh đầu trang: logo, menu |
| Banner | Ảnh bìa đầu trang: tiêu đề, mô tả, nút kêu gọi |
| Feature Section | Khối giới thiệu các điểm nổi bật |
| Data Plan Section (Global + Regions) | Danh sách gói data theo quốc gia và khu vực (phần sản phẩm) |
| Transfer Data (Why Eskimo eSIM) | Lý do chọn dịch vụ, chuyển data |
| More Reasons Grid | Lưới các lý do / ưu điểm |
| Video Section | Video giới thiệu |
| Comparison Table | Bảng so sánh |
| Install Steps | Các bước cài đặt eSIM (tóm tắt) |
| Reviews | Đánh giá của khách hàng |
| FAQ | Câu hỏi thường gặp |
| Recommendations | Gợi ý gói / điểm đến |
| Footer | Chân trang: liên kết, mạng xã hội, bản quyền |
| Plan Detail Hero | Phần đầu trang chi tiết gói |
| Sticky Checkout Bar | Thanh thanh toán cố định ở trang chi tiết gói |
| Data & eSIM Information | Thông tin data và eSIM của khách |
| Data Balance Screen | Màn hình xem data còn lại |
| Install eSIM Guide (iOS / Android, manual) | Hướng dẫn cài eSIM chi tiết theo thiết bị |

Danh sách module được thiết kế để **mở rộng**: module mới sẽ tự xuất hiện trong **+ Add Section** khi được bổ sung.
