# Hướng dẫn Admin: Thiết lập partner White Label

| | |
|---|---|
| **Dành cho** | Admin Eskimo trên Admin Portal |
| **Phạm vi** | Bật Corporate Program (White label) cho partner → tạo website và cấu trúc → đặt Application Fee → Config tên miền và email gửi → go-live → vận hành |
| **Cập nhật** | 26/10/2026 |

---

## 1. Tổng quan

### 1.1 Admin và Partner làm gì

| Vai trò | Làm ở đâu | Trách nhiệm |
|---|---|---|
| **Admin Eskimo** (tài liệu này) | Admin Portal | Bật Corporate Program, tạo website và quyết định **cấu trúc** (trang, module, thứ tự), đặt Application Fee, Config tên miền và email gửi, bật/tắt website |
| **Partner** | Partner Portal → **My Website** | Kết nối **Stripe**, chỉnh **nội dung và thương hiệu** trong từng module, thêm vào tên miền của mình các **bản ghi DNS** (website và email gửi) mà Admin gửi. **Không** thêm, xoá hay sắp xếp module được |

> Partner làm theo tài liệu riêng *"Hướng dẫn Partner: Quản lý website trên Partner Portal"*. Gửi tài liệu đó cho partner sau khi đã gán website (Bước 2).

### 1.2 Quy trình

```
LANES
```

### 1.3 Chuỗi điều kiện phụ thuộc

| Muốn làm được… | Cần có trước… |
|---|---|
| Gán partner trong **Assign Partner** | Partner có Corporate Program **ON** (Type White label) và **chưa có website nào** |
| **Application Fee** được lưu | Partner **đã bắt đầu** Connect Stripe (Stripe Connect Status khác *Not Connected* / *—*) |
| Khách **thanh toán** được | Stripe Connect Status = **Verified** |
| Website **hiển thị và bán hàng** | Corporate Program **đang hoạt động** (Status ON và hôm nay nằm trong Start → End Date) **và** website **Status = Active**. Admin chỉ bật website khi Stripe của partner đã **Verified** |
| Khách **nhận email QR eSIM + Magic Link từ Eskimo** | **Eskimo Email Notification = ON** **và** Email sender (tên miền email của partner) đã **Verified** (6.2) |
| Partner **chỉnh nội dung** trên My Website | Website đã được tạo và **gán** cho partner |

---

## 2. Chuẩn bị

1. Tài khoản Admin có quyền vào **Partnership › Partners** và menu **White Label**.
2. Partner đã có trên hệ thống, **Partner Email** đúng là email partner dùng đăng nhập Partner Portal.
3. Đã thống nhất với partner:
    - **Thời hạn** hợp tác (Start / End Date).
    - **Application Fee (%)**.
    - **Ai gửi email** cho khách (Eskimo hay partner).
    - **Số tài khoản tối đa** (Lifetime Account Limit). Nếu chưa thống nhất, để **mức tối đa (99999)**.
    - Partner đã gửi **tên miền con** cho website (ví dụ `esim.partner.com`).
    - **Ai gửi email cho khách:** partner nhờ Eskimo gửi thì partner phải gửi kèm **thông tin email gửi** trên tên miền email của họ (Sender name, From address, Reply-to). Partner tự gửi bằng hệ thống riêng thì không cần.

---

## 3. Bước 1 — Bật Corporate Program

**Màn hình:** **Partnership › Partners** → tìm partner → **Edit** → mục **Corporate Program** (cột phải).

### 3.1 Cấu hình Corporate Program

![Corporate Program của một partner White Label đã cấu hình xong](images/corporate-program/02-corporate-program-verified.png)

| # | Trường | Thao tác / quy tắc |
|---|---|---|
| 1 | **Status** | Gạt **ON**. Các trường bên dưới hiện ra |
| 2 | **Type** | Chọn **White label**. ⚠️ **Khoá sau khi lưu** |
| 3 | **Start Date** | Bắt buộc, `DD/MM/YYYY`. **Khoá** khi ngày bắt đầu đã qua (trong ngày bắt đầu vẫn sửa được) |
| 4 | **End Date** | Bắt buộc, **sau Start Date**; không chọn được hôm nay và ngày quá khứ (sớm nhất là ngày mai). Gia hạn được bất cứ lúc nào |
| 5 | **Eskimo Email Notification** | **ON** khi partner gửi **tên miền email** cho Eskimo cấu hình: Eskimo gửi khách email xác nhận mua hàng, email QR eSIM (kèm mã LPA) và Magic Link vào My Data bằng địa chỉ email của partner (Email sender, 6.2). **OFF** (mặc định) khi partner không gửi tên miền email: partner **tự xử lý** việc gửi xác nhận đơn, mã QR eSIM và mã OTP đăng nhập My Data cho khách qua **External API**; Eskimo **không gửi email nào**, bỏ qua 6.2. Partner không có tên miền email thì Eskimo không gửi email |
| 6 | **Lifetime Account Limit** | Hiển thị `<đã dùng> / <tối đa>`. Nhập số nguyên dương **< 100000** (tối đa 99999), bắt buộc. Chưa thống nhất với partner thì nhập **99999** |
| 7 | **Payment method** | **Direct Charge** (lựa chọn duy nhất) |
| 8 | **Data Expiry** | **2 Years** (data hết hạn 2 năm kể từ ngày mua) |
| 9 | **Application Fee Percentage** | **Chưa nhập ở bước này.** Hệ thống chỉ lưu phí khi partner đã bắt đầu kết nối Stripe; đặt ở Bước 3 |
| 10 | **Stripe Connect Status** | Chỉ xem. Partner tự kết nối trên Partner Portal |

Bấm **Ok** → **UPDATE SUCCESS**. Mở lại partner để kiểm tra.

![Payment method = Direct Charge](images/corporate-program/05-payment-method-direct-charge.png)

---

## 4. Bước 2 — Tạo website và chỉnh cấu trúc

**Màn hình:** menu **White Label** → **Website Templates**.

### 4.1 Màn hình Website Templates

![Màn hình Website Templates](images/website-structure/01-website-templates-after-clone.png)

| Cột | Nội dung |
|---|---|
| **Name** | Tên template / website |
| **Type** | `System Default` (template) hoặc `Partner Website` |
| **Partner** | Partner sở hữu, "—" nếu chưa gán hoặc là template |
| **Pages** | Số trang |
| **Status** | Công tắc **Active / Inactive** (chỉ website) |
| **Created Date** | Ngày tạo |
| **Actions** | Template: **Edit Structure**, **Clone**. Website: **Edit Structure**, **Config**, **Assign Partner** / **Reassign Partner**, **Delete** |

### 4.2 Clone website từ template

1. Trên dòng **Eskimo eCommerce (Default)** bấm **Clone** → thông báo **"Website draft created"**.
2. Dòng mới: Name **Untitled Website Draft**, Type **Partner Website**, Partner **—**, Status **Inactive**, Pages **5**.
3. Website mới sao chép **toàn bộ cấu trúc template tại thời điểm Clone** (Phụ lục A). Mỗi lần Clone tạo **một** website.

### 4.3 Gán partner

1. Trên dòng website mới bấm **Assign Partner**.
2. Gõ tên partner vào ô **Partner** (*"Search a partner by name"*), chọn đúng partner → **Assign**. Bỏ trống thì báo *"Please select a partner"*.
3. Kết quả: thông báo **"Untitled Website Draft" assigned**; cột Partner hiện tên; website tự đổi tên thành **"Website Template for partner &lt;tên partner&gt;"**.

![Website sau khi gán partner](images/website-structure/02-assigned-partner.png)

> Thấy **"No available partner"** → kiểm tra lại Bước 1, hoặc partner đã có website khác.
>
> **Reassign Partner**: với website đã gán, chọn partner khác (cũng phải hợp lệ) → **Assign**.

Gán xong, partner đăng nhập Partner Portal → **My Website** là thấy website của mình. Gửi partner tài liệu hướng dẫn Partner Portal.

### 4.4 Edit Structure

Bấm **Edit Structure** → cửa sổ **"Edit Structure — &lt;tên website&gt;"** gồm:
- **Thanh chọn trang**: `Home (12)`, `Plan Detail (4)`, `Checkout (2)`, `Install eSIM (3)`, `Data Balance (4)` (số trong ngoặc = số module).
- **Canvas** xem trước các module từ trên xuống.
- **Chân cửa sổ**: **Close** và **Save Page**.

Mỗi module có thanh tiêu đề: biểu tượng **≡** để kéo đổi vị trí (Header không có), tên module, nút **thùng rác đỏ**.

| Thao tác | Cách làm |
|---|---|
| **Thêm module** | Chọn trang → cuộn cuối canvas → **+ Add Section** → chọn module (Phụ lục B). Module được **thêm vào cuối trang** → kéo lên đúng vị trí (thường là **trên Footer**) |
| **Xoá module** | Bấm thùng rác → *"Remove this module?"* → **Remove** |
| **Sắp xếp** | Giữ **≡**, kéo lên/xuống, thả |
| **Chuyển module sang trang khác** | Không kéo được giữa các trang: xoá ở trang cũ → **+ Add Section** ở trang mới |
| **Lưu** | **Save Page** (1 trang thay đổi) hoặc **Save All (N pages)**. Nút mờ khi chưa có thay đổi. Thành công: **Saved: "Home"** |

![Module vừa thêm ở cuối trang](images/website-structure/03-editor-add-section.png)

> ⚠️ **Header luôn ở đầu trang** và không kéo được. **Footer kéo được**: sau khi thêm hoặc sắp xếp module, kiểm tra Footer vẫn ở **cuối** trang trước khi lưu.
>
> ⚠️ Bấm **Save Page / Save All trước khi Close.** Nút Close **không cảnh báo** khi còn thay đổi chưa lưu; đóng là mất.

>
> 💡 **Phối hợp với partner:** sau khi partner đã nhập nội dung, **xoá** một module sẽ làm khối nội dung đó không còn trên website. Nên thống nhất với partner trước khi xoá.

### 4.5 Quy tắc độc lập template ↔ website

| Tình huống | Kết quả |
|---|---|
| Sửa cấu trúc website của partner A | **Không** ảnh hưởng template hay website partner khác |
| Sửa template System Default | **Không** ảnh hưởng website đã tạo; chỉ website **Clone sau** nhận cấu trúc mới |
| Clone website mới | Nhận nguyên cấu trúc template tại thời điểm Clone, sau đó tách biệt hoàn toàn |

---

## 5. Bước 3 — Theo dõi Stripe và đặt Application Fee

### 5.1 Partner kết nối Stripe (Admin theo dõi)

Admin **không thể** kết nối Stripe thay partner. Partner làm trên Partner Portal: **My Website** → **Stripe payments** → **Connect Stripe**, rồi hoàn tất khai báo trên trang Stripe.

| Hiển thị | Ý nghĩa | Cần làm |
|---|---|---|
| **Not Connected** / **—** | Chưa kết nối (**—** = chưa từng bắt đầu) | Nhắc partner bấm **Connect Stripe** |
| **Pending verification** | Stripe đang xác minh | Chờ; nếu Stripe yêu cầu thêm, partner bấm **Continue setup** |
| **Verified** | Sẵn sàng nhận thanh toán | Hoàn tất |

![Stripe Connect Status = Pending verification](images/corporate-program/03-stripe-pending-verification.png)

> Trạng thái có thể mất **vài phút** để cập nhật sau khi Stripe xác minh. Mở lại partner để xem mới nhất.

### 5.2 Đặt Application Fee Percentage

> **Vì sao làm sau Stripe?** Hệ thống chỉ lưu phí khi partner **đã bắt đầu** kết nối Stripe (trạng thái không còn là *Not Connected* / *—*). Đặt trước thì partner vẫn lưu nhưng phí thì không, kèm thông báo *"Partner saved, but the Application Fee was not: Stripe onboarding has not been started for this partner"*.

1. Edit partner → **Corporate Program** → **Application Fee Percentage**.
2. **Quy tắc gốc** là dòng đầu tiên, **Apply To = Any Data Plan**: luôn đứng đầu, không đổi Apply To, không xoá được. **Fee** = *Percentage (%)*. Nhập % (placeholder *"10 (default)"*).
3. **Quy tắc riêng cho nhóm gói** (chỉ khi đã thoả thuận): bấm **+ Add Application Fee** → chọn **Apply To** (gõ tên để lọc, ví dụ `Any Fixed 1GB`, `Any Japan Plan`, hoặc một gói cụ thể) → nhập %. Sửa thì đổi % trên dòng đó; bỏ thì bấm nút xoá của dòng.
4. Bấm **Ok**.

**Mỗi gói dùng quy tắc nào:** quy tắc khớp với gói có **độ ưu tiên cao nhất**; không khớp quy tắc nào thì dùng quy tắc gốc.

| Ưu tiên | Apply To |
|---|---|
| 1 (cao nhất) | Một gói cụ thể (ví dụ Japan 1GB) |
| 2 | Any {Global / khu vực / quốc gia} Plan (ví dụ Any Japan Plan) |
| 3 | Any {dung lượng} (ví dụ Any Fixed 1GB) |
| 4 | Any {loại gói} (Any Fixed / Any Unlimited) |
| 5 | Any Data Plan (quy tắc gốc) |

> Đổi quy tắc chỉ áp dụng cho đơn mới; **đơn đã có giữ nguyên phí cũ**. Quy tắc được giữ nguyên khi tắt rồi bật lại chương trình.

| Nhập | Kết quả |
|---|---|
| `0` ≤ phí < `100`, tối đa 2 chữ số thập phân (`20`, `12.5`) | Hợp lệ, trong mức tối đa của nhóm gói (xem dưới) |
| `100` trở lên | *"Fee must be at least 0 and less than 100"* |
| Quá 2 chữ số thập phân (`12.345`), chữ, số âm | *"Value should contain just number"* |
| **Để trống** | Dùng **mặc định 10%** (*"Leave empty to use the default fee (10%)."*) |

> Ô phí hiện **mức đã lưu**; chưa đặt thì để trống (tức mặc định 10%). Nhập `0` nghĩa là Eskimo **không thu phí**, chỉ nhập khi đã thoả thuận như vậy.
>
> Từ Bước 1 tới Bước 3 không có đơn nào bị thiếu phí: khi Stripe của partner chưa **Verified**, khách chưa thanh toán được.

**Mức phí tối đa tuỳ nhóm gói.** Với quy tắc theo nhóm gói (**Any …**), phần partner nhận (**giá gói × (100% − phí)**) phải **từ 1 USD trở lên** với **mọi gói** trong nhóm, nên mức tối đa do **gói rẻ nhất** của nhóm quyết định. Vượt mức thì bấm **Ok** báo *"White label discount is invalid. Please check again."* và **không lưu gì** (lỗi không nói quy tắc nào; giảm % của quy tắc vừa thêm/sửa rồi lưu lại). Form có thể hiện cảnh báo *"… final bill < 1"* (ví dụ *"Africa 1GB final bill < 1"*) liệt kê gói bị dưới 1 USD.

| Apply To | Gói rẻ nhất | Phí tối đa |
|---|---|---|
| Any Fixed 1GB / Any Fixed | US$3.90 | **74%** |
| Any Fixed 3GB | US$7.90 | **87%** |
| Any Fixed 5GB | US$10.90 | **90%** |
| Any Fixed 10GB | US$17.90 | **94%** |
| Any Unlimited | US$5.00 | **80%** |

> Mức tối đa đi theo **giá gói hiện tại** (đo trên stage 27/10/2026); giá gói đổi thì mức tối đa đổi theo. **Khách luôn trả đủ giá gói**, phí chỉ chia phần giữa Eskimo và partner.

![Nhập Application Fee 90% và cảnh báo final bill < 1](images/corporate-program/04-application-fee-warning.png)

### 5.3 Cách tính

```
Application Fee (Eskimo nhận)   = Giá gói × Application Fee %
Partner Benefit (partner nhận)  = Giá gói × (100% − Application Fee %) − phí Stripe
```

**Application Fee %** là % của quy tắc áp dụng cho gói đó (5.2). Đơn có nhiều gói thì **phí của đơn = tổng phí từng gói**.

> **Phí xử lý thanh toán của Stripe do partner chịu.** Khách trả tiền vào tài khoản Stripe của partner; Stripe trừ phí xử lý trên tài khoản đó. Application Fee của Eskimo tính trên **giá gói**, không bị trừ phí Stripe.

> **Số tiền được làm tròn xuống tới cent:** 3.90 × 74% = 2.886 → **US$2.88**; 8.90 × 75% = 6.675 → **US$6.67**.

| Giá gói | Application Fee | Eskimo nhận | Partner nhận (trước phí Stripe) |
|---|---|---|---|
| USD 100 | 90% | USD 90 | USD 10 |
| USD 100 | 10% (mặc định) | USD 10 | USD 90 |
| USD 3.90 | 20% | USD 0.78 | USD 3.12 |

---

## 6. Bước 4 — Config tên miền và email gửi

Partner gửi Eskimo **tên miền con** cho website và, nếu Email Notification = ON, **thông tin email gửi**. Admin nhập vào Config, rồi gửi partner các **bản ghi DNS** để partner thêm vào tên miền của họ.

Trên dòng website ở **Website Templates**, bấm **Config** (*"Custom domain and website settings"*). Cửa sổ **"Config — &lt;tên website&gt;"** có 2 phần.

### 6.1 Custom domain

1. Nhập tên miền con partner gửi, ví dụ `esim.yourdomain.com` (không dùng tên miền gốc như `yourdomain.com`).
2. Bấm **Validate**. Kết quả: *Available*, *Already in use*, *Saved for this website*, *DNS pointed correctly* hoặc *DNS not pointed yet*.
3. Bấm **Save** (chỉ bật sau khi Validate hợp lệ đúng giá trị đang nhập) → *"Custom domain saved: &lt;host&gt;"*.
4. Gửi partner 2 bản ghi **CNAME** trong bảng **"DNS records to give the partner"** (có nút copy), nhắc partner để chế độ **DNS only, not proxied**:

| Bản ghi | Dùng cho |
|---|---|
| CNAME **&lt;tên miền&gt;** → storefront Eskimo | Trỏ website về hệ thống, để truy cập được bằng tên miền của partner |
| CNAME **_acme-challenge.&lt;tên miền&gt;** | Cấp và tự gia hạn chứng chỉ HTTPS. ⚠️ **Không bao giờ được xoá**: xoá thì tới kỳ gia hạn (vài tháng sau) website không truy cập được |

5. Khi partner báo đã thêm, gõ lại tên miền và **Validate** tới khi thấy *DNS pointed correctly*.

> Partner cần hỗ trợ thêm bản ghi DNS → chuyển cho **business team của Eskimo** hỗ trợ.

> Tên miền đã lưu trước đó **không tự hiện lại** trong ô. Muốn xem trạng thái, gõ lại tên miền và bấm **Validate**.

### 6.2 Email sender

> Chỉ làm khi **Eskimo Email Notification = ON**. Bắt buộc partner có **tên miền email** riêng; không có thì không cấu hình và Eskimo không gửi email.

1. Điền đủ 3 ô: **Sender name** (ví dụ *Klook eSIM*), **From address** (ví dụ *noreply@klook.com*), **Reply-to** (ví dụ *support@klook.com*) → **Save** → *"Email sender saved"*.
2. Phần **Domain authentication**: **lưu From address trước**, rồi bấm **Create / get records**. Gửi các bản ghi DNS (Type / Host / Value) cho partner, nhắc partner để chế độ **DNS only, not proxied**.
3. Khi partner báo đã thêm, bấm **Check again** tới khi trạng thái **Verified**. Trạng thái khác: *Pending DNS*, *Not set up*.
4. **Sender name** và **Reply-to** có hiệu lực ngay. **From address** trên tên miền mới chỉ có hiệu lực sau khi tên miền đó xác thực xong (*"… is waiting on DNS"*).

---

## 7. Bước 5 — Go-live

### 7.1 Bật website

- Website mới luôn **Inactive**. Khi cấu trúc và nội dung đã sẵn sàng, gạt cột **Status** sang **Active**. Thay đổi lưu ngay, không cần Save.
- ⚠️ **Chỉ bật Active khi Stripe Connect Status = Verified.** Partner chưa kết nối Stripe xong thì giữ website **Inactive**, kể cả khi tên miền và DNS đã cấu hình xong.

> **Hai công tắc khác nhau, cần bật cả hai:**
> - **Corporate Program Status** (Partnership › Partners): chương trình hợp tác.
> - **Website Status** (White Label › Website Templates): website.

### 7.2 Kiểm tra trước khi mở bán

1. Stripe Connect Status = **Verified**, Application Fee đúng khi mở lại partner.
2. Custom domain *DNS pointed correctly*; Domain authentication **Verified** (nếu Email Notification = ON).
3. Mở website trên máy tính và điện thoại, kiểm tra đủ 5 trang và các liên kết.
4. Thực hiện 1 đơn thử: thanh toán thành công → trang xác nhận có **Order number** `PUR-PN…` → email QR eSIM và Magic Link (nếu Email Notification = ON) → My Data hiển thị gói.
5. **Admin › Transactions › Eskimo Sale** có giao dịch mã **WHI-…** với giá trị = **giá đơn × Application Fee %** (ví dụ phí 10%, đơn US$3.90 → **0.39**).

> Hai mã khác nhau là đúng thiết kế: **PUR-PN…** là đơn của partner (khách thấy), **WHI-…** là phần phí Eskimo nhận (chỉ Admin thấy).

---

## 8. Vận hành

### 8.1 Khi nào website ngừng bán

| Trường hợp | Nguyên nhân |
|---|---|
| Corporate Program **Status = OFF** | Admin tắt chương trình |
| Website **Status = Inactive** | Admin tắt website, hoặc chưa bật vì Stripe của partner chưa **Verified** |
| **Chưa tới Start Date** / **đã qua End Date** | Ngoài thời hạn chương trình |

Khi đó website hiển thị **"This store isn't available — Please check back later."**; khách **không xem gói, không mua được**. Hiệu lực sau **vài phút**.

![Website khi chương trình không hoạt động](images/corporate-program/07-store-unavailable.png)

### 8.2 Thao tác

| Mục đích | Cách làm | Kết quả / ghi chú |
|---|---|---|
| **Ngưng chương trình** (tạm ngưng hoặc ngưng ngay) | Edit partner → **Status OFF** → hộp **Warning** → **Confirm** → **Ok** | Website ngừng bán sau vài phút. Đây là cách duy nhất để ngưng **ngay**: End Date không cho chọn ngày quá khứ |
| **Bật lại chương trình** | Edit partner → **Status ON** → **Ok** | **Không cần nhập lại gì**: mọi cấu hình giữ nguyên |
| **Gia hạn** | Edit partner → đổi **End Date** sang ngày tương lai → **Ok** | Cấu hình khác giữ nguyên |
| **Chỉ tắt website** (chương trình vẫn bật) | Website Templates → **Status Inactive** | Website ngừng bán; bật lại bằng **Status Active** |
| **Xoá website** | **Delete** → xác nhận → **"DELETE SUCCESS"** | ⚠️ **Không hoàn tác.** Partner mất website **và toàn bộ nội dung đã chỉnh**; Partner Portal báo *"No website has been assigned to you yet. Please contact your account manager."* |
| **Hoàn tiền (refund)** đơn White Label | — | **Chưa hỗ trợ**: tính năng đang được phát triển. Guide sẽ cập nhật khi có |

![Gạt Status sang OFF](images/corporate-program/06-status-off.png)

---

## 9. Xử lý sự cố

| Vấn đề | Nguyên nhân / cách xử lý |
|---|---|
| Không đổi được **Type** | Khoá sau lần lưu đầu. Chọn nhầm → liên hệ đội kỹ thuật Eskimo |
| Không sửa được **Start Date** | Khoá khi ngày bắt đầu đã qua; chỉ End Date sửa được |
| Lưu xong mà **phí không được ghi** | Partner chưa bắt đầu Connect Stripe. Nhờ partner kết nối rồi lưu lại phí |
| Stripe mãi **Not Connected** / **—** | Partner chưa vào **My Website → Connect Stripe**. Admin không làm thay được |
| Không thấy partner khi **Assign** / **"No available partner"** | Partner chưa bật Corporate Program, đã có website khác, hoặc từ khoá không khớp |
| Đóng Edit Structure bị mất thay đổi | Close không cảnh báo khi chưa lưu. Luôn **Save Page / Save All** trước |
| Tìm module hiển thị **sản phẩm** | **Data Plan Section (Global + Regions)** (Home), **Plan Detail Hero** (Plan Detail) |
| Tên miền đã lưu không hiện trong Config | Đúng hành vi. Gõ lại tên miền và **Validate** để xem trạng thái |
| Tắt chương trình mà khách vẫn thấy website | Chờ vài phút rồi tải lại |

---

## Phụ lục

### Phụ lục A — Cấu trúc mặc định template "Eskimo eCommerce (Default)"

| Trang | Số module | Module (theo thứ tự) |
|---|---|---|
| **Home** | 12 | Header → Banner → Data Plan Section (Global + Regions) → Transfer Data (Why Eskimo eSIM) → More Reasons Grid → Video Section → Comparison Table → Install Steps → Reviews → FAQ → Recommendations → Footer |
| **Plan Detail** | 4 | Header → Plan Detail Hero → Sticky Checkout Bar → Footer |
| **Checkout** | 2 | Header → Footer (form thanh toán do hệ thống cung cấp) |
| **Install eSIM** | 3 | Header → Install eSIM Guide (iOS / Android, manual) → Footer |
| **Data Balance** | 4 | Header → Data Balance Screen → Data & eSIM Information → Footer |

### Phụ lục B — Thư viện module (+ Add Section)

| Module | Dùng cho |
|---|---|
| Header | Logo, menu đầu trang |
| Banner | Ảnh bìa, tiêu đề, mô tả, nút kêu gọi |
| Feature Section | Các điểm nổi bật |
| Data Plan Section (Global + Regions) | Danh sách gói theo quốc gia / khu vực (sản phẩm) |
| Transfer Data (Why Eskimo eSIM) | Lý do chọn dịch vụ |
| More Reasons Grid | Lưới ưu điểm |
| Video Section | Video giới thiệu |
| Comparison Table | Bảng so sánh |
| Install Steps | Các bước cài eSIM (tóm tắt) |
| Reviews | Đánh giá khách hàng |
| FAQ | Câu hỏi thường gặp |
| Recommendations | Gợi ý gói / điểm đến |
| Footer | Liên kết, mạng xã hội, bản quyền |
| Plan Detail Hero | Đầu trang chi tiết gói |
| Sticky Checkout Bar | Thanh thanh toán cố định |
| Data & eSIM Information | Thông tin data và eSIM |
| Data Balance Screen | Màn hình data còn lại |
| Install eSIM Guide (iOS / Android, manual) | Hướng dẫn cài chi tiết theo thiết bị |
