# Hướng dẫn tổng hợp White Label (Eskimo)

| | |
|---|---|
| **Phạm vi** | Toàn bộ vòng đời một partner White Label: bật chương trình → tạo website → partner dựng thương hiệu & kết nối Stripe → go-live → khách mua và dùng eSIM → vận hành |
| **Đối tượng đọc** | Admin Eskimo (Admin Portal), Partner (Partner Portal), QC / Support |
| **Cập nhật** | 19/10/2026 |

> **Cách đọc nhanh**
> - Admin: đọc **Phần 1 → 4**, rồi **Phần 7 (Go-live)** và **Phần 9 (Vận hành)**.
> - Partner: đọc **Phần 1**, **Phần 5 (Stripe)**, **Phần 6 (Partner CMS)**.
> - Support / QC: **Phần 8 (Customer Journey)**, **Phần 10 (Đối soát)**, **Phần 11 (Xử lý sự cố)**.

---

## Mục lục

1. [Tổng quan White Label](#1-tổng-quan-white-label)
2. [Điều kiện trước khi bắt đầu](#2-điều-kiện-trước-khi-bắt-đầu)
3. [Bước A — Bật Corporate Program (Admin)](#3-bước-a--bật-corporate-program-admin)
4. [Bước B — Tạo website và chỉnh cấu trúc (Admin)](#4-bước-b--tạo-website-và-chỉnh-cấu-trúc-admin)
5. [Bước C — Kết nối Stripe và đặt Application Fee (Partner + Admin)](#5-bước-c--kết-nối-stripe-và-đặt-application-fee-partner--admin)
6. [Bước D — Chỉnh nội dung và thương hiệu (Partner CMS)](#6-bước-d--chỉnh-nội-dung-và-thương-hiệu-partner-cms)
7. [Bước E — Config tên miền, email gửi và Go-live](#7-bước-e--config-tên-miền-email-gửi-và-go-live)
8. [Customer Journey — khách mua và dùng eSIM](#8-customer-journey--khách-mua-và-dùng-esim)
9. [Vận hành: tạm ngưng, bật lại, gia hạn, xoá](#9-vận-hành-tạm-ngưng-bật-lại-gia-hạn-xoá)
10. [Tiền và đối soát](#10-tiền-và-đối-soát)
11. [Xử lý sự cố (FAQ tổng hợp)](#11-xử-lý-sự-cố-faq-tổng-hợp)
12. [Checklist go-live end-to-end](#12-checklist-go-live-end-to-end)
- [Phụ lục](#phụ-lục)

---

## 1. Tổng quan White Label

### 1.1 White Label là gì

White Label cho phép một **partner** bán eSIM của Eskimo **dưới thương hiệu riêng** (tên, logo, màu, tên miền, email) trên một website riêng. Eskimo cung cấp sản phẩm (gói data, eSIM), nền tảng website và hạ tầng thanh toán; tiền khách trả đi thẳng vào **tài khoản Stripe của partner**, Eskimo nhận **Application Fee** trên mỗi đơn.

### 1.2 Các vai trò

| Vai trò | Làm ở đâu | Trách nhiệm |
|---|---|---|
| **Admin Eskimo** | Admin Portal | Bật Corporate Program (thời hạn, phí, phương thức thanh toán, email); tạo website, gán partner, quyết định **cấu trúc** (trang, module, thứ tự); config tên miền & email gửi; bật/tắt website |
| **Partner** | Partner Portal → **My Website** | Kết nối **Stripe**; chỉnh **nội dung và thương hiệu** bên trong từng module. **Không** thêm/xoá/sắp xếp module được |
| **Khách hàng (end user)** | Website White Label | Chọn gói, thanh toán, nhận eSIM, xem "My Data", mua thêm |
| **Hệ thống** | — | Hiển thị **dữ liệu thật** (gói, giá, quốc gia, ví My Data); tạo tài khoản + eSIM sau khi thanh toán thành công; ghi nhận phí cho Eskimo |

> **Nguyên tắc vàng:** *Admin quyết định khung, Partner quyết định nội dung, hệ thống quyết định giá và dữ liệu gói.* Partner không sửa được giá; giá và danh sách gói luôn lấy từ hệ thống.

### 1.3 Khái niệm

| Khái niệm | Ý nghĩa |
|---|---|
| **Partner / Partner ID** | Đối tác White Label, mã dạng `PNxxxxxx` |
| **Corporate Program** | Chương trình gắn với partner, có 3 loại (**Type**): *Corporate*, *White label*, *Reseller*. Tài liệu này chỉ nói về **White label** |
| **Thời hạn chương trình** | Khoảng **Start Date → End Date**. Ngoài khoảng này chương trình tự ngưng |
| **Application Fee** | % trên **giá gói data** Eskimo nhận cho mỗi đơn. Phần còn lại là **Partner Benefit** |
| **Stripe Connect / Direct Charge** | Tài khoản Stripe riêng của partner, kết nối với Eskimo. Khách trả tiền trực tiếp vào tài khoản này; Eskimo nhận Application Fee |
| **Eskimo Email Notification** | Quy định **ai** gửi email cho khách: Eskimo (ON) hay partner tự gửi (OFF) |
| **Template** | Khung website dùng lại được. Mặc định: **"Eskimo eCommerce (Default)"** (System Default) |
| **Website (Partner Website)** | Bản sao độc lập của template, **mỗi partner một website** |
| **Page** | 5 trang: Home, Plan Detail, Checkout, Install eSIM, Data Balance |
| **Module / Section** | Một khối nội dung trong trang (Header, Banner, FAQ, Footer…) |
| **Brand identity** | Brand name, Logo, Primary color, Secondary color |
| **`{brand}` / `{country}`** | Từ khoá tự thay bằng tên thương hiệu / tên quốc gia. `{brand}` dùng được ở mọi module; `{country}` chỉ dùng trong tiêu đề của Plan Detail Hero |
| **My Data** | Ví dữ liệu của khách: gói, dung lượng còn lại, lịch sử |
| **Magic Link** | Liên kết trong email mở thẳng My Data, không cần OTP |

### 1.4 Quy trình end-to-end

```
 ADMIN                              PARTNER                          KHÁCH HÀNG
 ─────                              ───────                          ──────────
 A. Bật Corporate Program
    (Type = White label, thời hạn,
     email, account limit,
     Direct Charge, 2 Years)
        │
        ▼
 B. Clone website → Assign Partner
    → Edit Structure → Save
        │                           C1. Connect Stripe (My Website)
        │                               → Verified
        ▼                                   │
 C2. Đặt Application Fee  ◄─────────────────┘ (chỉ lưu được khi partner
        │                                      đã BẮT ĐẦU kết nối Stripe)
        │                           D. Partner CMS: thương hiệu,
        │                              Header/Footer, nội dung 5 trang
        ▼                              → Save All
 E. Config tên miền + email gửi
    → Website Status = Active
        │
        └──────────────────────────────────────────────►  Browse → Checkout → Pay
                                                          → Email QR + Magic Link
                                                          → My Data → Top-up
```

### 1.5 Chuỗi điều kiện phụ thuộc (đọc kỹ)

Các bước liên kết với nhau; thiếu một mắt xích thì bước sau không làm được hoặc khách không mua được:

| Muốn làm được… | Cần có trước… |
|---|---|
| Gán đúng partner trong **Assign Partner** | Partner có Corporate Program **ON**, **Type = White label**, và **chưa có website nào** |
| **Application Fee** được lưu | Partner **đã bắt đầu** Connect Stripe (Stripe Connect Status ≠ *Not Connected* / *—*) |
| Khách **thanh toán** được (Direct Charge) | Stripe Connect Status = **Verified** |
| Website **hiển thị và bán hàng** | Corporate Program **đang hoạt động** (Status ON và hôm nay nằm trong Start → End Date) **và** website **Status = Active** |
| Khách **nhận email QR + Magic Link từ Eskimo** | **Eskimo Email Notification = ON** (OFF → partner phải tự gửi) |
| Partner **chỉnh nội dung** trên My Website | Website đã được tạo và **gán** cho partner |

---

## 2. Điều kiện trước khi bắt đầu

**Admin**
1. Tài khoản Admin có quyền vào **Partnership › Partners** và menu **White Label**.
2. Thông tin partner: tên, **email đăng nhập Partner Portal**, Referral Code, người phụ trách (Assigned To), Source Of Lead.
3. Đã thống nhất với partner: **thời hạn** hợp tác, **Application Fee (%)**, **ai gửi email** cho khách, **số tài khoản tối đa**, tên miền và email gửi.

**Partner**
1. Truy cập email đã khai báo (để nhận OTP đăng nhập Partner Portal).
2. Thông tin doanh nghiệp và tài khoản ngân hàng để khai báo với **Stripe**.
3. Tài liệu thương hiệu:
    - **Logo**: PNG/JPEG, **dưới 1 MB**.
    - **Mã màu** chính và phụ (hex, ví dụ `#1957F5`).
    - **Hình ảnh** (banner, ô nổi bật, hướng dẫn cài): PNG/JPEG, **dưới 5 MB** mỗi file.
    - **Nội dung**: tiêu đề, giới thiệu, FAQ, email hỗ trợ, liên kết mạng xã hội.

---

## 3. Bước A — Bật Corporate Program (Admin)

**Màn hình:** **Partnership › Partners** → Edit partner (hoặc **New Partner**) → mục **Corporate Program** (cột phải).

### 3.1 Tạo partner mới (bỏ qua nếu đã có)

1. **Partnership › Partners** → **New Partner**. **Partner ID** được cấp sẵn (ví dụ `PN539084`).
2. Điền **Partner Configuration**:

| Trường | Bắt buộc | Ghi chú |
|---|---|---|
| **Referral Code** | Có | Chỉ chữ và số, không khoảng trắng. **Không sửa được sau khi tạo** |
| **Status** | — | Mặc định *Pending*. Chọn **Active** để partner dùng được. Khi khác *Pending*, các trường có * thành bắt buộc |
| **Partner Name** | Có | Tối đa 50 ký tự |
| **Partner Email** | Có | Email partner dùng đăng nhập **Partner Portal** |
| **Assigned To** | Có | Người phụ trách (chọn nhiều được) |
| **Source Of Lead** | Có | Nguồn khách |

3. Có thể cấu hình **Corporate Program** (mục 3.2) ngay trong cửa sổ này.
4. Bấm **Ok** → cảnh báo *"Once created, partner's referral code can not be changed. Are you sure want to continue?"* → **Confirm** → **CREATE SUCCESS**.

> ⚠️ **Application Fee nhập trong cửa sổ New Partner không được lưu.** Hệ thống chỉ lưu phí khi **Edit** partner đã có. Tạo partner trước, đặt phí ở Bước C2.

![Tạo partner mới, Corporate Program Type = White label](images/corporate-program/01-new-partner-white-label.png)

### 3.2 Cấu hình Corporate Program

![Corporate Program của một partner White Label đã cấu hình xong](images/corporate-program/02-corporate-program-verified.png)

| # | Trường | Thao tác / quy tắc |
|---|---|---|
| 1 | **Status** | Gạt **ON**. Các trường bên dưới hiện ra |
| 2 | **Type** | Chọn **White label**. ⚠️ **Khoá sau khi lưu** (*"Type can not be edited after corporate program confirmed"*) |
| 3 | **Start Date** | Bắt buộc, `DD/MM/YYYY`. **Khoá** khi ngày bắt đầu đã qua (trong ngày bắt đầu vẫn sửa được) |
| 4 | **End Date** | Bắt buộc, **sau Start Date**; không chọn được hôm nay và ngày quá khứ (sớm nhất là ngày mai). Gia hạn được bất cứ lúc nào |
| 5 | **Eskimo Email Notification** | ON / OFF, **mặc định OFF**. Xem 3.3 |
| 6 | **Lifetime Account Limit** | Hiển thị `<đã dùng> / <tối đa>`, ví dụ `0 / 100`. Nhập số nguyên dương **< 100000** (tối đa 99999), bắt buộc |
| 7 | **Payment method** | **Direct Charge** (phase 1 chỉ có lựa chọn này; *Eskimo Stripe Pay* ẩn) |
| 8 | **Data Expiry** | **2 Years** cố định (data hết hạn 2 năm kể từ ngày mua). *No Expiry* hiện xám, không chọn được |
| 9 | **Application Fee Percentage** | **Để trống ở bước này** — đặt ở Bước C2 sau khi partner bắt đầu kết nối Stripe |
| 10 | **Stripe Connect Status** | Chỉ xem. Partner tự kết nối (Bước C1) |

Bấm **Ok** → **UPDATE SUCCESS** / **CREATE SUCCESS**. Mở lại partner để kiểm tra.

Khi chọn **White label**, form khác loại *Corporate*:
- Hiện thêm **Eskimo Email Notification**, **Stripe Connect Status**, **Payment method**, **Data Expiry**.
- *Discount Benefit* đổi thành **Application Fee Percentage**.
- **Network Partner Commission (%) không hiển thị** (không áp dụng cho White Label).

![Payment method = Direct Charge](images/corporate-program/05-payment-method-direct-charge.png)
![Data Expiry: 2 Years cố định, No Expiry màu xám](images/corporate-program/08-data-expiry.png)

### 3.3 Eskimo Email Notification — quyết định quan trọng

| Giá trị | Ai gửi email cho khách | Hệ quả với khách |
|---|---|---|
| **ON** | **Eskimo** | Khách nhận email xác nhận mua hàng, **email QR eSIM** (kèm mã LPA) và **Magic Link** vào My Data. Email mang thương hiệu partner (tên người gửi, logo) |
| **OFF** | **Partner tự gửi** | Eskimo **không gửi bất kỳ email nào** cho khách của chương trình. Partner **bắt buộc** phải có quy trình riêng gửi QR eSIM và xác nhận đơn, nếu không khách mua xong sẽ không nhận được gì |

> Phần 8 (Customer Journey) mô tả hành trình với **Email Notification = ON**.

---

## 4. Bước B — Tạo website và chỉnh cấu trúc (Admin)

**Màn hình:** menu **White Label** → **Website Templates**.

### 4.1 Màn hình Website Templates

![Màn hình Website Templates](images/website-structure/01-website-templates-after-clone.png)

| Cột | Nội dung |
|---|---|
| **Name** | Tên template / website |
| **Type** | `System Default` (template) hoặc `Partner Website` |
| **Partner** | Partner sở hữu, "—" nếu chưa gán hoặc là template |
| **Pages** | Số trang |
| **Status** | Công tắc **Active / Inactive** (chỉ website) |
| **Created Date** | Ngày tạo |
| **Actions** | Template: **Edit Structure**, **Clone**. Website: **Edit Structure**, **Config**, **Assign Partner** / **Reassign Partner**, **Delete** |

### 4.2 Clone website từ template

1. Trên dòng **Eskimo eCommerce (Default)** bấm **Clone** → thông báo **"Website draft created"**.
2. Dòng mới: Name **Untitled Website Draft**, Type **Partner Website**, Partner **—**, Status **Inactive**, Pages **5**.
3. Website mới sao chép **toàn bộ cấu trúc template tại thời điểm Clone** (Phụ lục A). Mỗi lần Clone tạo **một** website.

### 4.3 Gán partner

1. Trên dòng website mới bấm **Assign Partner**.
2. Gõ tên partner vào ô **Partner** (*"Search a partner by name"*), chọn đúng partner → **Assign**. Bỏ trống thì báo *"Please select a partner"*.
3. Kết quả: thông báo **"Untitled Website Draft" assigned**; cột Partner hiện tên; website tự đổi tên thành **"Website Template for partner &lt;tên partner&gt;"**.

![Website sau khi gán partner](images/website-structure/02-assigned-partner.png)

> ⚠️ Danh sách hiện **mọi partner đang bật Corporate Program và chưa có website**, gồm cả partner loại *Corporate*. Hãy chọn đúng partner có **Type = White label** (kiểm tra ở Partnership › Partners nếu chưa chắc). Thấy **"No available partner"** → kiểm tra lại Bước A hoặc website cũ của partner.
>
> **Reassign Partner**: với website đã gán, chọn partner khác (cũng phải hợp lệ) → **Assign**.

### 4.4 Edit Structure

Bấm **Edit Structure** → cửa sổ **"Edit Structure — &lt;tên website&gt;"** gồm:
- **Thanh chọn trang**: `Home (13)`, `Plan Detail (4)`, `Checkout (2)`, `Install eSIM (3)`, `Data Balance (4)` (số trong ngoặc = số module).
- **Canvas** xem trước các module từ trên xuống.
- **Chân cửa sổ**: **Close** và **Save Page**.

Mỗi module có thanh tiêu đề: biểu tượng **≡** để kéo đổi vị trí (Header không có), tên module, nút **thùng rác đỏ**.

| Thao tác | Cách làm |
|---|---|
| **Thêm module** | Chọn trang → cuộn cuối canvas → **+ Add Section** → chọn module (Phụ lục B). Module được **thêm vào cuối trang** → kéo lên đúng vị trí (thường là **trên Footer**) |
| **Xoá module** | Bấm thùng rác → *"Remove this module?"* → **Remove** |
| **Sắp xếp (chuột)** | Giữ **≡**, kéo lên/xuống, thả |
| **Sắp xếp (bàn phím)** | Tab tới **≡** → **Space** nhấc → **↑ / ↓** → **Space** thả |
| **Chuyển module sang trang khác** | Không kéo được giữa các trang: xoá ở trang cũ → **+ Add Section** ở trang mới |
| **Lưu** | **Save Page** (1 trang thay đổi) hoặc **Save All (N pages)**. Nút mờ khi chưa có thay đổi. Thành công: **Saved: "Home"** |

![Module vừa thêm ở cuối trang](images/website-structure/03-editor-add-section.png)

> ⚠️ **Header luôn ở đầu trang** và không kéo được. **Footer kéo được**: sau khi thêm hoặc sắp xếp module, kiểm tra Footer vẫn ở **cuối** trang trước khi lưu.
>
> ⚠️ Bấm **Save Page / Save All trước khi Close.** Nút Close **không cảnh báo** khi còn thay đổi chưa lưu; đóng là mất.
>
> ⚠️ Thấy module tên **`downloadApp`** (hoặc `productSection`) kèm cảnh báo *"This section type is no longer used and doesn't show on the storefront. Remove it."*: đây là module đã ngừng dùng, website không hiển thị. **Xoá** module đó rồi lưu.
>
> 💡 **Phối hợp với partner:** sau khi partner đã nhập nội dung, việc **xoá** một module sẽ làm khối nội dung đó không còn trên website. Nên thống nhất với partner trước khi xoá module.

### 4.5 Quy tắc độc lập template ↔ website

| Tình huống | Kết quả |
|---|---|
| Sửa cấu trúc website của partner A | **Không** ảnh hưởng template hay website partner khác |
| Sửa template System Default | **Không** ảnh hưởng website đã tạo; chỉ website **Clone sau** nhận cấu trúc mới |
| Clone website mới | Nhận nguyên cấu trúc template tại thời điểm Clone, sau đó tách biệt hoàn toàn |

---

## 5. Bước C — Kết nối Stripe và đặt Application Fee (Partner + Admin)

### 5.1 C1 — Partner kết nối Stripe

Admin **không thể** kết nối thay partner. Dòng **Stripe Connect Status** trên Admin luôn ghi *"The partner connects Stripe from the Partner portal (My Website)."*

**Partner thực hiện:**
1. Đăng nhập **Partner Portal** bằng Partner Email (+ mã OTP gửi về email).
2. Vào **My Website** → khu vực **Stripe payments** → bấm **Connect Stripe**.
3. Hoàn tất khai báo doanh nghiệp, tài khoản nhận tiền và xác minh trên trang **Stripe**.
4. Làm dở thì quay lại **My Website** → **Continue setup**.

> Nút **Connect Stripe / Continue setup / Reconnect Stripe** chỉ hiện với tài khoản partner vai trò **Owner** hoặc **Admin User**. Vai trò khác chỉ thấy trạng thái.

**Trạng thái (Admin và Partner đều xem được):**

| Hiển thị | Ý nghĩa | Cần làm |
|---|---|---|
| **Not Connected** / **—** | Chưa kết nối (**—** = chưa từng bắt đầu) | Partner bấm **Connect Stripe** |
| **Setup incomplete** | Đã bắt đầu, chưa khai báo xong | Partner bấm **Continue setup** |
| **Pending verification** | Stripe đang xác minh | Chờ; nếu Stripe yêu cầu thêm → **Continue setup** |
| **Verified** | Sẵn sàng nhận thanh toán | Hoàn tất |
| **Disconnected** | Tài khoản bị ngắt khỏi Eskimo | Partner **Reconnect Stripe** |

![Stripe Connect Status = Pending verification](images/corporate-program/03-stripe-pending-verification.png)

> Trạng thái có thể mất **vài phút** để cập nhật sau khi Stripe xác minh. Mở lại partner để xem mới nhất.

### 5.2 C2 — Admin đặt Application Fee Percentage

> **Vì sao làm sau Stripe?** Hệ thống chỉ lưu phí khi partner **đã bắt đầu** kết nối Stripe. Đặt trước thì partner vẫn lưu nhưng phí thì không, kèm thông báo *"Partner saved, but the Application Fee was not: Stripe onboarding has not been started for this partner"*.

1. Edit partner → **Corporate Program** → **Application Fee Percentage**.
2. **Apply To** = *Any Data Plan* (cố định); **Fee** = *Percentage (%)*.
3. Nhập % (placeholder *"10 (default)"*) → **Ok**.

| Nhập | Kết quả |
|---|---|
| `0` ≤ phí < `100`, tối đa 2 chữ số thập phân (`20`, `12.5`, `99.99`) | Hợp lệ |
| `100` trở lên | *"Fee must be at least 0 and less than 100"* |
| Quá 2 chữ số thập phân (`12.345`), chữ, số âm | *"Value should contain just number"* |
| **Để trống** | Dùng **mặc định 10%** (*"Leave empty to use the default fee (10%)."*) |

> ⚠️ **Partner mới có thể được điền sẵn `0`.** Giữ `0` nghĩa là Eskimo **không thu phí**. Xoá trống (mặc định 10%) hoặc nhập đúng mức đã thoả thuận.

**Cảnh báo "final bill < 1"** (ví dụ *"Africa 1GB final bill < 1"*): hệ thống tính **giá gói × (100% − phí)** — tức phần partner nhận — và cảnh báo các gói có phần này **dưới 1 USD**. Cảnh báo **không chặn lưu**, và **khách vẫn trả đủ giá gói**.

![Nhập Application Fee 90% và cảnh báo final bill < 1](images/corporate-program/04-application-fee-warning.png)

Cách tính chi tiết: xem **Phần 10**.

---

## 6. Bước D — Chỉnh nội dung và thương hiệu (Partner CMS)

**Người làm:** Partner. **Màn hình:** Partner Portal → **My Website** → **Edit Website Content**.

![Màn hình Partner CMS](images/partner-cms/01-cms-workspace.png)

### 6.1 Bố cục màn hình

| Vùng | Chức năng |
|---|---|
| **Thanh chọn trang** | Chuyển giữa 5 trang (số trong ngoặc = số module) |
| **Brand identity** | Tên, logo, màu thương hiệu |
| **Stripe payments** | Trạng thái và nút kết nối Stripe (Phần 5.1). Nút kết nối chỉ hiện với tài khoản vai trò **Owner / Admin User**; vai trò khác chỉ xem trạng thái |
| **Khung xem trước** | Trang đang chọn, gần giống website thật |
| **Nút bút chì** | Trên mỗi module, mở cửa sổ **Configure &lt;tên module&gt;** |
| **Save Page / Save All (N pages)** | Lưu thay đổi lên website |

### 6.2 Cách chỉnh một module — hai nút Save khác nhau

1. Chọn trang → bấm **bút chì** trên module.
2. Sửa nội dung → bấm **Save** trong cửa sổ → **chỉ cập nhật khung xem trước**.
3. Làm tiếp các module/trang khác.
4. Bấm **Save Page / Save All** ở góc phải dưới → **lưu lên website**, thông báo `Saved: "<tên trang>"`.

> ⚠️ **Save** trong cửa sổ module ≠ **Save Page**. Chỉ **Save Page / Save All** mới ghi lên website. Luôn bấm trước khi rời màn hình.

**Các loại ô nhập**

| Loại ô | Cách dùng |
|---|---|
| Chữ một dòng / nhiều dòng | Ô ghi *"one per line"*: mỗi dòng thành một gạch đầu dòng |
| Liên kết (URL) | Nội bộ (`/esim`) hoặc đầy đủ (`https://...`), `mailto:`, `tel:`. Đường dẫn nội bộ không có trên website → cảnh báo màu cam dưới ô và liên kết **không hiển thị**. **Không** thêm tiền tố ngôn ngữ (dùng `/esim`, không dùng `/en/esim`) |
| Hình ảnh | **Upload** từ máy hoặc dán URL `https://` |
| Biểu tượng | Chọn trong thư viện (wifi, globe, shield…), có ô tìm |
| Danh sách | **+ Add** / **Remove** |
| Ô ✓ / ! / ✕ | Bảng so sánh: `✓ Yes`, `! Partly`, `✕ No` |
| **Show my text exactly as entered** | Tick để website hiển thị nguyên văn chữ đã nhập |

### 6.3 Thương hiệu (Brand identity)

![Brand identity](images/partner-cms/02-brand-identity.png)

| Ô | Hiển thị trên website |
|---|---|
| **Brand name** | Tiêu đề tab trình duyệt, dòng bản quyền, mọi chỗ có `{brand}` |
| **Logo URL** + **Upload** | Header và Footer mọi trang (PNG/JPEG < 1 MB). **Dùng nút Upload**: link ảnh dán từ nơi khác sẽ bị website bỏ qua. Không có logo thì hiển thị Brand name dạng chữ |
| **Primary** | Nút bấm, tiêu đề nhấn, liên kết, form thanh toán |
| **Secondary** | Thẻ khu vực trong Data Plan Section và các thẻ Install Steps |

Mã màu phải đúng dạng `#RRGGBB`; sai định dạng thì website dùng màu mặc định.

Nhập xong bấm **Save Page** → thông báo `Branding saved`.

### 6.4 Header và Footer

Mỗi trang có Header và Footer **riêng**. Cấu hình **giống nhau trên cả 5 trang** để website đồng nhất, rồi **Save All**.

![Configure Header](images/partner-cms/06-configure-header.png)

- **Header — Navigation links**: *Label* + *URL*, ví dụ `Travel eSIM` → `/esim`, `Install eSIM` → `/install-esim`. Logo lấy từ Brand identity; nút **My Data** tự hiện ở góc phải, trừ khi menu đã có liên kết tới `/data-balance`.

![Configure Footer](images/partner-cms/07-configure-footer.png)

| Ô Footer | Mô tả |
|---|---|
| **Support email** | Hiển thị ở dòng *Need help?* (để trống thì dòng này ẩn) |
| **Column 1/2/3 title + links** | 3 cột chân trang. Liên kết có URL trống hoặc trỏ tới trang không có trên website sẽ bị bỏ; cột không còn liên kết nào bị ẩn, kể cả khi có tiêu đề |
| **Social links** | Biểu tượng (facebook, instagram, youtube-play, tiktok…) + đường dẫn. Dòng có URL trống **vẫn hiện biểu tượng**: xoá dòng nếu không dùng |
| **Locale/currency label** | Ví dụ `EN • USD — $` |
| **Copyright text** | Ví dụ `© 2026 {brand}` |

### 6.5 Nội dung từng trang

| Trang | Module | Nội dung partner chỉnh được |
|---|---|---|
| **Home** | Banner | Ảnh nền, Title/Subtitle, Search label/placeholder (trống → *"Search N+ countries"* theo số thật), CTA text/link (trống text → không có nút), Rating value/note |
| | Data Plan Section | Tiêu đề, dòng nhấn, mô tả. Khu vực và số quốc gia **tự động** |
| | Transfer Data | Nhãn, tiêu đề, mô tả, 1–4 tính năng (icon, tiêu đề, mô tả), 1–4 ô nổi bật (tiêu đề, mô tả, hình) |
| | More Reasons Grid | Tiêu đề, 3–9 lý do (icon, tiêu đề, mô tả) |
| | Video Section | URL video (YouTube hoặc `.mp4`), 2 dòng chữ trên video |
| | Comparison Table | Tiêu đề, mô tả, tên 4 cột, 1–12 dòng (✓ / ! / ✕) |
| | Install Steps | Tiêu đề, mô tả, 3–8 bước tóm tắt |
| | Reviews | Tiêu đề, 3–9 đánh giá (tên, ngày, nội dung) |
| | FAQ | Tiêu đề, mô tả, 1–9 câu hỏi/trả lời (**+ Add Question**) |
| | Recommendations | Tiêu đề, tên 3 tab, liên kết hướng dẫn tab 3. Tab 1 (quốc gia phổ biến), tab 2 (khu vực) **tự động** |
| **Plan Detail** (`/plans/japan-esim`) | Plan Detail Hero | Tiêu đề (dùng `{country}`: `{country} eSIM` → *Japan eSIM*), điểm đánh giá, 2 tab loại gói (tên, nhãn, tính năng), 3–4 thẻ tính năng |
| | Sticky Checkout Bar | Chữ trên nút. Tên gói và giá **tự động** |
| **Checkout** | — | Chỉ Header/Footer; form thanh toán do hệ thống cung cấp |
| **Install eSIM** | Install eSIM Guide | Heading/Subtext, tên tab iOS/Android, Step label (`Step` → *Step 1, 2…*), 1–8 bước mỗi OS (tiêu đề, gạch đầu dòng, tối đa 4 hình) |
| **Data Balance** | Data Balance Screen | Tên trang, tên tab *My Plans* / *History*, nội dung khi chưa có gói, chữ *How to install eSIM*, chữ nút *Buy more data*. Gói/dung lượng/lịch sử **tự động** |
| | Data & eSIM Information | Tiêu đề, quyền lợi gói Fixed (3–8) và Unlimited (3–8) |

![Configure Banner](images/partner-cms/04-configure-banner.png)
![Configure FAQ](images/partner-cms/05-configure-faq.png)
![Configure Plan Detail Hero](images/partner-cms/08-configure-plan-detail-hero.png)
![Configure Install eSIM Guide](images/partner-cms/09-configure-install-guide.png)
![Configure Data Balance Screen](images/partner-cms/10-configure-data-balance.png)

### 6.6 Dữ liệu luôn tự động (partner không sửa được)

Danh sách quốc gia / khu vực / số quốc gia; gói data, dung lượng, **giá**; quốc gia phổ biến và khu vực trong Recommendations; tên gói và giá trên thanh thanh toán; gói, dung lượng, lịch sử trong My Data.

### 6.7 Lưu và kiểm tra

1. **Save Page / Save All**, chờ `Saved: …`.
2. Mở website, tải lại. Nội dung mới thường hiện sau **khoảng 30 giây**; chưa thấy thì chờ thêm và tải lại sau 1 phút.

![Website sau khi cấu hình](images/partner-cms/13-storefront-home.png)

### 6.8 Phạm vi và bảo mật

- Mỗi partner chỉ xem và chỉnh **website của chính mình**; ảnh upload được lưu riêng cho website đó.
- Chỉnh sửa của partner không ảnh hưởng website partner khác hay template gốc.

---

## 7. Bước E — Config tên miền, email gửi và Go-live

### 7.1 Config (Admin)

Trên dòng website ở **Website Templates**, bấm **Config** để cấu hình:
**Custom domain** — tên miền riêng của partner
1. Nhập tên miền con, ví dụ `esim.yourdomain.com` (không dùng tên miền gốc như `yourdomain.com`).
2. Bấm **Validate**. Kết quả: *Available*, *Already in use*, *Saved for this website*, *DNS pointed correctly* hoặc *DNS not pointed yet*.
3. Bấm **Save** (chỉ bật sau khi Validate hợp lệ đúng giá trị đang nhập) → *"Custom domain saved: &lt;host&gt;"*.
4. Gửi partner bảng **"DNS records to give the partner"** (có nút copy) để họ trỏ DNS.

> Tên miền đã lưu trước đó **không tự hiện lại** trong ô. Muốn xem trạng thái, gõ lại tên miền và bấm **Validate**.

**Email sender** — thông tin người gửi email cho khách
1. Điền đủ 3 ô: **Sender name** (ví dụ *Klook eSIM*), **From address** (ví dụ *noreply@klook.com*), **Reply-to** (ví dụ *support@klook.com*) → **Save** → *"Email sender saved"*.
2. Phần **Domain authentication**: **lưu From address trước**, rồi bấm **Create / get records**, gửi các bản ghi DNS (Type / Host / Value) cho partner, rồi **Check again** tới khi trạng thái **Verified**. Trạng thái khác: *Pending DNS*, *Not set up*.
3. **Sender name** và **Reply-to** có hiệu lực ngay. **From address** trên tên miền mới chỉ có hiệu lực sau khi tên miền đó xác thực xong (*"… is waiting on DNS"*).

> Config **không có** trường thanh toán. Thanh toán do partner kết nối Stripe (Phần 5.1).

### 7.2 Bật website (Admin)

- Website mới luôn **Inactive**. Khi cấu trúc và nội dung đã sẵn sàng, gạt cột **Status** sang **Active** — lưu ngay, không cần Save.
- Gạt về **Inactive** để tạm ngưng website.

> **Hai công tắc khác nhau, cần bật cả hai:**
> - **Corporate Program Status** (Partnership › Partners) — chương trình hợp tác.
> - **Website Status** (White Label › Website Templates) — website.

### 7.3 Kiểm tra trước khi mở bán

Xem checklist **Phần 12**. Tối thiểu: Stripe **Verified**, Application Fee đúng, website **Active**, mở thử 5 trang trên máy tính và điện thoại, thực hiện 1 đơn thử.

---

## 8. Customer Journey — khách mua và dùng eSIM

> Ví dụ website: `https://wellatsea.eskimo.travel/en`. Chữ in `như thế này` là nội dung hiển thị nguyên văn. Hành trình dưới đây giả định **Eskimo Email Notification = ON**.

### 8.1 Năm giai đoạn

| # | Giai đoạn | Khách làm gì | Kết quả mong đợi |
|---|---|---|---|
| 1 | **Browse** | Mở website → chọn gói | Thấy đúng danh sách gói của thương hiệu |
| 2 | **Checkout** | Nhập First name + Email → thanh toán thẻ | Thanh toán thành công |
| 3 | **Nhận eSIM** | (tự động) | Email **QR code** + **Magic Link** |
| 4 | **My Data** | Magic Link hoặc Email + OTP | Xem gói, dung lượng, lịch sử |
| 5 | **Top-up** | Mua thêm | Gói mới cộng vào **cùng tài khoản/eSIM** |

**Nguyên tắc:**
- **Tài khoản tách theo partner.** Cùng email ở 2 website khác nhau = **2 tài khoản riêng**, không gộp gói/dung lượng/lịch sử.
- **Chỉ khách đã mua** mới đăng nhập My Data được; email chưa mua không nhận OTP.
- eSIM và gói chỉ được tạo **sau khi thanh toán thành công**.
- Website bán bằng **tiếng Anh**, giá **USD**, thanh toán **thẻ qua Stripe**; không có chọn ngôn ngữ, đổi tiền tệ hay mã giảm giá.

### 8.2 Mua chuẩn (happy path)

1. **Chọn gói**: chọn quốc gia/khu vực → gói (ví dụ **Japan 1 GB**) → **`Checkout`**. (Mở thẳng `/checkout` khi chưa chọn gói → `No plan selected`.)
2. **Nhập thông tin**: **First name** và **Email** — email này dùng để nhận eSIM và đăng nhập My Data, cần **đúng chính tả** → **`Continue to payment`**.
3. **Thanh toán**: khung thẻ Stripe (email chuyển sẵn) → số thẻ, ngày hết hạn, CVC → **`Pay US$ …`** → `Processing payment…`.
4. **Trang xác nhận**: **Order number** (`PUR-PN…-…`), gói, tổng tiền, email nhận eSIM, `Payment received — we're preparing your eSIM`.
5. **Email**: **QR code** cài eSIM (kèm mã LPA) và **Magic Link** vào My Data. Email mang **thương hiệu partner**.

> ⏱ Sau khi trả tiền hệ thống cần **~30–60 giây** để tạo tài khoản + eSIM. Mở My Data quá sớm có thể tạm chưa đăng nhập được — chờ rồi thử lại.

### 8.3 Truy cập My Data

- **Cách A — Magic Link**: mở link trong email → vào thẳng ví, **không cần OTP**, dùng lại nhiều lần.
- **Cách B — Email + OTP**: `/en/data-balance` (hoặc nút **`My Data`**) → nhập email đã mua → **`Send code`** → màn `Enter your code` → nhập **mã 4 chữ số** (hết hạn sau **5 phút**) → **`View my data`**. Đăng nhập bằng OTP được giữ **7 ngày** trên trình duyệt đó.

Trong ví: tab **My Plans** (quốc gia + dung lượng còn lại; gói không giới hạn hiện nhãn như `Unlimited 30 days`) và **History** (ngày, gói, trạng thái).

### 8.4 Mua thêm (Top-up)

Mua thêm bằng **cùng email trên cùng website** → gói mới cộng vào **cùng tài khoản/eSIM**, không tạo tài khoản hay eSIM trùng.

### 8.5 Thông báo lỗi — tra cứu nhanh

**Checkout**

| Tình huống | Thông báo | Nên làm |
|---|---|---|
| Để trống tên | `Enter your first name.` | Nhập First name |
| Email trống / sai định dạng | `Enter a valid email address.` | Nhập email đúng |
| Mở `/checkout` khi chưa chọn gói | `No plan selected` | Quay lại chọn gói |
| Bấm thanh toán quá nhiều lần | `Too many checkout attempts. Please wait a few minutes and try again.` | Chờ vài phút |

**Thanh toán**

| Tình huống | Thông báo | Ý nghĩa / nên làm |
|---|---|---|
| Thẻ bị từ chối | `Your card has been declined.` | **Chưa bị trừ tiền**. Thử thẻ khác |
| Không khởi tạo được | `We couldn't start your payment. Please try again in a moment.` | Thử lại sau giây lát |
| Thanh toán không qua | `Your payment didn't go through. Please try again.` + `You haven't been charged. You can try again with the same or a different card.` | Chưa bị trừ, thử lại |
| Ngân hàng đang xác nhận (3-D Secure / chậm) | `Your bank is still confirming the payment. We'll email your eSIM as soon as it goes through — no need to pay again.` | **Không trả lần nữa**, chờ email |
| Không xác nhận được kết quả | `We couldn't confirm your payment` + `Please check your email before trying again — if the payment went through, your eSIM is on its way.` | **Kiểm tra email trước** để tránh trả trùng |

> **Thẻ bị từ chối:** hệ thống tạo tài khoản trạng thái **Pending**, **không** eSIM, **không** gói. Khách thanh toán lại bằng thẻ hợp lệ **cùng email** → hệ thống dùng lại tài khoản đó và hoàn tất đơn (không tạo trùng).

**My Data (Email + OTP)**

| Tình huống | Thông báo | Nên làm |
|---|---|---|
| Email chưa từng mua **hoặc** xin mã quá sớm sau khi trả tiền | `We're unable to process your request yet. Please purchase a data plan with this email to get started.` | Kiểm tra email đã nhập lúc checkout; nếu vừa mua thì chờ ~30–60 giây rồi `Send code` lại |
| Sai mã / mã cũ / mã đã dùng | `Invalid OTP` hoặc `That code isn't valid any more. Request a new one.` | Dùng mã mới nhất hoặc xin mã mới |
| Sai nhiều lần liên tiếp | `Too many invalid attempts. Please request a new OTP and try again in a few minutes.` | Tạm khoá nhập mã; chờ vài phút, xin mã mới |
| Xin mã quá nhiều lần | `Too many codes requested. Please wait a few minutes and try again.` | Chờ vài phút |
| Không gửi được mã | `We couldn't send your code right now. Please try again.` | Thử lại |

**Magic Link**

| Tình huống | Hiển thị | Nên làm |
|---|---|---|
| Còn hiệu lực | Vào thẳng ví | — |
| Hỏng / hết hạn | `That link has expired. Enter the email you used at checkout and we'll send you a code.` | Đăng nhập bằng Email + OTP (8.3 Cách B) |

---

## 9. Vận hành: tạm ngưng, bật lại, gia hạn, xoá

### 9.1 Khi nào website White Label ngừng bán

| Trường hợp | Nguyên nhân |
|---|---|
| Corporate Program **Status = OFF** | Admin tắt chương trình |
| Website **Status = Inactive** | Admin tắt website (Website Templates) |
| **Chưa tới Start Date** / **đã qua End Date** | Ngoài thời hạn chương trình |

Khi đó website hiển thị **"This store isn't available — Please check back later."**; khách **không xem gói, không mua được**. Hiệu lực sau **vài phút**.

![Website khi chương trình không hoạt động](images/corporate-program/07-store-unavailable.png)

### 9.2 Thao tác

| Thao tác | Cách làm | Ghi chú |
|---|---|---|
| **Tạm ngưng chương trình** | Edit partner → **Status OFF** → **Warning** → **Confirm** → **Ok** | |
| **Bật lại** | Gạt **Status ON** → **Ok** | **Không cần nhập lại gì**: mọi cấu hình giữ nguyên. Website hoạt động lại sau vài giây–vài phút |
| **Gia hạn** | Đổi **End Date** sang ngày tương lai → **Ok** | Cấu hình khác giữ nguyên |
| **Ngưng ngay** | Gạt **Status OFF** | Không thể chọn End Date trong quá khứ |
| **Tạm ngưng website** | Website Templates → **Status Inactive** | |
| **Xoá website** | **Delete** → xác nhận → **"DELETE SUCCESS"** | ⚠️ **Không hoàn tác.** Partner mất website **và toàn bộ nội dung CMS**; Partner Portal báo *"No website has been assigned to you yet"*. Template System Default không xoá được |

![Gạt Status sang OFF](images/corporate-program/06-status-off.png)

### 9.3 Thời gian cập nhật cần biết

| Thay đổi | Thời gian hiển thị |
|---|---|
| Nội dung Partner CMS | ~30 giây (tải lại sau 1 phút nếu chưa thấy) |
| Bật/tắt Corporate Program | Vài phút |
| Stripe Connect Status sau khi Stripe xác minh | Vài phút |
| Tài khoản + eSIM của khách sau khi trả tiền | ~30–60 giây |

---

## 10. Tiền và đối soát

### 10.1 Công thức

```
Application Fee (Eskimo nhận)   = Giá gói × Application Fee %
Partner Benefit (partner nhận)  = Giá gói × (100% − Application Fee %)
```

| Giá gói | Application Fee | Eskimo nhận | Partner nhận |
|---|---|---|---|
| USD 100 | 90% | USD 90 | USD 10 |
| USD 100 | 10% (mặc định) | USD 10 | USD 90 |
| USD 3.90 | 20% | USD 0.78 | USD 3.12 |

Khách luôn trả **đủ giá gói**; Application Fee chỉ chia phần giữa Eskimo và partner.

### 10.2 Hai mã đơn — đúng thiết kế

| Mã | Ở đâu | Ý nghĩa |
|---|---|---|
| **PUR-PN…** | Trang xác nhận của khách | Đơn hàng của partner |
| **WHI-…** | Admin › **Transactions › Eskimo Sale** | Phần phí Eskimo nhận = **giá đơn × Application Fee %** (ví dụ phí 10%, đơn US$3.90 → **0.39**) |

---

## 11. Xử lý sự cố (FAQ tổng hợp)

### Admin

| Vấn đề | Nguyên nhân / cách xử lý |
|---|---|
| Không đổi được **Type** | Khoá sau lần lưu đầu. Chọn nhầm → liên hệ đội kỹ thuật Eskimo |
| Không sửa được **Start Date** | Khoá khi ngày bắt đầu đã qua; chỉ End Date sửa được |
| Không chọn được End Date quá khứ | Đúng thiết kế. Muốn ngưng ngay → **Status OFF** |
| Lưu xong mà **phí không được ghi** | Partner chưa bắt đầu Connect Stripe. Nhờ partner kết nối rồi lưu lại phí |
| Phí hiển thị `0` | Partner mới có thể điền sẵn 0 → Eskimo không thu phí. Xoá trống (10%) hoặc nhập đúng |
| Stripe mãi **Not Connected** | Partner chưa vào **My Website → Connect Stripe**. Admin không làm thay được |
| Không thấy **Network Partner Commission**, **Eskimo Stripe Pay**, hay **No Expiry** xám | Đúng thiết kế phase 1 |
| Không thấy partner khi **Assign** / **"No available partner"** | Partner chưa bật Corporate Program, đã có website khác, hoặc từ khoá không khớp |
| Danh sách Assign có partner không phải White label | Danh sách hiện mọi partner bật Corporate Program. Chọn đúng partner **Type = White label** |
| **Save Page** mờ | Chưa có thay đổi |
| Thấy module **`downloadApp`** / `productSection` | Module đã ngừng dùng, website không hiển thị. Xoá rồi lưu |
| Đóng Edit Structure bị mất thay đổi | Close không cảnh báo khi chưa lưu. Luôn **Save Page / Save All** trước |
| Phí nhập lúc tạo partner không được lưu | Đúng hành vi: chỉ lưu phí khi Edit. Đặt phí ở Bước C2 |
| Tìm module hiển thị **sản phẩm** | **Data Plan Section (Global + Regions)** (Home), **Plan Detail Hero** (Plan Detail) |
| Tắt chương trình mà khách vẫn thấy website | Chờ vài phút rồi tải lại |

### Partner

| Vấn đề | Cách xử lý |
|---|---|
| My Website báo *"No website has been assigned to you yet"* | Admin chưa tạo/gán website, hoặc website đã bị xoá |
| Sửa xong nhưng website không đổi | Chưa bấm **Save Page / Save All** (nút Save trong cửa sổ module chỉ cập nhật xem trước), hoặc chưa đủ ~1 phút |
| Muốn thêm / xoá / đổi thứ tự module | Liên hệ Admin (Edit Structure) |
| Header/Footer khác nhau giữa các trang | Mỗi trang có Header/Footer riêng — cấu hình đủ 5 trang rồi **Save All** |
| Muốn đổi giá gói | Không được — giá lấy từ hệ thống |

### Khách hàng (Support)

| Vấn đề | Cách xử lý |
|---|---|
| Trả tiền rồi mà không vào được My Data | Chờ 30–60 giây rồi `Send code` lại. Sau vài phút vẫn lỗi → kiểm tra email nhập lúc checkout |
| Không nhận được email eSIM | Kiểm tra spam; kiểm tra **Eskimo Email Notification** của partner (OFF → partner tự gửi) |
| Thẻ declined có bị trừ tiền không | Không. Thanh toán lại bằng thẻ khác, cùng email, không tạo tài khoản trùng |
| Nhập sai OTP nhiều lần | Tạm khoá; chờ vài phút, xin mã mới |
| Email dùng ở website khác có chung dữ liệu không | Không. Mỗi partner là một tài khoản riêng |

---

## 12. Checklist go-live end-to-end

**A. Corporate Program (Admin)**
- [ ] Partner **Status = Active**, Partner Email đúng
- [ ] Corporate Program **ON**, **Type = White label** (ô Type khoá)
- [ ] **Start / End Date** đúng hợp đồng
- [ ] **Eskimo Email Notification** đúng thoả thuận (OFF → partner đã có quy trình gửi QR)
- [ ] **Lifetime Account Limit** đã nhập
- [ ] **Payment method = Direct Charge**, **Data Expiry = 2 Years**
- [ ] Không có mục Network Partner Commission

**B. Website (Admin)**
- [ ] Đã **Clone** và **Assign Partner**, website đổi tên theo partner
- [ ] Cấu trúc từng trang đã **Save**; mở lại kiểm tra: Header đầu, **Footer cuối** mỗi trang

**C. Stripe & phí**
- [ ] **Stripe Connect Status = Verified**
- [ ] **Application Fee** lưu đúng khi mở lại (không phải `0` ngoài ý muốn)

**D. Nội dung (Partner)**
- [ ] Brand name, logo, màu đúng bộ nhận diện
- [ ] Header/Footer đồng nhất cả 5 trang; email hỗ trợ và mạng xã hội là của partner
- [ ] Home, Plan Detail, Install eSIM, Data Balance đã cập nhật
- [ ] Đã **Save All** và thấy `Saved: …`

**E. Go-live**
- [ ] **Config**: custom domain, email sender
- [ ] Website **Status = Active**
- [ ] Mở website trên máy tính và điện thoại, kiểm tra 5 trang và các liên kết
- [ ] Đơn thử: thanh toán thành công → trang xác nhận `PUR-PN…` → email QR + Magic Link (nếu ON) → My Data hiển thị gói
- [ ] Admin › Eskimo Sale có giao dịch **WHI-…** = giá đơn × phí %

---

## Phụ lục

### Phụ lục A — Cấu trúc mặc định template "Eskimo eCommerce (Default)"

5 trang, 26 module:

| Trang | Số module | Module (theo thứ tự) |
|---|---|---|
| **Home** | 13 | Header → Banner → Data Plan Section (Global + Regions) → Transfer Data (Why Eskimo eSIM) → More Reasons Grid → downloadApp *(đã ngừng dùng, xoá đi)* → Video Section → Comparison Table → Install Steps → Reviews → FAQ → Recommendations → Footer |
| **Plan Detail** | 4 | Header → Plan Detail Hero → Sticky Checkout Bar → Footer |
| **Checkout** | 2 | Header → Footer (form thanh toán do hệ thống cung cấp) |
| **Install eSIM** | 3 | Header → Install eSIM Guide (iOS / Android, manual) → Footer |
| **Data Balance** | 4 | Header → Data Balance Screen → Data & eSIM Information → Footer |

### Phụ lục B — Thư viện module (+ Add Section)

| Module | Dùng cho |
|---|---|
| Header | Logo, menu đầu trang |
| Banner | Ảnh bìa, tiêu đề, mô tả, nút kêu gọi |
| Feature Section | Các điểm nổi bật |
| Data Plan Section (Global + Regions) | Danh sách gói theo quốc gia / khu vực (sản phẩm) |
| Transfer Data (Why Eskimo eSIM) | Lý do chọn dịch vụ |
| More Reasons Grid | Lưới ưu điểm |
| Video Section | Video giới thiệu |
| Comparison Table | Bảng so sánh |
| Install Steps | Các bước cài eSIM (tóm tắt) |
| Reviews | Đánh giá khách hàng |
| FAQ | Câu hỏi thường gặp |
| Recommendations | Gợi ý gói / điểm đến |
| Footer | Liên kết, mạng xã hội, bản quyền |
| Plan Detail Hero | Đầu trang chi tiết gói |
| Sticky Checkout Bar | Thanh thanh toán cố định |
| Data & eSIM Information | Thông tin data và eSIM |
| Data Balance Screen | Màn hình data còn lại |
| Install eSIM Guide (iOS / Android, manual) | Hướng dẫn cài chi tiết theo thiết bị |

Danh sách được thiết kế để mở rộng: module mới tự xuất hiện trong **+ Add Section**.

### Phụ lục C — Đường dẫn trong website

| Đường dẫn | Trang |
|---|---|
| `/` | Trang chủ |
| `/esim` | Danh sách gói theo quốc gia / khu vực |
| `/plans/<quốc-gia>-esim` | Chi tiết gói (`/plans/japan-esim`, `/plans/global-esim`) |
| `/checkout` | Thanh toán |
| `/data-balance` | My Data |
| `/install-esim` | Hướng dẫn cài; `?platform=ios` / `?platform=android` mở sẵn tab |

Trên trình duyệt, website có tiền tố ngôn ngữ (ví dụ `/en/data-balance`), nhưng khi nhập liên kết trong Partner CMS thì **bỏ tiền tố** (`/data-balance`). Mọi đường dẫn bắt đầu bằng `/plans/` đều hợp lệ.

### Phụ lục D — Giới hạn tải ảnh

| Loại | Định dạng | Tối đa |
|---|---|---|
| Logo | PNG, JPEG | 1 MB |
| Hình trong module (banner, ô nổi bật, hướng dẫn cài) | PNG, JPEG | 5 MB |
