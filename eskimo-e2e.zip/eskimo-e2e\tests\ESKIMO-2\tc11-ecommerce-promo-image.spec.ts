// ESKIMO-2 / EP-6036 – TC-11 (read-only): where are a promo code's Custom Icon / Custom Image shown on the
// e-commerce web? Uses the existing STG promo 8H70HJY7 (override: E2E_TC11_PROMO). Nothing is saved, redeemed,
// applied or paid: admin drawer is closed with Cancel, checkout stops at the promo list.
// Code read (eskimonextjs develop): only `customIcon` is rendered – Reward page (components/Reward/VoucherCard.js)
// and Checkout → Apply promo code list (components/Checkout/ListApplyPromoCode.js). `customImage` is not used.
// Evidence: npm run report:evidence -- ESKIMO-2 tc11-ecommerce-promo-image "EP-6036 TC-11 · STG"
import { test, expect, devices, type Browser, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { ecomSession, dismissCampaignPopup, ECOM_URL } from "../_support/ecommerce";
import { createEvidence, esc, type EvidenceMeta } from "../_support/evidence";

const ID = "@ESKIMO-2";
const AC = "EP-6036 TC-11";
const PROMO = process.env.E2E_TC11_PROMO || "8H70HJY7";
const evidence = createEvidence("ESKIMO-2", "tc11-ecommerce-promo-image");
const VIEWS = [
  { name: "Desktop 1440×900", options: { viewport: { width: 1440, height: 900 } } },
  { name: "Mobile iPhone 13 (390×844)", options: { ...devices["iPhone 13"] } },
];
const short = (v: unknown) =>
  v === null || v === undefined || v === "" ? "(empty)" : String(v).slice(0, 120) + (String(v).length > 120 ? "…" : "");

test.describe.serial(`ESKIMO-2 TC-11 promo images on e-commerce ${ID}`, () => {
  test.describe.configure({ retries: 0 });
  test.setTimeout(300_000);

  let admin: { ctx: any; page: Page };
  let scratch: Page;
  let adminDetail: any = null;
  let storage: any; // logged-in e-commerce member, reused for every viewport

  async function verify(page: Page, testInfo: TestInfo, meta: Omit<EvidenceMeta, "status">, checks: () => Promise<string[] | void>) {
    let err: unknown;
    let actual: string[] = [];
    try { actual = (await checks()) || []; } catch (e) { err = e; }
    const expected = [...meta.expected, ...actual.map((a) => `→ actual: ${a}`)];
    if (err) expected.push(`✗ ${String((err as Error).message).split("\n").find((l) => l.trim()) ?? err}`.slice(0, 300));
    await evidence.saveScreenshot(page, testInfo, { ...meta, expected, status: err ? "failed" : undefined });
    if (err) throw err;
  }

  async function dataCard(testInfo: TestInfo, heading: string, rows: [string, unknown][], meta: Omit<EvidenceMeta, "status">, checks: () => Promise<string[] | void> = async () => {}) {
    const imgs = rows.filter(([, v]) => typeof v === "string" && /^https?:\/\/.+\.(png|jpe?g)/i.test(v));
    await scratch.setContent(`<!DOCTYPE html><html><head><meta charset="utf-8"><style>
      body{font-family:Arial,sans-serif;padding:24px;color:#222} h2{font-size:16px;margin:0 0 12px}
      table{border-collapse:collapse;width:100%;font-size:13px} img{max-height:120px;border:1px solid #ddd;margin:8px 12px 0 0}
      th,td{border:1px solid #d0d0d0;padding:6px 10px;text-align:left;word-break:break-all} th{background:#f0f4ff}
    </style></head><body><h2>${esc(heading)}</h2><table><tr><th>Field</th><th>Value</th></tr>${rows
      .map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(short(v))}</td></tr>`).join("")}</table>
      <div>${imgs.map(([k, v]) => `<figure style="display:inline-block"><img src="${esc(v)}"><figcaption>${esc(k)}</figcaption></figure>`).join("")}</div>
      </body></html>`, { waitUntil: "load" });
    await verify(scratch, testInfo, meta, checks);
  }

  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    test.setTimeout(240_000);
    admin = await adminSession(browser);
    scratch = await admin.ctx.newPage();
  });

  // Log the member in once (first web test), then reuse the session for every viewport.
  async function memberStorage(browser: Browser) {
    if (!storage) {
      const { ctx } = await ecomSession(browser, { viewport: { width: 1440, height: 900 } }, process.env.E2E_TC11_PHONE);
      storage = await ctx.storageState();
      await ctx.close();
    }
    return storage;
  }

  test.afterAll(async () => {
    await admin?.ctx.close();
  });

  test(`TC-11a Admin config of ${PROMO} (read-only) ${ID}`, async ({}, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase(`TC-11a Admin – images configured on promo ${PROMO}`);
    const page = admin.page;
    await page.goto(`${ADMIN_URL}/#/promo-codes`, { waitUntil: "domcontentloaded" });
    const search = page.getByPlaceholder("Search by Promo Code");
    await search.waitFor({ state: "visible", timeout: 30000 });
    await search.fill(PROMO);
    await search.press("Enter");
    const row = page.locator(".ant-table-tbody tr.ant-table-row").filter({ hasText: PROMO }).first();
    await row.waitFor({ state: "visible", timeout: 30000 });
    const detailP = page.waitForResponse((r) => /\/api\/gift-code\/promo\/v2\/[^/?]+$/.test(r.url()) && r.request().method() === "GET");
    await row.getByRole("button", { name: "Edit" }).click();
    adminDetail = (await (await detailP).json())?.data;
    const drawer = page.locator(".ant-drawer-content:visible").first();
    const imageField = drawer.locator(".ant-form-item").filter({ has: page.locator(`label[title="Custom Image"]`) }).first();
    await imageField.waitFor({ state: "visible", timeout: 20000 });
    await imageField.scrollIntoViewIfNeeded();
    await verify(page, testInfo, {
      ac: AC, title: `Admin: ${PROMO} Custom Icon Image / Custom Image`,
      steps: [`Admin → Promo Codes → search "${PROMO}" → Edit (view only, closed with Cancel)`],
      expected: ["Record which images the promo has (precondition for the web check)"],
    }, async () => [`customIcon = ${short(adminDetail?.customIcon)}`, `customImage = ${short(adminDetail?.customImage)}`]);
    await drawer.locator("button.btn-action-cancel").click();
    await dataCard(testInfo, `GET /api/gift-code/promo/v2/{id} – ${PROMO}`, [
      ["promoCode", adminDetail?.promoCode], ["customIcon", adminDetail?.customIcon], ["customImage", adminDetail?.customImage],
      ["isSelectGroup (exclusive)", adminDetail?.isSelectGroup], ["startTime", adminDetail?.startTime], ["endTime", adminDetail?.endTime],
    ], { ac: AC, title: `Admin detail of ${PROMO}`, steps: ["Response of the Edit drawer"], expected: ["Promo exists on STG"] },
    async () => { expect(adminDetail, `promo ${PROMO} not found`).toBeTruthy(); });
  });

  for (const view of VIEWS) {
    test(`TC-11b Reward page – ${view.name} ${ID}`, async ({ browser }, testInfo) => {
      evidence.setCase(`TC-11b Web Reward page (/en/reward) – ${view.name}`);
      const ctx = await browser.newContext({ ...view.options, storageState: await memberStorage(browser) });
      const page = await ctx.newPage();
      try {
        const listP = page.waitForResponse((r) => r.url().includes("/api/gift-code/promo/get") && r.request().method() === "GET", { timeout: 60000 });
        await page.goto(`${ECOM_URL}/en/reward`, { waitUntil: "domcontentloaded" });
        const list: any[] = (await (await listP).json())?.data ?? [];
        await dismissCampaignPopup(page);
        const item = list.find((p) => p.name === PROMO);
        const card = page.locator(".reward-voucher").filter({ hasText: PROMO }).first();
        const found = await card.waitFor({ state: "visible", timeout: 20000 }).then(() => true).catch(() => false);
        if (found) await card.scrollIntoViewIfNeeded();
        else await page.locator(".reward-voucher").first().scrollIntoViewIfNeeded().catch(() => {});
        await verify(page, testInfo, {
          ac: AC, title: `Reward page – ${PROMO} voucher card (${view.name})`,
          steps: ["Log in as STG member (E2E_ECOM_PHONE)", "Open /en/reward → Vouchers", `Find the card "${PROMO}"`],
          expected: [
            "Card shows the promo's Custom Icon Image as the badge icon (top-left)",
            "Custom Image: rendered somewhere on the card? (code: not used on web)",
          ],
        }, async () => {
          expect(found, `voucher card "${PROMO}" not on the Reward page (${list.length} promos in /api/gift-code/promo/get)`).toBe(true);
          const icon = await card.locator("img.reward-voucher-badge-icon--custom").getAttribute("src").catch(() => null);
          const imgs = await card.locator("img").evaluateAll((els) => els.map((e) => (e as HTMLImageElement).src));
          return [
            `badge icon src = ${short(icon) }`,
            `customImage URL on card: ${item?.customImage && imgs.includes(item.customImage) ? "YES" : "NO"}`,
          ];
        });
        if (found) {
          // "Details" only opens a read-only sheet (no redeem).
          await card.getByText("Details").click();
          const sheet = page.getByText("12% Off", { exact: false }).last();
          await page.waitForTimeout(800);
          await verify(page, testInfo, {
            ac: AC, title: `Reward page – ${PROMO} Details sheet (${view.name})`,
            steps: [`Click "Details" on the ${PROMO} card`],
            expected: ["Custom Image: rendered in the detail sheet? (code VoucherDetailSheet.js: no image)"],
          }, async () => {
            const srcs = await page.locator("img").evaluateAll((els) => els.map((e) => (e as HTMLImageElement).src));
            return [`customImage URL on page: ${item?.customImage && srcs.includes(item.customImage) ? "YES" : "NO"}`];
          });
          void sheet;
        }
        if (view === VIEWS[0]) {
          await dataCard(testInfo, `GET /api/gift-code/promo/get (web) – item ${PROMO}`, [
            ["listed for this member", item ? "yes" : "no"], ["customIcon", item?.customIcon],
            ["customImage", item && "customImage" in item ? item.customImage : "(field not in web API)"],
            ["webContentKey", item?.webContentKey], ["expiredTime", item?.expiredTime],
          ], { ac: AC, title: `Web API data for ${PROMO}`, steps: ["Response used by the Reward page"], expected: ["Shows which image fields the web receives"] });
        }
      } finally {
        await ctx.close();
      }
    });
  }

  // Checkout: desktop only (mobile ignored per QC, 2026-10-13).
  for (const view of VIEWS.slice(0, 1)) {
    test(`TC-11c Checkout promo list – ${view.name} ${ID}`, async ({ browser }, testInfo) => {
      evidence.setCase(`TC-11c Web Checkout → promo code list – ${view.name}`);
      const ctx = await browser.newContext({ ...view.options, storageState: await memberStorage(browser) });
      const page = await ctx.newPage();
      try {
        await page.goto(`${ECOM_URL}/en`, { waitUntil: "domcontentloaded" });
        await dismissCampaignPopup(page);
        const vietnam = page.locator(".country-link, a[href*='vietnam']").filter({ hasText: /vietnam/i }).first();
        await vietnam.waitFor({ state: "visible", timeout: 60000 });
        await vietnam.click();
        await dismissCampaignPopup(page);
        const section = page.locator(".plans-section").filter({ has: page.locator(".plans-title-desc", { hasText: /^vietnam$/i }) });
        await section.scrollIntoViewIfNeeded();
        await section.locator(".day-card").first().click();
        await page.getByRole("button", { name: "No, browse here" }).click({ timeout: 3000 }).catch(() => {});
        await page.locator(".btn-checkout").first().click({ timeout: 20000 });
        await page.waitForURL("**/checkout", { timeout: 30000 });
        await page.locator(".checkout-page").waitFor({ state: "visible", timeout: 30000 });
        // A redeemed promo is auto-applied by the app: record that state and do not remove it.
        const promoRow = page.locator(".checkout-promo-inline").first();
        await promoRow.waitFor({ state: "visible", timeout: 20000 });
        await page.waitForLoadState("networkidle").catch(() => {});
        const autoApplied = page.locator(".checkout-promo-inline.__applied, .checkout-promo-inline").filter({ hasText: PROMO }).first();
        if (await autoApplied.isVisible().catch(() => false)) {
          await promoRow.scrollIntoViewIfNeeded();
          await verify(page, testInfo, {
            ac: AC, title: `Checkout – ${PROMO} auto-applied (${view.name})`,
            steps: ["Home → Vietnam → first plan → Checkout (member has redeemed the code)", "Look at Order summary + \"Got a promo code?\" (nothing clicked)"],
            expected: [
              `${PROMO} is auto-applied: code chip + order summary line`,
              "Custom Icon / Custom Image on this state? (code: chip shows text only)",
            ],
          }, async () => {
            const imgs = await promoRow.locator("img").evaluateAll((els) => els.map((e) => (e as HTMLImageElement).src));
            const summary = (await page.locator("text=" + PROMO).first().locator("xpath=..").innerText().catch(() => "")).replace(/\s+/g, " ");
            return [`promo row images: ${imgs.length ? imgs.map(short).join(", ") : "none"}`, `order summary: "${summary.slice(0, 80)}"`];
          });
          return;
        }
        // Not applied: open the list only (no "Use This Code", no pay).
        const listP = page.waitForResponse((r) => r.url().includes("/api/gift-code/promo/get?dataPlanId=") && r.request().method() === "GET", { timeout: 30000 }).catch(() => null);
        const trigger = page.locator(".checkout-promo-inline-btn").first();
        await trigger.scrollIntoViewIfNeeded();
        await trigger.click();
        const list: any[] = (await (await listP)?.json().catch(() => null))?.data ?? [];
        const ticket = page.locator(".checkout-voucher-ticket").filter({ hasText: PROMO }).first();
        const found = await ticket.waitFor({ state: "visible", timeout: 15000 }).then(() => true).catch(() => false);
        if (found) await ticket.scrollIntoViewIfNeeded();
        await verify(page, testInfo, {
          ac: AC, title: `Checkout promo list – ${PROMO} (${view.name})`,
          steps: ["Home → Vietnam → first plan → Checkout", "Open the promo code list (no code applied)", `Find "${PROMO}"`],
          expected: [
            "Ticket shows the promo's Custom Icon Image as its icon",
            "Custom Image: rendered on the ticket? (code: not used on web)",
          ],
        }, async () => {
          expect(found, `"${PROMO}" not in the checkout promo list for this plan (${list.length} promos returned)`).toBe(true);
          const imgs = await ticket.locator("img").evaluateAll((els) => els.map((e) => (e as HTMLImageElement).src));
          const item = list.find((p) => p.name === PROMO);
          return [`icon src = ${short(imgs[0])}`, `customImage URL on ticket: ${item?.customImage && imgs.includes(item.customImage) ? "YES" : "NO"}`];
        });
      } finally {
        await ctx.close();
      }
    });
  }
});
