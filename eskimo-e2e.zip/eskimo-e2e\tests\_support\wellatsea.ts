// White-label storefront Well At Sea (STG: BE stage, Stripe test mode) + Admin › Membership helpers,
// ported from eskimo_portal e2e/storefront/wellatsea-helpers.js. The storefront has no test ids:
// locators are its own wl-* classes. Every BE call runs in a Next server action, so the BE side is
// checked through the Admin API / Admin UI.
import { type Browser, type Frame, type Page } from "@playwright/test";
import { ADMIN_URL } from "./eskimo";

export const WL_URL = (process.env.E2E_WL_URL || "https://wellatsea.eskimo.travel").replace(/\/$/, "");
export const API_URL = (process.env.E2E_API_URL || "https://app-eskimo-api-stage-sea-001.azurewebsites.net").replace(/\/$/, "");

export type Card = { number: string; exp: string; cvc: string; zip: string };
export const CARD_OK: Card = { number: "4242424242424242", exp: "12 / 30", cvc: "123", zip: "12345" };
export const CARD_DECLINED: Card = { number: "4000000000000002", exp: "12 / 30", cvc: "123", zip: "12345" };

// Admin › Membership codes (eskimo_portal src/pages/Membership/utils.js renderStatusMemberCol).
export const ACCOUNT_STATUS: Record<number, string> = { 1: "Active", 2: "Suspended", 3: "Pending", 4: "OTP Verified" };
export const ESIM_STATUS: Record<number, string> = { 3: "Assigned", 4: "Error", 7: "Suspended", 8: "Waiting Sync Up", 10: "Waiting To Suspend", 11: "Waiting To Active", 15: "Provision" };
export const accountLabel = (s: number | null | undefined) => (s == null ? "—" : ACCOUNT_STATUS[s] ?? `status ${s}`);
export const esimLabel = (s: number | null | undefined) => (s == null ? "No eSIM" : ESIM_STATUS[s] ?? `esimStatus ${s}`);

export async function newShopper(browser: Browser) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  return { ctx, page: await ctx.newPage() };
}

// ─── Storefront checkout ──────────────────────────────────────────────────────

// "commit" + visible content: DCL sometimes never fires on this site although the page is shown.
async function gotoShown(page: Page, url: string) {
  for (let i = 1; i <= 2; i++) {
    try {
      await page.goto(url, { waitUntil: "commit", timeout: 75000 });
      await page.locator("header, main, h1, h2").first().waitFor({ state: "visible", timeout: 75000 });
      return;
    } catch (e) {
      if (i === 2) throw e;
    }
  }
}

/** Plan page → coverage area card → data tile (e.g. Japan / 1GB). */
export async function pickPlan(page: Page, { countryPath = "/en/plans/japan-esim", area = /^Japan/i, data = "1GB" } = {}) {
  await gotoShown(page, `${WL_URL}${countryPath}`);
  const plansShown = async () => {
    await page.locator(".day-card").first().waitFor({ state: "visible", timeout: 90000 });
    await page.getByText(/Loading plans/i).first().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
  };
  await plansShown();
  const areaCard = page.locator(".wl-coverage-area-card").filter({ hasText: area }).first();
  // Slow loads sometimes preselect another region without the wanted area: a customer reloads once.
  if (!(await areaCard.waitFor({ state: "visible", timeout: 30000 }).then(() => true).catch(() => false))) {
    await page.reload({ waitUntil: "domcontentloaded" });
    await plansShown();
    await areaCard.waitFor({ state: "visible", timeout: 45000 });
  }
  const [, value, unit] = data.match(/^(\d+)\s*([A-Za-z]+)$/) ?? [null, data, ""];
  const tile = areaCard
    .locator(".day-card")
    .filter({ has: page.locator(".day-card__value", { hasText: new RegExp(`^\\s*${value}\\s*$`) }) })
    .filter({ hasText: new RegExp(unit, "i") })
    .first();
  await tile.scrollIntoViewIfNeeded().catch(() => {});
  await tile.click({ timeout: 20000 });
  await page.locator(".wl-selected-plan-name").first().waitFor({ state: "visible", timeout: 10000 }).catch(() => {});
  return (await page.locator(".wl-selected-plan-name").first().innerText().catch(() => "")).trim();
}

export async function goToCheckout(page: Page) {
  await page.locator("a.btn-checkout:visible").first().click();
  await page.waitForURL(/\/checkout(\?|$)/, { timeout: 30000 });
  await page.locator("#wl-checkout-email").waitFor({ state: "visible", timeout: 30000 });
}

/** First name + Email → "Continue to payment" (create-order). Retried like a customer when it stalls. */
export async function continueToPayment(page: Page, firstName: string, email: string) {
  let last = { outcome: "timeout", errors: [] as string[] };
  for (let attempt = 1; attempt <= 3; attempt++) {
    await page.locator("#wl-checkout-first-name").fill(firstName);
    await page.locator("#wl-checkout-email").fill(email);
    await page.locator("button.checkout-proceed-btn", { hasText: /Continue to payment/i }).click();
    const outcome = await Promise.race([
      page.locator(".wl-checkout-card-section").waitFor({ state: "visible", timeout: 45000 }).then(() => "card"),
      page.locator(".wl-checkout-field__error").first().waitFor({ state: "visible", timeout: 45000 }).then(() => "error"),
    ]).catch(() => "timeout");
    last = { outcome, errors: await page.locator(".wl-checkout-field__error").allInnerTexts().catch(() => []) };
    if (outcome === "card") return last;
    await page.waitForTimeout(10000);
  }
  return last;
}

// Stripe Payment Element lives in a cross-origin iframe: find the frame that holds the card number.
async function stripeCardFrame(page: Page, timeoutMs = 45000): Promise<Frame | null> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    for (const f of page.frames()) {
      if (!/stripe/i.test(f.url())) continue;
      if (await f.$('input[name="number"], input[autocomplete="cc-number"]').catch(() => null)) return f;
    }
    await page.waitForTimeout(1000);
  }
  return null;
}

/** Fill the card, press "Pay US$ x" → checkout complete page or the inline Stripe error. */
export async function payWithCard(page: Page, card: Card) {
  const frame = await stripeCardFrame(page);
  if (!frame) return { outcome: "timeout", error: "Stripe card iframe not found" };
  const cardTab = await frame.$('button[data-testid="card"], [data-value="card"]').catch(() => null);
  if (cardTab) await cardTab.click().catch(() => {});
  await frame.fill('input[name="number"], input[autocomplete="cc-number"]', card.number);
  await frame.fill('input[name="expiry"], input[autocomplete="cc-exp"]', card.exp);
  await frame.fill('input[name="cvc"], input[autocomplete="cc-csc"]', card.cvc);
  const zip = await frame.$('input[name="postalCode"]').catch(() => null);
  if (zip && (await zip.isVisible().catch(() => false))) await zip.fill(card.zip);
  const pay = page.locator("button.checkout-proceed-btn", { hasText: /^Pay /i }).first();
  await pay.waitFor({ state: "visible", timeout: 20000 });
  await page.waitForFunction(() => {
    const b = [...document.querySelectorAll("button.checkout-proceed-btn")].find((x) => /^Pay /i.test((x as HTMLElement).innerText));
    return !!b && !(b as HTMLButtonElement).disabled;
  }, null, { timeout: 20000 }).catch(() => {});
  await pay.click();
  const outcome = await Promise.race([
    page.waitForURL(/\/checkout\/complete/, { timeout: 90000 }).then(() => "complete"),
    page.locator(".wl-checkout-pay__error").first().waitFor({ state: "visible", timeout: 90000 }).then(() => "error"),
  ]).catch(() => "timeout");
  const error = outcome === "error" ? (await page.locator(".wl-checkout-pay__error").first().innerText()).trim() : "";
  return { outcome, error };
}

/** /checkout/complete → "Order number" etc. */
export async function readCompletePage(page: Page) {
  await page.locator(".wl-checkout-complete__checking").waitFor({ state: "hidden", timeout: 60000 }).catch(() => {});
  await page.locator(".wl-checkout-complete__card").first().waitFor({ state: "visible", timeout: 60000 });
  const rows: Record<string, string> = await page.$$eval(".success-details-list .details-item", (els) =>
    Object.fromEntries(els.map((e) => [
      ((e.querySelector(".item-label") as HTMLElement)?.innerText || "").trim(),
      ((e.querySelector(".item-value") as HTMLElement)?.innerText || "").trim(),
    ])),
  ).catch(() => ({}));
  return { orderNumber: rows["Order number"] || "", rows };
}

// ─── My Data sign-in (OTP) ────────────────────────────────────────────────────
// Used only to verify the OTP gate's defences (rate limit / lockout / CAPTCHA).
// The tests submit deliberately-wrong codes; they never read or guess a valid code.

/** /en/data-balance → enter the e-mail → "Send code". Returns whether the code screen opened. */
export async function requestCode(page: Page, email: string) {
  for (let i = 1; i <= 2; i++) {
    try {
      await page.goto(`${WL_URL}/en/data-balance`, { waitUntil: "commit", timeout: 75000 });
      await page.locator("header, main, h1, h2").first().waitFor({ state: "visible", timeout: 75000 });
      break;
    } catch (e) {
      if (i === 2) throw e;
    }
  }
  const input = page.locator('input[aria-label="Email address"]');
  await input.waitFor({ state: "visible", timeout: 60000 });
  await page.waitForTimeout(1500); // let React hydrate so the value is accepted
  await input.fill(email);
  await page.locator("button.db-empty-plans__btn", { hasText: /Send code/i }).click();
  const outcome = await Promise.race([
    page.locator('input[aria-label="4-digit code"]').waitFor({ state: "visible", timeout: 45000 }).then(() => "code-screen"),
    page.locator(".wl-wallet-signin__error").first().waitFor({ state: "visible", timeout: 45000 }).then(() => "error"),
  ]).catch(() => "timeout");
  const error = outcome === "error" ? (await page.locator(".wl-wallet-signin__error").first().innerText()).trim() : "";
  return { outcome, error };
}

/** Submit one 4-digit code → the page's reaction. `signedIn` means the gate let us in. */
export async function submitCode(page: Page, code: string) {
  const input = page.locator('input[aria-label="4-digit code"]');
  await input.fill("");
  await input.fill(code);
  const btn = page.locator("button.db-empty-plans__btn", { hasText: /View my data/i });
  const disabledBefore = await btn.isDisabled().catch(() => false);
  if (!disabledBefore) await btn.click();
  const outcome = await Promise.race([
    page.locator(".wl-wallet-account").first().waitFor({ state: "visible", timeout: 20000 }).then(() => "signed-in"),
    page.locator(".wl-wallet-signin__error").first().waitFor({ state: "visible", timeout: 20000 }).then(() => "error"),
  ]).catch(() => "no-change");
  const error = (await page.locator(".wl-wallet-signin__error").first().innerText().catch(() => "")).trim();
  const codeStillThere = await input.isVisible().catch(() => false);
  return { outcome, error, codeStillThere, submitDisabled: disabledBefore };
}

// ─── Admin API (Membership) ───────────────────────────────────────────────────

/** JWT of a logged-in admin page (localStorage "accessToken", older builds "hotspot"). */
export async function adminToken(adminPage: Page): Promise<string> {
  const raw = await adminPage.evaluate(() => localStorage.getItem("accessToken") || localStorage.getItem("hotspot") || "");
  try {
    const p = JSON.parse(raw);
    return p.accessToken || p.token || raw;
  } catch {
    return raw;
  }
}

// Stage API sometimes answers 200 with an empty body: retry until JSON parses.
async function api(token: string, method: string, apiPath: string, body?: unknown) {
  for (let i = 0; i < 6; i++) {
    try {
      const res = await fetch(`${API_URL}${apiPath}`, {
        method,
        signal: AbortSignal.timeout(30000),
        headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: `Bearer ${token}` },
        ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      });
      const text = await res.text();
      if (text) return JSON.parse(text);
    } catch {
      /* retry */
    }
    await new Promise((r) => setTimeout(r, 1000));
  }
  return null;
}

export type Member = { id: string; email: string; status: number; esimStatus: number | null; [k: string]: unknown };

/** Admin › Membership search (Search by = Email), pending accounts included → every exact match. */
export async function membersByEmail(token: string, email: string): Promise<Member[]> {
  const res = await api(token, "POST", "/api/membership/search", {
    pageIndex: 1, pageSize: 20, searchText: email, searchType: 7, partnerIds: [], status: null,
    sortBy: { fieldName: "CreatedOn", ascending: false }, isShowPendingStatus: true, esimStatus: null,
  });
  const d = res?.data;
  const list: Member[] = (d && (d.data || d.items)) || [];
  return list.filter((m) => String(m.email || "").toLowerCase() === email.toLowerCase());
}

/** Member Detail data (field "Status" = status, isEsimAssign). */
export async function memberDetail(token: string, id: string) {
  const res = await api(token, "GET", `/api/membership/${id}`);
  return (res?.data ?? res) as { status?: number; isEsimAssign?: boolean; [k: string]: unknown } | null;
}

/** The webhook that creates/updates the account is asynchronous: poll until `done` or timeout. */
export async function pollMembers(token: string, email: string, done: (m: Member[]) => boolean, timeoutMs = 180000) {
  const deadline = Date.now() + timeoutMs;
  let members: Member[] = [];
  while (Date.now() < deadline) {
    members = await membersByEmail(token, email);
    if (done(members)) break;
    await new Promise((r) => setTimeout(r, 10000));
  }
  return members;
}

// ─── Admin UI (Membership list + Member Detail) ──────────────────────────────

const mark = { outline: "3px solid #cf1322", background: "rgba(255,229,143,.95)" };

/** Membership › Search by Email; highlights "Account Status" + "eSIM Status" cells. Returns their texts. */
export async function searchMembership(page: Page, email: string) {
  await page.goto(`${ADMIN_URL}/#/membership`, { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.locator(".ant-table").first().waitFor({ state: "visible", timeout: 60000 });
  await page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
  await page.locator(".search-type-select").first().click();
  await page.locator(".ant-select-item-option").filter({ hasText: /^Email$/ }).first().click();
  const search = page.getByPlaceholder("Search").first();
  await search.fill(email);
  await search.press("Enter");
  await page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
  // The email is not part of the row text (only name/phone columns): the search itself filters by email.
  const rows = page.locator(".ant-table-tbody tr.ant-table-row");
  await rows.first().waitFor({ state: "visible", timeout: 30000 }).catch(() => {});
  const row = rows.first();
  const headers = (await page.locator(".ant-table-thead tr").first().locator("th").allInnerTexts().catch(() => [])).map((h) => h.trim());
  const cell = (re: RegExp) => { const i = headers.findIndex((h) => re.test(h)); return i >= 0 ? row.locator("td").nth(i) : null; };
  const out = { rowCount: await rows.count(), accountStatus: "", esimStatus: "", row };
  for (const [key, re] of [["accountStatus", /^Account Status$/i], ["esimStatus", /^eSIM Status$/i]] as const) {
    const c = cell(re);
    if (!c || !(await c.isVisible().catch(() => false))) continue;
    await c.scrollIntoViewIfNeeded().catch(() => {});
    await c.evaluate((el, m) => Object.assign((el as HTMLElement).style, m), mark).catch(() => {});
    out[key] = (await c.innerText().catch(() => "")).trim();
  }
  return out;
}

/** View Detail → Personal Account "Status" (highlighted) + whether "No Data" panels are shown. */
export async function openMemberDetail(page: Page, row: ReturnType<Page["locator"]>) {
  await row.locator("button, a").filter({ hasText: /View Detail/i }).first().click({ timeout: 15000 });
  await page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
  const label = page.getByText(/^\s*Status\s*$/).first();
  await label.waitFor({ state: "visible", timeout: 20000 });
  const box = label.locator("xpath=ancestor::*[self::div or self::tr or self::li][1]");
  await box.scrollIntoViewIfNeeded().catch(() => {});
  await box.evaluate((el, m) => Object.assign((el as HTMLElement).style, m), mark).catch(() => {});
  const status = (await box.innerText().catch(() => "")).replace(/\s+/g, " ").replace(/^Status\s*:?\s*/i, "").trim();
  const noData = await page.getByText(/^\s*No Data\s*$/i).count();
  return { status, noData };
}
