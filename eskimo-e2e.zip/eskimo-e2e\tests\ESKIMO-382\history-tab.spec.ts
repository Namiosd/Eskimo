// ESKIMO-382 / EP-6054 – WellAtSea My Data: the History tab leaked a raw internal API message
// ("History isn't available yet. The white-label data-wallet API returns current plans only.").
// Test cases: testcases/ESKIMO-382/ESKIMO-382.md. Read only (no purchase, no OTP).
//   TC-01 History tab shows no internal API / technical message
//   TC-02 History tab shows a purchase list OR a customer-friendly empty/error message
// My Data is opened with the customer's magic link (E2E_WL_MAGIC_LINK) instead of e-mail OTP.
// Evidence: evidence/ESKIMO-382-history-tab → npm run report:evidence -- ESKIMO-382 history-tab
import { test, expect, type Page, type TestInfo } from "@playwright/test";
import { createEvidence, esc } from "../_support/evidence";
import { WL_URL, newShopper } from "../_support/wellatsea";

const ID = "@ESKIMO-382";
const AC = "EP-6054";
const evidence = createEvidence("ESKIMO-382", "history-tab");
const EMAIL = process.env.E2E_WL_CUSTOMER_EMAIL || "";
const MAGIC_LINK = process.env.E2E_WL_MAGIC_LINK || "";

// The exact leak from the bug, plus any technical wording a customer must never read.
const OLD_LEAK = /history isn'?t available yet|data-wallet api returns current plans only/i;
const TECHNICAL = /\b(data-wallet api|white-label .*api|endpoint|websiteId|accessToken|bearer|undefined|null|\{\s*"|stack trace|internal server|http \d{3})\b/i;

async function openWallet(page: Page) {
  await page.goto(MAGIC_LINK, { waitUntil: "commit", timeout: 75000 });
  const signedIn = await page.locator(".wl-wallet-account").first().waitFor({ state: "visible", timeout: 90000 }).then(() => true).catch(() => false);
  const email = (await page.locator(".wl-wallet-account__email").first().innerText().catch(() => "")).trim();
  return { signedIn, email };
}

test.describe(`ESKIMO-382 My Data History tab ${ID}`, () => {
  test.setTimeout(360_000); // magic-link open on this site can cold-start slowly

  test(`TC-01 History tab shows no internal API message ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 No internal API message");
    expect(EMAIL, "Set E2E_WL_CUSTOMER_EMAIL").toBeTruthy();
    expect(MAGIC_LINK, "Set E2E_WL_MAGIC_LINK").toBeTruthy();
    const { ctx, page } = await newShopper(browser);
    try {
      await test.step("1. Open My Data via magic link", async () => {
        const { signedIn, email } = await openWallet(page);
        expect(signedIn, "Magic link no longer signs in (use e-mail OTP by hand, TC-03)").toBe(true);
        expect(email.toLowerCase()).toBe(EMAIL.toLowerCase());
      });
      let bodyText = "";
      await test.step("2. Click the History tab", async () => {
        const tab = page.locator(".db-tab").filter({ hasText: /History/i }).first();
        await expect(tab, "History tab present").toBeVisible();
        await tab.click();
        // Wait for the History panel to settle (list, empty message, error, or skeleton).
        await page.locator(".db-history-list, .db-empty-plans, .wl-history-error").first().waitFor({ state: "visible", timeout: 30000 }).catch(() => {});
        await page.locator(".wl-history-skeleton").first().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
        const panel = page.locator(".db-wallet-tab-panel, .db-tabs-row, main").last();
        bodyText = ((await panel.innerText().catch(() => "")) || (await page.locator("body").innerText().catch(() => ""))).replace(/\s+/g, " ").trim();
        const leak = OLD_LEAK.test(bodyText);
        const technical = !leak && TECHNICAL.test(bodyText);
        await evidence.saveScreenshot(page, testInfo, {
          ac: AC, title: "TC-01 History tab – no internal API message",
          steps: [`${WL_URL}/en/data-balance · History tab`, `Old leak present: ${leak ? "YES" : "no"}`, `Other technical wording: ${technical ? "YES" : "no"}`],
          expected: ['No "History isn\'t available yet…" leak', "No raw API / technical details"], status: leak || technical ? "failed" : undefined,
        });
        expect(bodyText, "old internal API message must be gone").not.toMatch(OLD_LEAK);
        expect(bodyText, "no raw technical details").not.toMatch(TECHNICAL);
      });
    } finally {
      await ctx.close();
    }
  });

  test(`TC-02 History tab shows a list or a friendly message ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.setCase("TC-02 List or friendly message");
    const { ctx, page } = await newShopper(browser);
    try {
      const { signedIn } = await openWallet(page);
      test.skip(!signedIn, "Magic link no longer signs in");
      await page.locator(".db-tab").filter({ hasText: /History/i }).first().click();
      await page.locator(".db-history-list, .db-empty-plans, .wl-history-error").first().waitFor({ state: "visible", timeout: 30000 }).catch(() => {});
      await page.locator(".wl-history-skeleton").first().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});

      const items = await page.$$eval(".db-history-card", (cards) =>
        cards.map((c) => ({
          name: ((c.querySelector(".db-history-name") as HTMLElement)?.innerText || "").trim(),
          status: ((c.querySelector("[class*='db-history-badge']") as HTMLElement)?.innerText || "").trim(),
          date: ((c.querySelector(".db-history-date") as HTMLElement)?.innerText || "").trim(),
        })),
      ).catch(() => []);
      // Read the empty-state text only if it is actually present (bounded, never an open-ended wait).
      const readIfPresent = async (sel: string) => {
        const loc = page.locator(sel).first();
        if (!(await loc.count())) return "";
        return (await loc.innerText({ timeout: 3000 }).catch(() => "")).trim();
      };
      const emptyTitle = await readIfPresent(".db-empty-plans__title");
      const emptySub = await readIfPresent(".db-empty-plans__subtitle");

      // A real list (each item has plan + status + date) OR a friendly empty/error state.
      const listOk = items.length > 0 && items.every((i) => i.name && i.status && i.date);
      const emptyOk = !!emptyTitle && !OLD_LEAK.test(`${emptyTitle} ${emptySub}`) && !TECHNICAL.test(`${emptyTitle} ${emptySub}`);
      const ok = listOk || emptyOk;

      await page.locator(".db-history-list, .db-empty-plans").first().scrollIntoViewIfNeeded().catch(() => {});
      await evidence.saveScreenshot(page, testInfo, {
        ac: AC, title: "TC-02 History tab – purchase list or friendly message",
        steps: items.length
          ? [`${items.length} history item(s)`, ...items.slice(0, 6).map((i, n) => `#${n + 1} ${i.name} · ${i.status} · ${i.date}`)]
          : [`Empty state: "${emptyTitle}" — "${emptySub}"`],
        expected: ["A purchase list (plan · status · date) OR a customer-friendly empty/error message"], status: ok ? undefined : "failed",
      });
      const scratch = await ctx.newPage(); // same context — survives even if the run is tearing down
      await evidence.saveDataCard(scratch, testInfo, "History tab contents",
        items.length
          ? `<table><tr><th>#</th><th>Plan</th><th>Status</th><th>Date</th></tr>${items.map((i, n) => `<tr><td>${n + 1}</td><td>${esc(i.name)}</td><td>${esc(i.status)}</td><td>${esc(i.date)}</td></tr>`).join("")}</table>`
          : `<p>Empty state — <b>${esc(emptyTitle)}</b><br>${esc(emptySub)}</p>`,
        { ac: AC, title: "TC-02 History tab data", steps: [listOk ? "valid list" : emptyOk ? "friendly empty/error" : "neither"], expected: ["list or friendly message"], status: ok ? undefined : "failed" }).catch(() => {});
      await scratch.close().catch(() => {});

      expect(ok, listOk ? "" : `History shows neither a valid list nor a friendly message (title="${emptyTitle}")`).toBe(true);
    } finally {
      await ctx.close();
    }
  });
});
