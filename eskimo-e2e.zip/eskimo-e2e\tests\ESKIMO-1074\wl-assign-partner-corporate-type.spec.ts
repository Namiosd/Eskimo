// ESKIMO-1074 – Admin › White Label › Website Templates → Assign / Reassign Partner: the Partner dropdown must list only
// partners whose Corporate Program is ON with Type = White label (corporateType 1) and that have no website yet.
// Bug (stage 27/10): Corporate-type partners (test_net, partnernetwork, nantest, partnerofduc, Ciu Kayoko, Ciu Ciu partner)
// were listed in the Reassign dialog of "Website Template for partner WLBe2e".
//   TC-01 Reassign (WLBe2e row): every option is Corporate ON + Type White label
//   TC-02 Search each Corporate partner from the ticket → not listed
//   TC-03 Search each White label partner from the ticket → listed unless it already owns another website
//   TC-04 Assign (row without partner): every option is Corporate ON + Type White label (blocked if no such row)
//   TC-05 Partners that own another website are not listed; the current owner keeps its option in Reassign
// Read-only: dialogs are opened, read and closed with Cancel. Nothing is assigned.
// Option label = partnerName, value = partnerID (PN…): FE maps POST /api/partner/search rows (captured from the network).
// Evidence: npm run report:evidence -- ESKIMO-1074 wl-assign-partner-corporate-type
import { test, expect, type BrowserContext, type Locator, type Page, type TestInfo } from "@playwright/test";
import { ADMIN_URL, login } from "../_support/eskimo";
import { api, tokenOf, websites } from "../_support/whitelabel";
import { createEvidence, esc, type EvidenceMeta } from "../_support/evidence";

const ID = "@ESKIMO-1074";
const evidence = createEvidence("ESKIMO-1074", "wl-assign-partner-corporate-type");
const REASSIGN_ROW = /partner WLBe2e/i;
const WL_TYPE = 1; // PartnerCorporate.js: <Select.Option value={1}>White label</Select.Option>
const CORPORATE_PARTNERS = [
  ["test_net", "PN153886"], ["partnernetwork", "PN607757"], ["nantest", "PN708302"],
  ["partnerofduc", "PN139647"], ["Ciu Kayoko", "PN164473"], ["Ciu Ciu partner", "PN121270"],
];
const WL_PARTNERS = [
  ["QC976 NoCorp 1792634616489", "PN102463"], ["WLBe2e", "PN847236"],
  ["WhiteLabel Partner 3", "PN175128"], ["white label test Dev", "PN105327"],
];
const NAV = ["Admin STAGE (Super Admin) → White Label › Website Templates"];

test.setTimeout(300_000);

let ctx: BrowserContext;
let page: Page;
let token = "";
let sites: any[] = [];

// /white-label-templates needs the "White Label" permission module → Super Admin (see ESKIMO-953)
test.beforeAll(async ({ browser }) => {
  if (!process.env.E2E_SUPERADMIN_EMAIL || !process.env.E2E_SUPERADMIN_PASSWORD) throw new Error("Set E2E_SUPERADMIN_EMAIL / E2E_SUPERADMIN_PASSWORD");
  let last: unknown;
  for (let i = 1; i <= 3 && !ctx; i++) {
    const c = await browser.newContext({ baseURL: ADMIN_URL, viewport: { width: 1600, height: 1000 } });
    const p = await c.newPage();
    try { await login(p, `${ADMIN_URL}/#/login`, process.env.E2E_SUPERADMIN_EMAIL, process.env.E2E_SUPERADMIN_PASSWORD); ctx = c; page = p; }
    catch (e) { last = e; await c.close(); }
  }
  if (!ctx) throw last;
  token = await tokenOf(page);
  sites = await websites(token);
});
test.afterAll(async () => { await ctx?.close(); });

async function card(testInfo: TestInfo, html: string, meta: EvidenceMeta) {
  const scratch = await ctx.newPage();
  await evidence.saveDataCard(scratch, testInfo, meta.title, html, meta);
  await scratch.close();
}
const table = (head: string[], rows: unknown[][]) =>
  `<table><tr>${head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr>${rows.map((r) => `<tr>${r.map((c) => `<td>${typeof c === "string" && c.startsWith("<span") ? c : esc(c)}</td>`).join("")}</tr>`).join("")}</table>`;
const mark = (ok: boolean, text: string) => `<span class="${ok ? "ok" : "bad"}">${esc(text)}</span>`;

async function closeModals() {
  for (let i = 0; i < 3 && (await page.locator(".ant-modal-wrap:visible").count()) > 0; i++) {
    await page.keyboard.press("Escape");
    await page.locator(".ant-modal-wrap:visible").getByRole("button", { name: /Cancel/i }).first().click({ timeout: 3000 }).catch(() => {});
    await page.waitForTimeout(500);
  }
}

async function openTemplates() {
  await closeModals();
  const anyRow = page.locator(".ant-table-row").filter({ hasText: /Website Template/ }).first();
  if (await anyRow.isVisible().catch(() => false)) return;
  const link = page.locator("a[href*='white-label-templates']").first();
  let loaded = false;
  for (let i = 0; i < 3 && !loaded; i++) {
    if (i > 0 || !page.url().includes("#/")) await page.goto(`${ADMIN_URL}/#/dashboard`, { waitUntil: "domcontentloaded" });
    if (await link.waitFor({ state: "attached", timeout: 60000 }).then(() => true).catch(() => false)) {
      await link.evaluate((el) => el.scrollIntoView({ block: "center" })).catch(() => {});
      await link.click({ timeout: 10000 }).catch(() => {});
      loaded = await anyRow.waitFor({ timeout: 45000 }).then(() => true).catch(() => false);
    }
    if (!loaded) {
      await page.evaluate(() => { location.hash = "#/white-label-templates"; });
      loaded = await anyRow.waitFor({ timeout: 30000 }).then(() => true).catch(() => false);
    }
  }
  expect(loaded, "Website Templates table loaded").toBeTruthy();
}

type Row = { id: string; partnerID: string; partnerName: string };
const isSearch = (r: { url(): string; request(): { method(): string } }) => /\/api\/partner\/search/i.test(r.url()) && r.request().method() === "POST";

/** Open the Assign/Reassign dialog of a row and its Partner dropdown; returns the options + the BE rows behind them. */
async function openPicker(row: Locator) {
  await openTemplates();
  const respP = page.waitForResponse(isSearch, { timeout: 90000 });
  const btn = row.getByRole("button", { name: /Reassign Partner|Assign Partner/ });
  const label = (await btn.first().innerText()).trim();
  await btn.first().click();
  const modal = page.locator(".ant-modal:visible").filter({ hasText: "Assign Partner" }).first();
  await modal.waitFor({ timeout: 30000 });
  const rows: Row[] = (await (await respP).json().catch(() => null))?.data?.data ?? [];
  await modal.locator(".ant-select").first().click();
  const dd = modal.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ timeout: 15000 });
  await expect(dd.locator(".ant-spin")).toHaveCount(0, { timeout: 30000 }).catch(() => {});
  return { modal, dd, label, rows, options: await allOptions(dd) };
}

/** antd Select virtualises its list: scroll through it to collect every option (label + value). */
async function allOptions(dd: Locator) {
  const seen = new Map<string, string>();
  const holder = dd.locator(".rc-virtual-list-holder").first();
  for (let i = 0; i < 60; i++) {
    const batch = await dd.locator(".ant-select-item-option").evaluateAll((els) => els.map((e) => ({ label: (e as HTMLElement).innerText.trim(), title: e.getAttribute("title") || "" })));
    const before = seen.size;
    batch.forEach((o) => seen.set(o.label, o.title));
    const moved = await holder.evaluate((el) => { const t = el.scrollTop; el.scrollTop += 200; return el.scrollTop !== t; }).catch(() => false);
    if (!moved && seen.size === before) break;
    await page.waitForTimeout(150);
  }
  await holder.evaluate((el) => { el.scrollTop = 0; }).catch(() => {});
  return [...seen.keys()].filter(Boolean);
}

/** Type into the picker and return the options shown. The deployed FE loads every partner once (pageSize 10000) and
 *  filters locally, so typing may not hit the BE: a search response is used only if one comes. */
async function search(modal: Locator, text: string) {
  const input = modal.locator(".ant-select-selection-search-input").first();
  const respP = page.waitForResponse(isSearch, { timeout: 3000 }).catch(() => null);
  await input.fill(text);
  await respP;
  const dd = modal.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ timeout: 15000 });
  await expect(dd.locator(".ant-spin")).toHaveCount(0, { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(500);
  const options = (await dd.locator(".ant-select-item-option").allInnerTexts()).map((t) => t.trim()).filter(Boolean);
  const empty = await dd.getByText("No available partner").isVisible().catch(() => false);
  return { options, empty };
}

/** Partner GUID by name + partnerID via the admin partner search (all types). */
async function partnerGuid(name: string, code: string) {
  const s = await api(token, "POST", "/api/partner/search", { pageIndex: 1, pageSize: 50, searchText: name, status: null, partnerType: null, type: null, sortBy: { fieldName: "CreatedOn", ascending: false } });
  return ((s.json?.data?.data ?? []) as Row[]).find((x) => x.partnerID === code)?.id;
}

async function cancel(modal: Locator) {
  await page.keyboard.press("Escape");
  await modal.getByRole("button", { name: /Cancel/i }).click({ timeout: 5000 }).catch(() => closeModals());
}

const corpCache = new Map<string, { hasCorporate: boolean; corporateType: number | null }>();
async function corporateOf(guid: string) {
  if (!corpCache.has(guid)) {
    const d = await api(token, "GET", `/api/partner/v2/${guid}`);
    const c = d.json?.data?.configuration ?? {};
    corpCache.set(guid, { hasCorporate: !!c.hasCorporate, corporateType: c.corporateSetting?.corporateType ?? null });
  }
  return corpCache.get(guid)!;
}
const typeName = (t: number | null) => (t === WL_TYPE ? "White label" : t === null ? "—" : `Corporate (${t})`);

/** Each option → partner (via the captured search rows, else a direct search) → Corporate Program status/type. */
async function classify(options: string[], rows: Row[]) {
  const out: { label: string; code: string; hasCorporate: boolean | null; type: number | null; ok: boolean }[] = [];
  for (const label of options) {
    let r = rows.find((x) => String(x.partnerName).trim() === label || x.partnerID === label);
    if (!r) {
      const s = await api(token, "POST", "/api/partner/search", { pageIndex: 1, pageSize: 50, searchText: label, status: null, partnerType: null, type: null, sortBy: { fieldName: "CreatedOn", ascending: false } });
      r = (s.json?.data?.data ?? []).find((x: Row) => String(x.partnerName).trim() === label);
    }
    if (!r) { out.push({ label, code: "?", hasCorporate: null, type: null, ok: false }); continue; }
    const c = await corporateOf(r.id);
    out.push({ label, code: r.partnerID, hasCorporate: c.hasCorporate, type: c.corporateType, ok: c.hasCorporate && c.corporateType === WL_TYPE });
  }
  return out;
}
const classifyTable = (list: Awaited<ReturnType<typeof classify>>) =>
  table(["#", "Option", "Partner ID", "Corporate Program", "Type", "Eligible"],
    list.map((x, i) => [i + 1, x.label, x.code, x.hasCorporate === null ? "not found" : x.hasCorporate ? "ON" : "OFF", typeName(x.type), mark(x.ok, x.ok ? "yes" : "NO")]));

const ownerOf = (code: string) => sites.find((w) => w.partnerId === code);

test(`TC-01 Reassign: options are only White label partners ${ID}`, async ({}, testInfo) => {
  evidence.resetIfFirstAttempt(testInfo);
  evidence.setCase("TC-01 Reassign Partner – WLBe2e row");
  await openTemplates();
  const row = page.locator(".ant-table-row").filter({ hasText: REASSIGN_ROW }).first();
  const { modal, label, rows, options } = await openPicker(row);
  const list = await classify(options, rows);
  const bad = list.filter((x) => !x.ok);
  await evidence.saveScreenshot(page, testInfo, {
    ac: "Bug", title: `${label} dialog – ${options.length} partners listed, ${bad.length} not White label`,
    steps: [...NAV, "Row 'Website Template for partner WLBe2e' → " + label, "Open the Partner dropdown"],
    expected: ["Only partners with Corporate Program ON and Type = White label"],
    status: bad.length ? "failed" : undefined,
  });
  await cancel(modal);
  await card(testInfo, classifyTable(list), {
    ac: "Bug", title: `TC-01 every option checked via GET /api/partner/v2/{id}: ${bad.length ? `${bad.length} NOT eligible (${bad.map((b) => b.label).join(", ")})` : "all White label"}`,
    steps: ["For each option: partner → configuration.hasCorporate + corporateSetting.corporateType"],
    expected: ["hasCorporate = true", "corporateType = 1 (White label) for every option"],
    status: bad.length ? "failed" : undefined,
  });
  expect(options.length, "dropdown has options").toBeGreaterThan(0);
  expect(bad.map((b) => `${b.label} (${b.code}) ${typeName(b.type)}`), "non-White-label partners listed").toEqual([]);
});

test(`TC-02 Corporate-type partners from the ticket are not listed ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-02 Search Corporate partners");
  await openTemplates();
  const row = page.locator(".ant-table-row").filter({ hasText: REASSIGN_ROW }).first();
  const { modal } = await openPicker(row);
  const results: { name: string; code: string; type: string; listed: boolean }[] = [];
  for (const [name, code] of CORPORATE_PARTNERS) {
    const s = await search(modal, name);
    const listed = s.options.some((o) => o.toLowerCase() === name.toLowerCase());
    const guid = await partnerGuid(name, code);
    const type = guid ? typeName((await corporateOf(guid)).corporateType) : "(partner not found)";
    results.push({ name, code, type, listed });
    await evidence.saveScreenshot(page, testInfo, {
      ac: "Bug", title: `Search "${name}" → ${listed ? "LISTED" : s.empty ? "No available partner" : `not listed (${s.options.join(", ") || "-"})`}`,
      steps: [...NAV, "WLBe2e row → Reassign Partner", `Type "${name}" (${code}, Corporate Type: ${type}) in Partner`],
      expected: [`"${name}" is not in the dropdown (Corporate Program Type = Corporate)`],
      status: listed ? "failed" : undefined,
    });
  }
  await cancel(modal);
  const listed = results.filter((r) => r.listed);
  await card(testInfo, table(["Partner", "ID", "Corporate Type (API)", "Listed in dropdown"], results.map((r) => [r.name, r.code, r.type, mark(!r.listed, r.listed ? "YES" : "no")])), {
    ac: "Bug", title: `TC-02 summary – ${listed.length}/${results.length} Corporate partners still listed`,
    steps: CORPORATE_PARTNERS.map(([n, c]) => `Search ${n} (${c})`), expected: ["None of the 6 Corporate partners can be selected"],
    status: listed.length ? "failed" : undefined,
  });
  expect(listed.map((r) => r.name), "Corporate partners listed").toEqual([]);
});

test(`TC-03 White label partners from the ticket stay selectable unless they own a website ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-03 Search White label partners");
  await openTemplates();
  const row = page.locator(".ant-table-row").filter({ hasText: REASSIGN_ROW }).first();
  const current = sites.find((w) => w.partnerId === "PN847236");
  const { modal } = await openPicker(row);
  const results: { name: string; code: string; owns: string; expected: boolean; listed: boolean; corp: string }[] = [];
  for (const [name, code] of WL_PARTNERS) {
    const s = await search(modal, name);
    const listed = s.options.some((o) => o.toLowerCase() === name.toLowerCase());
    const guid = await partnerGuid(name, code);
    const c = guid ? await corporateOf(guid) : null;
    const own = ownerOf(code);
    const eligibleType = !!c && c.hasCorporate && c.corporateType === WL_TYPE;
    const isCurrent = own && current && own.id === current.id;
    const expected = isCurrent ? true : eligibleType && !own;
    const corp = c ? `${c.hasCorporate ? "ON" : "OFF"} / ${typeName(c.corporateType)}` : "(partner not found)";
    results.push({ name, code, owns: own ? `${own.name}${isCurrent ? " (this website)" : ""}` : "—", expected, listed, corp });
    await evidence.saveScreenshot(page, testInfo, {
      ac: "Bug", title: `Search "${name}" → ${listed ? "listed" : "not listed"} (expected ${expected ? "listed" : "not listed"})`,
      steps: [...NAV, "WLBe2e row → Reassign Partner", `Type "${name}" (${code}); Corporate ${corp}; website: ${own ? own.name : "none"}`],
      expected: [isCurrent ? "Current owner keeps its option" : own ? "Not listed: already owns a website" : eligibleType ? "Listed: White label partner without website" : "Not listed: Corporate Program not White label/ON"],
      status: listed === expected ? undefined : "failed",
    });
  }
  await cancel(modal);
  const wrong = results.filter((r) => r.listed !== r.expected);
  await card(testInfo, table(["Partner", "ID", "Corporate (API)", "Owns website", "Expected", "Listed"], results.map((r) => [r.name, r.code, r.corp, r.owns, r.expected ? "listed" : "not listed", mark(r.listed === r.expected, r.listed ? "listed" : "not listed")])), {
    ac: "Bug", title: `TC-03 summary – ${wrong.length} mismatch(es)`,
    steps: WL_PARTNERS.map(([n, c]) => `Search ${n} (${c})`), expected: ["White label partners without website are listed; owners of another website are not"],
    status: wrong.length ? "failed" : undefined,
  });
  expect(wrong.map((r) => `${r.name}: listed=${r.listed}, expected=${r.expected}`)).toEqual([]);
});

test(`TC-04 Assign (row without partner): options are only White label partners ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-04 Assign Partner – unassigned website");
  await openTemplates();
  const free = sites.find((w) => !w.partnerId);
  if (!free) {
    await card(testInfo, table(["Website", "Partner"], sites.map((w) => [w.name, w.partnerId])), {
      ac: "Bug", title: "No Partner Website without a partner on stage – Assign Partner not reachable (blocked)", status: "pending",
      steps: ["GET /api/white-label/websites"], expected: ["At least one website with no partner (not created by QC)"],
    });
    test.skip(true, "blocked: every stage website already has a partner");
  }
  const row = page.locator(".ant-table-row").filter({ hasText: free!.name }).first();
  const { modal, label, rows, options } = await openPicker(row);
  const list = await classify(options, rows);
  const bad = list.filter((x) => !x.ok);
  await evidence.saveScreenshot(page, testInfo, {
    ac: "Bug", title: `${label} dialog (${free!.name}) – ${options.length} partners listed, ${bad.length} not White label`,
    steps: [...NAV, `Row '${free!.name}' (no partner) → ${label}`, "Open the Partner dropdown"],
    expected: ["Only partners with Corporate Program ON and Type = White label, without website"],
    status: bad.length ? "failed" : undefined,
  });
  await cancel(modal);
  await card(testInfo, classifyTable(list), {
    ac: "Bug", title: `TC-04 options checked via API: ${bad.length ? `${bad.length} NOT eligible` : "all White label"}`,
    steps: ["For each option: GET /api/partner/v2/{id}"], expected: ["hasCorporate = true, corporateType = 1"],
    status: bad.length ? "failed" : undefined,
  });
  expect(bad.map((b) => `${b.label} (${b.code}) ${typeName(b.type)}`), "non-White-label partners listed").toEqual([]);
});

test(`TC-05 Partners owning another website are not listed ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-05 Website owners excluded");
  await openTemplates();
  const row = page.locator(".ant-table-row").filter({ hasText: REASSIGN_ROW }).first();
  const current = sites.find((w) => w.partnerId === "PN847236");
  const { modal, rows, options } = await openPicker(row);
  await cancel(modal);
  const codeOf = (label: string) => rows.find((r) => String(r.partnerName).trim() === label)?.partnerID;
  const shownCodes = new Set(options.map(codeOf).filter(Boolean));
  const owners = sites.filter((w) => w.partnerId);
  const res = owners.map((w) => {
    const isCurrent = current && w.id === current.id;
    const listed = shownCodes.has(w.partnerId);
    return { site: w.name, code: w.partnerId, partner: w.partnerName ?? "", isCurrent: !!isCurrent, listed, ok: isCurrent ? listed : !listed };
  });
  const bad = res.filter((r) => !r.ok);
  await card(testInfo, table(["Website", "Owner", "Owner ID", "Expected", "Listed in Reassign (WLBe2e)"], res.map((r) => [r.site, r.partner, r.code, r.isCurrent ? "listed (current owner)" : "not listed", mark(r.ok, r.listed ? "listed" : "not listed")])), {
    ac: "Bug", title: `TC-05 ${owners.length} website owners vs ${options.length} options – ${bad.length} mismatch(es)`,
    steps: ["GET /api/white-label/websites (owners)", "Options of Reassign Partner on the WLBe2e row"],
    expected: ["A partner that owns another website is not listed", "WLBe2e (current owner) keeps its option"],
    status: bad.length ? "failed" : undefined,
  });
  expect(bad.map((r) => `${r.site} / ${r.code}`)).toEqual([]);
});
