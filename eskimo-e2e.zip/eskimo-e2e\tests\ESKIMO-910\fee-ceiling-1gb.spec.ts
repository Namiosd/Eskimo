// ESKIMO-910 fee-ceiling follow-up (2026-10-28): Any Fixed 1GB vs a specific plan of a country it warns about.
//   C1G-01 UI: add "Any Fixed 1GB" = 80% -> warning list ("<plan> final bill < 1") + result of Ok (saved or rejected).
//   C1G-02 UI: add the specific plan "Vietnam 1GB" (one of the warned plans, $3.90) = 80% -> warning? saved?
//   C1G-03 API: same fee 74..80 and 99% for Vietnam 1GB (specific) vs Any Fixed 1GB, one rule per request.
// Partner WhiteLabel Partner 2 (PN101609), STAGE. The user's rules are read live first and restored in afterAll.
import { test, expect, type Browser, type Locator, type Page, type TestInfo } from "@playwright/test";
import { createEvidence, esc } from "../_support/evidence";
import { api, apiMessage, tokenOf, findPartner, readPartner, corporateBody, openCorporate, corporate, focus, clickOk, adminSessionRetry as adminSess } from "../_support/whitelabel";

const ID = "@ESKIMO-910";
const AC = "WL Application Fee - save ceiling: Any Fixed 1GB vs specific plan";
const evidence = createEvidence("ESKIMO-910", "fee-ceiling-1gb");
const P2 = process.env.E2E_WL_PARTNER_NAME || "WhiteLabel Partner 2";
const VN_1GB_ID = "733e74e8-076d-4c8a-0f21-08dbd475e39d";
const FEE = 80;

let snap: { p: { id: string; code: string; name: string }; plans: any[]; fee: number | null; feBody?: any; setting?: any } | null = null;
const plansOf = (d: any) => d?.configuration?.whiteLabelSetting?.plans ?? [];
const describe = (ps: any[]) => ps.map((p) => (p.dataPlanName ?? (p.dataPlanId ? "plan " + String(p.dataPlanId).slice(0, 8) : p.dataPlanUnitValue ? "Any Fixed " + p.dataPlanUnitValue + "GB" : "rule")) + " = " + p.value + "%").join(" | ");
const table = (head: string[], rows: unknown[][]) =>
  "<table><tr>" + head.map((h) => "<th>" + esc(h) + "</th>").join("") + "</tr>" + rows.map((r) => "<tr>" + r.map((c) => "<td>" + esc(c) + "</td>").join("") + "</tr>").join("") + "</table>";
async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const feeRows = (drawer: Locator) => corporate(drawer).body.locator(".list-data-merchant .merchant-item");
async function labelsLoaded(page: Page, drawer: Locator) {
  for (const until = Date.now() + 45000; Date.now() < until;) {
    const labels = await feeRows(drawer).locator(".ant-select").first().locator(".ant-select-selection-item").allInnerTexts().catch(() => [] as string[]);
    if (!labels.some((l) => /^[A-Z_]+\||^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(l.trim()))) return;
    await page.waitForTimeout(1500);
  }
}
/** Add a rule via the UI, type the fee, return the warning lines shown under it (before Ok). */
async function addRuleUI(page: Page, drawer: Locator, search: string, pick: RegExp, fee: number) {
  await page.locator(".custom-button-add-gift-code").filter({ hasText: /Application Fee/i }).first().click();
  await page.waitForTimeout(900);
  const row = feeRows(drawer).last();
  await row.locator(".ant-select").first().locator(".ant-select-selector").click();
  const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ state: "visible", timeout: 15000 });
  await dd.locator(".ant-select-item-option").first().waitFor({ state: "visible", timeout: 15000 }).catch(() => {});
  await page.keyboard.type(search, { delay: 40 });
  await page.waitForTimeout(1200);
  await dd.locator(".ant-select-item-option").filter({ hasText: pick }).first().click();
  const input = row.locator("input.ant-input").first();
  await input.fill(String(fee));
  await focus(input);
  await page.waitForTimeout(800);
  await row.scrollIntoViewIfNeeded().catch(() => {});
  const warn = (await row.locator(".warning-list").allInnerTexts().catch(() => [] as string[])).join("\n").split(/\n+/).map((x) => x.trim()).filter((x) => /final bill/i.test(x));
  return { row, warn };
}

test.describe("ESKIMO-910 fee ceiling 1GB " + ID, () => {
  test.describe.configure({ mode: "serial", timeout: 10 * 60 * 1000 });

  test.beforeAll(async ({ browser }) => {
    test.setTimeout(300000);
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const p = await findPartner(t, P2);
      if (!p) throw new Error("Partner not found");
      const now = await readPartner(t, p);
      snap = { p, plans: plansOf(now.detail), fee: now.fee, setting: now.detail?.configuration?.corporateSetting };
      console.log("[C1G] user config: base=" + now.fee + " rules=" + describe(snap.plans));
    } finally { await ctx.close(); }
  });

  test.afterAll(async ({ browser }, testInfo) => {
    test.setTimeout(300000);
    if (!snap?.feBody) { console.log("[C1G] nothing saved - no restore needed"); return; }
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const b = corporateBody(snap.feBody, true, snap.setting);
      b.configuration.whiteLabelSetting = { plans: snap.plans.map((p) => ({ ...p, id: "" })) };
      const r = await api(t, "PUT", "/api/partner/v2", b, 2);
      const now = await readPartner(t, snap.p);
      const key = (ps: any[]) => JSON.stringify(ps.map((p: any) => [p.dataPlanId, p.dataPlanUnitValue, p.countryId, p.dataPlanTierEnum, Number(p.value)]));
      const ok = key(plansOf(now.detail)) === key(snap.plans) && now.fee === snap.fee;
      evidence.setCase("Cleanup - restore");
      await card(browser, testInfo, "Restore - Partner 2 back to the user's rules", "<p>" + esc("PUT -> " + r.status + " " + apiMessage(r.json) + " ; now: base " + now.fee + " ; " + describe(plansOf(now.detail))) + "</p>",
        { ac: AC, title: "Restore (cleanup)", steps: ["Before: " + describe(snap.plans), "After: " + describe(plansOf(now.detail))], expected: ["Same rules as before the test"], status: ok ? undefined : "failed" });
      console.log("[C1G] restore " + (ok ? "OK (verified)" : "NOT VERIFIED - restore manually!"));
    } finally { await ctx.close(); }
  });

  test("C1G-01 UI: Any Fixed 1GB = " + FEE + "% (warning + save result) " + ID, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("C1G-01 Any Fixed 1GB " + FEE + "%");
    const { ctx, page } = await adminSess(browser);
    try {
      const o = await openCorporate(page, P2);
      await labelsLoaded(page, o.drawer);
      const { warn } = await addRuleUI(page, o.drawer, "Any Fixed 1GB", /^Any Fixed 1\s*GB$/i, FEE);
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "C1G-01 Any Fixed 1GB = " + FEE + " before Ok", steps: ["Apply To: Any Fixed 1GB", "Fee: " + FEE + "%", "Warnings shown: " + warn.length + (warn.length ? " (" + warn.slice(0, 6).join(" ; ") + (warn.length > 6 ? " ..." : "") + ")" : "")], expected: ["Fee validation is the same for group and specific rules"] });
      const saved = await clickOk(page, o.drawer);
      if (saved.status === 200 && saved.reqBody?.configuration?.hasCorporate) snap!.feBody = saved.reqBody;
      await page.waitForTimeout(800);
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "C1G-01 After Ok: " + saved.status + " " + saved.message, steps: ["PUT /api/partner/v2 -> " + saved.status + " " + saved.message, "Toast: " + (saved.toasts.join(" | ") || "-")], expected: ["Saved or rejected consistently with C1G-02"] });
      (snap as any).anyFixed = { status: saved.status, message: saved.message, warn };
      console.log("[C1G] C1G-01 Any Fixed 1GB " + FEE + "% warnings=" + warn.length + " save=" + saved.status + " " + saved.message);
    } finally { await ctx.close(); }
  });

  test("C1G-02 UI: specific plan Vietnam 1GB = " + FEE + "% (warned plan) " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("C1G-02 Vietnam 1GB " + FEE + "%");
    const { ctx, page } = await adminSess(browser);
    try {
      const o = await openCorporate(page, P2);
      await labelsLoaded(page, o.drawer);
      // if C1G-01 was saved, drop the Any Fixed 1GB row so this save tests the specific plan alone
      const rows = feeRows(o.drawer);
      for (let i = (await rows.count()) - 1; i >= 0; i--) {
        const label = (await rows.nth(i).locator(".ant-select").first().locator(".ant-select-selection-item").first().innerText().catch(() => "")).trim();
        if (/^Any Fixed 1\s*GB$/i.test(label)) {
          await rows.nth(i).locator(".merchant-item-delete button").first().click();
          const confirm = page.locator(".ant-modal-confirm:visible, .ant-popover:visible").getByRole("button", { name: /OK|Confirm|Yes/i }).first();
          if (await confirm.isVisible({ timeout: 2000 }).catch(() => false)) await confirm.click();
        }
      }
      const { warn } = await addRuleUI(page, o.drawer, "Vietnam 1GB", /^Vietnam 1\s*GB$/i, FEE);
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "C1G-02 Vietnam 1GB = " + FEE + " before Ok", steps: ["Apply To: Vietnam 1GB (specific plan, $3.90 - listed in the C1G-01 warning)", "Fee: " + FEE + "%", "Warnings shown: " + warn.length], expected: ["Same check as Any Fixed 1GB: final bill 3.90 x " + (100 - FEE) + "% = $" + (3.9 * (100 - FEE) / 100).toFixed(2) + " < $1"] });
      const saved = await clickOk(page, o.drawer);
      if (saved.status === 200 && saved.reqBody?.configuration?.hasCorporate) snap!.feBody = saved.reqBody;
      await page.waitForTimeout(800);
      const any = (snap as any).anyFixed ?? {};
      const consistent = (saved.status === 200) === (any.status === 200) && (warn.length > 0) === ((any.warn ?? []).length > 0);
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "C1G-02 After Ok: " + saved.status + " " + saved.message, steps: ["PUT /api/partner/v2 -> " + saved.status + " " + saved.message, "Any Fixed 1GB " + FEE + "%: warnings " + (any.warn ?? []).length + ", save " + any.status, "Vietnam 1GB " + FEE + "%: warnings " + warn.length + ", save " + saved.status], expected: ["Specific plan and the group rule covering it are validated the same way"], status: consistent ? undefined : "failed" });
      console.log("[C1G] C1G-02 Vietnam 1GB " + FEE + "% warnings=" + warn.length + " save=" + saved.status + " " + saved.message + " consistent=" + consistent);
      (snap as any).consistent = consistent; // asserted at the end of C1G-03 so the API table is not skipped (serial)
    } finally { await ctx.close(); }
  });

  test("C1G-03 API: Vietnam 1GB vs Any Fixed 1GB, fee 74..80 and 99 " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("C1G-03 API side by side");
    test.skip(!snap?.feBody, "no FE body captured (nothing saved in C1G-01/02)");
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const put = async (rule: any) => { const b = corporateBody(snap!.feBody, true, snap!.setting); b.configuration.whiteLabelSetting = { plans: [rule] }; const r = await api(t, "PUT", "/api/partner/v2", b, 1); return r.status + " " + apiMessage(r.json); };
      const mk = (extra: any, v: number) => ({ id: "", dataPlanId: null, regionId: null, countryId: null, value: String(v), priceDiscount: 0, networkPartnerCommissionPercentage: null, price: null, dataPlanTierEnum: null, unlimitedDayCount: null, dataPlanUnitValue: null, ...extra });
      const rows: unknown[][] = [];
      for (const v of [74, 75, 76, 78, 80, 99]) {
        rows.push([v + "%", "$" + (3.9 * (100 - v) / 100).toFixed(3), await put(mk({ dataPlanId: VN_1GB_ID, dataPlanName: "Vietnam 1GB" }, v)), await put(mk({ type: 5, dataPlanName: "Any Fixed 1GB", dataPlanUnitValue: 1 }, v))]);
      }
      await card(browser, testInfo, "C1G-03 - PUT /api/partner/v2, one rule per request",
        table(["Fee", "Final bill of Vietnam 1GB ($3.90)", "Vietnam 1GB (specific plan)", "Any Fixed 1GB (178 plans incl. Vietnam 1GB)"], rows),
        { ac: AC, title: "C1G-03 DATA side by side", steps: rows.map((r) => r.join(" | ")), expected: ["Both rules follow the same limit"], status: rows.every((r) => String(r[2]).slice(0, 3) === String(r[3]).slice(0, 3)) ? undefined : "failed" });
      console.log("[C1G] C1G-03 " + rows.map((r) => r.join(" / ")).join(" ;; "));
      expect.soft((snap as any).consistent, "C1G-02: Vietnam 1GB validated like Any Fixed 1GB").toBe(true);
      expect.soft(rows.every((r) => String(r[2]).slice(0, 3) === String(r[3]).slice(0, 3)), "C1G-03: same API result for both rules").toBe(true);
    } finally { await ctx.close(); }
  });
});
