// ESKIMO-910 / ESKIMO-1064 follow-up (2026-10-27): evidence that the save-time fee ceiling is inconsistent.
//   CEIL-01 UI: specific plan "Japan 10GB" = 99% -> Ok -> saved (200), reopen shows 99.
//   (run order: CEIL-01, CEIL-03, CEIL-02 so the API table is not skipped when CEIL-02 fails)
//   CEIL-02 UI: "Any Fixed 10GB" = 99% -> Ok -> 400 "White label discount is invalid" (rule covering the same plan size).
//   CEIL-03 API: same fee 90..99% for Japan 10GB vs Any Fixed 10GB (one rule per request), step by step.
// Partner: WhiteLabel Partner 2 (PN101609), STAGE. The user's rules are read live first and restored after (afterAll).
import { test, expect, type Browser, type Locator, type Page, type TestInfo } from "@playwright/test";
import { createEvidence, esc } from "../_support/evidence";
import { api, apiMessage, tokenOf, findPartner, readPartner, corporateBody, openCorporate, corporate, focus, clickOk, adminSessionRetry as adminSess } from "../_support/whitelabel";

const ID = "@ESKIMO-910";
const AC = "WL Application Fee - save-time ceiling (ESKIMO-1064 follow-up)";
const evidence = createEvidence("ESKIMO-910", "fee-ceiling-evidence");
const P2 = process.env.E2E_WL_PARTNER_NAME || "WhiteLabel Partner 2";
const JAPAN_10GB_PLAN_ID = "3a16ecaa-4554-48fc-0f06-08dbd475e39d";

let snap: { p: { id: string; code: string; name: string }; plans: any[]; fee: number | null; feBody?: any; setting?: any } | null = null;
const plansOf = (d: any) => d?.configuration?.whiteLabelSetting?.plans ?? [];
const describe = (ps: any[]) => ps.map((p) => (p.dataPlanName ?? (p.dataPlanId ? "plan " + p.dataPlanId.slice(0, 8) : p.dataPlanUnitValue ? "Any Fixed " + p.dataPlanUnitValue + "GB" : "rule")) + " = " + p.value + "%").join(" | ");
const table = (head: string[], rows: unknown[][]) =>
  "<table><tr>" + head.map((h) => "<th>" + esc(h) + "</th>").join("") + "</tr>" + rows.map((r) => "<tr>" + r.map((c) => "<td>" + esc(c) + "</td>").join("") + "</tr>").join("") + "</table>";
async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const feeRows = (drawer: Locator) => corporate(drawer).body.locator(".list-data-merchant .merchant-item");
async function labelsLoaded(page: Page, drawer: Locator) {
  for (const until = Date.now() + 45000; Date.now() < until;) {
    const labels = await feeRows(drawer).locator(".ant-select").first().locator(".ant-select-selection-item").allInnerTexts().catch(() => [] as string[]);
    if (!labels.some((l) => /^[A-Z_]+\||^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(l.trim()))) return;
    await page.waitForTimeout(1500);
  }
}
async function rowByLabel(drawer: Locator, re: RegExp) {
  const rows = feeRows(drawer);
  for (let i = 0; i < (await rows.count()); i++) {
    const label = (await rows.nth(i).locator(".ant-select").first().locator(".ant-select-selection-item").first().innerText().catch(() => "")).trim();
    if (re.test(label)) return { row: rows.nth(i), label };
  }
  return null;
}

test.describe("ESKIMO-910 fee ceiling evidence " + ID, () => {
  test.describe.configure({ mode: "serial", timeout: 10 * 60 * 1000 });

  test.beforeAll(async ({ browser }) => {
    test.setTimeout(300000);
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const p = await findPartner(t, P2);
      if (!p) throw new Error("Partner not found");
      const now = await readPartner(t, p);
      snap = { p, plans: plansOf(now.detail), fee: now.fee, setting: now.detail?.configuration?.corporateSetting };
      console.log("[CEIL] user config: base=" + now.fee + " rules=" + describe(snap.plans));
    } finally { await ctx.close(); }
  });

  test.afterAll(async ({ browser }, testInfo) => {
    test.setTimeout(300000);
    if (!snap?.feBody) return;
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const b = corporateBody(snap.feBody, true, snap.setting);
      b.configuration.whiteLabelSetting = { plans: snap.plans.map((p) => ({ ...p, id: "" })) };
      const r = await api(t, "PUT", "/api/partner/v2", b, 2);
      const now = await readPartner(t, snap.p);
      const ok = JSON.stringify(plansOf(now.detail).map((p: any) => [p.dataPlanId, p.dataPlanUnitValue, Number(p.value)])) === JSON.stringify(snap.plans.map((p) => [p.dataPlanId, p.dataPlanUnitValue, Number(p.value)])) && now.fee === snap.fee;
      evidence.setCase("Cleanup - restore");
      await card(browser, testInfo, "Restore - Partner 2 back to the user's rules", "<p>" + esc("PUT -> " + r.status + " " + apiMessage(r.json) + " ; now: base " + now.fee + " ; " + describe(plansOf(now.detail))) + "</p>",
        { ac: AC, title: "Restore (cleanup)", steps: ["Before: " + describe(snap.plans), "After: " + describe(plansOf(now.detail))], expected: ["Same rules as before the test"], status: ok ? undefined : "failed" });
      console.log("[CEIL] restore " + (ok ? "OK (verified)" : "NOT VERIFIED - restore manually!"));
    } finally { await ctx.close(); }
  });

  test("CEIL-01 UI: specific plan Japan 10GB = 99% saves " + ID, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("CEIL-01 Japan 10GB 99%");
    const { ctx, page } = await adminSess(browser);
    try {
      const o = await openCorporate(page, P2);
      await labelsLoaded(page, o.drawer);
      const hit = await rowByLabel(o.drawer, /^Japan 10\s*GB$/i);
      expect(hit, "existing rule Japan 10GB").not.toBeNull();
      const fee = hit!.row.locator("input.ant-input").first();
      await fee.fill("99");
      await focus(fee);
      await hit!.row.scrollIntoViewIfNeeded().catch(() => {});
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "CEIL-01 Japan 10GB = 99 before Ok", steps: ["Apply To: " + hit!.label, "Fee: 99%"], expected: ["Save succeeds"] });
      const saved = await clickOk(page, o.drawer);
      if (saved.status === 200 && saved.reqBody?.configuration?.hasCorporate) snap!.feBody = saved.reqBody;
      const o2 = await openCorporate(page, P2);
      await labelsLoaded(page, o2.drawer);
      const again = await rowByLabel(o2.drawer, /^Japan 10\s*GB$/i);
      const shown = again ? await again.row.locator("input.ant-input").first().inputValue() : "";
      await again?.row.scrollIntoViewIfNeeded().catch(() => {});
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "CEIL-01 Reopened: Japan 10GB = " + shown, steps: ["PUT /api/partner/v2 -> " + saved.status + " " + saved.message + (saved.toasts.length ? " ; toast: " + saved.toasts.join(" | ") : ""), "Reopened fee: " + shown + "%"], expected: ["Saved 200, reopen shows 99"], status: saved.status === 200 && shown === "99" ? undefined : "failed" });
      console.log("[CEIL] CEIL-01 Japan 10GB 99 -> " + saved.status + " " + saved.message + " reopen=" + shown);
      expect(saved.status).toBe(200);
      expect(shown).toBe("99");
    } finally { await ctx.close(); }
  });

  test("CEIL-03 API: Japan 10GB vs Any Fixed 10GB, fee 90..99% " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("CEIL-03 API side by side");
    const { ctx, page } = await adminSess(browser);
    try {
      const t = await tokenOf(page);
      const base = snap!.feBody ?? null;
      expect(base, "FE body captured in CEIL-01").not.toBeNull();
      const put = async (rule: any) => { const b = corporateBody(base, true, snap!.setting); b.configuration.whiteLabelSetting = { plans: [rule] }; const r = await api(t, "PUT", "/api/partner/v2", b, 1); return r.status + " " + apiMessage(r.json); };
      const mk = (extra: any, v: number) => ({ id: "", dataPlanId: null, regionId: null, countryId: null, value: String(v), priceDiscount: 0, networkPartnerCommissionPercentage: null, price: null, dataPlanTierEnum: null, unlimitedDayCount: null, dataPlanUnitValue: null, ...extra });
      const rows: unknown[][] = [];
      for (let v = 90; v <= 99; v++) {
        const a = await put(mk({ dataPlanId: JAPAN_10GB_PLAN_ID, dataPlanName: "Japan 10GB" }, v));
        const b = await put(mk({ type: 5, dataPlanName: "Any Fixed 10GB", dataPlanUnitValue: 10 }, v));
        rows.push([v + "%", a, b]);
      }
      await card(browser, testInfo, "CEIL-03 - PUT /api/partner/v2, one rule per request",
        table(["Fee", "Japan 10GB (specific plan)", "Any Fixed 10GB (all 10GB plans)"], rows) + "<p>Same FE body each time; only whiteLabelSetting.plans changes.</p>",
        { ac: AC, title: "CEIL-03 DATA side by side", steps: rows.map((r) => r.join(" | ")), expected: ["Both rule types follow the same limit (0 <= fee < 100)"], status: rows.every((r) => String(r[1]).slice(0, 3) === String(r[2]).slice(0, 3)) ? undefined : "failed" });
      console.log("[CEIL] CEIL-03 " + rows.map((r) => r.join(" / ")).join(" ;; "));
    } finally { await ctx.close(); }
  });
  test("CEIL-02 UI: Any Fixed 10GB = 99% is rejected " + ID, async ({ browser }, testInfo) => {
    evidence.setCase("CEIL-02 Any Fixed 10GB 99%");
    const { ctx, page } = await adminSess(browser);
    try {
      const o = await openCorporate(page, P2);
      await labelsLoaded(page, o.drawer);
      await page.locator(".custom-button-add-gift-code").filter({ hasText: /Application Fee/i }).first().click();
      await page.waitForTimeout(900);
      const row = feeRows(o.drawer).last();
      await row.locator(".ant-select").first().locator(".ant-select-selector").click();
      const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
      await dd.waitFor({ state: "visible", timeout: 15000 });
      await dd.locator(".ant-select-item-option").first().waitFor({ state: "visible", timeout: 15000 }).catch(() => {});
      await page.keyboard.type("Any Fixed 10GB", { delay: 40 });
      await page.waitForTimeout(1200);
      await dd.locator(".ant-select-item-option").filter({ hasText: /^Any Fixed 10\s*GB$/i }).first().click();
      const fee = row.locator("input.ant-input").first();
      await fee.fill("99");
      await focus(fee);
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "CEIL-02 Any Fixed 10GB = 99 before Ok", steps: ["Apply To: Any Fixed 10GB", "Fee: 99%", "Japan 10GB already saved at 99% (CEIL-01)"], expected: ["Same fee as the specific Japan 10GB rule -> should be accepted the same way"] });
      const saved = await clickOk(page, o.drawer);
      await page.waitForTimeout(800);
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "CEIL-02 After Ok: " + saved.status + " " + saved.message, steps: ["PUT /api/partner/v2 -> " + saved.status + " " + saved.message, "Toast: " + (saved.toasts.join(" | ") || "-")], expected: ["Consistent with CEIL-01 (Japan 10GB 99% accepted)"], status: saved.status === 200 ? undefined : "failed" });
      console.log("[CEIL] CEIL-02 Any Fixed 10GB 99 -> " + saved.status + " " + saved.message + " toasts=" + saved.toasts.join(" | "));
      expect.soft(saved.status, "Any Fixed 10GB 99% accepted like Japan 10GB 99%").toBe(200);
    } finally { await ctx.close(); }
  });

});
