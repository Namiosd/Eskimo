// WL-GUIDE – read-only: which templates / websites on stage still contain retired module types (downloadApp, productSection).
// GET only. Output: test-results/wl-guide-template-modules.json
import fs from "node:fs";
import { test } from "@playwright/test";
import { adminSessionRetry as adminSession } from "../_support/whitelabel";
import { api, tokenOf, websites } from "../_support/whitelabel";

const RETIRED = ["downloadApp", "productSection"];
const pagesOf = (d: any): any[] => d?.pages ?? d?.template?.pages ?? d?.website?.pages ?? [];
const typesOf = (p: any): string[] => (p?.modules ?? []).map((m: any) => m.type ?? m.moduleType ?? m.key ?? "?");

test("templates and websites: retired modules", async ({ browser }) => {
  test.setTimeout(240_000);
  const { page } = await adminSession(browser);
  const token = await tokenOf(page);
  const out: any = { templates: [], websites: [] };
  const t = await api(token, "GET", "/api/white-label/templates");
  const tpls: any[] = (t.json?.data ?? t.json)?.templates ?? [];
  for (const tp of tpls) {
    const d = await api(token, "GET", `/api/white-label/templates/${tp.id}`);
    const data = d.json?.data ?? d.json;
    const pages = pagesOf(data).map((p: any) => ({ name: p.name, types: typesOf(p) }));
    out.templates.push({ id: tp.id, name: tp.name, retired: pages.flatMap((p) => p.types.filter((x) => RETIRED.includes(x)).map((x) => `${p.name}:${x}`)), home: pages.find((p) => /home/i.test(p.name))?.types });
  }
  for (const w of await websites(token)) {
    const d = await api(token, "GET", `/api/white-label/websites/${w.id}`);
    const pages = pagesOf(d.json?.data ?? d.json).map((p: any) => ({ name: p.name, types: typesOf(p) }));
    out.websites.push({ name: w.name, retired: pages.flatMap((p) => p.types.filter((x) => RETIRED.includes(x)).map((x) => `${p.name}:${x}`)) });
  }
  fs.writeFileSync("test-results/wl-guide-template-modules.json", JSON.stringify(out, null, 2));
});
