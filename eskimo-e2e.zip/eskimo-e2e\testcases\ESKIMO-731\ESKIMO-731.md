# ESKIMO-731 – [EA-4380] WellAtSea My Data: tab History hiện message nội bộ API

Nguồn: Plane ESKIMO-731 (Jira EA-4380) — cùng nội dung bug với ESKIMO-382/EP-6054; spec copy từ tests/ESKIMO-382.

Môi trường: STG — storefront https://wellatsea.eskimo.travel/en/data-balance (BE stage, partner PN101609)
Khách test: E2E_WL_CUSTOMER_EMAIL (testwhitelabel168@yopmail.com — đã mua nhiều plan)
Vào My Data bằng magic link (E2E_WL_MAGIC_LINK) thay cho email + OTP. Chỉ đọc: không mua, không gửi OTP.

Expected (theo bug): Tab History phải hiện danh sách lịch sử mua (date, plan, status). Nếu BE chưa sẵn
sàng thì ẩn tab hoặc hiện message thân thiện — KHÔNG lộ message nội bộ/kỹ thuật của API.

Message nội bộ cũ (phải KHÔNG còn): "History isn't available yet. The white-label data-wallet API returns current plans only."

## TC-01 Tab History không lộ message nội bộ API
- Steps:
  1. Mở magic link → /en/data-balance (đã đăng nhập)
  2. Bấm tab "History"
- Expected: Không hiện message nội bộ cũ; không hiện chuỗi kỹ thuật (API/wallet/endpoint/websiteId/token/null/undefined/raw JSON)

## TC-02 Tab History hiện lịch sử mua hoặc message thân thiện
- Steps: Đọc nội dung tab History
- Expected:
  - Có danh sách item lịch sử (mỗi item có tên plan + status + ngày), HOẶC
  - Nếu trống: message thân thiện kiểu "No history yet" / "Your purchases … will show up here"
  - Nếu lỗi tải: message thân thiện + nút "Try again" (không lộ chi tiết kỹ thuật)

## TC-03 Login My Data bằng email + OTP (manual)
- Steps: /en/data-balance → email → Send code → OTP → History
- Expected: như TC-01/02
- Manual: OTP qua yopmail (captcha)
