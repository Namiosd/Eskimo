// ESKIMO-928 – Selective confirm of Pending recycle batches.
// Confirms ONLY Pending batches that HAVE recyclable eSIMs (totalEsim > 0).
// Pending batches with NO eSIM to recycle (totalEsim = 0 / null) are LEFT UNTOUCHED (still Pending).
//
//   TC-01 List all Pending batches and classify each: recyclable (totalEsim > 0) vs empty (totalEsim = 0/null)   (read-only)
//   TC-02 Confirm every recyclable Pending batch (real PUT update-batch batchStatus=2) -> poll until Confirmed(2) (writes)
//   TC-03 After confirming, the empty Pending batches are STILL Pending(1) — never confirmed               (read-only)
//
// What it DOES (writes):  confirms (recycles) all recyclable Pending batches (or up to E2E_RECYCLE_CONFIRM_LIMIT).
//                          Set E2E_RECYCLE_CONFIRM_DRY_RUN=1 to classify + plan only, NO real confirm.
// What it NEVER does:      delete / cancel (no batchStatus:3, no delete call).
//
// Auth:  set E2E_ADMIN_JWT (admin accessToken copied from the browser) -> used directly for API calls,
//        skips UI login (use this for PROD). Leave empty -> falls back to adminSession UI OTP login (staging).
//
// Run:
//   npx playwright test tests/ESKIMO-928/recycle-confirm-selective.spec.ts --output test-results/ESKIMO-928
//   npm run report:evidence -- ESKIMO-928 recycle-confirm-selective "ESKIMO-928 . selective confirm . <env>"
//     -> reports/ESKIMO-928-recycle-confirm-selective-e2e-report.html (open in Chrome, Ctrl+P -> PDF for Plane)
import fs from "node:fs";
import { test, expect, type Browser, type BrowserContext, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { API_URL, adminToken } from "../_support/wellatsea";
import { createEvidence, esc } from "../_support/evidence";

const ID = "@ESKIMO-928";
const AC = "ESKIMO-928 selective confirm";
const evidence = createEvidence("ESKIMO-928", "recycle-confirm-selective");
const STATUS: Record<number, string> = { 1: "Pending", 2: "Confirmed", 3: "Cancelled", 4: "Checking", 5: "Confirming" };
const PAGE_URL = `${ADMIN_URL}/#/esim-codes`;

// --- config (env) ---
const CONFIRM_LIMIT = Number(process.env.E2E_RECYCLE_CONFIRM_LIMIT || 0);   // 0 = confirm ALL recyclable Pending batches
const POLL_MS = Number(process.env.E2E_RECYCLE_POLL_MS || 5000);
const TIMEOUT_MS = Number(process.env.E2E_RECYCLE_TIMEOUT_MS || 900000);    // 15 min / transition
const JWT = process.env.E2E_ADMIN_JWT || "";
const DRY_RUN = /^(1|true|yes)$/i.test(process.env.E2E_RECYCLE_CONFIRM_DRY_RUN || ""); // 1 = classify only, no real confirm

type Batch = { batchID: string; status: number; totalEsim: number | null; assign: number | null; createdTime: string; batchName?: string };
type ConfirmRow = { batchId: string; totalEsim: number; start: string; end: string; durationSec: number; endStatus: number; note: string };
type SelectiveState = { recyclable: Batch[]; empty: Batch[]; confirmed: ConfirmRow[]; dryRun: boolean };

// Worker restart on failure loses module state: persist classification + results to a file.
const STATE_FILE = "test-results/ESKIMO-928-selective-state.json";
const ST: SelectiveState = { recyclable: [], empty: [], confirmed: [], dryRun: DRY_RUN };
const saveState = () => { fs.mkdirSync("test-results", { recursive: true }); fs.writeFileSync(STATE_FILE, JSON.stringify(ST)); };
const loadState = () => { try { const s = JSON.parse(fs.readFileSync(STATE_FILE, "utf8")) as SelectiveState; ST.recyclable = s.recyclable || []; ST.empty = s.empty || []; ST.confirmed = s.confirmed || []; ST.dryRun = s.dryRun ?? DRY_RUN; } catch { /* none yet */ } };

let ctx: BrowserContext;
let page: Page;
let scratch: Page;
let authToken = "";
// --- API (same endpoints the page calls) ---
async function api(method: string, path: string, body?: unknown) {
  if (!authToken) throw new Error("No auth token available - set E2E_ADMIN_JWT or run staging login.");
  const r = await fetch(`${API_URL}${path}`, {
    method, signal: AbortSignal.timeout(60000),
    headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: `Bearer ${authToken}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any = null;
  try { json = JSON.parse(text); } catch { /* not JSON */ }
  return { status: r.status, json, text };
}

/** List recycle batches, optionally filtered by status (1=Pending, 2=Confirmed, 3=Cancelled, 4=Checking, 5=Confirming). */
async function listBatches(status: number | null = null, size = 100): Promise<Batch[]> {
  const r = await api("POST", "/api/inventories/search-batch-recycle-inventory", {
    pageIndex: 1, pageSize: size, searchText: "", batchStatus: status,
    sortBy: { fieldName: "CreatedTime", ascending: false },
  });
  return r.json?.data?.data?.data ?? [];
}
/** List ALL batches of a status by paginating through every page (page size 100). */
async function listAllBatches(status: number | null = null, pageSize = 100): Promise<Batch[]> {
  const all: Batch[] = [];
  let page = 1;
  let pages = 1;
  do {
    const r = await api("POST", "/api/inventories/search-batch-recycle-inventory", {
      pageIndex: page, pageSize, searchText: "", batchStatus: status,
      sortBy: { fieldName: "CreatedTime", ascending: false },
    });
    const d = r.json?.data?.data;
    const rows: Batch[] = d?.data ?? [];
    all.push(...rows);
    pages = Number(d?.numOfPages ?? 1);
    if (rows.length < pageSize) break; // last page reached
    page++;
  } while (page <= pages);
  return all;
}
/** Find a single batch by its ID. Searches by searchText=ID so OLD batches (outside the newest-100) are still found. */
const getBatch = async (id: string) => {
  const r = await api("POST", "/api/inventories/search-batch-recycle-inventory", {
    pageIndex: 1, pageSize: 20, searchText: id, batchStatus: null,
    sortBy: { fieldName: "CreatedTime", ascending: false },
  });
  return (r.json?.data?.data?.data ?? []).find((b) => b.batchID === id);
};

/** Poll until the batch reaches one of `want` statuses (or timeout). Returns { batch, elapsedMs, seen }. */
async function waitStatus(id: string, want: number[], timeoutMs: number): Promise<{ batch?: Batch; elapsedMs: number; seen: string[] }> {
  const start = Date.now();
  const end = start + timeoutMs;
  const seen: string[] = [];
  let b: Batch | undefined;
  while (Date.now() < end) {
    b = await getBatch(id);
    const s = b ? STATUS[b.status] ?? String(b.status) : "not found";
    if (seen[seen.length - 1] !== s) seen.push(s);
    if (b && want.includes(b.status)) return { batch: b, elapsedMs: Date.now() - start, seen };
    await new Promise((r) => setTimeout(r, POLL_MS));
  }
  return { batch: b, elapsedMs: Date.now() - start, seen };
}

/** Confirm a Pending batch via API (batchStatus=2, processByJob=true). Returns tStart (moment PUT returned). */
async function confirmBatch(batchId: string): Promise<number> {
  const tStart = Date.now();
  const r = await api("PUT", "/api/inventories/update-batch", { batchId, batchStatus: 2, processByJob: true });
  if (r.status >= 400 || !r.json?.isSuccess) {
    throw new Error(`Confirm batch ${batchId} failed: HTTP ${r.status} - ${r.text.slice(0, 300)}`);
  }
  return tStart;
}

function isProd() {
  return /api\.eskimo\.travel/i.test(API_URL) || /admin\.eskimo\.travel/i.test(ADMIN_URL);
}
function fmtDate(ms: number) { return new Date(ms).toISOString(); }
/** A Pending batch is "recyclable" when it actually holds eSIMs that can be recycled (totalEsim > 0). */
const isRecyclable = (b: Batch) => (b.totalEsim ?? 0) > 0;

// --- session ---
async function selectiveSession(browser: Browser) {
  if (JWT) {
    authToken = JWT;
    ctx = await browser.newContext({ baseURL: ADMIN_URL });
    await (ctx as any).addInitScript((token: string) => {
      localStorage.setItem("accessToken", token);
      try {
        const decoded: any = JSON.parse(atob(token.split(".")[1]));
        localStorage.setItem("hotspot", JSON.stringify({
          token,
          userId: decoded.userId || decoded.sub || "",
          role: decoded["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"] || "Super Administrator",
        }));
      } catch { /* not a JWT / parse error - accessToken alone is enough for API calls */ }
    }, JWT);
    page = await ctx.newPage();
    await page.goto(PAGE_URL, { waitUntil: "domcontentloaded", timeout: 90000 }).catch(() => {});
  } else {
    if (isProd()) {
      throw new Error("PROD detected but E2E_ADMIN_JWT is empty. Copy the admin accessToken from the browser localStorage and set E2E_ADMIN_JWT (OTP login cannot be automated on PROD).");
    }
    ({ ctx, page } = await adminSession(browser));
    authToken = await adminToken(page);
    await page.goto(PAGE_URL, { waitUntil: "domcontentloaded", timeout: 90000 }).catch(() => {});
  }
  if (!authToken) throw new Error("No admin token after session start - check E2E_ADMIN_JWT / login.");
  const probe = await api("POST", "/api/inventories/search-batch-recycle-inventory", {
    pageIndex: 1, pageSize: 1, searchText: "", batchStatus: null, sortBy: { fieldName: "CreatedTime", ascending: false },
  });
  if (probe.status === 401 || probe.status === 403) {
    throw new Error(`Admin token rejected (HTTP ${probe.status}). Copy a fresh accessToken from the browser localStorage and set E2E_ADMIN_JWT.`);
  }
}
// --- evidence helpers (best-effort: never let evidence break the test) ---
async function card(testInfo: TestInfo, title: string, heading: string, bodyHtml: string, steps: string[], expected: string[], status?: "failed" | "pending") {
  try {
    evidence.setCase(title);
    await evidence.saveDataCard(scratch, testInfo, heading, bodyHtml, { ac: AC, title, steps, expected, status });
  } catch (e) { console.log(`  (evidence card skipped: ${(e as Error).message})`); }
}

function batchTableHtml(rows: Batch[], kind: "recyclable" | "empty"): string {
  const head = "<tr><th>BatchID</th><th>Status</th><th>totalEsim</th><th>Created</th><th>Class</th></tr>";
  const body = rows.map((b) =>
    `<tr><td>${esc(b.batchID)}</td><td>${esc(STATUS[b.status] ?? b.status)}</td><td class="${(b.totalEsim ?? 0) > 0 ? "ok" : "bad"}">${b.totalEsim ?? 0}</td><td>${esc(b.createdTime)}</td><td>${kind}</td></tr>`
  ).join("");
  return `<table>${head}${body}</table>`;
}

function confirmTableHtml(rows: ConfirmRow[]): string {
  const head = "<tr><th>BatchID</th><th>totalEsim</th><th>Duration (s)</th><th>End status</th><th>Note</th></tr>";
  const body = rows.map((r) =>
    `<tr><td>${esc(r.batchId)}</td><td>${r.totalEsim}</td><td>${r.durationSec}</td><td class="${r.endStatus === 2 ? "ok" : "bad"}">${esc(STATUS[r.endStatus] ?? r.endStatus)}</td><td>${esc(r.note)}</td></tr>`
  ).join("");
  return `<table>${head}${body}</table>`;
}

test.describe.serial(`ESKIMO-928 Selective confirm of Pending recycle batches ${ID}`, () => {
  test.beforeAll(async ({ browser }) => {
    loadState();
    await selectiveSession(browser);
    scratch = await ctx.newPage();
  });
  test.afterAll(async () => {
    await scratch?.close().catch(() => {});
    await ctx?.close().catch(() => {});
  });

  test(`TC-01 Classify Pending batches: recyclable vs empty ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-01 Classify Pending batches");
    // Re-classify fresh every run over ALL pending batches (paginated), not just the first page.
    const pending = await listAllBatches(1, 100);
    ST.recyclable = pending.filter(isRecyclable);
    ST.empty = pending.filter((b) => !isRecyclable(b));
    ST.confirmed = [];
    ST.dryRun = DRY_RUN;
    saveState();
    console.log(`[TC-01] Pending=${pending.length}  recyclable=${ST.recyclable.length}  empty=${ST.empty.length}  dryRun=${DRY_RUN}`);

    await card(testInfo, "TC-01 – Pending batch classification",
      "ESKIMO-928 - Pending recycle batches: recyclable (totalEsim > 0) vs empty (totalEsim = 0)",
      `<h3>Recyclable Pending batches (${ST.recyclable.length}) — eligible to confirm</h3>${batchTableHtml(ST.recyclable, "recyclable")}` +
      `<h3>Empty Pending batches (${ST.empty.length}) — NO eSIM to recycle, will be skipped</h3>${batchTableHtml(ST.empty, "empty")}` +
      (DRY_RUN ? `<p><b>DRY RUN</b> is ON: TC-02 will plan only, no real confirm.</p>` : `<p>Real confirm mode: TC-02 will confirm all ${ST.recyclable.length} recyclable batch(es).</p>`),
      [`GET pending batches (status=1): ${pending.length} found`, `Recyclable (totalEsim > 0): ${ST.recyclable.length}`, `Empty (totalEsim = 0/null): ${ST.empty.length}`, `Mode: ${DRY_RUN ? "DRY RUN (no confirm)" : "REAL confirm"}`],
      ["Every Pending batch is classified recyclable (totalEsim > 0) or empty (totalEsim = 0/null)"],
      undefined);

    expect(pending.length, "pending batch listing returned").toBeGreaterThanOrEqual(0);
    expect(ST.recyclable.length + ST.empty.length, "recyclable + empty = total pending").toBe(pending.length);
  });
  test(`TC-02 Confirm only recyclable Pending batches (totalEsim > 0) ${ID}`, async ({}, testInfo) => {
    // Real confirm of many batches polls each to Confirmed -> can run long; extend the per-test timeout.
    test.setTimeout(Number(process.env.E2E_RECYCLE_TEST_TIMEOUT_MS || 240) * 60_000);
    evidence.setCase("TC-02 Confirm recyclable batches");
    if (ST.recyclable.length === 0 && ST.empty.length === 0) loadState();
    let toConfirm = ST.recyclable.slice();
    if (CONFIRM_LIMIT > 0) toConfirm = toConfirm.slice(0, CONFIRM_LIMIT);
    console.log(`[TC-02] ${DRY_RUN ? "DRY RUN" : "REAL"} confirm ${toConfirm.length} recyclable batch(es)${CONFIRM_LIMIT > 0 ? ` (limit ${CONFIRM_LIMIT})` : ""}.`);

    const rows: ConfirmRow[] = [];
    if (DRY_RUN) {
      for (const b of toConfirm) {
        rows.push({ batchId: b.batchID, totalEsim: b.totalEsim ?? 0, start: fmtDate(Date.now()), end: fmtDate(Date.now()), durationSec: 0, endStatus: 1, note: "DRY RUN: not confirmed, would PUT update-batch batchStatus=2" });
      }
      ST.confirmed = rows;
      saveState();
      await card(testInfo, "TC-02 – DRY RUN: would confirm recyclable batches",
        "ESKIMO-928 - DRY RUN plan: confirm only recyclable Pending batches",
        confirmTableHtml(rows) + `<p>No confirm API call was made (E2E_RECYCLE_CONFIRM_DRY_RUN=1).</p>`,
        [`Recyclable Pending batches: ${toConfirm.length}`, ...rows.map((r) => `${r.batchId}: ${r.totalEsim} eSIM — planned (not confirmed)`)],
        ["In real mode, only recyclable Pending batches (totalEsim > 0) are confirmed; empty ones are skipped"],
        "pending");
      expect(rows.length, "planned confirm rows").toBe(toConfirm.length);
      return;
    }

    for (const b of toConfirm) {
      const fresh = await getBatch(b.batchID);
      if (!fresh || fresh.status !== 1) {
        rows.push({ batchId: b.batchID, totalEsim: b.totalEsim ?? 0, start: fmtDate(Date.now()), end: fmtDate(Date.now()), durationSec: 0, endStatus: fresh?.status ?? -1, note: `skipped: not Pending anymore (${STATUS[fresh?.status ?? -1] ?? "gone"})` });
        continue;
      }
      const tStart = await confirmBatch(b.batchID);
      const { batch, elapsedMs, seen } = await waitStatus(b.batchID, [2, 3], TIMEOUT_MS);
      const endStatus = batch?.status ?? -1;
      rows.push({
        batchId: b.batchID, totalEsim: b.totalEsim ?? 0,
        start: fmtDate(tStart), end: fmtDate(tStart + elapsedMs), durationSec: Math.round(elapsedMs / 1000),
        endStatus,
        note: endStatus === 2 ? `confirmed; seen: ${seen.join(" -> ")}` : `did NOT reach Confirmed (end ${STATUS[endStatus] ?? endStatus}); seen: ${seen.join(" -> ")}`,
      });
      console.log(`  confirmed ${b.batchID} (${b.totalEsim} eSIM): ${Math.round(elapsedMs / 1000)}s  (seen ${seen.join(" -> ")})`);
    }
    ST.confirmed = rows;
    saveState();

    const confirmedOk = rows.filter((r) => r.endStatus === 2);
    const notOk = rows.filter((r) => r.endStatus !== 2 && !r.note.startsWith("skipped"));
    await card(testInfo, "TC-02 – Confirm recyclable Pending batches",
      "ESKIMO-928 - Confirm only Pending batches that have recyclable eSIMs (totalEsim > 0)",
      confirmTableHtml(rows) + `<p>Confirmed OK: ${confirmedOk.length}/${rows.length}. Empty Pending batches (${ST.empty.length}) were NOT confirmed.</p>`,
      [`Recyclable Pending batches to confirm: ${toConfirm.length}`, ...rows.map((r) => `${r.batchId}: ${r.totalEsim} eSIM -> ${STATUS[r.endStatus] ?? r.endStatus} (${r.durationSec}s) — ${r.note}`)],
      ["Every recyclable Pending batch (totalEsim > 0) reaches Confirmed (status 2) after Confirming", "Empty Pending batches are NOT confirmed (no PUT for them)"],
      notOk.length ? "failed" : undefined);

    expect(notOk.length, `batches that did not reach Confirmed: ${notOk.map((r) => r.batchId).join(", ")}`).toBe(0);
  });
  test(`TC-03 Empty Pending batches (totalEsim = 0) are NOT confirmed ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-03 Empty batches untouched");
    if (ST.empty.length === 0 && ST.recyclable.length === 0) loadState();
    // Re-fetch ALL pending batches in ONE call (status=1), then look up each empty batch by id.
    // (A per-batch getBatch would fire N list calls and time out on prod with many empty batches.)
    const pendingNow = await listAllBatches(1, 100);
    const byId = new Map(pendingNow.map((b) => [b.batchID, b] as const));
    const recheck: { batchId: string; totalEsim: number; status: number; untouched: boolean }[] = [];
    for (const b of ST.empty) {
      const fresh = byId.get(b.batchID);
      const status = fresh ? fresh.status : -1; // -1 = no longer Pending (changed status, e.g. cancelled by someone else)
      recheck.push({ batchId: b.batchID, totalEsim: fresh?.totalEsim ?? b.totalEsim ?? 0, status, untouched: status === 1 });
    }
    console.log(`[TC-03] empty Pending batches=${ST.empty.length}  still Pending=${recheck.filter((r) => r.untouched).length}`);

    const notPending = recheck.filter((r) => r.status !== 1);
    const wronglyConfirmed = recheck.filter((r) => r.status === 2);
    const ok = wronglyConfirmed.length === 0;

    const head = "<tr><th>BatchID</th><th>totalEsim</th><th>Status now</th><th>Untouched (still Pending)</th></tr>";
    const body = recheck.map((r) =>
      `<tr><td>${esc(r.batchId)}</td><td>${r.totalEsim}</td><td class="${r.status === 2 ? "bad" : "ok"}">${esc(STATUS[r.status] ?? r.status)}</td><td class="${r.untouched ? "ok" : "bad"}">${r.untouched}</td></tr>`
    ).join("");
    await card(testInfo, "TC-03 – Empty Pending batches NOT confirmed",
      "ESKIMO-928 - Pending batches with NO eSIM (totalEsim = 0) stay Pending, never Confirmed",
      `<table>${head}${body}</table>` +
      (ST.empty.length === 0 ? `<p>No empty Pending batch found this run — the skip path could not be exercised (reported, not failed).</p>` : "") +
      (notPending.length ? `<p>Note: ${notPending.length} empty batch(es) left Pending but changed status (e.g. cancelled by someone else) — not caused by our confirm.</p>` : ""),
      [`Empty Pending batches recorded in TC-01: ${ST.empty.length}`, ...recheck.map((r) => `${r.batchId}: totalEsim=${r.totalEsim}, status=${STATUS[r.status] ?? r.status}, untouched=${r.untouched}`)],
      ["Empty Pending batches (totalEsim = 0) are NOT confirmed — they must not become Confirmed(2) by this flow"],
      ok ? (ST.empty.length === 0 ? "pending" : undefined) : "failed");

    expect(wronglyConfirmed.map((r) => r.batchId), "empty batches wrongly confirmed").toEqual([]);
  });
});