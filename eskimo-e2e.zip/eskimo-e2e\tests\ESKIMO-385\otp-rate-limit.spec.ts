// ESKIMO-385 / EP-6058 – WellAtSea My Data: the OTP sign-in step had no rate limiting.
// Test cases: testcases/ESKIMO-385/ESKIMO-385.md.
//
// SCOPE — this is a DEFENSIVE regression check, not an attack. It verifies the gate now
// pushes back after a few failures. It submits a FIXED list of deliberately-wrong codes
// (capped at 6, the item's own repro count), never reads a real OTP and never tries to
// find a valid one. A fix is present when the system, within those 6 attempts, rate-limits /
// locks out / shows a CAPTCHA / invalidates the current code. If every attempt just says
// "Invalid OTP" with no such defence, the bug is NOT fixed.
// Evidence: evidence/ESKIMO-385-otp-rate-limit → npm run report:evidence -- ESKIMO-385 otp-rate-limit
import { test, expect, type TestInfo } from "@playwright/test";
import { createEvidence, esc } from "../_support/evidence";
import { WL_URL, newShopper, requestCode, submitCode } from "../_support/wellatsea";

const ID = "@ESKIMO-385";
const AC = "EP-6058";
const evidence = createEvidence("ESKIMO-385", "otp-rate-limit");
const EMAIL = process.env.E2E_WL_CUSTOMER_EMAIL || "";
// Deliberately-wrong codes — obvious non-guesses, one per attempt, capped at the item's 6.
const WRONG_CODES = ["0000", "1111", "2222", "3333", "4444", "5555"];
// Signs that the gate pushed back (a fix). Plain "invalid" alone is NOT a defence.
const DEFENCE = /(too many|rate limit|locked|lockout|try again later|wait|captcha|blocked|temporarily|expired|request a new|resend)/i;

test.describe(`ESKIMO-385 OTP rate limiting ${ID}`, () => {
  test.setTimeout(240_000);

  test(`TC-01 Repeated wrong OTP codes are rate-limited / locked out ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Repeated wrong OTP codes");
    expect(EMAIL, "Set E2E_WL_CUSTOMER_EMAIL").toBeTruthy();
    const { ctx, page } = await newShopper(browser);
    const log: { attempt: number; code: string; outcome: string; message: string; defended: boolean }[] = [];
    try {
      await test.step("1. Request a code", async () => {
        const r = await requestCode(page, EMAIL);
        await evidence.saveScreenshot(page, testInfo, {
          ac: AC, title: "TC-01.0 Code requested for a known e-mail",
          steps: [`${WL_URL}/en/data-balance · ${EMAIL} · Send code → ${r.outcome}${r.error ? `: "${r.error}"` : ""}`],
          expected: ["4-digit code screen"], status: r.outcome === "code-screen" ? undefined : "failed",
        });
        expect(r.outcome, `Send code: ${r.error}`).toBe("code-screen");
      });

      let signedInBug = false;
      let defendedAt = 0;
      await test.step("2. Submit deliberately-wrong codes (max 6)", async () => {
        for (let i = 0; i < WRONG_CODES.length; i++) {
          const code = WRONG_CODES[i];
          const r = await submitCode(page, code);
          const defended = r.submitDisabled || DEFENCE.test(r.error) || (r.outcome === "no-change" && !r.codeStillThere);
          log.push({ attempt: i + 1, code, outcome: r.submitDisabled ? "submit-disabled" : r.outcome, message: r.error || "(none)", defended });
          if (r.outcome === "signed-in") { signedInBug = true; break; } // would mean a wrong code was accepted
          if (defended && !defendedAt) defendedAt = i + 1;
          await evidence.saveScreenshot(page, testInfo, {
            ac: AC, title: `TC-01.${i + 1} Wrong code #${i + 1} (${code}) → response`,
            steps: [`Attempt ${i + 1}/6 · wrong code ${code}`, `Reaction: ${log[i].outcome}`, `Message: "${r.error || "(none)"}"`, `Defence detected: ${defended ? "YES" : "no"}`],
            expected: ["After 3–5 failures: rate limit / lockout / CAPTCHA / OTP invalidated"],
            status: defended ? undefined : "failed",
          });
          if (defended) break; // the gate pushed back — enough to prove the fix
        }
      });

      const fixed = !signedInBug && defendedAt > 0;
      const scratch = await (await browser.newContext()).newPage();
      await evidence.saveDataCard(scratch, testInfo, "OTP attempts – rate-limit summary",
        `<table><tr><th>#</th><th>Code</th><th>Reaction</th><th>Message</th><th>Defence?</th></tr>${log.map((l) =>
          `<tr><td>${l.attempt}</td><td>${esc(l.code)}</td><td>${esc(l.outcome)}</td><td>${esc(l.message)}</td><td class="${l.defended ? "ok" : "bad"}">${l.defended ? "YES" : "no"}</td></tr>`).join("")}</table>` +
        `<h3 class="${fixed ? "ok" : "bad"}">${fixed ? `FIXED — a defence kicked in at attempt ${defendedAt}` : signedInBug ? "CRITICAL — a wrong code was accepted" : `NOT FIXED — ${log.length} wrong codes, no rate limit / lockout / CAPTCHA`}</h3>`,
        { ac: AC, title: "TC-01 Summary – OTP rate-limit verdict", steps: [`${log.length} wrong code(s) submitted`, `Defence first seen: ${defendedAt || "never"}`], expected: ["A defence within 3–5 failures"], status: fixed ? undefined : "failed" });
      await scratch.context().close();

      testInfo.annotations.push({ type: fixed ? "fixed" : "product failure", description: fixed ? `rate limit/lockout at attempt ${defendedAt}` : `no rate limiting after ${log.length} wrong codes` });
      expect(signedInBug, "a wrong code must never be accepted").toBe(false);
      expect(defendedAt, `rate limit / lockout / CAPTCHA within ${WRONG_CODES.length} wrong codes`).toBeGreaterThan(0);
    } finally {
      await ctx.close();
    }
  });
});
