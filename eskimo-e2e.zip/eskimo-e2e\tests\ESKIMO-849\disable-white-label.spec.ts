// ESKIMO-849 / EP-6073 – Admin cannot disable a White Label Corporate Program ("Corporate type cannot be updated.").
// Test cases: testcases/ESKIMO-849/ESKIMO-849.md (expected results = the item's Expected result):
//   TC-01 Disabled is saved (reload → Status OFF, API hasCorporate=false, no "Corporate type cannot be updated.")
//   TC-02 the partner's White Label storefront is unavailable while Disabled   (out of scope since 2026-10-14)
//   TC-03 the partner's White Label API (/api/white-label/websites/mine, partner JWT) is denied (out of scope)
//   TC-04 re-enable keeps Type / Start / End / Application Fee / other settings, nothing re-entered
//   TC-05 storefront plans + checkout are back after re-enable (no payment)        (out of scope)
// Partner = PN101609 "WhiteLabel Partner 2" (the item's partner, live storefront wellatsea). Its config is
// snapshotted before TC-01 and restored + verified after TC-05 (or at the start of the next run if interrupted).
// BE note: the storefront caches ~5 min → TC-02/TC-05 poll with cache-busted requests (60s, max 10 min).
// Evidence: evidence/ESKIMO-849-disable-white-label → npm run report:evidence -- ESKIMO-849 disable-white-label
import fs from "node:fs";
import path from "node:path";
import { test, expect, type Browser, type Locator, type Page, type TestInfo } from "@playwright/test";
import { adminSession, openPartnerDrawer, ADMIN_URL, PARTNER_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import { WL_URL, API_URL } from "../_support/wellatsea";

const ID = "@ESKIMO-849";
const AC = "EP-6073";
const evidence = createEvidence("ESKIMO-849", "disable-white-label");
const PARTNER_NAME = process.env.E2E_WL_PARTNER_NAME || "WhiteLabel Partner 2";
const PARTNER_CODE = process.env.E2E_WL_PARTNER_CODE || "PN101609";
const WL_PARTNER_EMAIL = process.env.E2E_WL_PARTNER_EMAIL || "";
const WL_PARTNER_OTP = process.env.E2E_WL_PARTNER_OTP || "";
const PLAN_PAGES = ["japan-esim", "united-states-esim", "europe-esim"];
const POLL_MS = Number(process.env.E2E_WL_CACHE_POLL_MS || 10 * 60 * 1000);
const TYPE_ERROR = /Corporate type cannot be updated/i;
// BA removed "storefront and APIs become unavailable" from the item (2026-10-14) → TC-02/03/05 are out of
// scope for ESKIMO-849 (they belong to EP-5991 AC4 / ESKIMO-757). Kept for reuse: E2E_849_AVAILABILITY=1.
const AVAILABILITY = process.env.E2E_849_AVAILABILITY === "1";
const OUT_OF_SCOPE = "Out of scope: the item's Expected result no longer includes storefront/API availability (EP-5991 AC4)";

// ─── State shared by the serial tests (a failed test restarts the worker → keep it on disk) ───
type Snap = Record<string, unknown>;
type State = { partnerId?: string; websiteId?: string; snapshot?: Snap; setting?: any; fee?: number | null; feBody?: any; restored?: boolean; completed?: string[] };
// Outside SCREENSHOT_DIR: resetIfFirstAttempt() wipes that folder, the restore state must survive it
const STATE = path.join(path.dirname(evidence.SCREENSHOT_DIR), "ESKIMO-849-state.json");
const load = (): State => { try { return JSON.parse(fs.readFileSync(STATE, "utf8")); } catch { return {}; } };
const save = (s: State) => { fs.mkdirSync(path.dirname(STATE), { recursive: true }); fs.writeFileSync(STATE, JSON.stringify(s, null, 1)); };

const KEYS = ["corporateType", "corporateStartDate", "corporateEndDate", "isEskimoEmailNotificationEnabled", "paymentMethod", "maxLifetimeAccounts", "percentCorporateDiscount", "networkPartnerCommissionPercentage"];
const snapOf = (detail: any): Snap => {
  const c = detail?.configuration ?? {};
  const s = c.corporateSetting ?? {};
  return Object.fromEntries([["hasCorporate", !!c.hasCorporate], ...KEYS.map((k) => [k, s[k] ?? null])]);
};
const diff = (a: Snap, b: Snap) => Object.keys(a).map((k) => ({ k, a: a[k], b: b?.[k], same: JSON.stringify(a[k] ?? null) === JSON.stringify(b?.[k] ?? null) }));

// ─── Stage API (it sometimes answers 200 with an empty body → retry until JSON) ───
async function api(token: string, method: string, p: string, body?: unknown, tries = 6) {
  let last = { status: 0, json: null as any };
  for (let i = 0; i < tries; i++) {
    const r = await fetch(`${API_URL}${p}`, { method, headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: body === undefined ? undefined : JSON.stringify(body) }).catch(() => null);
    const text = r ? await r.text().catch(() => "") : "";
    let json: any = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* not JSON */ }
    last = { status: r?.status ?? 0, json };
    if (json || (r && [401, 403, 404].includes(r.status))) return last;
    await new Promise((res) => setTimeout(res, 1000));
  }
  return last;
}
const adminToken = (page: Page) => page.evaluate(() => localStorage.getItem("accessToken") || "");

async function readPartner(token: string, s: State) {
  const d = await api(token, "GET", `/api/partner/v2/${s.partnerId}`);
  const list = await api(token, "GET", "/api/white-label/websites");
  const rows = Array.isArray(list.json?.data) ? list.json.data : list.json?.data?.websites ?? [];
  const site = rows.find((w: any) => w.partnerId === PARTNER_CODE);
  const det = site ? await api(token, "GET", `/api/white-label/websites/${site.id}`) : null;
  const fee = det?.json?.data?.stripeConnect?.platformFeePercent ?? null;
  return { detail: d.json?.data, snap: snapOf(d.json?.data), fee, websiteId: site?.id as string | undefined };
}

// ─── Admin drawer: Corporate Program section (no wrapper class — header + 2 sibling divs) ───
const corporate = (drawer: Locator) => {
  const header = drawer.locator(".header-member-view-detail").filter({ hasText: "Corporate Program" }).first();
  return { header, statusSwitch: header.locator("xpath=following-sibling::div[1]").locator(".ant-switch").first(), body: header.locator("xpath=following-sibling::div[2]") };
};
const isOn = (sw: Locator) => sw.evaluate((el) => el.classList.contains("ant-switch-checked"));
const formItem = (scope: Locator, label: string) =>
  scope.locator(".ant-form-item").filter({ has: scope.page().getByText(label, { exact: true }) }).first();

async function readCorporateForm(drawer: Locator) {
  const { body } = corporate(drawer);
  const sel = async (label: string) => (await formItem(body, label).locator(".ant-select-selection-item").first().innerText({ timeout: 2000 }).catch(() => "")).trim();
  return {
    type: await sel("Type"),
    start: await body.locator("input#corporateStartDate").inputValue({ timeout: 2000 }).catch(() => ""),
    end: await body.locator("input#corporateEndDate").inputValue({ timeout: 2000 }).catch(() => ""),
    fee: await body.locator("input#defaultPercentCorporate").inputValue({ timeout: 2000 }).catch(() => ""),
    email: await formItem(body, "Eskimo Email Notification").locator(".ant-switch").first().evaluate((el) => el.classList.contains("ant-switch-checked")).catch(() => null),
    payment: await sel("Payment method"),
    limit: await body.locator("input#maxLifetimeAccounts").inputValue({ timeout: 2000 }).catch(() => ""),
  };
}

async function openCorporate(page: Page) {
  const { drawer, detail } = await openPartnerDrawer(page, PARTNER_NAME);
  const c = corporate(drawer);
  await c.header.scrollIntoViewIfNeeded();
  // The fee input is filled from the website's stripeConnect after the "Stripe Connect" card stops loading
  await expect(drawer.getByText("Loading…")).toHaveCount(0, { timeout: 30000 }).catch(() => {});
  return { drawer, detail, ...c };
}

/** Click Ok; capture the partner PUT (+ fee PUT) and the toasts. */
async function clickOk(page: Page, drawer: Locator) {
  const putP = page.waitForResponse((r) => /\/api\/partner\/v2(\?|$)/.test(r.url()) && r.request().method() === "PUT", { timeout: 120000 }).catch(() => null);
  const feeP = page.waitForResponse((r) => /\/api\/payment\/connect\/partners\/.+\/fee/.test(r.url()) && r.request().method() === "PUT", { timeout: 20000 }).catch(() => null);
  await drawer.locator("button.btn-action-ok").first().click();
  const put = await putP;
  const fee = await feeP;
  const toasts = await page.locator(".Toastify__toast").allInnerTexts().catch(() => [] as string[]);
  let reqBody: any = null;
  try { reqBody = JSON.parse(put?.request().postData() || "null"); } catch { /* none */ }
  const resBody = put ? await put.json().catch(() => null) : null;
  return {
    status: put?.status() ?? 0, reqBody, resBody,
    message: (resBody?.messages ?? []).map((m: any) => m.content).join("; "),
    fee: fee ? { status: fee.status(), body: fee.request().postData() } : null,
    toasts: toasts.map((t) => t.trim()).filter(Boolean),
  };
}

// ─── Storefront (fresh context + no-cache + unique query = never served from cache) ───
async function storefrontPage(browser: Browser, slug: string) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, extraHTTPHeaders: { "Cache-Control": "no-cache", Pragma: "no-cache" } });
  const page = await ctx.newPage();
  const url = `${WL_URL}/en${slug ? `/plans/${slug}` : ""}?nocache=${Date.now()}`;
  const res = await page.goto(url, { waitUntil: "commit", timeout: 90000 }).catch(() => null);
  const plans = await page.locator(".day-card").first().waitFor({ state: "visible", timeout: 45000 }).then(() => page.locator(".day-card").count()).catch(() => 0);
  return { ctx, page, status: res?.status() ?? 0, plans };
}

/** Poll one country page every 60s until want(plans) (or POLL_MS). */
async function pollPlans(browser: Browser, want: (n: number) => boolean) {
  const t0 = Date.now();
  const timeline: string[] = [];
  for (;;) {
    const p = await storefrontPage(browser, PLAN_PAGES[0]);
    await p.ctx.close();
    const t = Math.round((Date.now() - t0) / 1000);
    timeline.push(`+${t}s: HTTP ${p.status}, ${p.plans} plans`);
    if (want(p.plans)) return { reached: t, timeline };
    if (Date.now() - t0 > POLL_MS) return { reached: null as number | null, timeline };
    await new Promise((res) => setTimeout(res, 60000));
  }
}

/** Every plan page: plans shown? first plan → Checkout → checkout page reached? (never pays). */
async function storefrontCheck(browser: Browser, testInfo: TestInfo, tc: string, expected: string) {
  const rows: { page: string; status: number; plans: number; checkout: string }[] = [];
  for (const slug of ["", ...PLAN_PAGES]) {
    const p = await storefrontPage(browser, slug);
    let checkout = slug ? "no plan to pick" : "—";
    try {
      if (slug && p.plans > 0) {
        await p.page.locator(".day-card").first().click();
        const btn = p.page.locator("a.btn-checkout:visible").first();
        if (await btn.isVisible().catch(() => false)) {
          await btn.click();
          checkout = (await p.page.locator("#wl-checkout-email").waitFor({ state: "visible", timeout: 45000 }).then(() => true).catch(() => false))
            ? "checkout page reached (not paid)" : "checkout page NOT reached";
        } else checkout = "Checkout button missing";
      }
      rows.push({ page: slug ? `/en/plans/${slug}` : "/en (home)", status: p.status, plans: p.plans, checkout });
      await evidence.saveScreenshot(p.page, testInfo, { ac: AC, title: `${tc} storefront ${slug || "home"}`, steps: [`GET ${WL_URL}/en${slug ? `/plans/${slug}` : ""} (no cache) → HTTP ${p.status}`, `Data plans shown: ${p.plans}`, `Plan → Checkout: ${checkout}`], expected: [expected] });
    } finally {
      await p.ctx.close();
    }
  }
  return rows;
}

async function partnerToken(browser: Browser) {
  const ctx = await browser.newContext({ baseURL: PARTNER_URL });
  const page = await ctx.newPage();
  try {
    await page.goto(`${PARTNER_URL}/#/login-partner`, { waitUntil: "domcontentloaded", timeout: 120000 });
    await page.locator("input[placeholder='Enter your email']").fill(WL_PARTNER_EMAIL);
    await page.locator("span.btn-send-code").click();
    const code = page.locator("input[placeholder='Enter code']");
    for (let i = 0; i < 3; i++) {
      await code.fill(WL_PARTNER_OTP);
      if (await expect(page.locator(".login-button")).toBeEnabled({ timeout: 5000 }).then(() => true).catch(() => false)) break;
    }
    await page.locator(".login-button").click();
    await page.waitForURL((u) => !u.hash.includes("/login"), { timeout: 60000 });
    return await page.evaluate(() => localStorage.getItem("accessToken") || "");
  } finally {
    await ctx.close();
  }
}

async function card(browser: Browser, testInfo: TestInfo | undefined, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const table = (head: string[], rows: (string | number | boolean | null)[][]) =>
  `<table><tr>${head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr>${rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</table>`;


/** Put Partner 2 back exactly as the snapshot (partner PUT with the FE body + fee PUT), verified via GET. */
async function restorePartner(browser: Browser, testInfo: TestInfo | undefined) {
  const s = load();
  if (!s.snapshot || !s.partnerId || s.restored) return true;
  const { ctx, page } = await adminSession(browser);
  try {
    const token = await adminToken(page);
    let now = await readPartner(token, s);
    const notes: string[] = [];
    for (let i = 1; i <= 3 && !(diff(s.snapshot, now.snap).every((x) => x.same) && now.fee === s.fee); i++) {
      if (s.feBody) {
        const body = JSON.parse(JSON.stringify(s.feBody));
        body.configuration = body.configuration || {};
        body.configuration.hasCorporate = s.snapshot.hasCorporate;
        body.configuration.corporateSetting = s.setting;
        const r = await api(token, "PUT", "/api/partner/v2", body, 2);
        notes.push(`#${i} PUT partner → ${r.status}`);
      }
      if (s.websiteId && now.fee !== s.fee) {
        const payload = s.fee === null ? { clearOverride: true } : { platformFeePercent: s.fee, clearOverride: false };
        const r = await api(token, "PUT", `/api/payment/connect/partners/${PARTNER_CODE}/fee`, payload, 2);
        notes.push(`#${i} PUT fee ${JSON.stringify(payload)} → ${r.status}`);
      }
      now = await readPartner(token, s);
    }
    const ok = diff(s.snapshot, now.snap).every((x) => x.same) && now.fee === s.fee;
    s.restored = ok;
    save(s);
    evidence.setCase("Cleanup — restore Partner 2");
    await card(browser, testInfo, "Restore — WhiteLabel Partner 2 back to the snapshot",
      table(["Field", "Snapshot", "Now", "Result"], [...diff(s.snapshot, now.snap).map((x) => [x.k, JSON.stringify(x.a), JSON.stringify(x.b), x.same ? "same" : "DIFF"]), ["Application Fee", String(s.fee), String(now.fee), now.fee === s.fee ? "same" : "DIFF"]]) + `<p>${esc(notes.join(" · ") || "nothing to restore")}</p>`,
      { ac: AC, title: "Restore Partner 2 (cleanup)", steps: notes.length ? notes : ["Already equal to the snapshot"], expected: ["Partner 2 equals the snapshot taken before TC-01"], status: ok ? undefined : "failed" });
    console.log(`[ESKIMO-849] restore Partner 2: ${ok ? "OK (verified)" : "NOT VERIFIED — restore manually!"} ${notes.join(" · ")}`);
    return ok;
  } finally {
    await ctx.close();
  }
}

// ═══════════════════════════════════════════════════════════════════════════════════════════════
// Not serial on purpose: TC-02/TC-03 may fail on the product, TC-04/TC-05 must still run. Run with --workers=1
// (file order). Partner 2 is restored only after TC-05 (a failed test restarts the worker → afterAll fires early).
test.describe(`ESKIMO-849 Disable White Label Corporate Program ${ID}`, () => {
  test.setTimeout(15 * 60 * 1000);

  test.afterEach(async ({}, testInfo) => {
    const s = load();
    s.completed = [...(s.completed ?? []), testInfo.title.slice(0, 5)];
    save(s);
  });

  test.afterAll(async ({ browser }) => {
    if (!(load().completed ?? []).includes("TC-05")) return; // more tests to come in this run
    await restorePartner(browser, undefined);
  });


  test(`TC-01 Save Corporate Program Disabled ${ID}`, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Save Disabled");
    // A previous run that never reached TC-05 may have left Partner 2 modified → restore it first
    const prev = load();
    if (prev.snapshot && !prev.restored) expect(await restorePartner(browser, testInfo), "restore of a previous interrupted run").toBe(true);
    evidence.setCase("TC-01 Save Disabled");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await adminToken(page);
      const { drawer, detail, statusSwitch } = await openCorporate(page);
      // Snapshot BEFORE any change (restored after TC-05)
      const s: State = { partnerId: detail.id, completed: [] };
      const before = await readPartner(token, s);
      expect(detail.partnerId ?? detail.partnerID ?? PARTNER_CODE).toBe(PARTNER_CODE);
      Object.assign(s, { snapshot: before.snap, setting: detail.configuration?.corporateSetting ?? null, fee: before.fee, websiteId: before.websiteId, restored: false });
      save(s);
      const form = await readCorporateForm(drawer);

      await test.step("1-2. Partners › WhiteLabel Partner 2 › Edit › Corporate Program Status ON → OFF", async () => {
        expect(await isOn(statusSwitch), "precondition: Corporate Program is ON").toBe(true);
        await statusSwitch.click();
        const warn = page.locator(".modal-dialog:visible").filter({ hasText: "Warning" }).first();
        if (await warn.isVisible({ timeout: 5000 }).catch(() => false)) await warn.getByRole("button", { name: "Confirm" }).click();
        await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "TC-01 Status switched OFF, before Ok", steps: [`Partner ${PARTNER_NAME} (${PARTNER_CODE})`, `Before: Type ${form.type}, Start ${form.start}, End ${form.end}, Application Fee ${form.fee || "(empty)"}%`, "Corporate Program Status → OFF"], expected: ["Ready to save"] });
      });
      const saved = await test.step("3. Click Ok", () => clickOk(page, drawer));
      if (saved.reqBody) { s.feBody = saved.reqBody; save(s); }
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "TC-01 After Ok", steps: [`PUT /api/partner/v2 → ${saved.status} ${saved.message}`, `Toast: ${saved.toasts.join(" | ") || "—"}`], expected: ['No "Corporate type cannot be updated."', "Saved"], status: saved.status === 200 && !saved.toasts.some((t) => TYPE_ERROR.test(t)) ? undefined : "failed" });

      const reopened = await test.step("4. Reload and reopen the partner", async () => {
        const r = await openCorporate(page);
        return { on: await isOn(r.statusSwitch) };
      });
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "TC-01 Reopened after reload", steps: [`Corporate Program Status: ${reopened.on ? "ON" : "OFF"}`], expected: ["Status OFF (Disabled)"], status: reopened.on ? "failed" : undefined });
      const after = await readPartner(token, s);
      await card(browser, testInfo, "TC-01 DATA — GET /api/partner/v2/{id}", table(["Field", "Before", "After"], [["hasCorporate", String(before.snap.hasCorporate), String(after.snap.hasCorporate)], ["PUT status / message", "", `${saved.status} ${saved.message}`]]), { ac: AC, title: "TC-01 DATA hasCorporate after save", steps: ["GET /api/partner/v2/{id}"], expected: ["hasCorporate = false"], status: after.snap.hasCorporate === false ? undefined : "failed" });

      expect(saved.toasts.join(" | "), "no 'Corporate type cannot be updated.'").not.toMatch(TYPE_ERROR);
      expect(saved.status, `PUT /api/partner/v2: ${saved.message}`).toBe(200);
      expect(reopened.on, "Status after reload").toBe(false);
      expect(after.snap.hasCorporate, "API hasCorporate").toBe(false);
    } finally {
      await ctx.close();
    }
  });

  test(`TC-02 Storefront unavailable when Disabled ${ID}`, async ({ browser }, testInfo) => {
    test.skip(!AVAILABILITY, OUT_OF_SCOPE);
    test.setTimeout(POLL_MS + 10 * 60 * 1000);
    evidence.setCase("TC-02 Storefront while Disabled");
    const poll = await test.step(`1. Poll ${PLAN_PAGES[0]} every 60s without cache (max ${POLL_MS / 60000} min)`, () => pollPlans(browser, (n) => n === 0));
    const rows = await test.step("2. Check home + plan pages + checkout", () => storefrontCheck(browser, testInfo, "TC-02", "Storefront unavailable (e.g. 404): no plans, no checkout"));
    const ok = rows.filter((r) => r.page !== "/en (home)").every((r) => r.plans === 0 && !/reached \(/.test(r.checkout));
    await card(browser, testInfo, "TC-02 — storefront while Disabled", table(["Page", "HTTP", "Plans", "Checkout"], rows.map((r) => [r.page, r.status, r.plans, r.checkout])) + `<h3>Cache poll</h3><p>${esc(poll.timeline.join(" · "))}</p><p>Plans gone after: ${poll.reached === null ? "NOT within the window" : `${poll.reached}s`}</p>`,
      { ac: AC, title: "TC-02 DATA storefront while Disabled", steps: rows.map((r) => `${r.page}: HTTP ${r.status}, ${r.plans} plans, ${r.checkout}`), expected: ["Storefront unavailable (e.g. 404)", "No data plans, no checkout"], status: ok ? undefined : "failed" });
    expect(rows.filter((r) => r.page !== "/en (home)" && (r.plans > 0 || /reached \(/.test(r.checkout))).map((r) => r.page), "pages still selling while Disabled").toEqual([]);
  });

  test(`TC-03 Partner WL API denied when Disabled ${ID}`, async ({ browser }, testInfo) => {
    test.skip(!AVAILABILITY, OUT_OF_SCOPE);
    evidence.setCase("TC-03 Partner API while Disabled");
    expect(WL_PARTNER_EMAIL && WL_PARTNER_OTP, "Set E2E_WL_PARTNER_EMAIL / E2E_WL_PARTNER_OTP").toBeTruthy();
    const token = await test.step("1. Log in to the partner portal (QA)", () => partnerToken(browser));
    const mine = await test.step("2. GET /api/white-label/websites/mine with the partner JWT", () => api(token, "GET", "/api/white-label/websites/mine"));
    const websiteId = mine.json?.data?.id ?? null;
    const denied = !(mine.status === 200 && websiteId);
    await card(browser, testInfo, "TC-03 — GET /api/white-label/websites/mine (partner JWT)", table(["Status", "isSuccess", "website id", "message"], [[mine.status, String(mine.json?.isSuccess ?? ""), websiteId ?? "—", (mine.json?.messages ?? []).map((m: any) => m.content).join("; ")]]),
      { ac: AC, title: "TC-03 DATA partner API while Disabled", steps: [`Partner ${WL_PARTNER_EMAIL.replace(/^(.).*@/, "$1***@")}`, `HTTP ${mine.status}, website ${websiteId ?? "—"}`], expected: ["Denied — the partner's website is not returned"], status: denied ? undefined : "failed" });
    expect(denied, `/websites/mine returned website ${websiteId}`).toBe(true);
  });

  test(`TC-04 Re-enable keeps configuration ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-04 Re-enable");
    const s = load();
    expect(s.snapshot, "snapshot from TC-01").toBeTruthy();
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await adminToken(page);
      const { drawer, statusSwitch } = await openCorporate(page);
      await test.step("1. Corporate Program Status OFF → ON, nothing else edited", async () => {
        if (!(await isOn(statusSwitch))) await statusSwitch.click();
        await corporate(drawer).header.scrollIntoViewIfNeeded();
        const f = await readCorporateForm(drawer);
        await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "TC-04 Status ON again, before Ok", steps: [`Prefilled: Type ${f.type}, Start ${f.start}, End ${f.end}, Fee ${f.fee || "(empty)"}, Email ${f.email ? "ON" : "OFF"}, Payment ${f.payment || "Not set"}, Limit ${f.limit}`], expected: ["Previous configuration already filled"] });
      });
      const saved = await test.step("2. Click Ok", () => clickOk(page, drawer));
      if (saved.reqBody && saved.status === 200) { s.feBody = saved.reqBody; save(s); }
      const r = await test.step("3. Reload and reopen", async () => {
        const o = await openCorporate(page);
        return { on: await isOn(o.statusSwitch), form: await readCorporateForm(o.drawer) };
      });
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "TC-04 Reopened after reload", steps: [`Status ${r.on ? "ON" : "OFF"}`, `Type ${r.form.type}, Start ${r.form.start}, End ${r.form.end}, Fee ${r.form.fee}, Email ${r.form.email ? "ON" : "OFF"}, Payment ${r.form.payment || "Not set"}, Limit ${r.form.limit}`], expected: ["Status ON, every setting as before Disable"] });
      const now = await readPartner(token, s);
      const d = diff(s.snapshot!, now.snap);
      const same = d.every((x) => x.same) && now.fee === s.fee;
      await card(browser, testInfo, "TC-04 — configuration before Disable vs after re-enable",
        table(["Field", "Before Disable", "After re-enable", "Result"], [...d.map((x) => [x.k, JSON.stringify(x.a), JSON.stringify(x.b), x.same ? "same" : "CHANGED"]), ["Application Fee (stripeConnect.platformFeePercent)", String(s.fee), String(now.fee), now.fee === s.fee ? "same" : "CHANGED"], ["Save", "", `PUT ${saved.status} ${saved.message} · fee ${saved.fee ? `${saved.fee.status} ${saved.fee.body}` : "—"}`, ""]]),
        { ac: AC, title: "TC-04 DATA configuration retained", steps: ["GET /api/partner/v2/{id}", "GET /api/white-label/websites/{id} → stripeConnect"], expected: ["Start Date, End Date, Application Fee and other settings unchanged"], status: same && r.on ? undefined : "failed" });
      expect(saved.status, `PUT: ${saved.message}`).toBe(200);
      expect(r.on, "Status after reload").toBe(true);
      expect(d.filter((x) => !x.same).map((x) => `${x.k}: ${JSON.stringify(x.a)} → ${JSON.stringify(x.b)}`), "settings changed by re-enable").toEqual([]);
      expect(now.fee, "Application Fee").toBe(s.fee);
    } finally {
      await ctx.close();
    }
  });

  test(`TC-05 Storefront back after re-enable ${ID}`, async ({ browser }, testInfo) => {
    test.skip(!AVAILABILITY, OUT_OF_SCOPE);
    test.setTimeout(POLL_MS + 10 * 60 * 1000);
    evidence.setCase("TC-05 Storefront after re-enable");
    const poll = await test.step("1. Poll until plans are back (no cache)", () => pollPlans(browser, (n) => n > 0));
    const rows = await test.step("2. Home + plan pages + checkout", () => storefrontCheck(browser, testInfo, "TC-05", "Plans shown, checkout reachable"));
    const ok = rows.filter((r) => r.page !== "/en (home)").every((r) => r.plans > 0 && /reached \(/.test(r.checkout));
    await card(browser, testInfo, "TC-05 — storefront after re-enable", table(["Page", "HTTP", "Plans", "Checkout"], rows.map((r) => [r.page, r.status, r.plans, r.checkout])) + `<p>${esc(poll.timeline.join(" · "))}</p>`,
      { ac: AC, title: "TC-05 DATA storefront after re-enable", steps: rows.map((r) => `${r.page}: ${r.plans} plans, ${r.checkout}`), expected: ["Plans + checkout work again"], status: ok ? undefined : "failed" });
    expect(ok, "plans + checkout on every page").toBe(true);
  });

});
