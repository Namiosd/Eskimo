# ESKIMO-732 – [EA-4381] WellAtSea My Data: OTP verification không có rate limiting (brute-force)

Nguồn: Plane ESKIMO-732 (Jira EA-4381) — cùng nội dung bug với ESKIMO-385/EP-6058; spec copy từ tests/ESKIMO-385. Không dùng email trong bug (gmail thật) mà dùng inbox test yopmail.

Môi trường: STG — storefront https://wellatsea.eskimo.travel/en/data-balance (BE stage, partner PN101609)
Email dùng test: E2E_WL_CUSTOMER_EMAIL (testwhitelabeluat2@yopmail.com — đã mua plan, nên bước Send code hợp lệ)

Phạm vi & an toàn (QC 2026-10-14):
- Đây là regression test PHÒNG THỦ: xác minh cổng OTP đã có cơ chế chặn (rate limit / lockout / CAPTCHA / vô hiệu OTP) chưa.
- Chỉ submit các mã CỐ Ý SAI (0000, 1111, 2222, …), **không đọc OTP thật, không dò mã đúng, không đăng nhập**.
- Số lần submit có giới hạn cứng = 6 (đúng như bước repro của bug). Mục tiêu là quan sát phản hồi, không phải vét không gian mã.

## TC-01 Gửi code rồi submit nhiều mã sai liên tiếp
- Preconditions: email đã mua plan
- Steps:
  1. /en/data-balance → nhập email → Send code → màn nhập code hiện ra
  2. Submit mã sai 6 lần liên tiếp, mỗi lần 1 giá trị 4 số cố ý sai khác nhau
  3. Ghi lại phản hồi từng lần
- Expected (theo bug): Sau một số ít lần sai (vd. 3–5), hệ thống phải: rate limit / tạm khoá / CAPTCHA / vô hiệu OTP hiện tại (bắt request lại). Nếu cả 6 lần đều trả cùng "Invalid OTP" mà không có chặn gì → bug CHƯA fix.

## TC-02 Request code mới sau khi đã sai nhiều lần
- Preconditions: TC-01
- Steps: Sau khi fail nhiều lần, thử bấm "Send code" / "Resend" lại
- Expected (ghi nhận): Có giới hạn số lần gửi code không (resend lockout / cooldown)
