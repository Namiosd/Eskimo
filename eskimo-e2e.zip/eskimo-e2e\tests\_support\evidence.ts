// QC evidence (same format as eskimo_portal e2e/networkFlow/evidence-helpers.js):
// every step = 1 screenshot + 1 manifest entry { caseName, ac, title, steps[], expected[], status }.
// Output: evidence/<ticket>-<feature>/ ; then `npm run report:evidence -- <ticket> <feature>`
// → reports/<ticket>-<feature>-e2e-report.html (AC badge / STEPS / EXPECTED / SCREENSHOT, Ctrl+P → PDF).
//
// Rules (from the portal pattern):
// - test.describe.serial, retries 0; resetIfFirstAttempt() only in the FIRST test (not beforeAll).
// - Screenshot first, assert after: compute ok → saveScreenshot(status: ok ? undefined : "failed") → expect.
// - The manifest is appended on disk per shot, so a failing test (worker restart) never loses evidence.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import type { Page, TestInfo } from "@playwright/test";

export type EvidenceMeta = { ac: string; title: string; steps: string[]; expected: string[]; status?: "failed" | "pending" }; // pending = cannot be judged yet (waiting for a confirmation)

export const esc = (s: unknown) =>
  String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// Data with no natural UI (API body, request payload) is rendered as a card, then screenshotted.
export function renderEvidenceHtml(heading: string, bodyHtml: string) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    body{font-family:Arial,sans-serif;padding:24px;color:#222}
    h2{font-size:16px;margin:0 0 12px} h3{font-size:13px;margin:14px 0 6px}
    table{border-collapse:collapse;width:100%;font-size:13px}
    th,td{border:1px solid #d0d0d0;padding:6px 10px;text-align:left;vertical-align:top;word-break:break-all} th{background:#f0f4ff}
    .ok{color:#389e0d;font-weight:700} .bad{color:#cf1322;font-weight:700}
  </style></head><body><h2>${heading}</h2>${bodyHtml}</body></html>`;
}

export function createEvidence(ticket: string, feature: string) {
  const SCREENSHOT_DIR = path.join(process.cwd(), "evidence", `${ticket}-${feature}`);
  const MANIFEST_PATH = path.join(SCREENSHOT_DIR, "manifest.json");
  let currentCase = "";

  const loadManifest = (): any[] => {
    try { return JSON.parse(fs.readFileSync(MANIFEST_PATH, "utf8")); } catch { return []; }
  };

  const setCase = (name: string) => { currentCase = name; };
  const reset = () => fs.rmSync(SCREENSHOT_DIR, { recursive: true, force: true });
  const resetIfFirstAttempt = (testInfo?: TestInfo) => { if (!testInfo || testInfo.retry === 0) reset(); };

  // Case slug + hash of the full title: two steps never share a file name.
  function nextShot(title: string) {
    fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });
    const idx = String(loadManifest().length + 1).padStart(2, "0");
    const caseSlug = (currentCase || "case").replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").toLowerCase().slice(0, 30);
    const slug = title.replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").toLowerCase().slice(0, 40);
    const hash = crypto.createHash("md5").update(title).digest("hex").slice(0, 6);
    const fileName = `${idx}-${caseSlug}-${slug}-${hash}.png`;
    return { fileName, filePath: path.join(SCREENSHOT_DIR, fileName) };
  }

  function appendEntry(meta: EvidenceMeta, fileName: string) {
    const manifest = loadManifest();
    manifest.push({ caseName: currentCase, ...meta, screenshot: fileName });
    fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });
    fs.writeFileSync(MANIFEST_PATH, JSON.stringify(manifest, null, 2), "utf8");
  }

  // CDP capture does not wait for "stable" elements, so antd drawer animations never hang it.
  async function saveScreenshot(page: Page, testInfo: TestInfo | undefined, meta: EvidenceMeta) {
    const { fileName, filePath } = nextShot(meta.title);
    await page.bringToFront().catch(() => {});
    const timeout = (ms: number) => new Promise<never>((_, rej) => setTimeout(() => rej(new Error("capture timeout")), ms));
    try {
      const cdp = await page.context().newCDPSession(page);
      const { data } = await Promise.race([cdp.send("Page.captureScreenshot", { format: "png" }), timeout(15000)]);
      await cdp.detach().catch(() => {});
      fs.writeFileSync(filePath, Buffer.from(data, "base64"));
    } catch {
      // Pages with endless animations can stall CDP capture: fall back to Playwright (animations frozen).
      await page.screenshot({ path: filePath, animations: "disabled", timeout: 20000 }).catch(() => {});
    }
    if (testInfo && fs.existsSync(filePath)) await testInfo.attach(meta.title, { path: filePath, contentType: "image/png" });
    appendEntry(meta, fileName);
  }

  // Render a data card on a scratch page (keeps the app page untouched) and record it as a step.
  async function saveDataCard(scratch: Page, testInfo: TestInfo | undefined, heading: string, bodyHtml: string, meta: EvidenceMeta) {
    await scratch.setContent(renderEvidenceHtml(esc(heading), bodyHtml));
    await saveScreenshot(scratch, testInfo, meta);
  }

  return { SCREENSHOT_DIR, MANIFEST_PATH, setCase, reset, resetIfFirstAttempt, saveScreenshot, saveDataCard };
}
