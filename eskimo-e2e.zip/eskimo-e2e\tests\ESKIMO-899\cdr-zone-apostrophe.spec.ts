// ESKIMO-899 – POST /api/CDR/esim-data-usage returned 500 when SearchZone contains an apostrophe
// (Datapro_Côte_d'Ivoire): the OData filter was built without escaping '.
// Every case runs on Admin › eSIM Live Report (#/transactions-esim-live-report) and records 2 evidence steps:
// the UI (filter + table + any error toast) and the API call the page made (request body, HTTP status, response).
//   TC-01 Zone "Datapro_Côte_d'Ivoire" → 200, only that zone's records                       (AC1)
//   TC-02 Zone with ' and no data ("Datapro_O'Test_None") → 200, numOfRecords = 0              (AC2)
//   TC-03 Zone "Datapro_Japan" (no special char) → 200, only Japan records, no error          (AC3)
//   TC-04 Search IMSI with '  → 200, no error toast                                           (AC4, open question 1)
//   TC-05 Search Singtel Sub ID with ' → 200, no error toast                                  (AC4, open question 1)
//   TC-06 Offer with ' → 200, no error toast                                                  (AC4, open question 1)
//   TC-07 Double-check (direct API, full body): ' / '' / ’ / " / \ / injection-like zones → 200    (AC1/AC2)
// Values missing from the FE dropdown (O'Test zone, offers with ') are sent by rewriting the
// page's own request; the screenshot shows a yellow note saying so. AC4 "one shared helper" = code review, not here.
// Read-only: nothing is created or changed.
// Evidence: evidence/ESKIMO-899-cdr-zone-apostrophe → npm run report:evidence -- ESKIMO-899 cdr-zone-apostrophe
import { test, expect, type Browser, type BrowserContext, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import { API_URL, adminToken } from "../_support/wellatsea";

const ID = "@ESKIMO-899";
const AC = "ESKIMO-899";
const evidence = createEvidence("ESKIMO-899", "cdr-zone-apostrophe");
const ENDPOINT = "/api/CDR/esim-data-usage";
const PAGE_URL = `${ADMIN_URL}/#/transactions-esim-live-report`;
const ZONE_CI = "Datapro_Côte_d'Ivoire";
const ZONE_EMPTY = "Datapro_O'Test_None";
const ZONE_JP = "Datapro_Japan";

type Call = { url: string; status: number; request: any; json: any; text: string; ms: number; rewritten: boolean };

// ─── Direct API (TC-07: zone values the FE dropdown never sends) ───
const FULL_BODY = { pageIndex: 1, pageSize: 20, searchMember: "", searchPlanId: "", searchIMSI: "", searchZone: "", offerName: null, subId: "", startTimeStamp: null, endTimeStamp: null, sortBy: { fieldName: "RecordOpeningTime", ascending: false } };
type Direct = { label: string; body: any; status: number; msg: string; total: number | null; ms: number };
async function direct(label: string, body: any): Promise<Direct> {
  const token = await adminToken(page);
  const t0 = Date.now();
  const r = await fetch(`${API_URL}${ENDPOINT}`, { method: "POST", signal: AbortSignal.timeout(60000), headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
  const text = await r.text();
  let j: any = null;
  try { j = JSON.parse(text); } catch { /* not JSON */ }
  const m = j?.messages;
  const msg = Array.isArray(m) ? m.map((x: any) => x.content).join("; ") : String(m ?? text).slice(0, 160);
  const err = j?.errors?.map((e: any) => `${e.field}: ${e.errorMessage?.map((x: any) => x.errorMessage).join(", ")}`).join("; ");
  return { label, body, status: r.status, msg: err ? `${msg} – ${err}` : msg, total: j?.data?.numOfRecords ?? null, ms: Date.now() - t0 };
}
const directTable = (rows: Direct[], expected: (d: Direct) => boolean) => `<table>
  <tr><th>#</th><th>Case</th><th>Request body (POST ${esc(API_URL + ENDPOINT)})</th><th>HTTP</th><th>numOfRecords</th><th>Message</th></tr>
  ${rows.map((d, i) => `<tr><td>${i + 1}</td><td>${esc(d.label)}</td><td><code>${esc(JSON.stringify(d.body))}</code></td><td class="${expected(d) ? "ok" : "bad"}">${d.status}</td><td>${esc(d.total)}</td><td>${esc(d.msg)}</td></tr>`).join("")}
</table>`;

let ctx: BrowserContext;
let page: Page;

// ─── UI helpers ───
const spinnerGone = () => page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
const mark = (sel: string) => page.locator(sel).first().evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", outlineOffset: "2px" })).catch(() => {});
const filterSelect = (label: string) => page.locator(".custom-filter-col").filter({ has: page.getByText(label, { exact: true }) }).locator(".ant-select").first();

/** Runs `action` and returns the next esim-data-usage call the page makes (request body as actually sent). */
async function captureCall(action: () => Promise<unknown>, match: Record<string, unknown>, override?: Record<string, unknown>): Promise<Call> {
  let sent: any = null;
  if (override) {
    await page.route(`**${ENDPOINT}`, async (route) => {
      sent = { ...(route.request().postDataJSON() ?? {}), ...override };
      await route.continue({ postData: JSON.stringify(sent) });
    });
  }
  const t0 = Date.now();
  // Only the call that carries the filter (the page also fires unfiltered loads on mount / reset)
  const respP = page.waitForResponse((r) => {
    if (!r.url().includes(ENDPOINT) || r.request().method() !== "POST") return false;
    if (override) return true;
    const b = r.request().postDataJSON() ?? {};
    return Object.entries(match).every(([k, v]) => b[k] === v);
  }, { timeout: 90000 });
  await action();
  const resp = await respP;
  const text = await resp.text().catch(() => "");
  let json: any = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* not JSON */ }
  if (override) await page.unroute(`**${ENDPOINT}`);
  await spinnerGone();
  return { url: resp.url(), status: resp.status(), request: sent ?? resp.request().postDataJSON(), json, text, ms: Date.now() - t0, rewritten: !!override };
}

/** One page load: navigate the first time, reload afterwards (a reload resets every filter). */
async function openLiveReport() {
  if (page.url().includes("transactions-esim-live-report")) await page.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
  else await page.goto(PAGE_URL, { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.locator(".ant-table").first().waitFor({ state: "visible", timeout: 60000 });
  await spinnerGone();
}

/** Picks `value` in a filter dropdown; false when the FE list has no such option. */
async function pickOption(label: string, value: string): Promise<boolean> {
  await filterSelect(label).click();
  await page.keyboard.type(value);
  const opt = page.locator(".dropdown-select-open:visible .ant-select-item-option").filter({ hasText: new RegExp(`^${value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`) }).first();
  if (await opt.waitFor({ state: "visible", timeout: 3000 }).then(() => true).catch(() => false)) {
    await opt.click();
    return true;
  }
  await page.keyboard.press("Escape");
  return false;
}

/** Looks for `value` in a filter dropdown without selecting it (no request fired). */
async function hasOption(label: string, value: string): Promise<boolean> {
  await filterSelect(label).click();
  await page.keyboard.type(value);
  const found = await page.locator(".dropdown-select-open:visible .ant-select-item-option").filter({ hasText: new RegExp(`^${value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`) }).first()
    .waitFor({ state: "visible", timeout: 3000 }).then(() => true).catch(() => false);
  await page.keyboard.press("Escape");
  return found;
}

/** Selects `value` in the Zone/Offer dropdown; when it is not in the FE list, rewrites the request the page sends. */
async function filterBy(label: "Zone" | "Offer", value: string, apiField: string) {
  await openLiveReport();
  const inList = await hasOption(label, value);
  if (inList) {
    const call = await captureCall(() => pickOption(label, value), { [apiField]: value });
    await mark(`.custom-filter-col:has-text("${label}") .ant-select`);
    return { call, inList };
  }
  const call = await captureCall(() => openLiveReport(), { [apiField]: value }, { [apiField]: value });
  await page.evaluate(({ label, value, apiField }) => {
    const host = document.querySelector(".custom-filter");
    const note = document.createElement("div");
    note.textContent = `⚠ ${label} "${value}" is not in the FE dropdown list → the test rewrote this page's request: ${apiField} = "${value}"`;
    Object.assign(note.style, { width: "100%", background: "#fff1b8", border: "2px solid #d4b106", padding: "6px 10px", margin: "6px 0", fontWeight: "700", color: "#614700" });
    host?.parentElement?.insertBefore(note, host);
  }, { label, value, apiField });
  return { call, inList };
}

async function searchText(placeholder: string, value: string, apiField: string) {
  await openLiveReport();
  const box = page.getByPlaceholder(placeholder, { exact: true }).first();
  await box.fill(value);
  const call = await captureCall(() => box.press("Enter"), { [apiField]: value });
  await mark(`input[placeholder="${placeholder}"]`);
  return call;
}

/** Table rows (Zone column) + error toast shown by handleApiError (react-toastify). */
async function readUi() {
  const toast = page.locator(".Toastify__toast");
  await toast.first().waitFor({ state: "visible", timeout: 2500 }).catch(() => {});
  const toasts = (await toast.allInnerTexts()).map((t) => t.trim()).filter(Boolean);
  const headers = (await page.locator(".ant-table-thead th").allInnerTexts()).map((h) => h.trim());
  const zi = headers.indexOf("Zone");
  const zones = zi < 0 ? [] : await page.locator(".ant-table-tbody tr.ant-table-row").evaluateAll((trs, i) => trs.map((tr) => (tr.children[i] as HTMLElement)?.innerText.trim()), zi);
  const empty = await page.locator(".ant-table-tbody .ant-empty").count() > 0;
  return { toasts, zones, empty };
}

// ─── API evidence card ───
const rowsOf = (c: Call): any[] => c.json?.data?.data ?? [];
const totalOf = (c: Call): number | null => c.json?.data?.numOfRecords ?? null;
const errOf = (c: Call) => (c.status === 200 ? "" : String(c.json?.message ?? c.json?.title ?? c.text).slice(0, 400));

function callHtml(c: Call) {
  const rows = rowsOf(c);
  const zones = [...new Set(rows.map((x) => x.zone))];
  return `<table>
    <tr><th>Request</th><td>POST ${esc(c.url)}${c.rewritten ? ' <span class="bad">(body rewritten by the test – value not in FE list)</span>' : " (sent by the page)"}</td></tr>
    <tr><th>Request body</th><td><pre style="margin:0;white-space:pre-wrap">${esc(JSON.stringify(c.request, null, 2))}</pre></td></tr>
    <tr><th>HTTP status</th><td class="${c.status === 200 ? "ok" : "bad"}">${c.status} (${c.ms} ms)</td></tr>
    <tr><th>isSuccess</th><td>${esc(c.json?.isSuccess)}</td></tr>
    <tr><th>numOfRecords</th><td>${esc(totalOf(c))}</td></tr>
    <tr><th>Rows on page 1</th><td>${rows.length}</td></tr>
    <tr><th>Distinct zones on page 1</th><td>${esc(zones.join(", ") || "—")}</td></tr>
    ${errOf(c) ? `<tr><th>Error body</th><td class="bad">${esc(errOf(c))}</td></tr>` : ""}
  </table>${rows.length ? `<h3>First rows</h3><table><tr><th>IMSI</th><th>Sub ID</th><th>Zone</th><th>Offer</th></tr>${rows.slice(0, 5).map((x) => `<tr><td>${esc(x.imsi)}</td><td>${esc(x.subscriptionId)}</td><td>${esc(x.zone)}</td><td>${esc(x.offerName)}</td></tr>`).join("")}</table>` : ""}`;
}

async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const c = await browser.newContext();
  try { await evidence.saveDataCard(await c.newPage(), testInfo, heading, html, meta); } finally { await c.close(); }
}

/** UI screenshot + API card for one case; returns whether it passed. */
async function record(browser: Browser, testInfo: TestInfo, o: { tc: string; ac: string; what: string; uiSteps: string[]; call: Call; ui: Awaited<ReturnType<typeof readUi>>; expectZone?: string; expectZero?: boolean; warn?: string[] }) {
  const { call, ui } = o;
  const apiRows = rowsOf(call);
  const otherApi = o.expectZone ? apiRows.filter((x) => x.zone !== o.expectZone) : [];
  const otherUi = o.expectZone ? ui.zones.filter((z) => z !== o.expectZone) : [];
  const zeroOk = !o.expectZero || totalOf(call) === 0;
  const uiOk = ui.toasts.length === 0 && otherUi.length === 0;
  const apiOk = call.status === 200 && call.json?.isSuccess !== false && otherApi.length === 0 && zeroOk;
  const noData = call.status === 200 && apiRows.length === 0 && !!o.expectZone;
  const warn = [...(o.warn ?? []), ...(noData ? [`⚠ WARNING: no CDR for this zone on stage → "only that zone's records" not verifiable`] : [])];
  await evidence.saveScreenshot(page, testInfo, {
    ac: `${AC} ${o.ac}`, title: `${o.tc} UI – ${o.what}`,
    steps: [
      "Admin › Transactions › eSIM Live Report",
      ...o.uiSteps,
      `Table: ${ui.empty ? "No Data" : `${ui.zones.length} rows`}${o.expectZone ? ` · rows of another zone: ${otherUi.length}` : ""}`,
      ui.toasts.length ? `Error toast: "${ui.toasts.join(" | ")}"` : "No error toast",
      ...warn,
    ],
    expected: ["Table loads, no error toast (\"Something went wrong…\" = HTTP 500)", ...(o.expectZone ? [`Zone column = ${o.expectZone} on every row`] : [])],
    status: uiOk ? undefined : "failed",
  });
  await card(browser, testInfo, `${o.tc} – API call made by the page: ${o.what}`, callHtml(call), {
    ac: `${AC} ${o.ac}`, title: `${o.tc} API – ${o.what}`,
    steps: [`POST ${ENDPOINT} ${JSON.stringify(Object.fromEntries(Object.entries(call.request ?? {}).filter(([k, v]) => ["searchZone", "searchIMSI", "subId", "offerName"].includes(k) && v)))}`, `HTTP ${call.status} · isSuccess=${call.json?.isSuccess} · numOfRecords=${totalOf(call)}`, ...(o.expectZone ? [`Rows of another zone: ${otherApi.length}`] : [])],
    expected: ["HTTP 200 (not 500)", ...(o.expectZero ? ["numOfRecords = 0"] : []), ...(o.expectZone ? [`Every record has zone = "${o.expectZone}"`] : [])],
    status: apiOk ? undefined : "failed",
  });
  expect(call.status, `HTTP status: ${errOf(call)}`).toBe(200);
  expect(ui.toasts, "error toast").toEqual([]);
  if (o.expectZero) expect(totalOf(call)).toBe(0);
  if (o.expectZone) {
    expect(otherApi.map((x) => x.zone), "API records of another zone").toEqual([]);
    expect(otherUi, "UI rows of another zone").toEqual([]);
  }
}

test.describe(`ESKIMO-899 CDR esim-data-usage zone with apostrophe ${ID}`, () => {
  test.describe.configure({ timeout: 180_000 }); // stage page loads take ~20 s each, several per case
  test.beforeAll(async ({ browser }) => { ({ ctx, page } = await adminSession(browser)); });
  test.afterAll(async () => { await ctx?.close(); });

  test(`TC-01 Zone Datapro_Côte_d'Ivoire returns 200 with only that zone ${ID}`, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Zone Côte d'Ivoire");
    const { call, inList } = await filterBy("Zone", ZONE_CI, "searchZone");
    await record(browser, testInfo, { tc: "TC-01", ac: "AC1", what: `Zone = ${ZONE_CI}`, call, ui: await readUi(), expectZone: ZONE_CI,
      uiSteps: [inList ? `Zone = ${ZONE_CI} (picked from the dropdown)` : `Zone "${ZONE_CI}" not in the dropdown (ESKIMO-864) → request rewritten`] });
  });

  test(`TC-02 Zone with apostrophe and no data returns 200 with 0 records ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-02 Zone with ' – no data");
    const { call } = await filterBy("Zone", ZONE_EMPTY, "searchZone");
    await record(browser, testInfo, { tc: "TC-02", ac: "AC2", what: `Zone = ${ZONE_EMPTY}`, call, ui: await readUi(), expectZero: true,
      uiSteps: [`Zone "${ZONE_EMPTY}" (zone that does not exist) → request rewritten`] });
  });

  test(`TC-03 Zone Datapro_Japan still filters correctly ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-03 Zone Japan – regression");
    const { call, inList } = await filterBy("Zone", ZONE_JP, "searchZone");
    expect(inList, `${ZONE_JP} must be in the Zone dropdown`).toBe(true);
    await record(browser, testInfo, { tc: "TC-03", ac: "AC3", what: `Zone = ${ZONE_JP}`, call, ui: await readUi(), expectZone: ZONE_JP,
      uiSteps: [`Zone = ${ZONE_JP} (picked from the dropdown)`] });
  });

  test(`TC-04 Search IMSI with apostrophe does not return 500 ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-04 Search IMSI with '");
    const call = await searchText("Search IMSI", "123'456", "searchIMSI");
    await record(browser, testInfo, { tc: "TC-04", ac: "AC4", what: "Search IMSI = 123'456", call, ui: await readUi(),
      uiSteps: ["Search IMSI = 123'456 → Enter"], warn: ["Note: open question 1 (escape IMSI too?) is unanswered on the item → result is reported"] });
  });

  test(`TC-05 Search Singtel Sub ID with apostrophe does not return 500 ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-05 Search Sub ID with '");
    const call = await searchText("Search Singtel Sub ID", "SUB'01", "subId");
    await record(browser, testInfo, { tc: "TC-05", ac: "AC4", what: "Search Singtel Sub ID = SUB'01", call, ui: await readUi(),
      uiSteps: ["Search Singtel Sub ID = SUB'01 → Enter"], warn: ["Note: open question 1 (escape SubId too?) is unanswered on the item → result is reported"] });
  });

  test(`TC-06 Offer with apostrophe does not return 500 ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-06 Offer with '");
    const { call } = await filterBy("Offer", "Plan'Test", "offerName");
    await record(browser, testInfo, { tc: "TC-06", ac: "AC4", what: "Offer = Plan'Test", call, ui: await readUi(),
      uiSteps: ["Offer \"Plan'Test\" (no offer with ' in the dropdown) → request rewritten"], warn: ["Note: open question 1 (escape OfferName too?) is unanswered on the item → result is reported"] });
  });

  test(`TC-07 Double-check: special characters in searchZone return 200 ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-07 Double-check – special characters");
    const zones: [string, string][] = [
      ["Côte d'Ivoire (')", ZONE_CI], ["only '", "'"], ["pre-escaped ''", "Datapro_Côte_d''Ivoire"], ["curly ’", "Datapro_Côte_d’Ivoire"],
      ["mojibake C?te", "Datapro_C?te_d'Ivoire"], ['double quote "', 'a"b'], ["backslash \\", "a\\b"], ["injection-like", "x' or Zone ne 'y"],
    ];
    const rows: Direct[] = [];
    for (const [label, z] of zones) rows.push(await direct(label, { ...FULL_BODY, searchZone: z }));
    const bad = rows.filter((d) => d.status !== 200);
    await card(browser, testInfo, "TC-07 – searchZone with special characters (full body, pageIndex 1)", directTable(rows, (d) => d.status === 200), {
      ac: `${AC} AC1/AC2`, title: "TC-07 API – special characters in searchZone",
      steps: ["Direct API call, same body as the eSIM Live Report page (pageIndex 1, pageSize 20)", ...rows.map((d) => `${d.label}: searchZone=${JSON.stringify(d.body.searchZone)} → HTTP ${d.status}`)],
      expected: ["HTTP 200 for every value (the ' no longer breaks the OData filter)"],
      status: bad.length ? "failed" : undefined,
    });
    expect(bad.map((d) => `${d.label}: ${d.status}`)).toEqual([]);
  });
});
