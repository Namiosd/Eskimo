# ESKIMO-386 – [EP-6059] WellAtSea Magic Link: click-tracking + reusable/no-OTP

Môi trường: STG — storefront https://wellatsea.eskimo.travel (partner PN101609, "White Label 2")
Dữ liệu: magic link + email link href của tài khoản test testwhitelabeluat2@yopmail.com
(lấy từ run journey EP-5965 ngày 2026-10-15/16, lưu ở d:\eskimo_portal\e2e\.tmp-wellatsea-run-state.json).
Chỉ đọc: không mua, không gửi OTP, KHÔNG dùng token của khách thật trong mô tả bug.

Bối cảnh: EP-6059 là bug của ticket chính EP-5965 / ESKIMO-753. Ticket chính đã chốt AC3 = **"The Magic Link no expires"** và AC4 = "partner can use magic link to quick login".

## TC-01 Click-tracking đã tắt cho email có magic link (phần cần fix)
- Steps: Đọc href gốc của mọi link trong email purchase/QR của tài khoản test
- Expected: Mọi link trỏ TRỰC TIẾP https://wellatsea.eskimo.travel/...; KHÔNG bọc ct.sendgrid.net / /ls/click
- Đây là Expected Result hợp lệ của bug → nếu đạt = phần đáng fix đã xong.

## TC-02 Magic link mở ví không cần OTP, dùng lại được (đúng thiết kế)
- Steps: Mở magic link ở 2 context trình duyệt MỚI (không session) liên tiếp
- Expected: Cả 2 lần vào thẳng ví của đúng email — reusable + quick login theo AC3/AC4
- Ghi nhận: đây là hành vi đúng spec (no expires, quick login), KHÔNG tính là lỗi. Mô tả bug coi "reusable/1-day expiry/single-use" là lỗi → sai so với AC3.

## TC-03 Đối chiếu mô tả bug vs AC3/AC4 (ghi nhận)
- Expected: Liệt kê các đoạn mô tả sai để team chỉnh:
  - "spec: 1 day, per AC3" → AC3 thật = no expires
  - "not single-use / reusable" là lỗi → thực tế là thiết kế (valid 730 ngày, reusable)
  - "confirm button thay cho GET-login" → ngược AC4 (quick login)
