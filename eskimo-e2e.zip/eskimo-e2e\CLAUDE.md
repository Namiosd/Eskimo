# CLAUDE.md — ESKIMO Portal E2E (Playwright)

This file provides guidance when working with the Eskimo Portal end-to-end test suite. The suite lives in `d:\eskimo-e2e` (sibling of the portal UI at `d:\eskimo_portal`). The PHP 7.3 compatibility rules in the portal's root `CLAUDE.md` apply to the UI code — **this e2e project is TypeScript + Playwright only.**

## Project

- **Type**: Playwright e2e suite (`@playwright/test@1.63.0`), ES modules (`"type": "module"`, TS via ts-node/Bun runtime).
- **SUT**: Admin partner portal SPA = `d:\eskimo_portal` built React app, hash-routing (`/#/...`), Ant Design 4.x.
- **Auth gate**: Playwright **cannot** fetch the login page (tool sees only the SPA shell / redirect). The admin session must be supplied externally (see *Browser context & sessions*). All selectors assume you are already authenticated.

## Commands

```bash
npm test                                       # run everything (headless)
npm run report                                 # open last HTML report

# Run a single file
npx playwright test tests/ESKIMO-910/application-fee-by-data-amount.spec.ts

# Run by test title (grep)
npx playwright test tests/ESKIMO-910/--grep "TC-02 Add" --timeout 360000 --workers 1 --reporter line

# Headed (for manual inspection of a hang)
npx playwright test <file> --headed --workers 1

# Open a saved trace
npx playwright show-trace test-results/<run-dir>/trace.zip

# Pretty evidence PDF (uses screenshots + testcases markdown)
npm run report:evidence
```

## Layout & conventions

```
e2e/
 tests/
   _support/            shared helpers
     whitelabel.ts      WL partner helpers  (openPartnerDrawer, openCorporate, corporate(), focus, shot, rowOf, formItem)
     wellatsea.ts       WellSea eSIM helpers
     eskimo.ts          core: ADMIN_URL, buildId, api(), apiJson(), findPartner()
     evidence.ts        shot()/screenshot evidence helpers
     ecommerce.ts, yopmail.ts, generate-report.mjs, print-pdf.mjs
   ESKIMO-NNN/            one folder per ticket
     <ticket>-<desc>.spec.ts
 testcases/ESKIMO-NNN/ESKIMO-NNN.md   written test-case description (spec-of-truth)
```

### Naming
- Use the ticket number as the feature tag, e.g. `@ESKIMO-910`.
- `TC-NNN <short> ...` test titles mirror `testcases/ESKIMO-NNN.md`.
- Evidence screenshots via `shot(page, name)` from `evidence.ts` — keep names stable so `report:evidence` can diff.

## Selector conventions (Ant Design 4)

| Target | Selector pattern | Notes |
|---|---|---|
| Visible modal/drawer | `.ant-modal:visible`, `.ant-drawer-open` | always `.first()`/`.last()` visible-filtered |
| a select trigger | `.ant-select-selector` | `.first()` inside the row/field |
| open dropdown | `page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last()` then `waitFor({timeout:15000})` | the `:not(.hidden)` guard avoids the closed one |
| select options | `.ant-select-item-option` (or `...-content`) | `hasText` regex filter, `.first()` |
| option disabled flag | class `ant-select-item-option-disabled` |
| list row match | `rowOf(new RegExp(...,"i"))` helper in whitelabel.ts |
| form label field | `formItem(body, "Label text")` → `.ant-form-item` |
| WL "add" button | `.custom-button-add-gift-code` filtered by `{hasText:/Add Application Fee|New Application Fee/i}` | confirmed present on staging |
| close drawer/modal | `button.btn-action-cancel:visible` with `/^\s*Close\s*$/` OR `Escape` |

### Dropdowns rendered inside a cell (`getPopupContainer`)
Many WL selects use `getPopupContainer={(trigger)=>trigger.parentNode}`, so the dropdown renders **inside its row/cell**. `.last()` on the visible dropdown usually picks the cell one — but if the row scrolls during the wait the dropdown can detach. Always `await row.scrollIntoViewIfNeeded()` before opening a select, and re-query the dropdown after the select opens.

## Diagnostics & debugging

- Inject temporary `console.log("[dbg-<name>] ...")` inside the failing helper — Playwright mirrors `console.*` to stdout (grep `dbg-`).
- Inspect the `error-context.md` (Page snapshot) in the failed `test-results` dir — note: the captured page is the **last** known state and may be the afterAll restore (dashboard), not the hang point. Use `trace.zip` + logs for the real hang location.
- The `trace.zip` is the source of truth — it includes step list, network, DOM snapshot and the "what's-visible" view.
- `screenshot-on-take` is auto; `test-failed-*.png` + `trace.zip` are emitted per failure.

## Browser context & sessions
- Tests reuse a pre-authenticated browser context. If you see the SPA shell with no `#/dashboard` nav, the session expired — refresh the persisted context/cookie before re-running.
- `ADMIN_URL` global points at the admin stage where you have active session.

## Conventions to keep
- PHP 7.3+ in portal code (no typed properties, no `?->`, no `match()`, no `str_contains`) — **only** relevant when editing portal, not e2e TS.
- Keep `testcases/ESKIMO-NNN.md` and the `.spec.ts` in sync (titles + steps).
- Don't add node_modules changes; deps are locked to Playwright 1.63.
