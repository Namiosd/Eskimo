// ESKIMO-928 - Recycle eSIM batch TIMING measurement.
// Measures two durations on the eSim Recycle flow (same endpoints the page calls):
//   T1 = Checking(4) -> Pending(1)    for newly created batches
//   T2 = Confirming(5) -> Confirmed(2) for Pending batches we Confirm
//
// What it DOES (writes):  creates E2E_RECYCLE_NEW_BATCH_COUNT batches (size E2E_RECYCLE_AMOUNT)
//                          confirms Pending batches (the newly created ones + E2E_RECYCLE_CONFIRM_BATCH_IDS,
//                          or all pending >= E2E_RECYCLE_MIN_ESIM if no IDs given)
// What it NEVER does:      delete  cancel  (no batchStatus:3, no delete call)
//
// Auth:  set E2E_ADMIN_JWT (admin accessToken copied from the browser) -> used directly for API calls,
//        skips UI login (use this for PROD). The token is read from env, no page.evaluate needed.
//        leave empty -> falls back to adminSession UI OTP login (staging); token then read from the page.
//
// Report (common template, same as other ESKIMO-* specs):
//   1) npx playwright test tests/ESKIMO-928/recycle-batch-timing.spec.ts   (writes evidence/ manifest + screenshots)
//   2) npm run report:evidence -- ESKIMO-928 recycle-batch-timing "PROD . timing"
//      -> reports/ESKIMO-928-recycle-batch-timing-e2e-report.html (open in Chrome, Ctrl+P -> PDF for Jira)
//   Also writes raw data: reports/ESKIMO-928-recycle-batch-timing-report.json + .md
import fs from "node:fs";
import { test, expect, type Browser, type BrowserContext, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { API_URL, adminToken } from "../_support/wellatsea";
import { createEvidence, esc } from "../_support/evidence";

const ID = "@ESKIMO-928";
const AC = "ESKIMO-928 timing";
const evidence = createEvidence("ESKIMO-928", "recycle-batch-timing");
const STATUS: Record<number, string> = { 1: "Pending", 2: "Confirmed", 3: "Cancelled", 4: "Checking", 5: "Confirming" };
const PAGE_URL = `${ADMIN_URL}/#/esim-codes`;

// --- config (env) ---
const AMOUNT = Number(process.env.E2E_RECYCLE_AMOUNT || 500);
const NEW_BATCH_COUNT = Number(process.env.E2E_RECYCLE_NEW_BATCH_COUNT || 2);
const CONFIRM_LIMIT = Number(process.env.E2E_RECYCLE_CONFIRM_LIMIT || 0); // 0 = all qualifying
const CONFIRM_BATCH_IDS = (process.env.E2E_RECYCLE_CONFIRM_BATCH_IDS || "").split(",").map((s) => s.trim()).filter(Boolean); // specific existing batch IDs to also confirm for T2 (comma-separated)
const MIN_ESIM = Number(process.env.E2E_RECYCLE_MIN_ESIM || 100);          // skip tiny batches for T2
const POLL_MS = Number(process.env.E2E_RECYCLE_POLL_MS || 5000);
const TIMEOUT_MS = Number(process.env.E2E_RECYCLE_TIMEOUT_MS || 900000);   // 15 min / transition
const JWT = process.env.E2E_ADMIN_JWT || "";

type Batch = { batchID: string; status: number; totalEsim: number | null; assign: number | null; createdTime: string; batchName?: string };
type TimingRow = {
  batchId: string; amount: number; phase: "Checking->Pending" | "Confirming->Confirmed";
  start: string; end: string; durationMs: number; durationSec: number;
  startStatus: number; endStatus: number; note?: string;
};
type Env = { AMOUNT: number; NEW_BATCH_COUNT: number; CONFIRM_LIMIT: number; CONFIRM_BATCH_IDS: string[]; MIN_ESIM: number; POLL_MS: number; TIMEOUT_MS: number; API_URL: string; ADMIN_URL: string; prod: boolean };
type Summary = { T1_Checking_to_Pending: Stat; T2_Confirming_to_Confirmed: Stat };
type Stat = { count: number; minSec: number | null; maxSec: number | null; avgSec: number | null };

let ctx: BrowserContext;
let page: Page;
let scratch: Page;
let authToken = "";

// --- API (same endpoints the page calls) ---
async function api(method: string, path: string, body?: unknown) {
  if (!authToken) throw new Error("No auth token available - set E2E_ADMIN_JWT or run staging login.");
  const r = await fetch(`${API_URL}${path}`, {
    method,
    signal: AbortSignal.timeout(60000),
    headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: `Bearer ${authToken}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any = null;
  try { json = JSON.parse(text); } catch (e) { /* not JSON */ }
  return { status: r.status, json, text };
}

async function listBatches(status: number | null = null, size = 100): Promise<Batch[]> {
  const r = await api("POST", "/api/inventories/search-batch-recycle-inventory", {
    pageIndex: 1, pageSize: size, searchText: "", batchStatus: status,
    sortBy: { fieldName: "CreatedTime", ascending: false },
  });
  return r.json?.data?.data?.data ?? [];
}
const getBatch = async (id: string) => (await listBatches(null, 100)).find((b) => b.batchID === id);

/** Poll until the batch reaches one of `want` statuses (or timeout). Returns the batch + elapsed ms + statuses seen. */
async function waitStatus(id: string, want: number[], timeoutMs: number): Promise<{ batch?: Batch; elapsedMs: number; seen: string[] }> {
  const start = Date.now();
  const end = start + timeoutMs;
  const seen: string[] = [];
  let b: Batch | undefined;
  while (Date.now() < end) {
    b = await getBatch(id);
    const s = b ? STATUS[b.status] ?? String(b.status) : "not found";
    if (seen[seen.length - 1] !== s) seen.push(s);
    if (b && want.includes(b.status)) return { batch: b, elapsedMs: Date.now() - start, seen };
    await new Promise((r) => setTimeout(r, POLL_MS));
  }
  return { batch: b, elapsedMs: Date.now() - start, seen };
}

/** Create one recycle batch via API; returns { batchId, tStart } once it appears in the list as Checking. */
async function createBatch(amount: number): Promise<{ batchId: string; tStart: number }> {
  const before = new Set((await listBatches(null, 30)).map((b) => b.batchID));
  const tStart = Date.now();
  const r = await api("POST", "/api/inventories/search-recycle-inventory", {
    detectionConfig: { esimQuantity: amount }, checkBySingtel: true,
  });
  if (r.status >= 400 || !r.json?.isSuccess) {
    throw new Error(`Create batch failed: HTTP ${r.status} - ${r.text.slice(0, 300)}`);
  }
  let newBatch: Batch | undefined;
  for (let i = 0; i < 30 && !newBatch; i++) {
    const after = await listBatches(null, 30);
    newBatch = after.find((b) => !before.has(b.batchID));
    if (!newBatch) await new Promise((r) => setTimeout(r, 2000));
  }
  if (!newBatch) throw new Error("Created batch did not appear in the list after 60s");
  return { batchId: newBatch.batchID, tStart };
}

/** Confirm a Pending batch via API (batchStatus=2, processByJob=true). Returns tStart (moment PUT returned). */
async function confirmBatch(batchId: string): Promise<number> {
  const tStart = Date.now();
  const r = await api("PUT", "/api/inventories/update-batch", { batchId, batchStatus: 2, processByJob: true });
  if (r.status >= 400 || !r.json?.isSuccess) {
    throw new Error(`Confirm batch ${batchId} failed: HTTP ${r.status} - ${r.text.slice(0, 300)}`);
  }
  return tStart;
}

function isProd() {
  return /api\.eskimo\.travel/i.test(API_URL) || /admin\.eskimo\.travel/i.test(ADMIN_URL);
}

// --- session ---
async function timingSession(browser: Browser) {
  if (JWT) {
    // PROD: use the token directly from env for all API calls (no page.evaluate needed).
    authToken = JWT;
    ctx = await browser.newContext({ baseURL: ADMIN_URL });
    await (ctx as any).addInitScript((token: string) => {
      localStorage.setItem("accessToken", token);
      try {
        const decoded: any = JSON.parse(atob(token.split(".")[1]));
        localStorage.setItem("hotspot", JSON.stringify({
          token,
          userId: decoded.userId || decoded.sub || "",
          role: decoded["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"] || "Super Administrator",
        }));
      } catch (e) { /* not a JWT / parse error - accessToken alone is enough for API calls */ }
    }, JWT);
    page = await ctx.newPage();
    // Best-effort load of the admin page (for screenshots only); API timing does not depend on it.
    await page.goto(PAGE_URL, { waitUntil: "domcontentloaded", timeout: 90000 }).catch(() => {});
  } else {
    if (isProd()) {
      throw new Error("PROD detected but E2E_ADMIN_JWT is empty. Copy the admin accessToken from the browser localStorage and set E2E_ADMIN_JWT (OTP login cannot be automated on PROD).");
    }
    ({ ctx, page } = await adminSession(browser));
    authToken = await adminToken(page);
    await page.goto(PAGE_URL, { waitUntil: "domcontentloaded", timeout: 90000 }).catch(() => {});
  }
  if (!authToken) throw new Error("No admin token after session start - check E2E_ADMIN_JWT / login.");
  // Verify the token is accepted by the API.
  const probe = await api("POST", "/api/inventories/search-batch-recycle-inventory", {
    pageIndex: 1, pageSize: 1, searchText: "", batchStatus: null, sortBy: { fieldName: "CreatedTime", ascending: false },
  });
  if (probe.status === 401 || probe.status === 403) {
    throw new Error(`Admin token rejected (HTTP ${probe.status}). Copy a fresh accessToken from the browser localStorage and set E2E_ADMIN_JWT.`);
  }
}

// --- report data ---
function fmtDate(ms: number) { return new Date(ms).toISOString(); }
function buildEnv(): Env {
  return { AMOUNT, NEW_BATCH_COUNT, CONFIRM_LIMIT, CONFIRM_BATCH_IDS, MIN_ESIM, POLL_MS, TIMEOUT_MS, API_URL, ADMIN_URL, prod: isProd() };
}
function computeSummary(rows: TimingRow[]): Summary {
  const stat = (xs: TimingRow[]): Stat => xs.length
    ? { count: xs.length, minSec: Math.min(...xs.map((x) => x.durationSec)), maxSec: Math.max(...xs.map((x) => x.durationSec)), avgSec: Math.round(xs.reduce((a, b) => a + b.durationSec, 0) / xs.length) }
    : { count: 0, minSec: null, maxSec: null, avgSec: null };
  return {
    T1_Checking_to_Pending: stat(rows.filter((r) => r.phase === "Checking->Pending" && r.endStatus === 1)),
    T2_Confirming_to_Confirmed: stat(rows.filter((r) => r.phase === "Confirming->Confirmed" && r.endStatus === 2)),
  };
}

function timingTableHtml(rows: TimingRow[]): string {
  const head = "<tr><th>BatchID</th><th>Amount</th><th>Phase</th><th>Duration (s)</th><th>Start->End</th><th>Note</th></tr>";
  const body = rows.map((r) => {
    const ok = r.endStatus === 1 || r.endStatus === 2;
    return `<tr><td>${esc(r.batchId)}</td><td>${r.amount}</td><td>${esc(r.phase)}</td><td class="${ok ? "ok" : "bad"}">${r.durationSec}</td><td>${esc(STATUS[r.startStatus] ?? r.startStatus)}->${esc(STATUS[r.endStatus] ?? r.endStatus)}</td><td>${esc(r.note ?? "")}</td></tr>`;
  }).join("");
  return `<table>${head}${body}</table>`;
}

function summaryCardHtml(env: Env, summary: Summary): string {
  const s1 = summary.T1_Checking_to_Pending;
  const s2 = summary.T2_Confirming_to_Confirmed;
  return `<h3>Config</h3><table>
    <tr><th>Environment</th><td>${esc(env.prod ? "PROD" : "STAGE/QA")} (${esc(env.API_URL)})</td></tr>
    <tr><th>Amount / batch</th><td>${env.AMOUNT}</td></tr>
    <tr><th>New batches</th><td>${env.NEW_BATCH_COUNT}</td></tr>
    <tr><th>Min eSIM (T2 filter)</th><td>${env.MIN_ESIM}</td></tr>
    <tr><th>Confirm batch IDs</th><td>${esc(JSON.stringify(env.CONFIRM_BATCH_IDS))}</td></tr>
    <tr><th>Poll / timeout</th><td>${env.POLL_MS}ms / ${env.TIMEOUT_MS}ms</td></tr>
  </table>
  <h3>Summary (min / avg / max seconds)</h3><table>
    <tr><th>Phase</th><th>Count</th><th>Min (s)</th><th>Avg (s)</th><th>Max (s)</th></tr>
    <tr><td>T1 Checking->Pending</td><td>${s1.count}</td><td>${s1.minSec ?? "-"}</td><td>${s1.avgSec ?? "-"}</td><td>${s1.maxSec ?? "-"}</td></tr>
    <tr><td>T2 Confirming->Confirmed</td><td>${s2.count}</td><td>${s2.minSec ?? "-"}</td><td>${s2.avgSec ?? "-"}</td><td>${s2.maxSec ?? "-"}</td></tr>
  </table>`;
}

function writeReport(rows: TimingRow[], env: Env, summary: Summary) {
  fs.mkdirSync("reports", { recursive: true });
  const jsonPath = "reports/ESKIMO-928-recycle-batch-timing-report.json";
  const mdPath = "reports/ESKIMO-928-recycle-batch-timing-report.md";
  const generatedAt = new Date().toISOString();
  fs.writeFileSync(jsonPath, JSON.stringify({ ticket: "ESKIMO-928", generatedAt, env, summary, rows }, null, 2));

  const md: string[] = [];
  md.push(`# ESKIMO-928 - Recycle eSIM batch timing report`);
  md.push(``);
  md.push(`- Generated: ${generatedAt}`);
  md.push(`- Environment: ${env.prod ? "PROD" : "STAGE/QA"} (${env.API_URL})`);
  md.push(`- Config: amount=${env.AMOUNT}, newBatches=${env.NEW_BATCH_COUNT}, confirmLimit=${env.CONFIRM_LIMIT}, confirmBatchIds=${JSON.stringify(env.CONFIRM_BATCH_IDS)}, minEsim=${env.MIN_ESIM}, pollMs=${env.POLL_MS}, timeoutMs=${env.TIMEOUT_MS}`);
  md.push(``);
  md.push(`## Summary`);
  md.push(`| Phase | Count | Min (s) | Avg (s) | Max (s) |`);
  md.push(`|---|---|---|---|---|`);
  md.push(`| T1 Checking->Pending | ${summary.T1_Checking_to_Pending.count} | ${summary.T1_Checking_to_Pending.minSec ?? "-"} | ${summary.T1_Checking_to_Pending.avgSec ?? "-"} | ${summary.T1_Checking_to_Pending.maxSec ?? "-"} |`);
  md.push(`| T2 Confirming->Confirmed | ${summary.T2_Confirming_to_Confirmed.count} | ${summary.T2_Confirming_to_Confirmed.minSec ?? "-"} | ${summary.T2_Confirming_to_Confirmed.avgSec ?? "-"} | ${summary.T2_Confirming_to_Confirmed.maxSec ?? "-"} |`);
  md.push(``);
  md.push(`## Per-batch`);
  md.push(`| BatchID | Amount | Phase | Duration (s) | Start status | End status | Start | End | Note |`);
  md.push(`|---|---|---|---|---|---|---|---|---|`);
  for (const r of rows) {
    md.push(`| ${r.batchId} | ${r.amount} | ${r.phase} | ${r.durationSec} | ${STATUS[r.startStatus] ?? r.startStatus} | ${STATUS[r.endStatus] ?? r.endStatus} | ${r.start} | ${r.end} | ${r.note ?? ""} |`);
  }
  fs.writeFileSync(mdPath, md.join("\n"));

  const line = "=".repeat(112);
  console.log(`\n${line}\nESKIMO-928 RECYCLE BATCH TIMING - ${generatedAt} - ${env.prod ? "PROD" : "STAGE/QA"}\n${line}`);
  console.log("Phase                       BatchID                Amount   Duration(s)   Start->End          Note");
  console.log("-".repeat(112));
  for (const r of rows) {
    console.log(`${r.phase.padEnd(28)} ${r.batchId.padEnd(22)} ${String(r.amount).padEnd(8)} ${String(r.durationSec).padEnd(13)} ${STATUS[r.startStatus] ?? r.startStatus}->${STATUS[r.endStatus] ?? r.endStatus}   ${r.note ?? ""}`);
  }
  console.log("-".repeat(112));
  console.log(`T1 Checking->Pending:     ${summary.T1_Checking_to_Pending.count} batches - min ${summary.T1_Checking_to_Pending.minSec ?? "-"}s, avg ${summary.T1_Checking_to_Pending.avgSec ?? "-"}s, max ${summary.T1_Checking_to_Pending.maxSec ?? "-"}s`);
  console.log(`T2 Confirming->Confirmed:  ${summary.T2_Confirming_to_Confirmed.count} batches - min ${summary.T2_Confirming_to_Confirmed.minSec ?? "-"}s, avg ${summary.T2_Confirming_to_Confirmed.avgSec ?? "-"}s, max ${summary.T2_Confirming_to_Confirmed.maxSec ?? "-"}s`);
  console.log(`Report -> ${jsonPath} + ${mdPath}  (HTML: npm run report:evidence -- ESKIMO-928 recycle-batch-timing)\n${line}\n`);
}

// --- evidence helpers (best-effort: never let evidence break the timing test) ---
async function card(testInfo: TestInfo, title: string, heading: string, bodyHtml: string, steps: string[], expected: string[], status?: "failed" | "pending") {
  try {
    evidence.setCase(title);
    await evidence.saveDataCard(scratch, testInfo, heading, bodyHtml, { ac: AC, title, steps, expected, status });
  } catch (e) { console.log(`  (evidence card skipped: ${(e as Error).message})`); }
}

// --- test ---
test.describe.serial(`ESKIMO-928 Recycle batch timing ${ID}`, () => {
  test(`Measure T1 (Checking->Pending) and T2 (Confirming->Confirmed) ${ID}`, async ({ browser }, testInfo) => {
    test.setTimeout(Number(process.env.E2E_RECYCLE_TEST_TIMEOUT_MS || 40) * 60_000);
    evidence.resetIfFirstAttempt(testInfo);
    await timingSession(browser);
    scratch = await ctx.newPage();
    const rows: TimingRow[] = [];

    // -- Phase 1: create N new batches, measure Checking -> Pending --
    console.log(`[Phase 1] Creating ${NEW_BATCH_COUNT} batch(es) of ${AMOUNT} eSIMs to measure Checking->Pending ...`);
    const created: { batchId: string; tStart: number }[] = [];
    for (let i = 0; i < NEW_BATCH_COUNT; i++) {
      const c = await createBatch(AMOUNT);
      created.push(c);
      console.log(`  created batch ${c.batchId} (Checking) at ${fmtDate(c.tStart)}`);
    }

    for (const c of created) {
      const { batch, elapsedMs, seen } = await waitStatus(c.batchId, [1, 2, 3, 5], TIMEOUT_MS);
      const endStatus = batch?.status ?? -1;
      rows.push({
        batchId: c.batchId, amount: AMOUNT, phase: "Checking->Pending",
        start: fmtDate(c.tStart), end: fmtDate(c.tStart + elapsedMs),
        durationMs: elapsedMs, durationSec: Math.round(elapsedMs / 1000),
        startStatus: 4, endStatus,
        note: endStatus === 1 ? `seen: ${seen.join(" -> ")}` : `did not reach Pending (end ${STATUS[endStatus] ?? endStatus}); seen: ${seen.join(" -> ")}`,
      });
      console.log(`  T1 batch ${c.batchId}: ${Math.round(elapsedMs / 1000)}s  (seen ${seen.join(" -> ")})`);
    }

    let t1ok = false;
    let t1rows: TimingRow[] = [];
    if (NEW_BATCH_COUNT > 0) {
    t1rows = rows.filter((r) => r.phase === "Checking->Pending");
    t1ok = t1rows.some((r) => r.endStatus === 1);
    await card(testInfo, "T1 Checking->Pending", "T1 - Checking to Pending (created batches)", timingTableHtml(t1rows),
      [`Created ${NEW_BATCH_COUNT} batch(es) of ${AMOUNT} eSIMs`, `Polled each batch (API, every ${POLL_MS}ms) until Pending`, ...t1rows.map((r) => `${r.batchId}: ${r.durationSec}s (${STATUS[r.startStatus]}->${STATUS[r.endStatus] ?? r.endStatus})`)],
      [`Each new batch reaches Pending (status 1) after Checking completes`],
      t1ok ? undefined : "failed");
    }

    // -- Phase 2: confirm Pending batches (many-eSIM first), measure Confirming -> Confirmed --
    // Candidate set:
    //   - always include the batches just created in Phase 1 (now Pending, large = accurate T2)
    //   - if E2E_RECYCLE_CONFIRM_BATCH_IDS is set: also include those specific existing batch IDs
    //     (use this to target particular batches, e.g. today without confirming every old pending)
    //   - otherwise: all current Pending batches with >= MIN_ESIM eSIMs
    console.log(`[Phase 2] Building T2 confirm candidates ...`);
    let pending: Batch[] = [];
    if (CONFIRM_BATCH_IDS.length) {
      pending = (await listBatches(1, 100)).filter((b) => CONFIRM_BATCH_IDS.includes(b.batchID));
    } else {
      pending = (await listBatches(1, 100)).filter((b) => (b.totalEsim ?? 0) >= MIN_ESIM);
    }
    for (const c of created) {
      const fb = await getBatch(c.batchId);
      if (fb && !pending.some((p) => p.batchID === fb.batchID)) pending.push(fb);
    }
    pending = pending
      .filter((b) => (b.totalEsim ?? 0) >= MIN_ESIM)
      .sort((a, b) => (b.totalEsim ?? 0) - (a.totalEsim ?? 0));
    console.log(`  candidates (${pending.length}): ` + pending.map((b) => `${b.batchID}(${b.totalEsim})`).join(", "));

    if (CONFIRM_LIMIT > 0) pending = pending.slice(0, CONFIRM_LIMIT);

    for (const b of pending) {
      const fresh = await getBatch(b.batchID);
      if (!fresh || fresh.status !== 1) {
        rows.push({ batchId: b.batchID, amount: b.totalEsim ?? 0, phase: "Confirming->Confirmed", start: fmtDate(Date.now()), end: fmtDate(Date.now()), durationMs: 0, durationSec: 0, startStatus: fresh?.status ?? -1, endStatus: fresh?.status ?? -1, note: `skipped: not Pending anymore (${STATUS[fresh?.status ?? -1] ?? "gone"})` });
        continue;
      }
      const tStart = await confirmBatch(b.batchID);
      const { batch, elapsedMs, seen } = await waitStatus(b.batchID, [2, 3], TIMEOUT_MS);
      const endStatus = batch?.status ?? -1;
      rows.push({
        batchId: b.batchID, amount: b.totalEsim ?? 0, phase: "Confirming->Confirmed",
        start: fmtDate(tStart), end: fmtDate(tStart + elapsedMs),
        durationMs: elapsedMs, durationSec: Math.round(elapsedMs / 1000),
        startStatus: 5, endStatus,
        note: endStatus === 2 ? `seen: ${seen.join(" -> ")}` : `did not reach Confirmed (end ${STATUS[endStatus] ?? endStatus}); seen: ${seen.join(" -> ")}`,
      });
      console.log(`  T2 batch ${b.batchID} (${b.totalEsim} eSIM): ${Math.round(elapsedMs / 1000)}s  (seen ${seen.join(" -> ")})`);
    }

    if (pending.length === 0) {
      console.log(`  no Pending batch with >= ${MIN_ESIM} eSIMs found - T2 not measured this run.`);
      rows.push({ batchId: "-", amount: 0, phase: "Confirming->Confirmed", start: fmtDate(Date.now()), end: fmtDate(Date.now()), durationMs: 0, durationSec: 0, startStatus: -1, endStatus: -1, note: `no Pending batch with >= ${MIN_ESIM} eSIMs to confirm` });
    }

    const t2rows = rows.filter((r) => r.phase === "Confirming->Confirmed");
    const t2ok = t2rows.some((r) => r.endStatus === 2);
    const env = buildEnv();
    const summary = computeSummary(rows);
    writeReport(rows, env, summary);

    await card(testInfo, "T2 Confirming->Confirmed", "T2 - Confirming to Confirmed", timingTableHtml(t2rows),
      [`Confirmed ${pending.length} pending batch(es) (many-eSIM first, >= ${MIN_ESIM})`, `Polled each (API, every ${POLL_MS}ms) until Confirmed`, ...t2rows.map((r) => `${r.batchId}: ${r.durationSec}s (${r.amount} eSIM)`)],
      [`Each confirmed batch reaches Confirmed (status 2) after Confirming completes`],
      t2ok ? undefined : "failed");

    const allOk = t1ok && t2ok;
    await card(testInfo, "Timing summary", "ESKIMO-928 - Recycle batch timing summary", summaryCardHtml(env, summary) + timingTableHtml(rows),
      [`T1: ${summary.T1_Checking_to_Pending.count} batches, avg ${summary.T1_Checking_to_Pending.avgSec ?? "-"}s`, `T2: ${summary.T2_Confirming_to_Confirmed.count} batches, avg ${summary.T2_Confirming_to_Confirmed.avgSec ?? "-"}s`],
      [`T1 and T2 durations recorded for the recycle batch flow`],
      allOk ? undefined : "failed");

    console.log(`Measured: T1=${t1rows.filter((r) => r.endStatus === 1).length}/${NEW_BATCH_COUNT}, T2=${t2rows.filter((r) => r.endStatus === 2).length}.`);
    expect(rows.length, "at least one timing row recorded").toBeGreaterThan(0);

    await scratch.close().catch(() => {});
    await ctx.close();
  });
});
