# White Label Master Guide (Eskimo)

| | |
|---|---|
| **Scope** | The full lifecycle of a White Label partner: enable the program → create the website → partner sets up branding & connects Stripe → go-live → customers buy and use eSIMs → operations |
| **Audience** | Eskimo Admins (Admin Portal), Partners (Partner Portal), QC / Support |
| **Last updated** | 19 Oct 2026 |

> **Quick reading paths**
> - Admin: **Sections 1 → 4**, then **Section 7 (Go-live)** and **Section 9 (Operations)**.
> - Partner: **Section 1**, **Section 5 (Stripe)**, **Section 6 (Partner CMS)**.
> - Support / QC: **Section 8 (Customer Journey)**, **Section 10 (Reconciliation)**, **Section 11 (Troubleshooting)**.

---

## Contents

1. [White Label overview](#1-white-label-overview)
2. [Prerequisites](#2-prerequisites)
3. [Step A — Enable the Corporate Program (Admin)](#3-step-a--enable-the-corporate-program-admin)
4. [Step B — Create the website and edit its structure (Admin)](#4-step-b--create-the-website-and-edit-its-structure-admin)
5. [Step C — Connect Stripe and set the Application Fee (Partner + Admin)](#5-step-c--connect-stripe-and-set-the-application-fee-partner--admin)
6. [Step D — Edit content and branding (Partner CMS)](#6-step-d--edit-content-and-branding-partner-cms)
7. [Step E — Domain, email sender and go-live](#7-step-e--domain-email-sender-and-go-live)
8. [Customer Journey — buying and using an eSIM](#8-customer-journey--buying-and-using-an-esim)
9. [Operations: pause, re-enable, extend, delete](#9-operations-pause-re-enable-extend-delete)
10. [Money and reconciliation](#10-money-and-reconciliation)
11. [Troubleshooting (combined FAQ)](#11-troubleshooting-combined-faq)
12. [End-to-end go-live checklist](#12-end-to-end-go-live-checklist)
- [Appendices](#appendices)

---

## 1. White Label overview

### 1.1 What White Label is

White Label lets a **partner** sell Eskimo eSIMs **under its own brand** (name, logo, colours, domain, email) on a dedicated website. Eskimo provides the products (data plans, eSIMs), the website platform and the payment infrastructure. Customer payments go directly to the **partner's Stripe account**, and Eskimo collects an **Application Fee** on every order.

### 1.2 Roles

| Role | Where | Responsibilities |
|---|---|---|
| **Eskimo Admin** | Admin Portal | Enables the Corporate Program (term, fee, payment method, email); creates the website, assigns the partner, owns the **structure** (pages, modules, order); configures domain & email sender; activates/deactivates the website |
| **Partner** | Partner Portal → **My Website** | Connects **Stripe**; edits **content and branding** inside each module. **Cannot** add, remove or reorder modules |
| **Customer (end user)** | White Label website | Picks a plan, pays, receives the eSIM, views "My Data", tops up |
| **System** | — | Shows **live data** (plans, prices, countries, My Data wallet); creates the account + eSIM after a successful payment; records Eskimo's fee |

> **Golden rule:** *Admin owns the frame, the Partner owns the content, the system owns prices and plan data.* Partners cannot change prices; prices and the plan list always come from the system.

### 1.3 Key terms

| Term | Meaning |
|---|---|
| **Partner / Partner ID** | The White Label partner, ID format `PNxxxxxx` |
| **Corporate Program** | The program attached to a partner. Three **Types**: *Corporate*, *White label*, *Reseller*. This guide covers **White label** only |
| **Program term** | **Start Date → End Date**. Outside this window the program stops automatically |
| **Application Fee** | Percentage of the **data plan price** that Eskimo receives per order. The remainder is the **Partner Benefit** |
| **Stripe Connect / Direct Charge** | The partner's own Stripe account, connected to Eskimo. Customers pay straight into it; Eskimo receives the Application Fee |
| **Eskimo Email Notification** | Decides **who** emails the customer: Eskimo (ON) or the partner itself (OFF) |
| **Template** | A reusable website skeleton. Default: **"Eskimo eCommerce (Default)"** (System Default) |
| **Website (Partner Website)** | An independent copy of the template, **one website per partner** |
| **Page** | 5 pages: Home, Plan Detail, Checkout, Install eSIM, Data Balance |
| **Module / Section** | A content block on a page (Header, Banner, FAQ, Footer…) |
| **Brand identity** | Brand name, Logo, Primary colour, Secondary colour |
| **`{brand}` / `{country}`** | Placeholders replaced with the brand name / country name. `{brand}` works in any module; `{country}` only in the Plan Detail Hero heading |
| **My Data** | The customer's data wallet: plans, remaining data, history |
| **Magic Link** | A link in the email that opens My Data directly, no OTP required |

### 1.4 End-to-end flow

```
 ADMIN                              PARTNER                          CUSTOMER
 ─────                              ───────                          ────────
 A. Enable Corporate Program
    (Type = White label, term,
     email, account limit,
     Direct Charge, 2 Years)
        │
        ▼
 B. Clone website → Assign Partner
    → Edit Structure → Save
        │                           C1. Connect Stripe (My Website)
        │                               → Verified
        ▼                                   │
 C2. Set Application Fee  ◄─────────────────┘ (only saves once the partner
        │                                      has STARTED Stripe onboarding)
        │                           D. Partner CMS: branding,
        │                              Header/Footer, content on 5 pages
        ▼                              → Save All
 E. Configure domain + email sender
    → Website Status = Active
        │
        └──────────────────────────────────────────────►  Browse → Checkout → Pay
                                                          → QR + Magic Link email
                                                          → My Data → Top-up
```

### 1.5 Dependency chain (read carefully)

The steps depend on each other. If one link is missing, the next step cannot be done or customers cannot buy:

| To be able to… | You first need… |
|---|---|
| Assign the right partner in **Assign Partner** | The partner has Corporate Program **ON**, **Type = White label**, and **no other website** |
| Save the **Application Fee** | The partner has **started** Connect Stripe (Stripe Connect Status ≠ *Not Connected* / *—*) |
| Let customers **pay** (Direct Charge) | Stripe Connect Status = **Verified** |
| Have the website **visible and selling** | Corporate Program **active** (Status ON and today within Start → End Date) **and** website **Status = Active** |
| Have customers **receive the QR + Magic Link email from Eskimo** | **Eskimo Email Notification = ON** (OFF → the partner must send it) |
| Let the partner **edit content** in My Website | The website has been created and **assigned** to the partner |

---

## 2. Prerequisites

**Admin**
1. An Admin account with access to **Partnership › Partners** and the **White Label** menu.
2. Partner details: name, **Partner Portal login email**, Referral Code, owner (Assigned To), Source Of Lead.
3. Agreed with the partner: program **term**, **Application Fee (%)**, **who emails customers**, **maximum number of accounts**, domain and email sender.

**Partner**
1. Access to the registered email (for the Partner Portal login OTP).
2. Company and bank account details for **Stripe** onboarding.
3. Brand assets:
    - **Logo**: PNG/JPEG, **under 1 MB**.
    - **Primary and secondary colours** (hex, e.g. `#1957F5`).
    - **Images** (banner, highlight tiles, install guide): PNG/JPEG, **under 5 MB** each.
    - **Copy**: headings, introduction, FAQs, support email, social media links.

---

## 3. Step A — Enable the Corporate Program (Admin)

**Screen:** **Partnership › Partners** → Edit partner (or **New Partner**) → **Corporate Program** section (right column).

### 3.1 Create a new partner (skip if it already exists)

1. **Partnership › Partners** → **New Partner**. A **Partner ID** is pre-assigned (e.g. `PN539084`).
2. Fill in **Partner Configuration**:

| Field | Required | Notes |
|---|---|---|
| **Referral Code** | Yes | Letters and digits only, no spaces. **Cannot be changed after creation** |
| **Status** | — | Defaults to *Pending*. Choose **Active** so the partner can operate. When not *Pending*, fields marked * become required |
| **Partner Name** | Yes | Max 50 characters |
| **Partner Email** | Yes | Email the partner uses to sign in to the **Partner Portal** |
| **Assigned To** | Yes | Owner(s) of the partner (multi-select) |
| **Source Of Lead** | Yes | Lead source |

3. You can configure the **Corporate Program** (section 3.2) in the same dialog.
4. Click **Ok** → warning *"Once created, partner's referral code can not be changed. Are you sure want to continue?"* → **Confirm** → **CREATE SUCCESS**.

> ⚠️ **An Application Fee typed in the New Partner dialog is not saved.** The fee is only saved when you **Edit** an existing partner. Create the partner first, then set the fee in Step C2.

![New partner, Corporate Program Type = White label](images/corporate-program/01-new-partner-white-label.png)

### 3.2 Configure the Corporate Program

![A fully configured White Label Corporate Program](images/corporate-program/02-corporate-program-verified.png)

| # | Field | Action / rule |
|---|---|---|
| 1 | **Status** | Switch **ON**. The fields below appear |
| 2 | **Type** | Select **White label**. ⚠️ **Locked after saving** (*"Type can not be edited after corporate program confirmed"*) |
| 3 | **Start Date** | Required, `DD/MM/YYYY`. **Locked** once the start day has passed (still editable on the start day itself) |
| 4 | **End Date** | Required, **after Start Date**; today and past dates cannot be picked (earliest is tomorrow). Can be extended any time |
| 5 | **Eskimo Email Notification** | ON / OFF, **default OFF**. See 3.3 |
| 6 | **Lifetime Account Limit** | Shown as `<used> / <max>`, e.g. `0 / 100`. Enter a positive integer **< 100000** (max 99999), required |
| 7 | **Payment method** | **Direct Charge** (the only option in phase 1; *Eskimo Stripe Pay* is hidden) |
| 8 | **Data Expiry** | Fixed at **2 Years** (data expires 2 years from purchase). *No Expiry* is greyed out and cannot be selected |
| 9 | **Application Fee Percentage** | **Leave empty at this step** — set it in Step C2 once the partner has started Stripe onboarding |
| 10 | **Stripe Connect Status** | Read-only. The partner connects Stripe (Step C1) |

Click **Ok** → **UPDATE SUCCESS** / **CREATE SUCCESS**. Reopen the partner to verify.

When **White label** is selected, the form differs from the *Corporate* type:
- **Eskimo Email Notification**, **Stripe Connect Status**, **Payment method** and **Data Expiry** appear.
- *Discount Benefit* becomes **Application Fee Percentage**.
- **Network Partner Commission (%) is hidden** (not applicable to White Label).

![Payment method = Direct Charge](images/corporate-program/05-payment-method-direct-charge.png)
![Data Expiry: fixed 2 Years, No Expiry greyed out](images/corporate-program/08-data-expiry.png)

### 3.3 Eskimo Email Notification — an important decision

| Value | Who emails the customer | Effect for the customer |
|---|---|---|
| **ON** | **Eskimo** | The customer receives the purchase confirmation, the **eSIM QR email** (with LPA code) and the **Magic Link** to My Data. Emails carry the partner's branding (sender name, logo) |
| **OFF** | **The partner** | Eskimo sends **no emails at all** to this program's customers. The partner **must** have its own process to deliver the QR code and order confirmation, otherwise customers receive nothing after buying |

> Section 8 (Customer Journey) describes the journey with **Email Notification = ON**.

---

## 4. Step B — Create the website and edit its structure (Admin)

**Screen:** **White Label** menu → **Website Templates**.

### 4.1 Website Templates screen

![Website Templates screen](images/website-structure/01-website-templates-after-clone.png)

| Column | Content |
|---|---|
| **Name** | Template / website name |
| **Type** | `System Default` (template) or `Partner Website` |
| **Partner** | Owning partner, "—" if unassigned or a template |
| **Pages** | Number of pages |
| **Status** | **Active / Inactive** switch (websites only) |
| **Created Date** | Creation date |
| **Actions** | Template: **Edit Structure**, **Clone**. Website: **Edit Structure**, **Config**, **Assign Partner** / **Reassign Partner**, **Delete** |

### 4.2 Clone a website from the template

1. On the **Eskimo eCommerce (Default)** row click **Clone** → toast **"Website draft created"**.
2. New row: Name **Untitled Website Draft**, Type **Partner Website**, Partner **—**, Status **Inactive**, Pages **5**.
3. The new website copies the **template's full structure as of the moment of cloning** (Appendix A). Each Clone creates **one** website.

### 4.3 Assign the partner

1. On the new website row click **Assign Partner**.
2. Type the partner's name in the **Partner** field (*"Search a partner by name"*), pick the right partner → **Assign**. Leaving it empty shows *"Please select a partner"*.
3. Result: toast **"Untitled Website Draft" assigned**; the Partner column shows the name; the website is renamed **"Website Template for partner &lt;partner name&gt;"**.

![Website after assigning a partner](images/website-structure/02-assigned-partner.png)

> ⚠️ The list shows **every partner with Corporate Program on and no website**, including partners of type *Corporate*. Pick a partner whose **Type = White label** (check under Partnership › Partners if unsure). If you see **"No available partner"**, re-check Step A or the partner's existing website.
>
> **Reassign Partner**: for an assigned website, pick another (also eligible) partner → **Assign**.

### 4.4 Edit Structure

Click **Edit Structure** → the **"Edit Structure — &lt;website name&gt;"** dialog has:
- **Page tabs**: `Home (13)`, `Plan Detail (4)`, `Checkout (2)`, `Install eSIM (3)`, `Data Balance (4)` (number = module count).
- A **canvas** previewing modules top to bottom.
- **Footer bar**: **Close** and **Save Page**.

Each module has a title bar: a **≡** drag handle (not on Header), the module name, and a **red bin** button.

| Action | How |
|---|---|
| **Add a module** | Select the page → scroll to the bottom of the canvas → **+ Add Section** → pick a module (Appendix B). It is **added at the end of the page** → drag it into place (usually **above the Footer**) |
| **Remove a module** | Click the bin → *"Remove this module?"* → **Remove** |
| **Reorder (mouse)** | Hold **≡**, drag up/down, drop |
| **Reorder (keyboard)** | Tab to **≡** → **Space** to lift → **↑ / ↓** → **Space** to drop |
| **Move a module to another page** | Not possible by dragging across pages: remove it from the old page → **+ Add Section** on the new page |
| **Save** | **Save Page** (one changed page) or **Save All (N pages)**. Disabled when nothing changed. Success: **Saved: "Home"** |

![A newly added module at the end of the page](images/website-structure/03-editor-add-section.png)

> ⚠️ **The Header always stays at the top** and cannot be dragged. **The Footer can be dragged**: after adding or reordering modules, check the Footer is still **last** before saving.
>
> ⚠️ Click **Save Page / Save All before Close.** Close gives **no warning** about unsaved changes; they are simply lost.
>
> ⚠️ If you see a module named **`downloadApp`** (or `productSection`) with the warning *"This section type is no longer used and doesn't show on the storefront. Remove it."*: it is a retired module that the website does not show. **Remove** it and save.
>
> 💡 **Coordinate with the partner:** once the partner has entered content, **removing** a module takes that content block off the website. Agree with the partner before removing modules.

### 4.5 Template ↔ website independence

| Situation | Result |
|---|---|
| Edit partner A's website structure | **No** effect on the template or other partners' websites |
| Edit the System Default template | **No** effect on existing websites; only websites **cloned afterwards** get the new structure |
| Clone a new website | Gets the template structure as of cloning, then is fully independent |

---

## 5. Step C — Connect Stripe and set the Application Fee (Partner + Admin)

### 5.1 C1 — The partner connects Stripe

Admins **cannot** connect Stripe on the partner's behalf. The **Stripe Connect Status** row in Admin always reads *"The partner connects Stripe from the Partner portal (My Website)."*

**Partner steps:**
1. Sign in to the **Partner Portal** with the Partner Email (+ OTP sent by email).
2. Go to **My Website** → **Stripe payments** panel → click **Connect Stripe**.
3. Complete the business details, payout account and verification on **Stripe**.
4. If interrupted, return to **My Website** → **Continue setup**.

> The **Connect Stripe / Continue setup / Reconnect Stripe** buttons only show for partner accounts with the **Owner** or **Admin User** role. Other roles see the status only.

**Statuses (visible to Admin and Partner):**

| Shown | Meaning | Next action |
|---|---|---|
| **Not Connected** / **—** | Not connected (**—** = never started) | Partner clicks **Connect Stripe** |
| **Setup incomplete** | Started but not finished | Partner clicks **Continue setup** |
| **Pending verification** | Stripe is verifying | Wait; if Stripe asks for more → **Continue setup** |
| **Verified** | Ready to accept payments | Done |
| **Disconnected** | Account disconnected from Eskimo | Partner clicks **Reconnect Stripe** |

![Stripe Connect Status = Pending verification](images/corporate-program/03-stripe-pending-verification.png)

> The status can take **a few minutes** to update after Stripe finishes verification. Reopen the partner to see the latest.

### 5.2 C2 — Admin sets the Application Fee Percentage

> **Why after Stripe?** The fee is only saved once the partner has **started** Stripe onboarding. If set earlier, the partner is saved but the fee is not, with the message *"Partner saved, but the Application Fee was not: Stripe onboarding has not been started for this partner"*.

1. Edit partner → **Corporate Program** → **Application Fee Percentage**.
2. **Apply To** = *Any Data Plan* (fixed); **Fee** = *Percentage (%)*.
3. Enter the % (placeholder *"10 (default)"*) → **Ok**.

| Input | Result |
|---|---|
| `0` ≤ fee < `100`, up to 2 decimals (`20`, `12.5`, `99.99`) | Valid |
| `100` or more | *"Fee must be at least 0 and less than 100"* |
| More than 2 decimals (`12.345`), letters, negatives | *"Value should contain just number"* |
| **Empty** | Uses the **10% default** (*"Leave empty to use the default fee (10%)."*) |

> ⚠️ **New partners may be pre-filled with `0`.** Keeping `0` means Eskimo **collects no fee**. Clear it (10% default) or enter the agreed rate.

**"final bill < 1" warning** (e.g. *"Africa 1GB final bill < 1"*): the system computes **plan price × (100% − fee)** — i.e. the partner's share — and lists plans where that share is **below USD 1**. The warning **does not block saving**, and **customers still pay the full plan price**.

![Application Fee 90% with the final bill < 1 warning](images/corporate-program/04-application-fee-warning.png)

Detailed calculation: see **Section 10**.

---

## 6. Step D — Edit content and branding (Partner CMS)

**Who:** Partner. **Screen:** Partner Portal → **My Website** → **Edit Website Content**.

![Partner CMS screen](images/partner-cms/01-cms-workspace.png)

### 6.1 Screen layout

| Area | Purpose |
|---|---|
| **Page tabs** | Switch between the 5 pages (number = module count) |
| **Brand identity** | Brand name, logo, colours |
| **Stripe payments** | Stripe status and connect button (Section 5.1). The connect button only shows for **Owner / Admin User** roles; other roles see the status only |
| **Preview** | The selected page, close to the live website |
| **Pencil button** | On each module, opens **Configure &lt;module name&gt;** |
| **Save Page / Save All (N pages)** | Publishes changes to the website |

### 6.2 Editing a module — two different Save buttons

1. Select the page → click the **pencil** on the module.
2. Edit → click **Save** in the dialog → **only updates the preview**.
3. Continue with other modules/pages.
4. Click **Save Page / Save All** (bottom right) → **publishes to the website**, toast `Saved: "<page name>"`.

> ⚠️ **Save** in a module dialog ≠ **Save Page**. Only **Save Page / Save All** writes to the website. Always click it before leaving the screen.

**Input types**

| Type | Usage |
|---|---|
| Single / multi-line text | Fields marked *"one per line"*: each line becomes a bullet |
| Link (URL) | Internal (`/esim`) or full (`https://...`), `mailto:`, `tel:`. An internal path the website does not have shows an orange warning and the link is **not displayed**. Do **not** add a language prefix (use `/esim`, not `/en/esim`) |
| Image | **Upload** from your computer or paste an `https://` image URL |
| Icon | Pick from the built-in library (wifi, globe, shield…), searchable |
| List | **+ Add** / **Remove** |
| ✓ / ! / ✕ select | Comparison table: `✓ Yes`, `! Partly`, `✕ No` |
| **Show my text exactly as entered** | Tick to render the entered text verbatim |

### 6.3 Brand identity

![Brand identity](images/partner-cms/02-brand-identity.png)

| Field | Where it appears |
|---|---|
| **Brand name** | Browser tab title, copyright line, every `{brand}` |
| **Logo URL** + **Upload** | Header and Footer on every page (PNG/JPEG < 1 MB). **Use Upload**: image links pasted from elsewhere are ignored by the website. Without a logo, the Brand name shows as text |
| **Primary** | Buttons, accent headings, links, payment form |
| **Secondary** | Region cards in the Data Plan Section and the Install Steps cards |

Colours must be `#RRGGBB`; otherwise the website falls back to the default colour.

Then click **Save Page** → toast `Branding saved`.

### 6.4 Header and Footer

Each page has **its own** Header and Footer. Configure them **identically on all 5 pages** for a consistent site, then **Save All**.

![Configure Header](images/partner-cms/06-configure-header.png)

- **Header — Navigation links**: *Label* + *URL*, e.g. `Travel eSIM` → `/esim`, `Install eSIM` → `/install-esim`. The logo comes from Brand identity; the **My Data** button shows on the right automatically, unless the menu already links to `/data-balance`.

![Configure Footer](images/partner-cms/07-configure-footer.png)

| Footer field | Description |
|---|---|
| **Support email** | Shown in the *Need help?* line (hidden when empty) |
| **Column 1/2/3 title + links** | Three footer columns. Links with an empty URL, or pointing to a page the website does not have, are dropped; a column with no remaining links is hidden, even if it has a title |
| **Social links** | Icon (facebook, instagram, youtube-play, tiktok…) + URL. A row with an empty URL **still shows its icon**: remove unused rows |
| **Locale/currency label** | e.g. `EN • USD — $` |
| **Copyright text** | e.g. `© 2026 {brand}` |

### 6.5 Content per page

| Page | Module | What the partner can edit |
|---|---|---|
| **Home** | Banner | Background image, Title/Subtitle, Search label/placeholder (empty → *"Search N+ countries"* using the real count), CTA text/link (empty text → no button), Rating value/note |
| | Data Plan Section | Heading, highlight line, description. Regions and country counts are **automatic** |
| | Transfer Data | Eyebrow label, heading, description, 1–4 features (icon, title, description), 1–4 highlight tiles (title, description, image) |
| | More Reasons Grid | Heading, 3–9 reasons (icon, title, description) |
| | Video Section | Video URL (YouTube or `.mp4`), 2 overlay text lines |
| | Comparison Table | Heading, description, 4 column names, 1–12 rows (✓ / ! / ✕) |
| | Install Steps | Heading, description, 3–8 summary steps |
| | Reviews | Heading, 3–9 reviews (name, date, text) |
| | FAQ | Heading, description, 1–9 Q&As (**+ Add Question**) |
| | Recommendations | Heading, 3 tab names, guide link for tab 3. Tab 1 (popular countries) and tab 2 (regions) are **automatic** |
| **Plan Detail** (`/plans/japan-esim`) | Plan Detail Hero | Page title (use `{country}`: `{country} eSIM` → *Japan eSIM*), rating, 2 plan-type tabs (name, badge, features), 3–4 feature cards |
| | Sticky Checkout Bar | Button text. Plan name and price are **automatic** |
| **Checkout** | — | Header/Footer only; the payment form is provided by the system |
| **Install eSIM** | Install eSIM Guide | Heading/Subtext, iOS/Android tab names, Step label (`Step` → *Step 1, 2…*), 1–8 steps per OS (title, bullets, up to 4 images) |
| **Data Balance** | Data Balance Screen | Page title, *My Plans* / *History* tab names, empty-state text, *How to install eSIM* link text, *Buy more data* button text. Plans/data/history are **automatic** |
| | Data & eSIM Information | Heading, Fixed plan benefits (3–8) and Unlimited plan benefits (3–8) |

![Configure Banner](images/partner-cms/04-configure-banner.png)
![Configure FAQ](images/partner-cms/05-configure-faq.png)
![Configure Plan Detail Hero](images/partner-cms/08-configure-plan-detail-hero.png)
![Configure Install eSIM Guide](images/partner-cms/09-configure-install-guide.png)
![Configure Data Balance Screen](images/partner-cms/10-configure-data-balance.png)

### 6.6 Always-live data (not editable by the partner)

Countries / regions / country counts; data plans, allowances, **prices**; popular countries and regions in Recommendations; plan name and price on the checkout bar; plans, remaining data and history in My Data.

### 6.7 Save and verify

1. **Save Page / Save All**, wait for `Saved: …`.
2. Open the website and reload. New content usually appears within **about 30 seconds**; if not, wait and reload after a minute.

![Website after configuration](images/partner-cms/13-storefront-home.png)

### 6.8 Scope and security

- Each partner sees and edits **only its own website**; uploaded images are stored per website.
- Partner edits do not affect other partners' websites or the base template.

---

## 7. Step E — Domain, email sender and go-live

### 7.1 Config (Admin)

On the website row in **Website Templates**, click **Config** to set:
**Custom domain** — the partner's own domain
1. Enter a subdomain, e.g. `esim.yourdomain.com` (root domains such as `yourdomain.com` are not accepted).
2. Click **Validate**. Result: *Available*, *Already in use*, *Saved for this website*, *DNS pointed correctly* or *DNS not pointed yet*.
3. Click **Save** (enabled only after a valid result for exactly the typed value) → *"Custom domain saved: &lt;host&gt;"*.
4. Send the partner the **"DNS records to give the partner"** table (with copy buttons) so they can point their DNS.

> A domain saved earlier is **not shown again** in the field. To see its state, type it again and click **Validate**.

**Email sender** — who customer emails come from
1. Fill in all three fields: **Sender name** (e.g. *Klook eSIM*), **From address** (e.g. *noreply@klook.com*), **Reply-to** (e.g. *support@klook.com*) → **Save** → *"Email sender saved"*.
2. Under **Domain authentication**: **save the From address first**, then click **Create / get records**, send the DNS records (Type / Host / Value) to the partner, then **Check again** until the status is **Verified**. Other statuses: *Pending DNS*, *Not set up*.
3. **Sender name** and **Reply-to** apply immediately. A **From address** on a new domain only takes effect once that domain is verified (*"… is waiting on DNS"*).

> Config has **no** payment field. Payments go through the partner's own Stripe connection (Section 5.1).

### 7.2 Activate the website (Admin)

- New websites are always **Inactive**. When structure and content are ready, switch the **Status** column to **Active** — it saves immediately, no Save needed.
- Switch back to **Inactive** to pause the website.

> **Two different switches — both must be on:**
> - **Corporate Program Status** (Partnership › Partners) — the partnership program.
> - **Website Status** (White Label › Website Templates) — the website.

### 7.3 Pre-launch check

See the checklist in **Section 12**. At minimum: Stripe **Verified**, correct Application Fee, website **Active**, all 5 pages checked on desktop and mobile, one test order.

---

## 8. Customer Journey — buying and using an eSIM

> Example site: `https://wellatsea.eskimo.travel/en`. Text in `this style` is shown verbatim on screen. The journey below assumes **Eskimo Email Notification = ON**.

### 8.1 Five stages

| # | Stage | Customer action | Expected result |
|---|---|---|---|
| 1 | **Browse** | Open the website → pick a plan | Sees the brand's correct plan list |
| 2 | **Checkout** | Enter First name + Email → pay by card | Payment succeeds |
| 3 | **Receive eSIM** | (automatic) | Email with **QR code** + **Magic Link** |
| 4 | **My Data** | Magic Link or Email + OTP | Sees plans, remaining data, history |
| 5 | **Top-up** | Buy another plan | New plan added to the **same account/eSIM** |

**Principles:**
- **Accounts are separate per partner.** The same email on 2 different websites = **2 separate accounts**; plans, data and history are not merged.
- **Only customers who have purchased** can sign in to My Data; an email with no purchase gets no OTP.
- The eSIM and plan are created **only after a successful payment**.
- The store is in **English**, priced in **USD**, and takes **card payments through Stripe**; there is no language switcher, currency switcher or promo code.

### 8.2 Happy path

1. **Pick a plan**: choose a country/region → plan (e.g. **Japan 1 GB**) → **`Checkout`**. (Opening `/checkout` directly without a plan shows `No plan selected`.)
2. **Enter details**: **First name** and **Email** — this email receives the eSIM and is the My Data login, so it must be **spelled correctly** → **`Continue to payment`**.
3. **Pay**: Stripe card form (email pre-filled) → card number, expiry, CVC → **`Pay US$ …`** → `Processing payment…`.
4. **Confirmation page**: **Order number** (`PUR-PN…-…`), plan, total, eSIM email, `Payment received — we're preparing your eSIM`.
5. **Email**: eSIM **QR code** (with LPA code) and **Magic Link** to My Data, carrying the **partner's branding**.

> ⏱ After payment the system needs **~30–60 seconds** to create the account + eSIM. Opening My Data too early may fail temporarily — wait and retry.

### 8.3 Accessing My Data

- **Option A — Magic Link**: open the link in the email → straight into the wallet, **no OTP**, reusable.
- **Option B — Email + OTP**: `/en/data-balance` (or the **`My Data`** button) → enter the purchase email → **`Send code`** → `Enter your code` screen → enter the **4-digit code** (expires after **5 minutes**) → **`View my data`**. An OTP sign-in stays valid for **7 days** in that browser.

In the wallet: **My Plans** tab (country + remaining data; unlimited plans show a label such as `Unlimited 30 days`) and **History** (date, plan, status).

### 8.4 Top-up

Buying again with the **same email on the same website** adds the new plan to the **same account/eSIM** — no duplicate account or eSIM.

### 8.5 Error messages — quick reference

**Checkout**

| Situation | Message | What to do |
|---|---|---|
| Empty first name | `Enter your first name.` | Enter First name |
| Empty / invalid email | `Enter a valid email address.` | Enter a valid email |
| `/checkout` opened with no plan | `No plan selected` | Go back and pick a plan |
| Too many payment attempts | `Too many checkout attempts. Please wait a few minutes and try again.` | Wait a few minutes |

**Payment**

| Situation | Message | Meaning / what to do |
|---|---|---|
| Card declined | `Your card has been declined.` | **Not charged**. Try another card |
| Payment could not start | `We couldn't start your payment. Please try again in a moment.` | Retry shortly |
| Payment failed | `Your payment didn't go through. Please try again.` + `You haven't been charged. You can try again with the same or a different card.` | Not charged, retry |
| Bank still confirming (3-D Secure / slow) | `Your bank is still confirming the payment. We'll email your eSIM as soon as it goes through — no need to pay again.` | **Do not pay again**, wait for the email |
| Result could not be confirmed | `We couldn't confirm your payment` + `Please check your email before trying again — if the payment went through, your eSIM is on its way.` | **Check email first** to avoid paying twice |

> **Declined card:** the system creates a **Pending** account with **no** eSIM and **no** plan. When the customer pays again with a valid card **using the same email**, the system reuses that account and completes the order (no duplicate).

**My Data (Email + OTP)**

| Situation | Message | What to do |
|---|---|---|
| Email never purchased **or** code requested too soon after paying | `We're unable to process your request yet. Please purchase a data plan with this email to get started.` | Check the email used at checkout; if just purchased, wait ~30–60 s and `Send code` again |
| Wrong / old / used code | `Invalid OTP` or `That code isn't valid any more. Request a new one.` | Use the latest code or request a new one |
| Too many wrong attempts | `Too many invalid attempts. Please request a new OTP and try again in a few minutes.` | Temporarily locked; wait, request a new code |
| Too many code requests | `Too many codes requested. Please wait a few minutes and try again.` | Wait a few minutes |
| Code could not be sent | `We couldn't send your code right now. Please try again.` | Retry |

**Magic Link**

| Situation | Shown | What to do |
|---|---|---|
| Valid | Straight into the wallet | — |
| Broken / expired | `That link has expired. Enter the email you used at checkout and we'll send you a code.` | Sign in with Email + OTP (8.3 Option B) |

---

## 9. Operations: pause, re-enable, extend, delete

### 9.1 When a White Label website stops selling

| Case | Cause |
|---|---|
| Corporate Program **Status = OFF** | Admin switched the program off |
| Website **Status = Inactive** | Admin switched the website off (Website Templates) |
| **Before Start Date** / **after End Date** | Outside the program term |

The website then shows **"This store isn't available — Please check back later."**; customers **cannot see plans or buy**. Takes effect within **a few minutes**.

![Website when the program is inactive](images/corporate-program/07-store-unavailable.png)

### 9.2 Actions

| Action | How | Notes |
|---|---|---|
| **Pause the program** | Edit partner → **Status OFF** → **Warning** → **Confirm** → **Ok** | |
| **Re-enable** | Switch **Status ON** → **Ok** | **Nothing to re-enter**: all settings are kept. Website returns within seconds to minutes |
| **Extend** | Change **End Date** to a future date → **Ok** | Other settings unchanged |
| **Stop immediately** | Switch **Status OFF** | Past End Dates cannot be selected |
| **Pause the website** | Website Templates → **Status Inactive** | |
| **Delete the website** | **Delete** → confirm → **"DELETE SUCCESS"** | ⚠️ **Irreversible.** The partner loses the website **and all CMS content**; the Partner Portal shows *"No website has been assigned to you yet"*. The System Default template cannot be deleted |

![Switching Status OFF](images/corporate-program/06-status-off.png)

### 9.3 Propagation times

| Change | Visible after |
|---|---|
| Partner CMS content | ~30 seconds (reload after a minute if not visible) |
| Corporate Program on/off | A few minutes |
| Stripe Connect Status after Stripe verification | A few minutes |
| Customer account + eSIM after payment | ~30–60 seconds |

---

## 10. Money and reconciliation

### 10.1 Formula

```
Application Fee (Eskimo receives)  = Plan price × Application Fee %
Partner Benefit (partner receives) = Plan price × (100% − Application Fee %)
```

| Plan price | Application Fee | Eskimo receives | Partner receives |
|---|---|---|---|
| USD 100 | 90% | USD 90 | USD 10 |
| USD 100 | 10% (default) | USD 10 | USD 90 |
| USD 3.90 | 20% | USD 0.78 | USD 3.12 |

Customers always pay the **full plan price**; the Application Fee only splits it between Eskimo and the partner.

### 10.2 Two order IDs — by design

| ID | Where | Meaning |
|---|---|---|
| **PUR-PN…** | Customer confirmation page | The partner's order |
| **WHI-…** | Admin › **Transactions › Eskimo Sale** | Eskimo's fee = **order price × Application Fee %** (e.g. 10% fee, US$3.90 order → **0.39**) |

---

## 11. Troubleshooting (combined FAQ)

### Admin

| Issue | Cause / fix |
|---|---|
| Cannot change **Type** | Locked after the first save. Wrong choice → contact the Eskimo tech team |
| Cannot edit **Start Date** | Locked once the start day has passed; only End Date is editable |
| Cannot pick a past End Date | By design. To stop now → **Status OFF** |
| Saved but **fee not recorded** | The partner has not started Connect Stripe. Ask them to connect, then save the fee again |
| Fee shows `0` | New partners may be pre-filled with 0 → no fee collected. Clear it (10%) or enter the agreed rate |
| Stripe stuck on **Not Connected** | The partner has not done **My Website → Connect Stripe**. Admins cannot do it for them |
| **Network Partner Commission**, **Eskimo Stripe Pay** missing, or **No Expiry** greyed out | By design in phase 1 |
| Partner missing in **Assign** / **"No available partner"** | Corporate Program not enabled, partner already has a website, or the search text doesn't match |
| Assign list shows partners that are not White label | The list shows every partner with Corporate Program on. Pick a partner with **Type = White label** |
| **Save Page** disabled | No changes yet |
| A **`downloadApp`** / `productSection` module appears | Retired module the website does not show. Remove it and save |
| Changes lost after closing Edit Structure | Close gives no unsaved-changes warning. Always **Save Page / Save All** first |
| Fee typed when creating the partner was not saved | Expected: the fee is only saved on Edit. Set it in Step C2 |
| Which module shows **products** | **Data Plan Section (Global + Regions)** (Home), **Plan Detail Hero** (Plan Detail) |
| Website still visible after disabling the program | Wait a few minutes and reload |

### Partner

| Issue | Fix |
|---|---|
| My Website shows *"No website has been assigned to you yet"* | Admin hasn't created/assigned the website yet, or it was deleted |
| Edited but the website hasn't changed | **Save Page / Save All** not clicked (the module dialog's Save only updates the preview), or ~1 minute hasn't passed |
| Want to add / remove / reorder modules | Ask the Admin (Edit Structure) |
| Header/Footer differ between pages | Each page has its own Header/Footer — configure all 5 pages, then **Save All** |
| Want to change plan prices | Not possible — prices come from the system |

### Customer (Support)

| Issue | Fix |
|---|---|
| Paid but cannot open My Data | Wait 30–60 s and `Send code` again. Still failing after a few minutes → check the email used at checkout |
| No eSIM email | Check spam; check the partner's **Eskimo Email Notification** (OFF → the partner sends it) |
| Charged for a declined card? | No. Pay again with another card using the same email; no duplicate account is created |
| Too many wrong OTPs | Temporarily locked; wait a few minutes, request a new code |
| Same email on another website — shared data? | No. Each partner is a separate account |

---

## 12. End-to-end go-live checklist

**A. Corporate Program (Admin)**
- [ ] Partner **Status = Active**, correct Partner Email
- [ ] Corporate Program **ON**, **Type = White label** (Type locked)
- [ ] **Start / End Date** match the contract
- [ ] **Eskimo Email Notification** as agreed (OFF → partner has its own QR delivery process)
- [ ] **Lifetime Account Limit** entered
- [ ] **Payment method = Direct Charge**, **Data Expiry = 2 Years**
- [ ] No Network Partner Commission field

**B. Website (Admin)**
- [ ] **Cloned** and **Assigned**, website renamed after the partner
- [ ] Each page's structure **saved**; reopened to check: Header first, **Footer last** on every page

**C. Stripe & fee**
- [ ] **Stripe Connect Status = Verified**
- [ ] **Application Fee** shows correctly on reopen (not an unintended `0`)

**D. Content (Partner)**
- [ ] Brand name, logo, colours match the brand guidelines
- [ ] Header/Footer consistent on all 5 pages; support email and social links belong to the partner
- [ ] Home, Plan Detail, Install eSIM, Data Balance updated
- [ ] **Save All** clicked and `Saved: …` seen

**E. Go-live**
- [ ] **Config**: custom domain, email sender
- [ ] Website **Status = Active**
- [ ] Website checked on desktop and mobile, all 5 pages and links
- [ ] Test order: payment succeeds → `PUR-PN…` confirmation → QR + Magic Link email (if ON) → My Data shows the plan
- [ ] Admin › Eskimo Sale shows a **WHI-…** transaction = order price × fee %

---

## Appendices

### Appendix A — Default structure of "Eskimo eCommerce (Default)"

5 pages, 26 modules:

| Page | Modules | Modules (in order) |
|---|---|---|
| **Home** | 13 | Header → Banner → Data Plan Section (Global + Regions) → Transfer Data (Why Eskimo eSIM) → More Reasons Grid → downloadApp *(retired, remove it)* → Video Section → Comparison Table → Install Steps → Reviews → FAQ → Recommendations → Footer |
| **Plan Detail** | 4 | Header → Plan Detail Hero → Sticky Checkout Bar → Footer |
| **Checkout** | 2 | Header → Footer (payment form provided by the system) |
| **Install eSIM** | 3 | Header → Install eSIM Guide (iOS / Android, manual) → Footer |
| **Data Balance** | 4 | Header → Data Balance Screen → Data & eSIM Information → Footer |

### Appendix B — Module library (+ Add Section)

| Module | Used for |
|---|---|
| Header | Logo, top menu |
| Banner | Hero image, heading, description, call to action |
| Feature Section | Key highlights |
| Data Plan Section (Global + Regions) | Plan list by country / region (products) |
| Transfer Data (Why Eskimo eSIM) | Why choose the service |
| More Reasons Grid | Grid of benefits |
| Video Section | Intro video |
| Comparison Table | Comparison table |
| Install Steps | eSIM install steps (summary) |
| Reviews | Customer reviews |
| FAQ | Frequently asked questions |
| Recommendations | Suggested plans / destinations |
| Footer | Links, social media, copyright |
| Plan Detail Hero | Top of the plan detail page |
| Sticky Checkout Bar | Fixed checkout bar |
| Data & eSIM Information | Data and eSIM information |
| Data Balance Screen | Remaining data screen |
| Install eSIM Guide (iOS / Android, manual) | Detailed per-device install guide |

The library is designed to grow: new modules appear in **+ Add Section** automatically.

### Appendix C — Website paths

| Path | Page |
|---|---|
| `/` | Home |
| `/esim` | Plans by country / region |
| `/plans/<country>-esim` | Plan detail (`/plans/japan-esim`, `/plans/global-esim`) |
| `/checkout` | Checkout |
| `/data-balance` | My Data |
| `/install-esim` | Install guide; `?platform=ios` / `?platform=android` opens that tab |

In the browser the site uses a language prefix (e.g. `/en/data-balance`), but links entered in the Partner CMS must **omit the prefix** (`/data-balance`). Any path starting with `/plans/` is valid.

### Appendix D — Image upload limits

| Type | Format | Max |
|---|---|---|
| Logo | PNG, JPEG | 1 MB |
| Module images (banner, highlight tiles, install guide) | PNG, JPEG | 5 MB |
