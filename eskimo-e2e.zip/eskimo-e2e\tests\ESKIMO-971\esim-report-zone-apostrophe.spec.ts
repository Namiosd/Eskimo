// ESKIMO-971 – eSIM Report: POST /api/CDR/analytic/search returned 500 for zone Datapro_Côte_d'Ivoire
// (the apostrophe breaks the query; Datapro_Côte_dIvoire without ' → 200).
// Test cases (expected results = the item's Expected: "HTTP 200 with the CDR records of that zone, like every other zone"):
//   TC-01 eSIM Report UI, Zone = Datapro_Côte_d'Ivoire → 200, no error toast, only that zone's rows   (UI + API)
//   TC-02 Regression: Zone = Datapro_Australia (has data) → 200, only Australia rows                  (UI + API)
//   TC-03 Every zone of the stage Zone dropdown → 200 (same body as the page)                          (API)
//   TC-04 Apostrophe variants: Datapro_Cote_d'Ivoire (no ô), ' only, '' → 200                          (API)
// UI cases record 2 evidence steps: the page (filter + table + toast) and the API call the page made.
// Read-only: nothing is created or changed.
// Evidence: evidence/ESKIMO-971-esim-report-zone-apostrophe → npm run report:evidence -- ESKIMO-971 esim-report-zone-apostrophe
import { test, expect, type Browser, type BrowserContext, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import { API_URL, adminToken } from "../_support/wellatsea";

const ID = "@ESKIMO-971";
const AC = "ESKIMO-971";
const evidence = createEvidence("ESKIMO-971", "esim-report-zone-apostrophe");
const ENDPOINT = "/api/CDR/analytic/search";
const PAGE_URL = `${ADMIN_URL}/#/transactions-esim-report`;
const ZONE_CI = "Datapro_Côte_d'Ivoire";
const ZONE_AU = "Datapro_Australia";
// Body the eSIM Report page sends (EsimAnalytics.js) when only the Zone filter is set
const PAGE_BODY = { pageIndex: 1, pageSize: 100, searchMember: "", searchIMSI: "", searchSubId: "", searchOperator: "", searchZone: "", startDate: null, endDate: null, sortBy: { fieldName: "StartModifiedDate", ascending: false } };
// Zone column renders zone without "Datapro_" and with "_" → " "
const zoneLabel = (z: string) => z.replace("Datapro_", "").replace(/_/g, " ").trim();

type Call = { url: string; status: number; request: any; json: any; text: string; ms: number };

let ctx: BrowserContext;
let page: Page;

// ─── UI helpers ───
const settle = async () => {
  await page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 60000 }).catch(() => {});
  await page.locator("[data-testid='overlay']").first().waitFor({ state: "hidden", timeout: 90000 }).catch(() => {});
};
const zoneSelect = () => page.locator(".custom-filter-col").filter({ has: page.getByText("Zone", { exact: true }) }).locator(".ant-select").first();

/** One page load: navigate the first time, reload afterwards (a reload resets every filter). */
async function openReport() {
  if (page.url().includes("transactions-esim-report")) await page.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
  else await page.goto(PAGE_URL, { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.locator(".ant-table").first().waitFor({ state: "visible", timeout: 60000 });
  await settle();
}

/** Picks the zone in the dropdown and returns the analytic/search call the page makes for it. */
async function filterZone(zone: string): Promise<{ call: Call; inList: boolean }> {
  await openReport();
  await zoneSelect().click();
  await page.keyboard.type(zone);
  const opt = page.locator(".dropdown-select-open:visible .ant-select-item-option").filter({ hasText: new RegExp(`^${zone.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`) }).first();
  const inList = await opt.waitFor({ state: "visible", timeout: 5000 }).then(() => true).catch(() => false);
  expect(inList, `Zone "${zone}" must be in the Zone dropdown`).toBe(true);
  const t0 = Date.now();
  const respP = page.waitForResponse((r) => r.url().includes(ENDPOINT) && r.request().method() === "POST" && r.request().postDataJSON()?.searchZone === zone, { timeout: 120000 });
  await opt.click();
  const resp = await respP;
  const text = await resp.text().catch(() => "");
  let json: any = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* not JSON */ }
  await settle();
  await zoneSelect().evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", outlineOffset: "2px" })).catch(() => {});
  return { call: { url: resp.url(), status: resp.status(), request: resp.request().postDataJSON(), json, text, ms: Date.now() - t0 }, inList };
}

/** Table rows (Zone column) + error toast shown by handleApiError (react-toastify). */
async function readUi() {
  const toast = page.locator(".Toastify__toast");
  await toast.first().waitFor({ state: "visible", timeout: 2500 }).catch(() => {});
  const toasts = (await toast.allInnerTexts()).map((t) => t.trim()).filter(Boolean);
  const headers = (await page.locator(".ant-table-thead tr").last().locator("th").allInnerTexts()).map((h) => h.trim());
  const zi = headers.indexOf("Zone");
  const zones = zi < 0 ? [] : await page.locator(".ant-table-tbody tr.ant-table-row").evaluateAll((trs, i) => trs.map((tr) => (tr.children[i] as HTMLElement)?.innerText.trim()), zi);
  const empty = (await page.locator(".ant-table-tbody .ant-empty").count()) > 0;
  return { toasts, zones, empty };
}

// ─── API evidence ───
const rowsOf = (c: { json: any }): any[] => c.json?.data?.data ?? [];
const totalOf = (c: { json: any }): number | null => c.json?.data?.numOfRecords ?? null;
const msgOf = (j: any, text = "") => { const m = j?.messages; return Array.isArray(m) ? m.map((x: any) => x.content).join("; ") : String(m ?? text).slice(0, 200); };

function callHtml(c: Call) {
  const rows = rowsOf(c);
  const zones = [...new Set(rows.map((x) => x.zone))];
  return `<table>
    <tr><th>Request</th><td>POST ${esc(c.url)} (sent by the page)</td></tr>
    <tr><th>Request body</th><td><pre style="margin:0;white-space:pre-wrap">${esc(JSON.stringify(c.request, null, 2))}</pre></td></tr>
    <tr><th>HTTP status</th><td class="${c.status === 200 ? "ok" : "bad"}">${c.status} (${c.ms} ms)</td></tr>
    <tr><th>isSuccess / message</th><td>${esc(c.json?.isSuccess)} – ${esc(msgOf(c.json, c.text))}</td></tr>
    <tr><th>numOfRecords</th><td>${esc(totalOf(c))}</td></tr>
    <tr><th>Rows on page 1</th><td>${rows.length}</td></tr>
    <tr><th>Distinct zones on page 1</th><td>${esc(zones.join(", ") || "—")}</td></tr>
  </table>${rows.length ? `<h3>First rows</h3><table><tr><th>Member</th><th>IMSI</th><th>Sub ID</th><th>Zone</th><th>Plan Type</th></tr>${rows.slice(0, 5).map((x) => `<tr><td>${esc(x.memberName)}</td><td>${esc(x.imsi)}</td><td>${esc(x.subcriptionId)}</td><td>${esc(x.zone)}</td><td>${esc(x.planType)}</td></tr>`).join("")}</table>` : ""}`;
}

async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const c = await browser.newContext();
  try { await evidence.saveDataCard(await c.newPage(), testInfo, heading, html, meta); } finally { await c.close(); }
}

type Direct = { label: string; zone: string; status: number; msg: string; total: number | null };
async function direct(label: string, zone: string): Promise<Direct> {
  const token = await adminToken(page);
  for (let i = 0; i < 3; i++) {
    try {
      const r = await fetch(`${API_URL}${ENDPOINT}`, { method: "POST", signal: AbortSignal.timeout(90000), headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ ...PAGE_BODY, searchZone: zone }) });
      const text = await r.text();
      let j: any = null;
      try { j = JSON.parse(text); } catch { /* not JSON */ }
      if (r.status === 200 && !j) continue; // stage sometimes answers 200 with an empty body
      return { label, zone, status: r.status, msg: msgOf(j, text), total: j?.data?.numOfRecords ?? null };
    } catch { /* retry */ }
  }
  return { label, zone, status: 0, msg: "no response", total: null };
}
const directTable = (rows: Direct[]) => `<p>POST ${esc(API_URL + ENDPOINT)} – body = page body with <code>searchZone</code> replaced:<br><code>${esc(JSON.stringify(PAGE_BODY))}</code></p><table>
  <tr><th>#</th><th>Case</th><th>searchZone</th><th>HTTP</th><th>numOfRecords</th><th>Message</th></tr>
  ${rows.map((d, i) => `<tr><td>${i + 1}</td><td>${esc(d.label)}</td><td>${esc(d.zone)}</td><td class="${d.status === 200 ? "ok" : "bad"}">${d.status}</td><td>${esc(d.total)}</td><td>${esc(d.msg)}</td></tr>`).join("")}
</table>`;

/** UI screenshot + API card for one zone; asserts 200, no toast, only that zone's rows. */
async function zoneCase(browser: Browser, testInfo: TestInfo, tc: string, ac: string, zone: string) {
  const { call } = await filterZone(zone);
  const ui = await readUi();
  const apiRows = rowsOf(call);
  const otherApi = apiRows.filter((x) => x.zone !== zone);
  const otherUi = ui.zones.filter((z) => z !== zoneLabel(zone));
  const noData = call.status === 200 && apiRows.length === 0;
  const uiOk = ui.toasts.length === 0 && otherUi.length === 0;
  const apiOk = call.status === 200 && call.json?.isSuccess !== false && otherApi.length === 0;
  await evidence.saveScreenshot(page, testInfo, {
    ac, title: `${tc} UI – Zone = ${zone}`,
    steps: [
      "Admin › Transactions › eSIM Report (#/transactions-esim-report)",
      `Zone = ${zone} (picked from the dropdown)`,
      `Table: ${ui.empty ? "No Data" : `${ui.zones.length} rows`} · rows of another zone: ${otherUi.length}`,
      ui.toasts.length ? `Error toast: "${ui.toasts.join(" | ")}"` : "No error toast",
      ...(noData ? ["⚠ WARNING: no CDR for this zone on stage → \"only that zone's records\" not verifiable"] : []),
    ],
    expected: ["Table loads, no error toast", `Zone column = "${zoneLabel(zone)}" on every row`],
    status: uiOk ? undefined : "failed",
  });
  await card(browser, testInfo, `${tc} – API call made by the page: Zone = ${zone}`, callHtml(call), {
    ac, title: `${tc} API – Zone = ${zone}`,
    steps: [`POST ${ENDPOINT} searchZone="${zone}"`, `HTTP ${call.status} · isSuccess=${call.json?.isSuccess} · numOfRecords=${totalOf(call)}`, `Rows of another zone: ${otherApi.length}`],
    expected: ["HTTP 200 (not 500)", `Every record has zone = "${zone}"`],
    status: apiOk ? undefined : "failed",
  });
  expect(call.status, `HTTP status: ${msgOf(call.json, call.text)}`).toBe(200);
  expect(ui.toasts, "error toast").toEqual([]);
  expect(otherApi.map((x) => x.zone), "API records of another zone").toEqual([]);
  expect(otherUi, "UI rows of another zone").toEqual([]);
}

test.describe(`ESKIMO-971 eSIM Report analytic/search zone with apostrophe ${ID}`, () => {
  test.describe.configure({ timeout: 300_000 }); // stage page loads ~20 s; TC-03 calls 170 zones
  test.beforeAll(async ({ browser }) => { ({ ctx, page } = await adminSession(browser)); });
  test.afterAll(async () => { await ctx?.close(); });

  test(`TC-01 eSIM Report Zone Datapro_Côte_d'Ivoire returns 200 ${ID}`, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Zone Côte d'Ivoire");
    await zoneCase(browser, testInfo, "TC-01", `${AC} Expected`, ZONE_CI);
  });

  test(`TC-02 eSIM Report Zone Datapro_Australia still filters correctly ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-02 Zone Australia – regression");
    await zoneCase(browser, testInfo, "TC-02", `${AC} Regression`, ZONE_AU);
  });

  test(`TC-03 Every zone of the Zone dropdown returns 200 ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-03 All zones");
    // Zone options as the stage FE renders them (antd virtual list → scroll and collect)
    await openReport();
    await zoneSelect().click();
    const holder = page.locator(".dropdown-select-open:visible .rc-virtual-list-holder").first();
    await holder.waitFor({ state: "visible", timeout: 10000 });
    const seen = new Set<string>();
    for (let i = 0; i < 300; i++) {
      for (const t of await page.locator(".dropdown-select-open:visible .ant-select-item-option").allInnerTexts()) seen.add(t.trim());
      const atEnd = await holder.evaluate((el) => { const before = el.scrollTop; el.scrollTop += 150; return el.scrollTop === before; });
      if (atEnd) break;
      await page.locator(".dropdown-select-open:visible .ant-select-item-option").last().waitFor({ state: "visible" });
    }
    await page.keyboard.press("Escape");
    seen.delete("All");
    const zones = [...seen];
    const rows: Direct[] = [];
    for (const z of zones) rows.push(await direct(z.includes("'") ? "contains '" : "", z));
    const bad = rows.filter((d) => d.status !== 200);
    const withData = rows.filter((d) => d.total).length;
    await card(browser, testInfo, `TC-03 – analytic/search for all ${zones.length} zones of the stage Zone dropdown`,
      `<p><strong>${rows.length - bad.length}/${rows.length} → 200</strong> · ${withData} zones with data · non-200: ${esc(bad.map((d) => `${d.zone}=${d.status}`).join(", ") || "none")}</p>` + directTable(rows), {
      ac: `${AC} Expected`, title: "TC-03 API – all zones",
      steps: [`Zones read from the stage Zone dropdown: ${zones.length}`, `HTTP 200: ${rows.length - bad.length}/${rows.length} (${withData} with data)`, bad.length ? `Non-200: ${bad.map((d) => `${d.zone}=${d.status}`).join(", ")}` : "No zone returns 500"],
      expected: ["HTTP 200 for every zone, like every other zone"],
      status: bad.length ? "failed" : undefined,
    });
    expect(zones.length, "zones read from the dropdown").toBeGreaterThan(100);
    expect(bad.map((d) => `${d.zone}: ${d.status}`), "zones not returning 200").toEqual([]);
  });

  test(`TC-04 Apostrophe variants return 200 ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-04 Apostrophe variants");
    const rows: Direct[] = [
      await direct("Côte d'Ivoire (ô + ')", ZONE_CI),
      await direct("no ô, with '", "Datapro_Cote_d'Ivoire"),
      await direct("only '", "'"),
      await direct("pre-escaped ''", "Datapro_Côte_d''Ivoire"),
      await direct("control: ô, no '", "Datapro_Côte_dIvoire"),
    ];
    const bad = rows.filter((d) => d.status !== 200);
    await card(browser, testInfo, "TC-04 – apostrophe variants in searchZone", directTable(rows), {
      ac: `${AC} Analysis`, title: "TC-04 API – apostrophe variants",
      steps: rows.map((d) => `${d.label}: "${d.zone}" → HTTP ${d.status}`),
      expected: ["HTTP 200 for every value (the ' no longer breaks the query)"],
      status: bad.length ? "failed" : undefined,
    });
    expect(bad.map((d) => `${d.label}: ${d.status}`)).toEqual([]);
  });
});
