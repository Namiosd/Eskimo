// ESKIMO-953 – Admin › White Label › Config › Email sender: validating an UNVERIFIED email domain must not return 500.
// Endpoint: POST /api/white-label/websites/{id}/email-sender/domain/validate ("Check again" button).
// PASS (agreed with QC 2026-10-22): no 5xx AND a clear message — 4xx with messages[], or 200 verified:false
// (UI toast "DNS records not visible yet…"). Never the generic "Something went wrong" toast.
//   TC-01 validate on a website with no email sender configured (UGC site-mzsch4, if still unconfigured)
//   TC-02 from-address saved on an unverified domain, domain auth NOT created yet → validate
//   TC-03 domain auth created (records returned), DNS not added → validate   ← the bug scenario
//   TC-04 UI: Config → Email sender → Check again → clear message, not a generic error
//   TC-05 regression: validate on an already verified website (WLBe2e site-ks26k6) → 200 verified:true
// Writes on stage (approved): email sender of UGC site-mzsch4 + one SendGrid domain auth for qc953.eskimo.travel.
// Evidence: npm run report:evidence -- ESKIMO-953 wl-email-domain-validate
import { test, expect, type BrowserContext, type Locator, type Page, type TestInfo } from "@playwright/test";
import { ADMIN_URL, login } from "../_support/eskimo";
import { adminSessionRetry, api, tokenOf, apiMessage } from "../_support/whitelabel";
import { createEvidence, esc, type EvidenceMeta } from "../_support/evidence";

const ID = "@ESKIMO-953";
const evidence = createEvidence("ESKIMO-953", "wl-email-domain-validate");
const SITE = process.env.QC953_SITE || "site-mzsch4"; // Website Template for partner UGC
const SITE_ROW = /partner UGC/i;
const VERIFIED_SITE = "site-ks26k6"; // WLBe2e, domain verified
const SENDER = { senderName: "QC953 Test", fromAddress: "noreply@qc953.eskimo.travel", replyTo: "support@qc953.eskimo.travel" };
const base = (id: string) => `/api/white-label/websites/${id}/email-sender`;

// TC-01..04 walk the same website through its states: one file = one worker, run in order (not serial, so a
// product failure in one case does not skip the others).
test.setTimeout(240_000);

let ctx: BrowserContext;
let page: Page;
let token = "";

test.beforeAll(async ({ browser }) => {
  ({ ctx, page } = await adminSessionRetry(browser));
  token = await tokenOf(page);
});
test.afterAll(async () => { await ctx?.close(); });

const clear = (r: { status: number; json: any }) => {
  const msg = apiMessage(r.json);
  const ok4xx = r.status >= 400 && r.status < 500 && msg.length > 0;
  const okUnverified = r.status === 200 && r.json?.data?.verified === false;
  return { ok: r.status > 0 && r.status < 500 && (ok4xx || okUnverified), msg };
};

async function card(testInfo: TestInfo, data: unknown, meta: EvidenceMeta) {
  const scratch = await ctx.newPage();
  await evidence.saveDataCard(scratch, testInfo, meta.title, `<pre>${esc(JSON.stringify(data, null, 2))}</pre>`, meta);
  await scratch.close();
}

async function validate(id: string) {
  const r = await api(token, "POST", `${base(id)}/domain/validate`, undefined, 3);
  return { request: `POST ${base(id)}/domain/validate`, httpStatus: r.status, body: r.json };
}

test(`TC-01 Validate on a website without email sender ${ID}`, async ({}, testInfo) => {
  evidence.resetIfFirstAttempt(testInfo);
  evidence.setCase("TC-01 Validate – no email sender configured");
  const before = await api(token, "GET", base(SITE));
  if (before.json?.data) {
    await card(testInfo, { website: SITE, emailSender: before.json.data }, {
      ac: "Bug", title: `${SITE} already has an email sender – precondition gone (earlier run)`, status: "pending",
      steps: [`GET ${base(SITE)}`], expected: ["data = null (never configured)"],
    });
    test.skip(true, "precondition gone: website already configured by an earlier run");
  }
  const v = await validate(SITE);
  const c = clear({ status: v.httpStatus, json: v.body });
  await card(testInfo, { website: SITE, emailSenderBefore: before.json?.data ?? null, ...v }, {
    ac: "Bug", title: `Validate (no config) → HTTP ${v.httpStatus} ${c.msg ? `"${c.msg}"` : ""}`,
    steps: [`GET ${base(SITE)} → data null`, `POST ${base(SITE)}/domain/validate`],
    expected: ["HTTP 4xx with a validation message (not 500)"],
    status: c.ok ? undefined : "failed",
  });
  expect(v.httpStatus, "must not be 5xx").toBeLessThan(500);
  expect(c.ok, `clear message, got ${v.httpStatus} ${c.msg}`).toBeTruthy();
});

test(`TC-02 Validate after saving an unverified from-address, before Create ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-02 Validate – from-address on unverified domain, domain auth not created");
  const put = await api(token, "PUT", base(SITE), SENDER, 2);
  const cfg = put.json?.data ?? null;
  await card(testInfo, { request: `PUT ${base(SITE)}`, payload: SENDER, httpStatus: put.status, body: put.json }, {
    ac: "Precondition", title: `Save email sender ${SENDER.fromAddress} → HTTP ${put.status}`,
    steps: ["Admin STAGE → White Label › Website Templates › UGC › Config", `Email sender: ${SENDER.senderName} / ${SENDER.fromAddress} / ${SENDER.replyTo}`, "Save"],
    expected: ["HTTP 200", "address staged as pending (domain not verified)"],
    status: put.status === 200 ? undefined : "failed",
  });
  expect(put.status, `PUT email-sender: ${apiMessage(put.json)}`).toBe(200);
  const v = await validate(SITE);
  const c = clear({ status: v.httpStatus, json: v.body });
  await card(testInfo, { website: SITE, emailSender: cfg, ...v }, {
    ac: "Bug", title: `Validate (domain auth not created) → HTTP ${v.httpStatus} ${c.msg ? `"${c.msg}"` : ""}`,
    steps: [`POST ${base(SITE)}/domain/validate (no Create yet)`],
    expected: ["HTTP 4xx with a message (e.g. create the domain first) – never 500"],
    status: c.ok ? undefined : "failed",
  });
  expect(v.httpStatus, "must not be 5xx").toBeLessThan(500);
  expect(c.ok, `clear message, got ${v.httpStatus} ${c.msg}`).toBeTruthy();
});

test(`TC-03 Validate an unverified domain (records created, DNS not added) ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-03 Validate – unverified domain (bug scenario)");
  const cr = await api(token, "POST", `${base(SITE)}/domain`, undefined, 1);
  const records = cr.json?.data?.records ?? [];
  await card(testInfo, { request: `POST ${base(SITE)}/domain`, httpStatus: cr.status, body: cr.json }, {
    ac: "Precondition", title: `Create domain auth → HTTP ${cr.status}, ${records.length} DNS records, verified=${cr.json?.data?.verified}`,
    steps: ["Config › Email sender › Create / get records"],
    expected: ["HTTP 200 with the CNAME records for qc953.eskimo.travel", "verified = false (records are NOT added to DNS)"],
    status: cr.status === 200 ? undefined : "failed",
  });
  expect(cr.status, `POST domain: ${apiMessage(cr.json)}`).toBe(200);
  const v = await validate(SITE);
  const c = clear({ status: v.httpStatus, json: v.body });
  const after = await api(token, "GET", base(SITE));
  await card(testInfo, { website: SITE, ...v, emailSenderAfter: after.json?.data }, {
    ac: "Bug", title: `Validate unverified domain → HTTP ${v.httpStatus} ${c.msg ? `"${c.msg}"` : `verified=${v.body?.data?.verified}`}`,
    steps: [`POST ${base(SITE)}/domain/validate`, `GET ${base(SITE)} (state after)`],
    expected: ["Never 500", "4xx 'Domain is not verified' or 200 verified:false", "pending address stays pending"],
    status: c.ok ? undefined : "failed",
  });
  expect(v.httpStatus, "must not be 5xx").toBeLessThan(500);
  expect(c.ok, `clear message, got ${v.httpStatus} ${c.msg}`).toBeTruthy();
});

// ─── UI helpers ───
// UI cases log in as a Super Admin: since FE commit db2a94c4 /white-label-templates needs the "White Label" permission
// module, which the E2E Admin User (E2E_ADMIN_EMAIL) does not have on stage (22/10). API cases keep the E2E token.
let uiCtx: BrowserContext | undefined;
async function superAdminPage() {
  if (!process.env.E2E_SUPERADMIN_EMAIL || !process.env.E2E_SUPERADMIN_PASSWORD) throw new Error("Set E2E_SUPERADMIN_EMAIL / E2E_SUPERADMIN_PASSWORD in .env (Super Admin, White Label access)");
  if (uiCtx) return;
  let last: unknown;
  for (let i = 1; i <= 3 && !uiCtx; i++) {
    const c = await ctx.browser()!.newContext({ baseURL: ADMIN_URL });
    const p = await c.newPage();
    try { await login(p, `${ADMIN_URL}/#/login`, process.env.E2E_SUPERADMIN_EMAIL, process.env.E2E_SUPERADMIN_PASSWORD); uiCtx = c; page = p; }
    catch (e) { last = e; await c.close(); }
  }
  if (!uiCtx) throw last;
}
test.afterAll(async () => { await uiCtx?.close(); });

async function openConfig() {
  await superAdminPage();
  // The UI session is shared between cases: close a Config modal left open by the previous case.
  for (let i = 0; i < 3 && (await page.locator(".ant-modal-wrap:visible").count()) > 0; i++) {
    await page.locator(".ant-modal-wrap:visible .ant-modal-close").first().click({ timeout: 3000 }).catch(() => page.keyboard.press("Escape"));
    await page.waitForTimeout(500);
  }
  await page.setViewportSize({ width: 1600, height: 1000 });
  // After login the SPA bounces deep links to the dashboard; the sidebar link sits in a collapsed group.
  const row = page.locator(".ant-table-row").filter({ hasText: SITE_ROW }).first();
  let loaded = false;
  // Sidebar item "White Label" (bottom, top-level) only renders once permissions have loaded – click it, then
  // fall back to setting the hash.
  const link = page.locator("a[href*='white-label-templates']").first();
  for (let i = 0; i < 3 && !loaded; i++) {
    if (i > 0 || !page.url().includes("#/")) await page.goto(`${ADMIN_URL}/#/dashboard`, { waitUntil: "domcontentloaded" });
    if (await link.waitFor({ state: "attached", timeout: 60000 }).then(() => true).catch(() => false)) {
      await link.evaluate((el) => el.scrollIntoView({ block: "center" })).catch(() => {});
      await link.click({ timeout: 10000 }).catch(() => {});
      loaded = await row.waitFor({ timeout: 45000 }).then(() => true).catch(() => false);
    }
    if (!loaded) {
      await page.evaluate(() => { location.hash = "#/white-label-templates"; });
      loaded = await row.waitFor({ timeout: 30000 }).then(() => true).catch(() => false);
    }
  }
  expect(loaded, "Website Templates table loaded").toBeTruthy();
  await row.getByRole("button", { name: /^Config$/ }).or(row.getByText(/^Config$/)).first().click();
  const modal = page.locator(".ant-modal:visible").filter({ hasText: "Email sender" }).first();
  await modal.waitFor({ timeout: 30000 });
  await modal.getByText("Domain authentication").first().waitFor({ timeout: 30000 });
  return modal;
}

const outline = (l: Locator) => l.evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", outlineOffset: "2px" }), undefined, { timeout: 2000 }).catch(() => {});

/** Click, wait for the API response and the toast it raises; the toast is still on screen when the caller shoots. */
async function clickAndRead(button: Locator, url: RegExp, method: string) {
  await page.locator(".Toastify__toast").evaluateAll((els) => els.forEach((e) => e.remove())).catch(() => {});
  const respP = page.waitForResponse((r) => url.test(r.url()) && r.request().method() === method, { timeout: 120000 });
  await button.click();
  const resp = await respP;
  const status = resp.status();
  const body = await resp.json().catch(() => null);
  const t = page.locator(".Toastify__toast").last();
  const toast = (await t.waitFor({ timeout: 8000 }).then(() => t.innerText()).catch(() => "")).trim();
  if (toast) await t.hover({ timeout: 2000 }).catch(() => {}); // Toastify pauses autoClose on hover → still on screen for the shot
  if (toast) await t.evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322" }), undefined, { timeout: 2000 }).catch(() => {});
  return { status, body, toast };
}
const isGeneric = (toast: string) => /Something went wrong|An error occurred|requested API does not exist/i.test(toast);

test(`TC-04 UI: Check again on an unverified domain shows a clear message ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-04 UI – Config › Email sender › Check again");
  const modal = await openConfig();
  const panel = modal.getByText("Domain authentication").first();
  await panel.scrollIntoViewIfNeeded();
  const cr = await clickAndRead(modal.getByRole("button", { name: /Create \/ get records|Get records again/ }), new RegExp(`/${SITE}/email-sender/domain$`), "POST");
  const check = modal.getByRole("button", { name: /Check again/ });
  const hasCheck = await check.waitFor({ timeout: 30000 }).then(() => true).catch(() => false);
  let v = { status: 0, body: null as any, toast: cr.toast };
  if (hasCheck) {
    await check.scrollIntoViewIfNeeded();
    v = await clickAndRead(check, new RegExp(`/${SITE}/email-sender/domain/validate`), "POST");
    await outline(check);
  }
  const generic = isGeneric(v.toast);
  const ok = hasCheck && v.status > 0 && v.status < 500 && !generic && v.toast.length > 0;
  await evidence.saveScreenshot(page, testInfo, {
    ac: "Bug", title: `Check again → HTTP ${v.status}, toast "${v.toast || "(none)"}"`,
    steps: ["Admin STAGE → White Label › Website Templates", "Row 'Website Template for partner UGC' → Config", `Email sender › Create / get records (HTTP ${cr.status})`, "Check again (DNS not added)"],
    expected: ["Validate request is not 5xx", "A clear message (e.g. 'Domain is not verified' / 'DNS records not visible yet'), not 'Something went wrong'"],
    status: ok ? undefined : "failed",
  });
  await card(testInfo, { request: `POST ${base(SITE)}/domain/validate (from UI)`, httpStatus: v.status, body: v.body, toast: v.toast }, {
    ac: "Bug", title: `Check again – network response HTTP ${v.status}`,
    steps: ["Captured from the browser network"], expected: ["not 5xx"], status: ok ? undefined : "failed",
  });
  expect(hasCheck, `Check again button after Create / get records (create HTTP ${cr.status} ${cr.toast})`).toBeTruthy();
  expect(v.status, "must not be 5xx").toBeLessThan(500);
  expect(generic, `generic error toast: ${v.toast}`).toBeFalsy();
  expect(v.toast, "a message is shown").not.toBe("");
});

test(`TC-05 Regression: validate on a verified website ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-05 Regression – verified domain");
  const before = await api(token, "GET", base(VERIFIED_SITE));
  const v = await validate(VERIFIED_SITE);
  // Ticket rule only: never 500, always a proper answer. (A verified site with nothing pending has no domain auth
  // to check, so BE answers 400 "no pending domain authentication" – that is a valid 4xx message.)
  const msg = apiMessage(v.body);
  const ok = v.httpStatus > 0 && v.httpStatus < 500 && (v.body?.data?.verified === true || (v.httpStatus >= 400 && msg.length > 0));
  const after = await api(token, "GET", base(VERIFIED_SITE));
  const unchanged = JSON.stringify(after.json?.data) === JSON.stringify(before.json?.data);
  await card(testInfo, { website: VERIFIED_SITE, emailSenderBefore: before.json?.data, ...v, emailSenderAfter: after.json?.data }, {
    ac: "Regression", title: `Validate verified domain → HTTP ${v.httpStatus} ${msg ? `"${msg}"` : `verified=${v.body?.data?.verified}`}`,
    steps: [`GET ${base(VERIFIED_SITE)} → domainStatus verified`, `POST ${base(VERIFIED_SITE)}/domain/validate`, `GET ${base(VERIFIED_SITE)} (after)`],
    expected: ["Never 500", "200 verified:true or 4xx with a clear message", "email sender config unchanged (still verified)"],
    status: ok && unchanged ? undefined : "failed",
  });
  expect(v.httpStatus).toBeLessThan(500);
  expect(ok, `got ${v.httpStatus} ${msg}`).toBeTruthy();
  expect(unchanged, "verified website config unchanged").toBeTruthy();
});

// QC repro steps (2026-10-22): any stage website → Email sender → From address on a never-verified domain → Save →
// Domain authentication (DNS records shown) → no DNS added → Validate. Everything through the UI.
const UI_FROM = process.env.QC953_UI_FROM || "noreply@test-wl-1020.example.com";

test(`TC-06 UI end-to-end: new unverified domain → Save → Domain authentication → Validate ${ID}`, async ({}, testInfo) => {
  evidence.setCase("TC-06 UI – full repro with a never-verified domain");
  const modal = await openConfig();
  const steps = ["Admin STAGE → White Label › Website Templates", "Row 'Website Template for partner UGC' → Config"];

  // Step 1 – From address on a never-verified domain → Save
  const name = modal.getByLabel("Sender name");
  const from = modal.getByLabel("From address");
  const reply = modal.getByLabel("Reply-to");
  if (!(await name.inputValue())) await name.fill(SENDER.senderName);
  if (!(await reply.inputValue())) await reply.fill(SENDER.replyTo);
  await from.fill(UI_FROM);
  await from.scrollIntoViewIfNeeded();
  const saveBtn = modal.getByRole("button", { name: /^Save$/ }).last();
  const sv = await clickAndRead(saveBtn, new RegExp(`/${SITE}/email-sender$`), "PUT");
  const pendingAlert = modal.getByText(`${UI_FROM} is waiting on DNS`);
  const pendingShown = await pendingAlert.waitFor({ timeout: 10000 }).then(() => true).catch(() => false);
  await modal.getByText("Email sender").first().scrollIntoViewIfNeeded();
  await outline(pendingAlert);
  const okSave = sv.status === 200 && pendingShown;
  await evidence.saveScreenshot(page, testInfo, {
    ac: "Step 1", title: `Save From address ${UI_FROM} → HTTP ${sv.status}, toast "${sv.toast || "(none)"}"`,
    steps: [...steps, `Email sender › From address = ${UI_FROM}`, "Save"],
    expected: ["Saved (HTTP 200, toast 'Email sender saved')", `Banner '${UI_FROM} is waiting on DNS' (address staged, domain not verified)`],
    status: okSave ? undefined : "failed",
  });
  expect(sv.status, `PUT email-sender: ${JSON.stringify(sv.body?.messages ?? "")}`).toBe(200);

  // Step 2 – Domain authentication → DNS records listed
  const createBtn = modal.getByRole("button", { name: /Create \/ get records|Get records again/ });
  await createBtn.scrollIntoViewIfNeeded();
  const cr = await clickAndRead(createBtn, new RegExp(`/${SITE}/email-sender/domain$`), "POST");
  const records = cr.body?.data?.records ?? [];
  const firstRecord = modal.getByText("Mail sending (return path)").first();
  const recordsShown = await firstRecord.waitFor({ timeout: 10000 }).then(() => true).catch(() => false);
  if (recordsShown) await modal.getByText("Domain authentication").first().evaluate((el) => el.scrollIntoView({ block: "start" }));
  const crGeneric = isGeneric(cr.toast);
  const okCreate = cr.status < 500 && !crGeneric && (recordsShown || (cr.status >= 400 && cr.toast.length > 0));
  await evidence.saveScreenshot(page, testInfo, {
    ac: "Step 2", title: recordsShown
      ? `Domain authentication → HTTP ${cr.status}, ${records.length} DNS records shown (waiting)`
      : `Domain authentication → HTTP ${cr.status}, toast "${cr.toast || "(none)"}"`,
    steps: [...steps, "Domain authentication › Create / get records"],
    expected: ["The DNS records to add are listed (CNAME mail_cname / dkim1 / dkim2, status 'waiting')", "or, if the domain cannot be registered, a clear 4xx message – never 500 / generic error"],
    status: okCreate ? undefined : "failed",
  });
  expect(cr.status, "create must not be 5xx").toBeLessThan(500);
  expect(crGeneric, `generic error toast: ${cr.toast}`).toBeFalsy();
  test.skip(!recordsShown, `domain not registrable (HTTP ${cr.status} "${cr.toast}") – Validate step not reachable`);

  // Step 3 – no DNS added → Validate (Check again)
  const check = modal.getByRole("button", { name: /Check again/ });
  await check.scrollIntoViewIfNeeded();
  const v = await clickAndRead(check, new RegExp(`/${SITE}/email-sender/domain/validate`), "POST");
  await outline(check);
  await modal.getByText("Domain authentication").first().evaluate((el) => el.scrollIntoView({ block: "start" }));
  const generic = isGeneric(v.toast);
  const stillPending = await modal.getByText("Pending DNS").first().isVisible().catch(() => false);
  const ok = v.status > 0 && v.status < 500 && !generic && v.toast.length > 0;
  await evidence.saveScreenshot(page, testInfo, {
    ac: "Bug", title: `Validate (no DNS) → HTTP ${v.status}, toast "${v.toast || "(none)"}"`,
    steps: [...steps, "DNS records NOT added", "Check again (Validate)"],
    expected: ["Never 500", "Clear message (4xx 'Domain is not verified' or 'DNS records not visible yet…'), not 'Something went wrong'", "Status stays 'Pending DNS'"],
    status: ok && stillPending ? undefined : "failed",
  });
  await card(testInfo, {
    save: { request: `PUT ${base(SITE)}`, httpStatus: sv.status, body: sv.body },
    create: { request: `POST ${base(SITE)}/domain`, httpStatus: cr.status, body: cr.body },
    validate: { request: `POST ${base(SITE)}/domain/validate`, httpStatus: v.status, body: v.body, toast: v.toast },
  }, {
    ac: "Bug", title: `TC-06 network: save ${sv.status} → create ${cr.status} → validate ${v.status}`,
    steps: ["Responses captured from the browser network"], expected: ["no 5xx"], status: ok ? undefined : "failed",
  });
  expect(v.status, "validate must not be 5xx").toBeLessThan(500);
  expect(generic, `generic error toast: ${v.toast}`).toBeFalsy();
  expect(v.toast, "a message is shown").not.toBe("");
  expect(stillPending, "status stays Pending DNS").toBeTruthy();
});
