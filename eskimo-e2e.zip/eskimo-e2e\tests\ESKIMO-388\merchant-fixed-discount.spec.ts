// ESKIMO-388 / EP-6063 – Merchant Fixed Discount not validated against plan price.
// Test cases: testcases/ESKIMO-388/ESKIMO-388.md. Runs serially on one partner (partnerofduc):
//   TC-01 rule 456789 → warning (+ record whether the BE saved it)   TC-03 Discount Price >= 0
//   TC-05 buy 1 voucher → Remaining Credits must not increase        TC-02 rule = 5 saves
//   TC-04 Discount Price = price − 5
// Cleanup (afterAll) removes the "Any Unlimited Vietnam" rule it added, or restores the original.
// Evidence: evidence/ESKIMO-388-merchant-fixed-discount/; report:
//   npm run report:evidence -- ESKIMO-388 merchant-fixed-discount "EP-6063 · STG Admin + Partner"
import { test, expect, type Browser, type Locator, type Page, type TestInfo } from "@playwright/test";
import {
  adminSession, partnerSession, openPartnerDrawer, findMerchantRow, addMerchantRow, deleteMerchantRow,
  setDiscount, readDiscountType, rowValueInput, savePartnerDrawer,
  openPurchaseVoucher, selectVoucherPlan, openVouchers, readRemainingCredits, type PurchasePlan,
} from "../_support/eskimo";
import { createEvidence } from "../_support/evidence";

const ID = "@ESKIMO-388";
const AC = "EP-6063";
const RULE = "Any Unlimited Vietnam";
const FIXED = "Fixed Discount ($US)";
const HUGE = 456789;
const NORMAL = 5;
const TARGET_PRICE = 16;
const evidence = createEvidence("ESKIMO-388", "merchant-fixed-discount");

test.describe.serial(`ESKIMO-388 Merchant Fixed Discount ${ID}`, () => {
  test.describe.configure({ retries: 0 });
  test.setTimeout(300_000);

  let admin: { ctx: any; page: Page };
  let partner: { ctx: any; page: Page; partnerName: string };
  let original: { type: string; value: string } | null = null; // rule existed before the run
  let touched = false;
  let hugeSaved = false;
  let target: PurchasePlan | null = null;

  const openRule = async () => {
    const { drawer, detail } = await openPartnerDrawer(admin.page, partner.partnerName);
    return { drawer, detail, row: await findMerchantRow(drawer, RULE) };
  };

  const pickTarget = (plans: PurchasePlan[]) => {
    const unl = plans.filter((p) => /^Unlimited Vietnam\b/i.test(p.dataPlanName));
    expect(unl.length, "No 'Unlimited Vietnam …' plan offered to this partner").toBeGreaterThan(0);
    return unl.find((p) => p.price === TARGET_PRICE) ?? unl[0];
  };

  // Screenshot first, assert after: a failing check still lands in the report.
  const shot = (page: Page, testInfo: TestInfo, title: string, steps: string[], expected: string[], ok = true) =>
    evidence.saveScreenshot(page, testInfo, { ac: AC, title, steps, expected, status: ok ? undefined : "failed" });

  const scrollTo = async (loc: Locator) => {
    await loc.scrollIntoViewIfNeeded().catch(() => {});
    await loc.evaluate((el) => el.scrollIntoView({ block: "center" })).catch(() => {});
  };

  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    admin = await adminSession(browser);
    partner = await partnerSession(browser);
    console.log(`[INFO] partner = "${partner.partnerName}"`);
  });

  test.afterAll(async () => {
    if (touched) {
      try {
        const { drawer, row } = await openRule();
        if (row && original) await setDiscount(drawer, RULE, original.type, original.value);
        else if (row) await deleteMerchantRow(row);
        const r = await savePartnerDrawer(drawer);
        console.log(`[INFO] Cleanup ${row ? (original ? "restored" : "removed") : "nothing to remove for"} "${RULE}" → HTTP ${r.status}`);
      } catch (e) {
        console.log(`[WARN] Cleanup failed, fix "${RULE}" on ${partner.partnerName} by hand: ${(e as Error).message}`);
      }
    }
    await admin?.ctx.close();
    await partner?.ctx.close();
  });

  test(`TC-01 Fixed Discount 456789 shows a warning ${ID}`, async ({}, testInfo) => {
    // KEEP_EVIDENCE=1: re-run a subset without wiping the shots of cases run earlier.
    if (!process.env.KEEP_EVIDENCE) evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Admin: warning when Fixed Discount > plan price");
    let drawer!: Locator, row: Locator | null = null;
    await test.step("1. Admin → Partners → partner → Merchant Program", async () => {
      ({ drawer, row } = await openRule());
      if (row) original = { type: await readDiscountType(row), value: await rowValueInput(row).inputValue() };
      console.log(`[INFO] rule "${RULE}" before run: ${original ? JSON.stringify(original) : "none"}`);
    });
    await test.step(`2. Discount Benefit: ${RULE}, ${FIXED}, ${HUGE}`, async () => {
      if (!row) await addMerchantRow(drawer, RULE);
      touched = true;
      await setDiscount(drawer, RULE, FIXED, HUGE);
      const warning = drawer.getByText(/final bill < 1/).last();
      const ok = await warning.waitFor({ state: "visible", timeout: 15000 }).then(() => true).catch(() => false);
      const ruleRow = await findMerchantRow(drawer, RULE);
      if (ruleRow) await scrollTo(ruleRow);
      const text = ok ? (await drawer.locator(".warning-list, .text-danger").filter({ hasText: "final bill" }).allInnerTexts()).join(" | ").slice(0, 200) : "none";
      await shot(admin.page, testInfo, `1.1. ${RULE} = ${FIXED} ${HUGE} → warning`,
        [`Admin → Partnership → Partners → ${partner.partnerName} → Edit`, `Merchant Program → New Discount Benefit: ${RULE}, ${FIXED}, ${HUGE}`],
        [`Warning "<plan> final bill < 1" shown`, `→ actual: ${ok ? `shown (${text})` : "NOT shown"}`], ok);
      expect(ok, "warning 'final bill < 1' expected").toBe(true);
    });
    await test.step("3. Save (outcome recorded, decided by BE)", async () => {
      const r = await savePartnerDrawer(drawer);
      const reopened = await openRule();
      hugeSaved = !!reopened.row && Number(await rowValueInput(reopened.row).inputValue()) === HUGE;
      if (reopened.row) await scrollTo(reopened.row);
      const note = `BE ${hugeSaved ? "SAVED" : "did NOT save"} the rule (HTTP ${r.status}${r.message ? `: ${r.message}` : ""})`;
      test.info().annotations.push({ type: "BE save result", description: note });
      await shot(admin.page, testInfo, "1.2. Save → reopen partner (BE decides)",
        ["Click Ok (Save)", `Reopen ${partner.partnerName} → Merchant Program`],
        ["Recorded only (QC decision: saving is the BE's call)", `→ actual: ${note}`]);
      console.log(`[INFO] ${note}`);
      await admin.page.keyboard.press("Escape");
    });
  });

  test(`TC-03 Discount Price is never negative ${ID}`, async ({}, testInfo) => {
    test.skip(!hugeSaved, "BE refused the 456789 rule in TC-01: precondition not met");
    evidence.setCase("TC-03 Partner: Discount Price never negative");
    const { drawer, plans } = await openPurchaseVoucher(partner.page);
    target = pickTarget(plans);
    const ui = await selectVoucherPlan(drawer, target.dataPlanName);
    const ok = ui !== null && ui >= 0 && target.discountPrice >= 0;
    await shot(partner.page, testInfo, `3.1. Purchase Voucher "${target.dataPlanName}" with rule ${HUGE}`,
      [`Partner (${partner.partnerName}) → Vouchers → Purchase Voucher`, `Select "${target.dataPlanName}" (price $${target.price}), no submit`],
      ["Discount Price >= 0 (never negative), UI and API",
        `→ actual: UI Discount Price $${ui}, API discountPrice $${target.discountPrice}`], ok);
    expect.soft(target.discountPrice, "API discountPrice must be >= 0").toBeGreaterThanOrEqual(0);
    expect(ui, "UI Discount Price must be >= 0").toBeGreaterThanOrEqual(0);
  });

  test(`TC-05 Remaining Credits do not increase after buying a voucher ${ID}`, async ({}, testInfo) => {
    test.skip(!hugeSaved, "BE refused the 456789 rule in TC-01: precondition not met");
    evidence.setCase("TC-05 Partner: Remaining Credits after buying 1 voucher");
    let before: number | null = null;
    let plan!: PurchasePlan;
    let discountPrice: number | null = null;
    await test.step("1. Read Remaining Credits", async () => {
      await openVouchers(partner.page);
      before = await readRemainingCredits(partner.page);
      await shot(partner.page, testInfo, "5.1. Remaining Credits before purchase",
        [`Partner (${partner.partnerName}) → Vouchers`], [`→ Remaining Credits: $${before}`], before !== null);
      expect(before, "Remaining Credits not shown (prepaid merchant expected)").not.toBeNull();
    });
    await test.step("2. Purchase Voucher, plan $16, Quantity 1, Submit", async () => {
      const { drawer, plans } = await openPurchaseVoucher(partner.page);
      plan = target ?? pickTarget(plans);
      discountPrice = await selectVoucherPlan(drawer, plan.dataPlanName);
      await drawer.locator("input[placeholder='Insert Quantity']").first().fill("1");
      await shot(partner.page, testInfo, `5.2. Purchase "${plan.dataPlanName}" × 1`,
        ["Purchase Voucher", `Plan "${plan.dataPlanName}" (price $${plan.price}), Quantity 1`],
        [`→ Discount Price shown: $${discountPrice}`]);
      await drawer.locator(".btn-action-ok").click();
      const closed = await drawer.waitFor({ state: "hidden", timeout: 60000 }).then(() => true).catch(() => false);
      if (!closed) {
        const err = await partner.page.locator(".ant-modal-body, .ant-notification-notice").first().innerText({ timeout: 2000 }).catch(() => "");
        await shot(partner.page, testInfo, "5.3. Submit purchase", ["Click Ok"], ["Purchase completes", `→ actual: ${err || "drawer stayed open"}`], false);
        throw new Error(`Purchase not completed: ${err || "drawer stayed open"}`);
      }
    });
    await test.step("3. Read Remaining Credits again", async () => {
      await openVouchers(partner.page);
      const after = await readRemainingCredits(partner.page);
      const debited = Number((before! - after!).toFixed(2));
      const notIncreased = after! <= before!;
      const withinPrice = debited <= plan.price;
      test.info().annotations.push({ type: "credits", description: `before $${before}, after $${after}, debited $${debited}` });
      await shot(partner.page, testInfo, "5.3. Remaining Credits after purchase",
        ["Submit purchase", "Vouchers → read Remaining Credits"],
        ["Remaining Credits do NOT increase (increase = bug)", `Debited <= plan price $${plan.price}`,
          `→ actual: before $${before}, after $${after}, debited $${debited} (Discount Price $${discountPrice})`],
        notIncreased && withinPrice);
      expect(after!, `Remaining Credits increased: $${before} → $${after}`).toBeLessThanOrEqual(before!);
      expect(debited, `Debited $${debited} exceeds plan price $${plan.price}`).toBeLessThanOrEqual(plan.price);
    });
  });

  test(`TC-02 Fixed Discount 5 saves ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-02 Admin: valid Fixed Discount saves");
    let drawer!: Locator, row: Locator | null = null;
    await test.step(`Set ${RULE} = ${FIXED} ${NORMAL}`, async () => {
      ({ drawer, row } = await openRule());
      if (!row) await addMerchantRow(drawer, RULE);
      touched = true;
      await setDiscount(drawer, RULE, FIXED, NORMAL);
    });
    await test.step("Save, reopen", async () => {
      const r = await savePartnerDrawer(drawer);
      const { row: saved } = await openRule();
      const type = saved ? await readDiscountType(saved) : "";
      const value = saved ? Number(await rowValueInput(saved).inputValue()) : null;
      if (saved) await scrollTo(saved);
      const ok = r.ok && !!saved && type === FIXED && value === NORMAL;
      await shot(admin.page, testInfo, `2.1. ${RULE} = ${FIXED} ${NORMAL} → Save → reopen`,
        [`Merchant Program: ${RULE}, ${FIXED}, ${NORMAL}`, "Click Ok (Save)", "Reopen partner"],
        [`Saved; row shows ${FIXED} ${NORMAL}`, `→ actual: HTTP ${r.status}, row ${saved ? `${type} ${value}` : "not found"}`], ok);
      expect(r.ok, `Save failed: HTTP ${r.status} ${r.message}`).toBe(true);
      expect(saved, `rule "${RULE}" not found after save`).not.toBeNull();
      expect(type).toBe(FIXED);
      expect(value).toBe(NORMAL);
      await admin.page.keyboard.press("Escape");
    });
  });

  test(`TC-04 Discount Price = price − 5 ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-04 Partner: normal Fixed Discount priced correctly");
    const { drawer, plans } = await openPurchaseVoucher(partner.page);
    const plan = pickTarget(plans);
    const expected = Number(Math.max(plan.price - NORMAL, 0).toFixed(2));
    const ui = await selectVoucherPlan(drawer, plan.dataPlanName);
    const ok = ui !== null && Math.abs(ui - expected) < 0.005 && Math.abs(plan.discountPrice - expected) < 0.005;
    await shot(partner.page, testInfo, `4.1. Purchase Voucher "${plan.dataPlanName}" with rule ${NORMAL}`,
      [`Partner → Vouchers → Purchase Voucher`, `Select "${plan.dataPlanName}" (price $${plan.price}), no submit`],
      [`Discount Price = $${plan.price} − $${NORMAL} = $${expected}`, `→ actual: UI $${ui}, API $${plan.discountPrice}`], ok);
    expect.soft(plan.discountPrice, "API discountPrice").toBeCloseTo(expected, 2);
    expect(ui, "UI Discount Price").toBeCloseTo(expected, 2);
  });
});
