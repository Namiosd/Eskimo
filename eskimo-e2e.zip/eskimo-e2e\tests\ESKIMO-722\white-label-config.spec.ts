// ESKIMO-722 (EA-4290, BE story) / EP-5991 – Configure White Label under Corporate Program (Admin › Partnership › Partner).
// Copied from tests/ESKIMO-757 (same feature, FE sub-task). Test cases: testcases/ESKIMO-722/ESKIMO-722.md.
// Expected = Docmost spec V1mdGKDN2D (EP-5991, 2026-10-13) + Plane ESKIMO-757 phase-1 revision 2026-10-16
// (Eskimo Stripe Pay / No Expiry hidden) — QC decision 2026-10-20. STAGING.
// Sub-tasks recorded only ("verified indirectly via ESKIMO-722", no own verdict):
//   ESKIMO-822 (AC2) ← TC-06/TC-07 · ESKIMO-831 (program gate) ← TC-12/13/14 storefront status · ESKIMO-818 (Test flag) ← SUB-818
//   AC1: TC-01 fields · TC-02 Payment Method · TC-03 Data Expiry · TC-04 Stripe "Not Connected"/"Verified" · TC-05 no NPC
//   AC2: TC-06 email default False · TC-07 True/False persist · TC-08 mails per toggle (recorded: evidence 2026-10-09)
//   AC3: TC-09 "Application Fee Percentage" section · TC-10 fee saved + applied · TC-11 fee on real sales (recorded)
//   AC4 (Partner 2, live storefront): TC-12 Disabled blocks website/API · TC-15 re-enable keeps config ·
//        TC-13 before Start Date blocks · TC-14 after End Date blocks
// No purchase (kept for the journey flow). WLBe2e (config) and WhiteLabel Partner 2 (AC4) are snapshotted in TC-01 and
// restored + verified after the last test (or at the start of the next run when a run was interrupted).
// Evidence: evidence/ESKIMO-722-white-label-config → npm run report:evidence -- ESKIMO-722 white-label-config
import path from "node:path";
import { test, expect, type Browser, type Page, type TestInfo } from "@playwright/test";
import { ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import {
  api, tokenOf, apiMessage, findPartner, websites, readPartner, restorePartner, corporateBody, diff, snapOf,
  openCorporate, corporate, formItem, isOn, focus, selectOptions, choose, selected, readCorporateForm, clickOk,
  storefrontPage, pollPlans, partnerToken, stateFile, adminSessionRetry as adminSession, findKeys, PLAN_PAGES, POLL_MS, type PartnerState,
} from "../_support/whitelabel";

const ID = "@ESKIMO-722";
const AC = "EP-5991";
const evidence = createEvidence("ESKIMO-722", "white-label-config");
const WLB = process.env.E2E_WL_TEST_PARTNER || "WLBe2e"; // own test partner for config changes
const P2 = process.env.E2E_WL_PARTNER_NAME || "WhiteLabel Partner 2"; // storefront partner (AC4)
// User-approved exception (2026-10-15): same stage test account + static stage OTP as eskimo_portal
// e2e/setup/partner-wl.setup.js when the env vars are not set.
const P2_EMAIL = process.env.E2E_WL_PARTNER_EMAIL || "wlb@yopmail.com";
const P2_OTP = process.env.E2E_WL_PARTNER_OTP || "1234";

type State = { wlb?: PartnerState; p2?: PartnerState; completed?: string[] };
const st = stateFile(path.join(path.dirname(evidence.SCREENSHOT_DIR), "ESKIMO-722-state.json"));
const load = () => st.load<State>();
const save = (s: State) => st.save(s);
const LAST = "TC-14";
// 2026-10-16: FE removed the Data Expiry field and is adding it back → TC-03 (and TC-01's Data Expiry row)
// are PENDING while E2E_722_DATA_EXPIRY_PENDING=1. Run without it once the FE is deployed.
const DATA_EXPIRY_PENDING = process.env.E2E_722_DATA_EXPIRY_PENDING === "1";
// Partial re-runs (e.g. --grep "TC-01|TC-03"): keep the other cases' evidence and restore at the end of THIS run.
const KEEP_EVIDENCE = process.env.E2E_722_KEEP_EVIDENCE === "1";
const RESTORE_AT_END = process.env.E2E_722_RESTORE_AT_END === "1";

const table = (head: string[], rows: unknown[][]) =>
  `<table><tr>${head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr>${rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</table>`;
async function card(browser: Browser, testInfo: TestInfo | undefined, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}
const shot = (page: Page, testInfo: TestInfo, title: string, steps: string[], expected: string[], ok = true) =>
  evidence.saveScreenshot(page, testInfo, { ac: AC, title, steps, expected, status: ok ? undefined : "failed" });

/** Remember the FE PUT body of a partner (restore template) after a successful UI save. */
function remember(key: "wlb" | "p2", saved: Awaited<ReturnType<typeof clickOk>>) {
  const s = load();
  if (!s[key]) return;
  s[key]!.restored = false; // something was saved → cleanup must check this partner again
  if (saved.status === 200 && saved.reqBody?.configuration?.hasCorporate) s[key]!.feBody = saved.reqBody;
  save(s);
}
const savedLine = (x: Awaited<ReturnType<typeof clickOk>>) =>
  `PUT /api/partner/v2 → ${x.status} ${x.message}${x.fee ? ` · fee PUT ${x.fee.req} → ${x.fee.status} ${x.fee.message}` : ""}${x.toasts.length ? ` · toast: ${x.toasts.join(" | ")}` : ""}`;

async function restoreAll(browser: Browser, testInfo: TestInfo | undefined) {
  const s = load();
  const todo = (["wlb", "p2"] as const).filter((k) => s[k] && !s[k]!.restored);
  if (!todo.length) return true;
  const { ctx, page } = await adminSession(browser);
  let all = true;
  try {
    const token = await tokenOf(page);
    evidence.setCase("Cleanup — restore partners");
    for (const k of todo) {
      const r = await restorePartner(token, s[k]!);
      s[k]!.restored = r.ok;
      all = all && r.ok;
      save(s);
      await card(browser, testInfo, `Restore — ${s[k]!.name} back to the snapshot`,
        table(["Field", "Snapshot", "Now", "Result"], [...diff(s[k]!.snapshot, r.now.snap).map((x) => [x.k, JSON.stringify(x.a), JSON.stringify(x.b), x.same ? "same" : "DIFF"]), ["Application Fee", s[k]!.fee, r.now.fee, r.now.fee === s[k]!.fee ? "same" : "DIFF"]]) + `<p>${esc(r.notes.join(" · ") || "nothing to restore")}</p>`,
        { ac: AC, title: `Restore ${s[k]!.name} (cleanup)`, steps: r.notes.length ? r.notes : ["Already equal to the snapshot"], expected: ["Equal to the snapshot taken in TC-01"], status: r.ok ? undefined : "failed" });
      console.log(`[ESKIMO-722] restore ${s[k]!.name}: ${r.ok ? "OK (verified)" : "NOT VERIFIED — restore manually!"} ${r.notes.join(" · ")}`);
    }
  } finally {
    await ctx.close();
  }
  return all;
}

/** Storefront pages + partner API while the program should be unavailable. */
async function availability(browser: Browser, testInfo: TestInfo, tc: string, label: string) {
  const poll = await test.step(`Poll /en/plans/${PLAN_PAGES[0]} every 60s without cache (max ${POLL_MS / 60000} min)`, () => pollPlans(browser, (n) => n === 0));
  const rows: unknown[][] = [];
  let selling = 0;
  for (const slug of PLAN_PAGES) {
    const p = await storefrontPage(browser, slug);
    try {
      if (p.plans > 0) selling++;
      // 2026-10-15: BE now answers with the storefront's "This store isn't available" page (HTTP 200)
      const notice = (await p.page.getByText(/store isn.t available/i).first().innerText({ timeout: 5000 }).catch(() => "")).trim();
      rows.push([`/en/plans/${slug}`, p.status, p.plans, notice || "—"]);
      await shot(p.page, testInfo, `${tc} storefront ${slug} (${label})`, [`HTTP ${p.status} (no cache)`, `Page: ${notice ? `"${notice}"` : "normal storefront page"}`, `Data plans shown: ${p.plans}`], ["White Label website not usable"], p.plans === 0);
    } finally {
      await p.ctx.close();
    }
  }
  const token = await test.step("Partner portal login (Partner 2) → partner JWT", () => partnerToken(browser, P2_EMAIL, P2_OTP));
  const mine = await api(token, "GET", "/api/white-label/websites/mine");
  const apiOpen = mine.status === 200 && !!mine.json?.data?.id;
  // QC decision 2026-10-16: expected = the WEBSITE (storefront) is disabled. /websites/mine is a Partner Portal
  // API (partner JWT) → recorded only, not part of the verdict.
  const blocked = selling === 0;
  await card(browser, testInfo, `${tc} — ${label}: website + API`,
    table(["Page", "HTTP", "Plans", "Page message"], rows) + `<p>ESKIMO-831 (recorded, verified indirectly via ESKIMO-722): storefront HTTP status + message above while the program is unavailable. The storefront BE API needs the Worker signature, so the error code itself is not visible to QC.</p><h3>Partner API</h3>${table(["Call (Partner Portal side — recorded only)", "HTTP", "Website returned"], [["GET /api/white-label/websites/mine (partner JWT)", mine.status, mine.json?.data?.id ?? "—"]])}<h3>Cache poll</h3><p>${esc(poll.timeline.join(" · "))}</p>`,
    { ac: AC, title: `${tc} DATA ${label}: website + API`, steps: [`Storefront pages still selling: ${selling}/${PLAN_PAGES.length}`, `Note (Partner Portal API, not in verdict): /websites/mine → ${mine.status} ${mine.json?.data?.id ?? ""}`], expected: ["White Label website (storefront) disabled"], status: blocked ? undefined : "failed" });
  return { selling, apiOpen, mineStatus: mine.status };
}

// ═══════════════════════════════════════════════════════════════════════════════════════════════
// Not serial: a product failure must not skip the remaining checks. Run with --workers=1 (file order).
test.describe(`ESKIMO-722 White Label Corporate Program ${ID}`, () => {
  test.setTimeout(15 * 60 * 1000);

  test.afterEach(async ({}, testInfo) => {
    const s = load();
    s.completed = [...(s.completed ?? []), testInfo.title.slice(0, 5)];
    save(s);
  });
  test.afterAll(async ({ browser }) => {
    if (RESTORE_AT_END || (load().completed ?? []).includes(LAST)) await restoreAll(browser, undefined);
  });

  // ─── AC1 ───────────────────────────────────────────────────────────────────────────────────
  test(`TC-01 White Label fields on Corporate Program ${ID}`, async ({ browser }, testInfo) => {
    if (!KEEP_EVIDENCE) evidence.resetIfFirstAttempt(testInfo);
    expect(await restoreAll(browser, testInfo), "restore of a previous interrupted run").toBe(true);
    evidence.setCase("TC-01 AC1 fields");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      // Snapshot both partners before anything changes
      const s: State = { completed: [] };
      for (const [k, name] of [["wlb", WLB], ["p2", P2]] as const) {
        const p = await findPartner(token, name);
        expect(p, `partner ${name} on staging`).toBeTruthy();
        const r = await readPartner(token, p!);
        s[k] = { ...p!, snapshot: r.snap, setting: r.detail?.configuration?.corporateSetting ?? null, fee: r.fee, restored: false };
      }
      save(s);

      const { drawer } = await openCorporate(page, WLB);
      const f = await readCorporateForm(drawer);
      const body = corporate(drawer).body;
      const checks: [string, string, boolean][] = [
        ["Status", f.status === null ? "missing" : f.status ? "ON" : "OFF", f.status !== null],
        ["Type", f.type, /^white label$/i.test(f.type)],
        ["Start Date", f.start, !!f.start],
        ["End Date", f.end, !!f.end],
        ["Eskimo Email Notification toggle", f.email === null ? "missing" : "present", f.email !== null],
        ["Application Fee", /Application Fee/i.test(f.text) ? "present" : "missing", /Application Fee/i.test(f.text)],
        ["Payment Method", (await formItem(body, "Payment method").count()) ? "present" : "missing", (await formItem(body, "Payment method").count()) > 0],
        ["Data Expiry dropdown", (await formItem(body, "Data Expiry").count()) ? "present" : DATA_EXPIRY_PENDING ? "PENDING — FE re-adding the field (2026-10-16)" : "missing", DATA_EXPIRY_PENDING || (await formItem(body, "Data Expiry").count()) > 0],
        ["Stripe Connect Status", f.stripe || "missing", !!f.stripe],
      ];
      await shot(page, testInfo, "TC-01 Corporate Program form (WLBe2e, Type White label)", [`Admin ${ADMIN_URL} › Partners › ${WLB} › Edit`, ...checks.map(([k, v, ok]) => `${ok ? "✓" : "✗"} ${k}: ${v}`)], ["Status, Type White Label, Start/End Date, Eskimo Email Notification, Application Fee, Payment Method, Data Expiry, Stripe Connect Status"], checks.every((c) => c[2]));
      expect(checks.filter((c) => !c[2]).map((c) => c[0]), "fields missing on the form").toEqual([]);
    } finally {
      await ctx.close();
    }
  });

  // AC1 rev 2026-10-16: "Eskimo Stripe Pay … (hide on phase 1)" → only Direct Charge is offered
  test(`TC-02 Payment Method persists ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-02 AC1 Payment Method");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const { drawer } = await openCorporate(page, WLB);
      const item = formItem(corporate(drawer).body, "Payment method");
      await focus(item);
      const options = await selectOptions(page, item);
      await shot(page, testInfo, "TC-02 Payment Method options", [`Options: ${options.join(" / ") || "none"}`], ["Only Direct Charge (Eskimo Stripe Pay hidden on phase 1)"], JSON.stringify(options) === JSON.stringify(["Direct Charge"]));
      expect(options, "Payment Method options (phase 1)").toEqual(["Direct Charge"]);
      const o = await openCorporate(page, WLB);
      await choose(page, formItem(o.body, "Payment method"), "Direct Charge");
      const saved = await clickOk(page, o.drawer);
      remember("wlb", saved);
      const r = await openCorporate(page, WLB);
      const shown = await selected(formItem(r.body, "Payment method"));
      await focus(formItem(r.body, "Payment method"));
      const apiVal = (await readPartner(token, s.wlb!)).snap.paymentMethod;
      await shot(page, testInfo, "TC-02 Payment Method = Direct Charge after reopen", [`Save: ${savedLine(saved)}`, `Reopened: "${shown}" · API paymentMethod ${apiVal}`], ["Direct Charge saved"], shown === "Direct Charge" && apiVal === 0);
      expect(shown, "Payment Method after reopen").toBe("Direct Charge");
      expect(apiVal, "API paymentMethod (0 = Direct Charge)").toBe(0);
    } finally {
      await ctx.close();
    }
  });

  // AC1 rev 2026-10-16: "No Expiry … (hide on phase 1)". FE build 2026-10-16 11:36 GMT: Data Expiry is a display-only
  // field (dataExpiryDisplay, fixed "2 Years", not sent on save); "No Expiry" is listed but DISABLED.
  // Verdict: only "2 Years" can be selected/shown; a visible-but-disabled "No Expiry" is recorded as a CLARIFY note.
  test(`TC-03 Data Expiry options persist ${ID}`, async ({ browser }, testInfo) => {
    test.skip(DATA_EXPIRY_PENDING, "PENDING: FE removed the Data Expiry field on 2026-10-16 and is adding it back — re-run without E2E_722_DATA_EXPIRY_PENDING");
    evidence.setCase("TC-03 AC1 Data Expiry");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const { drawer } = await openCorporate(page, WLB);
      const item = formItem(corporate(drawer).body, "Data Expiry");
      const present = (await item.count()) > 0;
      expect(present, "Data Expiry dropdown on the Corporate Program form").toBe(true);
      await focus(item);
      const shownBefore = await selected(item);
      await item.locator(".ant-select").first().click();
      const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
      await dd.waitFor({ state: "visible", timeout: 8000 });
      const opts = await dd.locator(".ant-select-item-option").evaluateAll((els) => els.map((e) => ({ text: (e.textContent || "").trim(), disabled: e.classList.contains("ant-select-item-option-disabled") })));
      await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "TC-03 Data Expiry dropdown opened", steps: [`Shown: "${shownBefore}"`, ...opts.map((o) => `Option "${o.text}": ${o.disabled ? "disabled (greyed, not selectable)" : "selectable"}`)], expected: ["Only 2 Years (No Expiry hidden on phase 1)"] });
      await page.keyboard.press("Escape");
      const selectable = opts.filter((o) => !o.disabled).map((o) => o.text);
      const disabledShown = opts.filter((o) => o.disabled).map((o) => o.text);
      // try to pick No Expiry like a user would — must not be possible
      if (disabledShown.includes("No Expiry")) {
        await item.locator(".ant-select").first().click();
        await page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last().locator(".ant-select-item-option").filter({ hasText: /^\s*No Expiry\s*$/ }).first().click({ force: true }).catch(() => {});
        await page.keyboard.press("Escape");
      }
      const afterTry = await selected(item);
      const saved = await clickOk(page, drawer);
      remember("wlb", saved);
      const r = await openCorporate(page, WLB);
      const shown = await selected(formItem(r.body, "Data Expiry"));
      await focus(formItem(r.body, "Data Expiry"));
      const stored = findKeys((await readPartner(token, s.wlb!)).detail?.configuration, /expir/i).join(", ") || "none";
      const ok = JSON.stringify(selectable) === JSON.stringify(["2 Years"]) && afterTry === "2 Years" && shown === "2 Years";
      await card(browser, testInfo, "TC-03 — Data Expiry (phase 1)", table(["Check", "Result"], [
        ["Selectable options", selectable.join(", ") || "none"],
        ["Shown but disabled", disabledShown.join(", ") || "none"],
        ["Value after trying to pick No Expiry", afterTry],
        ["After Ok + reopen", shown],
        ["Save", savedLine(saved)],
        ["GET /api/partner/v2 expiry fields", stored],
        ["Note (CLARIFY)", disabledShown.length ? `AC says "No Expiry (hide on phase 1)"; the form lists it greyed-out / not selectable instead of hiding it` : "No Expiry hidden"],
      ]), { ac: AC, title: "TC-03 DATA Data Expiry phase 1", steps: [`Selectable: ${selectable.join(", ")}`, `Disabled: ${disabledShown.join(", ") || "none"}`, `After reopen: ${shown}`], expected: ["Only 2 Years can be used; 2 Years kept"], status: ok ? undefined : "failed" });
      expect(selectable, "selectable Data Expiry options (phase 1)").toEqual(["2 Years"]);
      expect(afterTry, "No Expiry cannot be picked").toBe("2 Years");
      expect(shown, "Data Expiry after reopen").toBe("2 Years");
    } finally {
      await ctx.close();
    }
  });

  test(`TC-04 Stripe Connect status labels ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-04 AC1 Stripe Connect");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      // (a) a White Label partner that never connected Stripe (read only). QC decision 2026-10-19 (same as ESKIMO-383):
      // such a partner has no Stripe record yet → the form shows "—" + the "connects Stripe from the Partner portal"
      // hint; that is accepted as "not connected" (a missing "Not Connected" default label is noted, not failed).
      const NOT_CONNECTED_CODE = process.env.E2E_WL_NOT_CONNECTED_PARTNER || "PN105327";
      const nc = await api(token, "POST", "/api/partner/search", { pageIndex: 1, pageSize: 20, searchText: NOT_CONNECTED_CODE, status: null, partnerType: null, type: null, sortBy: { fieldName: "CreatedOn", ascending: false } });
      const ncRow = (nc.json?.data?.data ?? []).find((x: any) => (x.partnerID ?? x.partnerId) === NOT_CONNECTED_CODE);
      const notConnected: string | null = ncRow?.partnerName ?? null;
      console.log(`[TC-04] not-connected partner ${NOT_CONNECTED_CODE} → ${notConnected ?? "not found"}`);
      const res: unknown[][] = [];
      let okA = false;
      if (notConnected) {
        const a = await openCorporate(page, notConnected);
        const tag = (await readCorporateForm(a.drawer)).stripe;
        const hint = /connects Stripe from the Partner portal/i.test(await formItem(a.body, "Stripe Connect Status").innerText().catch(() => ""));
        okA = /^not connected$/i.test(tag) || (/^[—-]$/.test(tag) && hint);
        await focus(formItem(a.body, "Stripe Connect Status"));
        res.push([`${notConnected} (${NOT_CONNECTED_CODE}, never connected Stripe)`, tag, 'Not Connected (or "—" + hint: no Stripe record yet)', okA ? (/^not connected$/i.test(tag) ? "PASS" : "PASS — note: shows \"—\", default label \"Not Connected\" missing") : "FAIL"]);
        await shot(page, testInfo, `TC-04 Stripe Connect — ${notConnected} (not connected)`, ["View only, no Save", `Shown: "${tag}"${hint ? " + hint \"The partner connects Stripe from the Partner portal (My Website).\"" : ""}`], ['"Not Connected"'], okA);
      }
      const b = await openCorporate(page, P2);
      const p2 = await readPartner(token, load().p2!);
      const tagB = (await readCorporateForm(b.drawer)).stripe;
      await focus(formItem(b.body, "Stripe Connect Status"));
      const okB = /^verified$/i.test(tagB);
      res.push([`${P2} (Stripe verified: chargesEnabled ${p2.stripe?.chargesEnabled}, detailsSubmitted ${p2.stripe?.detailsSubmitted})`, tagB, "Verified", okB ? "PASS" : "FAIL"]);
      await shot(page, testInfo, `TC-04 Stripe Connect — ${P2} (verified)`, ["View only, no Save", `Shown: "${tagB}"`], ['"Verified"'], okB);
      await card(browser, testInfo, "TC-04 — Stripe Connect status", table(["Partner", "Shown", "Expected (AC1)", "Result"], res), { ac: AC, title: "TC-04 DATA Stripe Connect labels", steps: res.map((r) => `${r[0]}: "${r[1]}"`), expected: ["Not connected → Not Connected", "Verified → Verified"], status: okA && okB ? undefined : "failed" });
      expect(notConnected, `partner ${NOT_CONNECTED_CODE} on staging`).toBeTruthy();
      expect(res.filter((r) => !String(r[3]).startsWith("PASS")).map((r) => `${r[0]} shows "${r[1]}", expected "${r[2]}"`)).toEqual([]);
    } finally {
      await ctx.close();
    }
  });

  test(`TC-05 No Network Partner Commission ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-05 AC1 NPC");
    const { ctx, page } = await adminSession(browser);
    try {
      const { drawer } = await openCorporate(page, WLB);
      const shown = /Network Partner Commission/i.test((await readCorporateForm(drawer)).text);
      await shot(page, testInfo, "TC-05 Network Partner Commission (%) on a White Label program", [`Network Partner Commission (%) shown: ${shown}`], ["Not applied / not shown for White Label"], !shown);
      expect(shown, "Network Partner Commission (%) shown").toBe(false);
    } finally {
      await ctx.close();
    }
  });

  // ─── AC2 ───────────────────────────────────────────────────────────────────────────────────
  test(`TC-06 Email toggle default False ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-06 AC2 default");
    const { ctx, page } = await adminSession(browser);
    const writes: string[] = [];
    page.on("request", (r) => { if (/\/api\/partner\/v2/.test(r.url()) && ["POST", "PUT"].includes(r.method())) writes.push(`${r.method()} ${r.url()}`); });
    try {
      await page.goto(`${ADMIN_URL}/#/partnership-partners`, { waitUntil: "domcontentloaded" });
      await page.getByRole("button", { name: "New Partner" }).click();
      const drawer = page.locator(".ant-drawer-content:visible").first();
      await drawer.waitFor({ state: "visible", timeout: 30000 });
      const c = corporate(drawer);
      await c.header.scrollIntoViewIfNeeded();
      await c.statusSwitch.click();
      await choose(page, formItem(c.body, "Type"), "White label");
      const sw = formItem(c.body, "Eskimo Email Notification").locator(".ant-switch").first();
      const on = await isOn(sw);
      await focus(formItem(c.body, "Type"));
      await shot(page, testInfo, "TC-06 New Partner: Type White label → Eskimo Email Notification default", ["Partners › New Partner (not saved)", "Corporate Program ON, Type White label", `Eskimo Email Notification: ${on ? "ON (True)" : "OFF (False)"}`], ["Default False"], !on);
      await drawer.locator(".ant-drawer-close").first().click().catch(() => page.keyboard.press("Escape"));
      expect(writes, "nothing saved").toEqual([]);
      expect(on, "default value").toBe(false);
    } finally {
      await ctx.close();
    }
  });

  test(`TC-07 Email toggle persists ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-07 AC2 persist");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const bad: string[] = [];
      for (const want of [true, false]) {
        const o = await openCorporate(page, WLB);
        const sw = formItem(o.body, "Eskimo Email Notification").locator(".ant-switch").first();
        if ((await isOn(sw)) !== want) await sw.click();
        const saved = await clickOk(page, o.drawer);
        remember("wlb", saved);
        const r = await openCorporate(page, WLB);
        const shown = await isOn(formItem(r.body, "Eskimo Email Notification").locator(".ant-switch").first());
        await focus(formItem(r.body, "Eskimo Email Notification"));
        const apiVal = (await readPartner(token, s.wlb!)).snap.isEskimoEmailNotificationEnabled;
        const ok = shown === want && apiVal === want;
        if (!ok) bad.push(`${want}: UI ${shown}, API ${apiVal}`);
        await shot(page, testInfo, `TC-07 Eskimo Email Notification = ${want ? "True" : "False"} after reopen`, [`Save: ${savedLine(saved)}`, `Reopened: ${shown ? "ON" : "OFF"} · API ${apiVal}`], [`${want} saved`], ok);
      }
      expect(bad).toEqual([]);
    } finally {
      await ctx.close();
    }
  });

  test(`TC-08 Mails per toggle (recorded evidence 2026-10-09) ${ID}`, async () => {
    test.skip(true, "Recorded, not re-run (no new purchase): EP-5991 business report 2026-10-09 — True: purchase mail received, QR mail not within 6 min (WARNING); False: no Eskimo mail (PASS)");
  });

  // ─── AC3 ───────────────────────────────────────────────────────────────────────────────────
  test(`TC-09 Application Fee section ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-09 AC3 section");
    const { ctx, page } = await adminSession(browser);
    try {
      const { drawer } = await openCorporate(page, WLB);
      const t = (await readCorporateForm(drawer)).text;
      const ok = /Application Fee Percentage/i.test(t);
      await shot(page, testInfo, "TC-09 Application Fee Percentage section (Type White label)", [`"Application Fee Percentage" shown: ${ok}`, `"Discount Benefit" shown: ${/Discount Benefit/i.test(t)}`], ["Application Fee Percentage section displayed"], ok);
      expect(ok, '"Application Fee Percentage" section').toBe(true);
    } finally {
      await ctx.close();
    }
  });

  test(`TC-10 Application Fee saved and applied ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-10 AC3 fee");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const o = await openCorporate(page, WLB);
      const fee = o.body.locator("input#defaultPercentCorporate");
      await fee.fill("90");
      await focus(fee);
      await shot(page, testInfo, "TC-10 Application Fee Percentage = 90 before Ok", ["Fee 90"], ["Saved"]);
      const saved = await clickOk(page, o.drawer);
      remember("wlb", saved);
      const now = await readPartner(token, s.wlb!);
      const r = await openCorporate(page, WLB);
      const shown = await r.body.locator("input#defaultPercentCorporate").inputValue();
      await focus(r.body.locator("input#defaultPercentCorporate"));
      const ok = now.fee === 90 && shown === "90";
      await shot(page, testInfo, "TC-10 Reopened: Application Fee", [`Save: ${savedLine(saved)}`, `Reopened fee: "${shown}"`, `Effective fee (stripeConnect.platformFeePercent): ${now.fee}`], ["90% saved and effective"], ok);
      const rows = [100, 4.5, 12.99].map((p) => [`USD ${p}`, `USD ${(Math.round(p * 90) / 100).toFixed(2)}`, `USD ${(Math.round(p * 10) / 100).toFixed(2)}`]);
      await card(browser, testInfo, "TC-10 — Application Fee formula (90%)", table(["Original Data Plan Price", "Eskimo Application Fee (× 90%)", "Partner Benefit (× 10%)"], rows) + `<p>Effective fee read from GET /api/white-label/websites/{id} → stripeConnect.platformFeePercent = ${esc(now.fee)}. Fee on real sales: evidence 2026-10-09 (TC-11).</p>`,
        { ac: AC, title: "TC-10 DATA fee applied (formula)", steps: ["Application Fee = price × 90%", "Partner Benefit = price × 10%"], expected: ["USD 100 → 90 / 10"], status: ok ? undefined : "failed" });
      expect(now.fee, "effective fee").toBe(90);
      expect(shown, "fee shown after reopen").toBe("90");
    } finally {
      await ctx.close();
    }
  });

  test(`TC-11 Fee on real sales (recorded evidence 2026-10-09) ${ID}`, async () => {
    test.skip(true, "Recorded, not re-run (no new purchase): EP-5991 business report 2026-10-09 B3 — fee 10% → WHI 0.39 on US$3.90, fee 20% → WHI 0.78 on US$3.90 (PASS)");
  });

  // ─── Sub-task ESKIMO-818 (recorded only, read-only) ───
  test(`SUB-818 Test/Staging flag visible to admin (recorded) ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("SUB-818 Test/Staging flag (recorded)");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      const list = await websites(token);
      const rows = list.map((w) => [w.id, w.partnerId, w.name ?? w.domain ?? "", findKeys(w, /mode|test|stag|live|status|active/i).join(" · ") || "—"]);
      const p2 = await findPartner(token, P2);
      const site = list.find((w) => w.partnerId === p2?.code);
      const det = site ? await api(token, "GET", `/api/white-label/websites/${site.id}`) : null;
      const detKeys = det ? findKeys(det.json?.data, /mode|test|stag|live|status|active/i) : [];
      await page.goto(`${ADMIN_URL}/#/white-label-templates`);
      await page.waitForLoadState("networkidle").catch(() => {});
      const uiText = await page.locator("body").innerText({ timeout: 10000 }).catch(() => "");
      const uiFlag = (uiText.match(/\b(test mode|staging|test|live)\b/gi) ?? []).slice(0, 10);
      await shot(page, testInfo, "SUB-818 Admin › White Label templates/websites page", [`Words test/staging/live on the page: ${uiFlag.join(", ") || "none"}`], ["Recorded only — verified indirectly via ESKIMO-722"]);
      await card(browser, testInfo, "SUB-818 — website mode fields (admin API, recorded)",
        table(["Website", "Partner", "Name", "Mode/status fields"], rows) + `<h3>${esc(P2)} website detail</h3><p>${esc(detKeys.join(" · ") || "no mode/test/staging field")}</p>`,
        { ac: "ESKIMO-818", title: "SUB-818 DATA website Test/Staging flag (recorded)", steps: ["GET /api/white-label/websites", `GET /api/white-label/websites/${site?.id ?? "?"}`], expected: ["Recorded only — no verdict"] });
    } finally {
      await ctx.close();
    }
  });

  // ─── AC4 (Partner 2) ───────────────────────────────────────────────────────────────────────
  test(`TC-12 Disabled blocks website and API ${ID}`, async ({ browser }, testInfo) => {
    test.setTimeout(POLL_MS + 15 * 60 * 1000);
    evidence.setCase("TC-12 AC4 Disabled");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const o = await openCorporate(page, P2);
      const before = await readCorporateForm(o.drawer);
      await o.statusSwitch.click();
      const warn = page.locator(".modal-dialog:visible").filter({ hasText: "Warning" }).getByRole("button", { name: "Confirm" });
      if (await warn.isVisible({ timeout: 4000 }).catch(() => false)) await warn.click();
      await shot(page, testInfo, `TC-12 ${P2}: Status OFF before Ok`, [`Before: Start ${before.start}, End ${before.end}, Fee ${before.fee}, Email ${before.email ? "ON" : "OFF"}, Payment ${before.payment || "Not set"}`, "Status → OFF"], ["Program Disabled"]);
      const saved = await clickOk(page, o.drawer);
      remember("p2", saved);
      const off = await readPartner(token, s.p2!);
      expect(off.snap.hasCorporate, `Disabled saved: ${savedLine(saved)}`).toBe(false);
      const a = await availability(browser, testInfo, "TC-12", "Status Disabled");
      expect(a.selling, "storefront pages still selling").toBe(0);
    } finally {
      await ctx.close();
    }
  });

  test(`TC-15 Re-enable keeps configuration ${ID}`, async ({ browser }, testInfo) => {
    test.setTimeout(POLL_MS + 15 * 60 * 1000);
    evidence.setCase("TC-15 AC4 re-enable");
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      const o = await openCorporate(page, P2);
      if (!(await isOn(o.statusSwitch))) await o.statusSwitch.click();
      const pre = await readCorporateForm(o.drawer);
      await shot(page, testInfo, `TC-15 ${P2}: Status ON again, nothing re-entered`, [`Prefilled: Type ${pre.type}, Start ${pre.start}, End ${pre.end}, Fee ${pre.fee || "(empty)"}, Email ${pre.email ? "ON" : "OFF"}, Payment ${pre.payment || "Not set"}, Limit ${pre.limit}`], ["Previous configuration already there"]);
      const saved = await clickOk(page, o.drawer);
      remember("p2", saved);
      const r = await openCorporate(page, P2);
      const f = await readCorporateForm(r.drawer);
      const now = await readPartner(token, s.p2!);
      const d = diff(s.p2!.snapshot, now.snap);
      const same = d.every((x) => x.same) && now.fee === s.p2!.fee;
      await shot(page, testInfo, `TC-15 ${P2}: reopened after re-enable`, [`Status ${f.status ? "ON" : "OFF"}, Start ${f.start}, End ${f.end}, Fee ${f.fee}, Email ${f.email ? "ON" : "OFF"}, Payment ${f.payment || "Not set"}, Limit ${f.limit}`], ["Every setting as before"], same && !!f.status);
      const back = await pollPlans(browser, (n) => n > 0);
      await card(browser, testInfo, "TC-15 — configuration before Disable vs after re-enable",
        table(["Field", "Before", "After", "Result"], [...d.map((x) => [x.k, JSON.stringify(x.a), JSON.stringify(x.b), x.same ? "same" : "CHANGED"]), ["Application Fee", s.p2!.fee, now.fee, now.fee === s.p2!.fee ? "same" : "CHANGED"], ["Save", "", savedLine(saved), ""], ["Storefront plans back", "", back.reached === null ? "NOT back" : `after ${back.reached}s`, back.reached === null ? "FAIL" : "PASS"]]),
        { ac: AC, title: "TC-15 DATA configuration retained after re-enable", steps: ["GET /api/partner/v2/{id}", "GET website stripeConnect", "Storefront poll"], expected: ["Start/End Date, fee and other settings retained, no re-configuration"], status: same && back.reached !== null ? undefined : "failed" });
      expect(d.filter((x) => !x.same).map((x) => `${x.k}: ${JSON.stringify(x.a)} → ${JSON.stringify(x.b)}`), "settings changed").toEqual([]);
      expect(now.fee, "Application Fee").toBe(s.p2!.fee);
      expect(back.reached, "storefront usable again").not.toBeNull();
    } finally {
      await ctx.close();
    }
  });

  /** Date cases: Start/End set through the API (Start picker locks once started, End picker blocks past dates). */
  async function dateCase(browser: Browser, testInfo: TestInfo, tc: string, label: string, dates: (setting: any) => any) {
    const { ctx, page } = await adminSession(browser);
    try {
      const token = await tokenOf(page);
      const s = load();
      expect(s.p2?.feBody, "FE body of Partner 2 (from TC-15)").toBeTruthy();
      const setting = { ...s.p2!.setting, ...dates(s.p2!.setting) };
      s.p2!.restored = false;
      save(s);
      const put = await api(token, "PUT", "/api/partner/v2", corporateBody(s.p2!.feBody, true, setting), 2);
      const mid = await readPartner(token, s.p2!);
      const o = await openCorporate(page, P2);
      const f = await readCorporateForm(o.drawer);
      await shot(page, testInfo, `${tc} ${P2}: ${label}`, [`PUT /api/partner/v2 (dates only) → ${put.status} ${apiMessage(put.json)}`, `Form: Start ${f.start}, End ${f.end}`, `API: ${mid.snap.corporateStartDate} → ${mid.snap.corporateEndDate}`], [label]);
      const a = await availability(browser, testInfo, tc, label);
      // put the original dates back, check nothing else moved
      const back = await api(token, "PUT", "/api/partner/v2", corporateBody(s.p2!.feBody, true, s.p2!.setting), 2);
      const now = await readPartner(token, s.p2!);
      const d = diff(s.p2!.snapshot, now.snap);
      await card(browser, testInfo, `${tc} — original dates restored`, table(["Field", "Snapshot", "Now", "Result"], [...d.map((x) => [x.k, JSON.stringify(x.a), JSON.stringify(x.b), x.same ? "same" : "CHANGED"]), ["PUT back", "", `${back.status} ${apiMessage(back.json)}`, ""]]), { ac: AC, title: `${tc} DATA dates restored`, steps: ["PUT original Start/End"], expected: ["Configuration equal to the snapshot"], status: d.every((x) => x.same) ? undefined : "failed" });
      const plansBack = await pollPlans(browser, (n) => n > 0);
      expect(a.selling, "storefront pages still selling").toBe(0);
      expect(plansBack.reached, "storefront usable again after restoring the dates").not.toBeNull();
    } finally {
      await ctx.close();
    }
  }
  const ymd = (offset: number) => { const d = new Date(); d.setDate(d.getDate() + offset); return d.toISOString().slice(0, 10); };

  test(`TC-13 Before Start Date blocks ${ID}`, async ({ browser }, testInfo) => {
    test.setTimeout(2 * POLL_MS + 15 * 60 * 1000);
    evidence.setCase("TC-13 AC4 before Start");
    await dateCase(browser, testInfo, "TC-13", `Start Date = ${ymd(1)} (tomorrow)`, () => ({ corporateStartDate: `${ymd(1)}T00:00:00` }));
  });

  test(`TC-14 After End Date blocks ${ID}`, async ({ browser }, testInfo) => {
    test.setTimeout(2 * POLL_MS + 15 * 60 * 1000);
    evidence.setCase("TC-14 AC4 after End");
    await dateCase(browser, testInfo, "TC-14", `End Date = ${ymd(-1)} (yesterday)`, () => ({ corporateStartDate: `${ymd(-10)}T00:00:00`, corporateEndDate: `${ymd(-1)}T23:59:59` }));
  });
});
