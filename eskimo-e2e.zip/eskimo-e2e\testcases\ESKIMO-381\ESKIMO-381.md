# ESKIMO-381 – [EP-6053] WellAtSea My Data: badge trạng thái plan hiện "Unknown"

Môi trường: STG — storefront https://wellatsea.eskimo.travel/en (BE stage, partner PN101609), Admin = E2E_ADMIN_URL
Khách test: E2E_WL_CUSTOMER_EMAIL (testwhitelabel168@yopmail.com — có nhiều plan đã mua)
Vào My Data bằng magic link của khách (E2E_WL_MAGIC_LINK) — thay cho email + OTP (OTP qua yopmail có captcha → TC-04 manual)

Expected đã chốt (QC + BA, 2026-10-14):
- Bug là badge hiện chữ "Unknown". Fix = KHÔNG còn "Unknown".
- Hành vi mong muốn giống eskimo.travel/en/data-balance: card plan chỉ hiện badge LOẠI PLAN
  (vd. "Unlimited 2 days"); plan GP cố định (5GB/10GB/1GB) KHÔNG có badge. KHÔNG hiện badge trạng thái.
- Chỉ đọc: không mua, không gửi OTP.

## TC-01 Không card nào hiện "Unknown" / placeholder
- Steps:
  1. Mở magic link → /en/data-balance (đã đăng nhập, đúng email khách)
  2. Đọc badge trên từng card ở tab My Plans
- Expected: Không có "Unknown", không có text rỗng/`null`/`undefined`/mã kỹ thuật trên bất kỳ card nào

## TC-02 Chỉ hiện badge loại plan, không hiện trạng thái (giống eskimo.travel)
- Steps: Đọc badge trên từng card
- Expected:
  - Plan Unlimited hiện badge "Unlimited <N> days"
  - Plan GB cố định không có badge
  - Không card nào hiện badge trạng thái (active/inactive/not activated/in use/…)

## TC-03 Đối chiếu Admin Data Wallet (ghi nhận)
- Steps: Admin → Membership → Search by Email → View Detail → Data Wallet: đọc status từng plan; đối chiếu badge storefront
- Expected: Ghi nhận bảng plan ↔ badge ↔ Admin status (ghi nhận, không pass/fail)

## TC-04 Login My Data bằng email + OTP (manual)
- Steps: /en/data-balance → nhập email → Send code → nhập OTP từ mail → View my data → xem badge
- Expected: như TC-01/02
- Manual: OTP qua yopmail (Cloudflare captcha)

## TC-05 Mua plan mới rồi kiểm badge (manual)
- Steps: Mua 1 plan → My Data
- Expected: card mới không hiện "Unknown"; badge đúng loại plan
- Manual: tạo đơn mới; không chạy trong lần auto này
