# ESKIMO-2 – [EP-6036] Update promo code configuration

Môi trường: STG Admin (E2E_ADMIN_URL, login E2E_ADMIN_EMAIL)
Trang: Admin → Promo Codes (`#/promo-codes`) → drawer New/Edit Promo Code → phần "Promo Configuration"
Test data: mỗi lần chạy tạo 1 promo code mới `E2EESK2<timestamp>` (Percentage 10%, Max Redemption 1), chạy xong thì Delete.

Acceptance criteria:
- AC1 – Thêm field upload **Custom Image** cho Promo Code configure. Validation giống field **Custom Icon Image**.
- AC2 – Cho phép xoá ảnh đã upload ở cả **Custom Icon Image** và **Custom Image**.

Ảnh test (sinh trong test, không cần file):
- PNG vuông 64×64, JPEG vuông 64×64 → hợp lệ
- PNG 100×50 (không vuông), file 2.1MB (image/png), GIF 1×1 → không hợp lệ

## TC-01 Field "Custom Image" hiển thị trong Promo Configuration (AC1)
- Steps:
  1. Admin → Promo Codes → bấm "New Promo Code"
  2. Xem phần Promo Configuration
  3. Mở Edit một promo code có sẵn (promo test)
- Expected: Có field "Custom Image" nằm ngay sau "Custom Icon Image", có nút upload và ô placeholder "1:1" như Custom Icon Image (cả drawer New và Edit).

## TC-02 Upload PNG vuông hợp lệ vào Custom Image (AC1)
- Steps: Drawer Edit promo test → Custom Image → upload PNG 64×64
- Expected: Hiện ảnh preview, có nút "Remove", không có lỗi.

## TC-03 Upload JPEG vuông hợp lệ vào Custom Image (AC1)
- Steps: Drawer Edit promo test → Custom Image → upload JPEG 64×64
- Expected: Hiện ảnh preview, không có lỗi.

## TC-04 Ảnh không vuông bị chặn – giống Custom Icon Image (AC1)
- Steps: Upload PNG 100×50 vào Custom Icon Image, rồi vào Custom Image
- Expected: Cả hai field báo lỗi tỉ lệ 1:1 (cùng nội dung, chỉ khác chữ Icon/Image), ảnh không được nhận (không có preview).

## TC-05 File >= 2MB bị chặn – giống Custom Icon Image (AC1)
- Steps: Upload file 2.1MB vào Custom Icon Image, rồi vào Custom Image
- Expected: Cả hai field báo lỗi giới hạn 2MB, cùng nội dung; ảnh không được nhận.

## TC-06 Sai định dạng (GIF) bị chặn – giống Custom Icon Image (AC1)
- Steps: Upload GIF vào Custom Icon Image, rồi vào Custom Image
- Expected: Cả hai field báo lỗi chỉ nhận JPG, JPEG, PNG, cùng nội dung; ảnh không được nhận.

## TC-07 Lưu promo với Custom Icon + Custom Image (AC1)
- Steps:
  1. Edit promo test → upload PNG vuông vào Custom Icon Image và Custom Image
  2. Save → "UPDATE SUCCESS"
  3. Mở lại Edit
- Expected: Cả hai field hiển thị ảnh đã lưu; API detail trả về customIcon và customImage khác rỗng.

## TC-08 Xoá Custom Image (AC2)
- Preconditions: TC-07 (promo có cả 2 ảnh)
- Steps: Edit → Custom Image → "Remove" → Save → mở lại Edit
- Expected: Custom Image trống (placeholder 1:1), Custom Icon Image vẫn còn ảnh. API detail: customImage rỗng, customIcon còn.

## TC-09 Xoá Custom Icon Image (AC2)
- Preconditions: TC-08 (promo còn Custom Icon)
- Steps: Edit → Custom Icon Image → "Remove" → Save → mở lại Edit
- Expected: Custom Icon Image trống (placeholder 1:1). API detail: customIcon rỗng.

## TC-10 Remove rồi Cancel thì không mất ảnh (AC2)
- Preconditions: promo có Custom Image (test tự upload + Save trước)
- Steps: Edit → Custom Image → "Remove" → Cancel (đóng drawer, không Save) → mở lại Edit
- Expected: Custom Image vẫn còn ảnh.

## TC-11 (manual) Custom Image hiển thị phía người dùng
- Ticket không nói Custom Image hiển thị ở đâu (app/website) → chưa cover, cần BA/PO xác nhận.
