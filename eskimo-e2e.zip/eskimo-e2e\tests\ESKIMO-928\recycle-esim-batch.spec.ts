// ESKIMO-928 – Refactor recycle eSIM flow (eSIM Status API), BE EA-4408.
// Admin › eSIM › eSIM Codes › eSim Recycle. AC1:
//   "New recycle esim batch" → amount (> 0 and < 1000) → Confirm → batch Checking (new) → Pending when the
//   check is done → Confirm → Confirming (new). Confirm/Cancel disabled at Checking/Confirming.
//   The check uses the eSIM Status API: only eSIMs with status RELEASED may be put in the batch.
//   TC-01 button opens the "New Recycle eSIM Batch" popup                         (read-only)
//   TC-02 invalid amounts (0, -1, 1000, 1001, 1.5, abc, empty) are blocked, nothing created  (read-only)
//   TC-03 boundary 999 accepted by the form (popup cancelled, not submitted)       (read-only)
//   TC-04 amount 1 → CREATE SUCCESS → new batch Checking, Confirm/Cancel disabled   (creates 1 batch)
//   TC-05 Status filter has Checking/Confirming; Checking filter lists the batch
//   TC-06 check done → batch Pending (Confirm/Delete/Export enabled)
//   TC-07 eSIMs put in the batch: recorded only (PENDING). RELEASED is the profile status `resourceStatus` of
//         Singtel FetchEsimDetails (by ICCID); no portal endpoint returns it. GET /api/Esims/esim-status returns
//         the service status (Active/Suspend), so it is shown for reference, not judged. Waiting for BE (EA-4408).
//   TC-08 batch holds the requested amount (totalEsim = 1)
//   TC-09 Confirm on Pending → Confirming (buttons disabled) → Confirmed
// Cleanup (last test, not a TC): the test batch is cancelled (Confirmed) or deleted (Pending).
// WARNING: TC-09 Confirm really recycles the eSIM (cancels the previous user's plans at Singtel, removes it from the
// user). Cancel does NOT give it back (eSIM becomes Reverted / WaitingToRecycle). Every run creates and confirms 1 batch.
// Evidence: evidence/ESKIMO-928-recycle-esim-batch → npm run report:evidence -- ESKIMO-928 recycle-esim-batch
import fs from "node:fs";
import { test, expect, type Browser, type BrowserContext, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import { API_URL, adminToken } from "../_support/wellatsea";

const ID = "@ESKIMO-928";
const AC = "ESKIMO-928 AC1";
const evidence = createEvidence("ESKIMO-928", "recycle-esim-batch");
const PAGE_URL = `${ADMIN_URL}/#/esim-codes`;
const STATUS: Record<number, string> = { 1: "Pending", 2: "Confirmed", 3: "Cancelled", 4: "Checking", 5: "Confirming" };
const INV_STATUS: Record<number, string> = { 0: "Available", 1: "Unavailable", 2: "Provisioning", 3: "Assigned", 4: "Error", 7: "Suspended", 9: "Pre-Assigned", 10: "Waiting To Suspend", 11: "Waiting To Active", 12: "Pre-Active", 15: "Provision", 16: "Waiting To Recycle" };

let ctx: BrowserContext;
let page: Page;
// A failing test restarts the worker (module state lost): the batch under test is kept in a file.
const STATE = "test-results/ESKIMO-928-state.json";
type Counts = { available: number; waiting: number; availableCodes: number | null };
let batchId = "";
let createdAt = 0;
let amount = 0;
let before: Counts | null = null;
const saveState = () => { fs.mkdirSync("test-results", { recursive: true }); fs.writeFileSync(STATE, JSON.stringify({ batchId, createdAt, amount, before })); };
const loadState = () => { try { ({ batchId, createdAt, amount, before } = JSON.parse(fs.readFileSync(STATE, "utf8"))); } catch { /* none yet */ } };

// ─── API (same endpoints the page calls) ───
async function api(method: string, path: string, body?: unknown) {
  const token = await adminToken(page);
  const r = await fetch(`${API_URL}${path}`, {
    method, signal: AbortSignal.timeout(60000),
    headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: `Bearer ${token}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any = null;
  try { json = JSON.parse(text); } catch { /* not JSON */ }
  return { status: r.status, json, text };
}
type Batch = { batchID: string; status: number; totalEsim: number | null; assign: number | null; createdTime: string; batchName?: string };
async function listBatches(size = 20): Promise<Batch[]> {
  const r = await api("POST", "/api/inventories/search-batch-recycle-inventory", { pageIndex: 1, pageSize: size, searchText: "", batchStatus: null, sortBy: { fieldName: "CreatedTime", ascending: false } });
  return r.json?.data?.data?.data ?? [];
}
const getBatch = async (id: string) => (await listBatches(30)).find((b) => b.batchID === id);
/** eSIM Codes search (same call as the eSIM Codes table): status null = all. */
async function searchInventory(status: number | null, searchText = "") {
  const r = await api("POST", "/api/inventories/search", { pageIndex: 1, pageSize: 50, searchText, status, partnerIds: [], fromDate: null, importFile: null, toDate: null });
  const d = r.json?.data?.data;
  return { total: Number(d?.numOfRecords ?? 0), availableCodes: d?.availableCodes ?? null, rows: (d?.data ?? []) as any[] };
}
async function stockCounts(): Promise<Counts> {
  const a = await searchInventory(0);
  const w = await searchInventory(16);
  return { available: a.total, waiting: w.total, availableCodes: a.availableCodes };
}
async function waitStatus(id: string, want: number[], timeoutMs: number, seen: string[] = []) {
  const end = Date.now() + timeoutMs;
  let b: Batch | undefined;
  while (Date.now() < end) {
    b = await getBatch(id);
    const s = b ? STATUS[b.status] ?? String(b.status) : "not found";
    if (seen[seen.length - 1] !== s) seen.push(s);
    if (b && want.includes(b.status)) return b;
    await new Promise((r) => setTimeout(r, 1000));
  }
  return b;
}

// ─── UI helpers ───
const spinnerGone = () => page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
const recycleTable = () => page.locator(".ant-table").first();
const popup = () => page.getByRole("dialog").filter({ hasText: "New Recycle eSIM Batch" });
const amountBox = () => popup().getByPlaceholder("insert number");
const formError = () => popup().locator(".ant-form-item-explain-error");
const mark = (loc: ReturnType<Page["locator"]>) => loc.first().evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", outlineOffset: "2px" })).catch(() => {});

async function openRecycle() {
  await page.goto(PAGE_URL, { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
  await recycleTable().waitFor({ state: "visible", timeout: 60000 });
  await page.locator(".ant-table-tbody").first().locator("tr.ant-table-row").first().waitFor({ state: "visible", timeout: 60000 }).catch(() => {});
  await spinnerGone();
}
async function openPopup() {
  await page.getByRole("button", { name: "New recycle esim batch" }).click();
  await popup().waitFor({ state: "visible", timeout: 15000 });
}
async function closePopup() {
  if (await popup().isVisible().catch(() => false)) {
    await popup().getByRole("button", { name: "Cancel" }).click();
    await popup().waitFor({ state: "hidden", timeout: 10000 }).catch(() => {});
  }
}
/** Status + action buttons of one batch row on the recycle table (page 1). */
async function readRow(id: string) {
  const row = page.locator(".ant-table-tbody").first().locator("tr.ant-table-row").filter({ hasText: id }).first();
  if (!(await row.isVisible().catch(() => false))) return { row, found: false, status: "", buttons: [] as { name: string; disabled: boolean }[] };
  await row.scrollIntoViewIfNeeded().catch(() => {});
  const status = (await row.locator("td").nth(4).innerText()).trim();
  const buttons = await row.locator("button").evaluateAll((bs) => bs.map((b) => ({ name: (b.textContent || "").trim(), disabled: (b as HTMLButtonElement).disabled })));
  await mark(row);
  return { row, found: true, status, buttons };
}
const btnText = (bs: { name: string; disabled: boolean }[]) => bs.map((b) => `${b.name}${b.disabled ? " (disabled)" : ""}`).join(", ") || "none";
const btn = (bs: { name: string; disabled: boolean }[], n: string) => bs.find((b) => b.name === n);

async function card(browser: Browser, testInfo: TestInfo | undefined, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const c = await browser.newContext();
  try { await evidence.saveDataCard(await c.newPage(), testInfo, heading, html, meta); } finally { await c.close(); }
}

test.describe(`ESKIMO-928 eSIM recycle batch flow ${ID}`, () => {
  // Not serial (a product failure must not skip later cases); run with --workers=1 so cases keep their order.
  test.describe.configure({ timeout: 180_000 });
  test.beforeAll(async ({ browser }) => { loadState(); ({ ctx, page } = await adminSession(browser)); });
  test.afterAll(async () => { await ctx?.close(); });

  test(`TC-01 New recycle esim batch opens the popup ${ID}`, async ({}, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    batchId = ""; createdAt = 0; saveState();
    evidence.setCase("TC-01 New recycle esim batch popup");
    await openRecycle();
    await openPopup();
    const hasField = await amountBox().isVisible();
    const hasButtons = (await popup().getByRole("button", { name: "Confirm" }).isVisible()) && (await popup().getByRole("button", { name: "Cancel" }).isVisible());
    await mark(popup());
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: "TC-01 Popup New Recycle eSIM Batch",
      steps: ["Admin › eSIM › eSIM Codes › eSim Recycle", 'Click "New recycle esim batch"', `Amount of eSIM field: ${hasField ? "shown" : "missing"}`, `Confirm / Cancel: ${hasButtons ? "shown" : "missing"}`],
      expected: ["Popup lets the admin insert the amount of requested eSIM", "Confirm and Cancel buttons"],
      status: hasField && hasButtons ? undefined : "failed",
    });
    expect(hasField, "Amount of eSIM field").toBe(true);
    expect(hasButtons, "Confirm/Cancel in popup").toBe(true);
    await closePopup();
  });

  test(`TC-02 Invalid amounts are blocked and create nothing ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-02 Invalid amount validation");
    await openRecycle();
    let createCalls = 0;
    const onReq = (r: any) => { if (r.url().includes("/api/inventories/search-recycle-inventory") && r.method() === "POST") createCalls++; };
    page.on("request", onReq);
    const rows: { value: string; error: string; open: boolean; calls: number }[] = [];
    for (const value of ["0", "-1", "1000", "1001", "1.5", "abc", ""]) {
      await openPopup();
      await amountBox().fill(value);
      const before = createCalls;
      await popup().getByRole("button", { name: "Confirm" }).click();
      await formError().first().waitFor({ state: "visible", timeout: 5000 }).catch(() => {});
      await page.waitForLoadState("networkidle", { timeout: 5000 }).catch(() => {});
      const error = (await formError().allInnerTexts()).join(" | ").trim();
      const open = await popup().isVisible();
      if (value === "1000") {
        await mark(formError());
        await evidence.saveScreenshot(page, testInfo, {
          ac: AC, title: "TC-02 Amount 1000 rejected",
          steps: ['Open "New recycle esim batch"', "Amount of eSIM = 1000", "Click Confirm", `Message: "${error || "none"}"`],
          expected: ["Amount must be > 0 and < 1000 → error shown, popup stays open, no batch created"],
          status: error && open && createCalls === before ? undefined : "failed",
        });
      }
      rows.push({ value, error, open, calls: createCalls - before });
      await closePopup();
    }
    page.off("request", onReq);
    const bad = rows.filter((r) => !r.error || !r.open || r.calls > 0);
    await card(browser, testInfo, "TC-02 – invalid amounts (each: fill → Confirm)", `<table>
      <tr><th>Amount</th><th>Validation message</th><th>Popup still open</th><th>Create API calls</th><th>Result</th></tr>
      ${rows.map((r) => `<tr><td>${esc(r.value === "" ? "(empty)" : r.value)}</td><td>${esc(r.error || "—")}</td><td>${r.open}</td><td>${r.calls}</td><td class="${bad.includes(r) ? "bad" : "ok"}">${bad.includes(r) ? "FAIL" : "PASS"}</td></tr>`).join("")}</table>`, {
      ac: AC, title: "TC-02 Invalid amounts summary",
      steps: rows.map((r) => `${r.value === "" ? "(empty)" : r.value} → ${r.error || "no message"} · popup ${r.open ? "open" : "closed"} · create calls ${r.calls}`),
      expected: ["Every value ≤ 0, ≥ 1000, decimal, text or empty is rejected", "POST /api/inventories/search-recycle-inventory is never sent"],
      status: bad.length ? "failed" : undefined,
    });
    expect(bad.map((r) => r.value), "amounts not blocked").toEqual([]);
  });

  test(`TC-03 Boundary 999 is accepted by the form ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-03 Boundary 999");
    await openRecycle();
    await openPopup();
    await amountBox().fill("999");
    await amountBox().blur();
    await page.waitForLoadState("networkidle", { timeout: 3000 }).catch(() => {});
    const error = (await formError().allInnerTexts()).join(" | ").trim();
    await mark(amountBox());
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: "TC-03 Amount 999 no validation error",
      steps: ['Open "New recycle esim batch"', "Amount of eSIM = 999 (not submitted, popup cancelled after)", `Validation message: ${error || "none"}`],
      expected: ["999 (< 1000) is a valid amount: no validation error"],
      status: error ? "failed" : undefined,
    });
    expect(error, "validation error for 999").toBe("");
    await closePopup();
  });

  test(`TC-04 Amount N creates a batch in Checking with Confirm/Cancel disabled ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-04 Create batch Checking");
    await openRecycle();
    // Stock before the batch (TC-10 compares with it); N = eSIMs waiting to be recycled right now.
    before = await stockCounts();
    amount = before.waiting;
    saveState();
    test.skip(amount < 1, "no eSIM in Waiting To Recycle: nothing to recycle");
    const known = new Set((await listBatches(30)).map((b) => b.batchID));
    await openPopup();
    await amountBox().fill(String(amount));
    const respP = page.waitForResponse((r) => r.url().includes("/api/inventories/search-recycle-inventory") && r.request().method() === "POST", { timeout: 90000 });
    createdAt = Date.now();
    // The check takes < 1 min: read the row from the list refresh the page itself makes after CREATE SUCCESS
    // (a full reload takes ~20 s on stage and can already show Pending).
    const refreshP = respP.then(() => page.waitForResponse((r) => r.url().includes("search-batch-recycle-inventory") && r.request().method() === "POST", { timeout: 60000 })).catch(() => null);
    await popup().getByRole("button", { name: "Confirm" }).click();
    const resp = await respP;
    await refreshP;
    await spinnerGone();
    const reqBody = resp.request().postDataJSON();
    const resJson = await resp.json().catch(() => null);
    const toast = await page.locator(".Toastify__toast").filter({ hasText: /CREATE SUCCESS/i }).first().isVisible({ timeout: 10000 }).catch(() => false);
    // The new batch = newest one not in the list before the click (other testers may create batches too).
    for (let i = 0; i < 30 && !batchId; i++) {
      batchId = (await listBatches(30)).find((b) => !known.has(b.batchID))?.batchID ?? "";
      if (!batchId) await new Promise((r) => setTimeout(r, 1000));
    }
    saveState();
    const ui = await readRow(batchId || "no-batch");
    const apiB = batchId ? await getBatch(batchId) : undefined;
    const ok = !!batchId && ui.status === "Checking" && btn(ui.buttons, "Confirm")?.disabled === true && btn(ui.buttons, "Cancel")?.disabled === true;
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: "TC-04 New batch in Checking",
      steps: [`Stock before: Available ${before.available} · Waiting To Recycle ${before.waiting}`, `"New recycle esim batch" → Amount of eSIM = ${amount} → Confirm`, `Toast CREATE SUCCESS: ${toast ? "shown" : "not seen"}`, `New batch: ${batchId || "not found"} (API status ${apiB ? STATUS[apiB.status] : "-"})`, `Row status: ${ui.status || "-"}`, `Buttons: ${btnText(ui.buttons)}`],
      expected: ["Batch created with status Checking", "Confirm and Cancel buttons disabled at Checking"],
      status: ok ? undefined : "failed",
    });
    await card(browser, testInfo, "TC-04 – create call made by the page", `<table>
      <tr><th>Request</th><td>POST ${esc(resp.url())}</td></tr><tr><th>Body</th><td><code>${esc(JSON.stringify(reqBody))}</code></td></tr>
      <tr><th>HTTP</th><td class="${resp.status() === 200 ? "ok" : "bad"}">${resp.status()}</td></tr><tr><th>Response</th><td><code>${esc(JSON.stringify(resJson)?.slice(0, 600))}</code></td></tr>
      <tr><th>New batch (API)</th><td><code>${esc(JSON.stringify(apiB))}</code></td></tr></table>`, {
      ac: AC, title: "TC-04 Create API call",
      steps: [`POST /api/inventories/search-recycle-inventory ${JSON.stringify(reqBody)}`, `HTTP ${resp.status()}`, `Batch ${batchId}: status ${apiB?.status} (${apiB ? STATUS[apiB.status] : "-"})`],
      expected: [`HTTP 200, esimQuantity = ${amount}, checkBySingtel = true`, "New batch status 4 (Checking)"],
      status: resp.status() === 200 && !!batchId ? undefined : "failed",
    });
    expect(resp.status()).toBe(200);
    expect(batchId, "new batch id").toBeTruthy();
    expect(ui.status, "row status right after create").toBe("Checking");
    expect(btn(ui.buttons, "Confirm")?.disabled, "Confirm disabled at Checking").toBe(true);
    expect(btn(ui.buttons, "Cancel")?.disabled, "Cancel disabled at Checking").toBe(true);
  });

  test(`TC-05 Status filter has Checking/Confirming and filters the batch ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-05 Status filter");
    test.skip(!batchId, "no batch from TC-04");
    await openRecycle();
    // The initial list load can land after the filtered one (stale rows): let the page settle first.
    await page.waitForLoadState("networkidle", { timeout: 30000 }).catch(() => {});
    const select = page.locator(".custom-filter").first().locator(".ant-select").first();
    await select.click();
    const options = (await page.locator(".ant-select-dropdown:visible .ant-select-item-option").allInnerTexts()).map((t) => t.trim());
    // Always filter the new status Checking; the test batch is listed only if its check is still running.
    const b = await getBatch(batchId);
    const pick = "Checking";
    const respP = page.waitForResponse((r) => r.url().includes("search-batch-recycle-inventory") && r.request().method() === "POST", { timeout: 60000 });
    await page.locator(".ant-select-dropdown:visible .ant-select-item-option").filter({ hasText: new RegExp(`^${pick}\\s*$`) }).first().click();
    const resp = await respP;
    const sent = resp.request().postDataJSON()?.batchStatus;
    const apiTotal = (await resp.json().catch(() => null))?.data?.data?.numOfRecords;
    await page.waitForLoadState("networkidle", { timeout: 30000 }).catch(() => {});
    await spinnerGone();
    const statuses = (await page.locator(".ant-table-tbody").first().locator("tr.ant-table-row td:nth-child(5)").allInnerTexts()).map((t) => t.trim());
    const ui = await readRow(batchId);
    const stillChecking = b?.status === 4;
    const ok = options.includes("Checking") && options.includes("Confirming") && sent === 4 && statuses.every((s) => s === pick) && (!stillChecking || ui.found);
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: `TC-05 Filter Status = ${pick}`,
      steps: [`Status options: ${options.join(", ")}`, `Select "${pick}" → request batchStatus=${sent} → numOfRecords ${apiTotal}`, `Rows: ${statuses.length} · statuses: ${[...new Set(statuses)].join(", ") || "-"}`, `Test batch (API status ${b ? STATUS[b.status] : "-"}) listed: ${ui.found}`],
      expected: ["Status filter offers the new statuses Checking and Confirming", `Filter "${pick}" sends batchStatus 4 and lists only ${pick} batches (incl. the test batch while it is still Checking)`],
      status: ok ? undefined : "failed",
    });
    expect(options).toEqual(expect.arrayContaining(["Checking", "Confirming"]));
    expect(statuses.filter((s) => s !== pick), "rows of another status").toEqual([]);
    expect(sent, "batchStatus sent for Checking").toBe(4);
    if (stillChecking) expect(ui.found, "test batch (still Checking) in filtered list").toBe(true);
  });

  test(`TC-06 Checking completes and the batch becomes Pending ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-06 Checking to Pending");
    test.setTimeout(420_000);
    test.skip(!batchId, "no batch from TC-04");
    const seen: string[] = [];
    const b = await waitStatus(batchId, [1, 2, 3, 5], 360000, seen);
    const secs = Math.round((Date.now() - createdAt) / 1000);
    await openRecycle();
    const ui = await readRow(batchId);
    const ok = b?.status === 1 && ui.status === "Pending" && btn(ui.buttons, "Confirm")?.disabled === false;
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: "TC-06 Batch Pending after check",
      steps: [`Poll batch ${batchId} (API, every 1 s, max 6 min)`, `Statuses seen: ${seen.join(" → ")} (~${secs}s after create)`, `Row status: ${ui.status}`, `Buttons: ${btnText(ui.buttons)}`],
      expected: ["When checking completes the status changes to Pending", "Confirm enabled on Pending"],
      status: ok ? undefined : "failed",
    });
    expect(b?.status, `status after check (seen ${seen.join(" → ")})`).toBe(1);
    expect(ui.status).toBe("Pending");
    expect(btn(ui.buttons, "Confirm")?.disabled, "Confirm enabled on Pending").toBe(false);
  });

  test(`TC-08 Batch holds the requested amount ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-08 Amount in batch");
    test.skip(!batchId, "no batch from TC-04");
    const b = await getBatch(batchId);
    await openRecycle();
    const ui = await readRow(batchId);
    const assignTotal = ui.found ? (await ui.row.locator("td").nth(2).innerText()).trim() : "";
    const ok = b?.totalEsim === amount;
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: "TC-08 Assign/Total eSim = requested amount",
      steps: [`Requested amount: ${amount}`, `Batch ${batchId}: totalEsim = ${b?.totalEsim ?? "-"} (Assign/Total column "${assignTotal}")`],
      expected: [`Batch contains ${amount} eSIM (the requested amount)`],
      status: ok ? undefined : "failed",
    });
    expect(b?.totalEsim, "totalEsim").toBe(amount);
  });

  test(`TC-09 Confirm on Pending → Confirming (buttons disabled) → Confirmed ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-09 Confirm to Confirming");
    test.setTimeout(420_000);
    test.skip(!batchId, "no batch from TC-04");
    await openRecycle();
    let ui = await readRow(batchId);
    test.skip(ui.status !== "Pending", `batch is ${ui.status}, not Pending`);
    // Confirming can last < 1 s: poll the API (~300 ms) from the click, in parallel with the UI.
    const timeline: { ms: number; s: string }[] = [];
    let polling = true;
    const t0 = Date.now();
    const poller = (async () => {
      while (polling && Date.now() - t0 < 360000) {
        const b = await getBatch(batchId).catch(() => undefined);
        const s = b ? STATUS[b.status] ?? String(b.status) : "not found";
        if (timeline[timeline.length - 1]?.s !== s) timeline.push({ ms: Date.now() - t0, s });
        if (b && (b.status === 2 || b.status === 3)) break;
        await new Promise((r) => setTimeout(r, 300));
      }
    })();
    const putP = page.waitForResponse((r) => r.url().includes("/api/inventories/update-batch") && r.request().method() === "PUT", { timeout: 60000 });
    await ui.row.getByRole("button", { name: "Confirm" }).click();
    const put = await putP;
    const putBody = put.request().postDataJSON();
    // The page reloads the list after the PUT: read the row as soon as it re-renders.
    await page.waitForResponse((r) => r.url().includes("search-batch-recycle-inventory"), { timeout: 30000 }).catch(() => {});
    await spinnerGone();
    ui = await readRow(batchId);
    const uiMs = Date.now() - t0;
    const uiConfirming = ui.status === "Confirming";
    const disabledOk = btn(ui.buttons, "Confirm")?.disabled === true && btn(ui.buttons, "Cancel")?.disabled === true;
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: "TC-09 Row right after Confirm",
      steps: ["Row of the test batch (Pending) → click Confirm", `PUT /api/inventories/update-batch ${JSON.stringify(putBody)} → HTTP ${put.status()}`, `Row status after the page's list refresh (+${uiMs} ms): ${ui.status}`, `Buttons: ${btnText(ui.buttons)}`,
        ...(uiConfirming ? [] : ["Note: Confirming had already ended when the list refreshed → disabled state checked on the API timeline + TC-04 (same rule: Checking OR Confirming)"])],
      expected: ["Status changes to Confirming", "Confirm and Cancel disabled at Confirming"],
      status: uiConfirming && !disabledOk ? "failed" : undefined,
    });
    await poller;
    polling = false;
    const fin = await getBatch(batchId);
    const sawConfirming = timeline.some((t) => t.s === "Confirming");
    const path = ["Pending", ...timeline.map((t) => t.s)].filter((s, i, arr) => arr[i - 1] !== s);
    await openRecycle();
    const end = await readRow(batchId);
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: "TC-09 Status timeline Pending → Confirming → Confirmed",
      steps: [`API timeline after click: ${timeline.map((t) => `+${t.ms}ms ${t.s}`).join(" · ")}`, `Path: ${path.join(" → ")}`, `Row status now: ${end.status}`, `Buttons: ${btnText(end.buttons)}`],
      expected: ["After Confirm the status is Confirming", "Confirming finishes (not stuck) → Confirmed"],
      status: sawConfirming && fin?.status === 2 ? undefined : "failed",
    });
    expect(put.status()).toBe(200);
    expect(sawConfirming, `Confirming seen (path ${path.join(" → ")})`).toBe(true);
    if (uiConfirming) {
      expect(btn(ui.buttons, "Confirm")?.disabled, "Confirm disabled at Confirming").toBe(true);
      expect(btn(ui.buttons, "Cancel")?.disabled, "Cancel disabled at Confirming").toBe(true);
    }
    expect(fin?.status, `final status (path ${path.join(" → ")})`).toBe(2);
  });

  test(`TC-10 Recycled eSIMs are back in stock as Available ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-10 eSIMs back to Available");
    test.setTimeout(300_000);
    test.skip(!batchId || !before, "no batch / no stock baseline from TC-04");
    const b = await waitStatus(batchId, [2, 3], 120000);
    // Export = the eSIMs of the batch and their recycle status (Processed = recycled).
    const ex = await api("POST", "/api/inventories/export-recycle-inventory", { batchIdList: [batchId] });
    const cols: string[] = ex.json?.data?.columns ?? [];
    const data: any[][] = ex.json?.data?.dataExports ?? [];
    const col = (r: any[], name: string) => String(r[cols.indexOf(name)] ?? "");
    const items: { imsi: string; prev: string; recycle: string; stock: string }[] = [];
    for (const r of data) {
      const imsi = col(r, "IMSI");
      const inv = (await searchInventory(null, imsi)).rows.find((x) => x.imsi === imsi);
      items.push({ imsi, prev: col(r, "Previous User ID"), recycle: col(r, "Recycle status"), stock: inv ? INV_STATUS[inv.status] ?? String(inv.status) : "not found" });
    }
    const after = await stockCounts();
    const processed = items.filter((i) => i.recycle === "Processed").length;
    const notAvailable = items.filter((i) => i.stock !== "Available");
    const okCount = after.available === before!.available + processed;
    await card(browser, testInfo, `TC-10 – batch ${batchId}: eSIMs and stock`, `<table>
      <tr><th>IMSI</th><th>Previous User ID</th><th>Export: Recycle status</th><th>eSIM Codes status now</th></tr>
      ${items.map((i) => `<tr><td>${esc(i.imsi)}</td><td>${esc(i.prev || "—")}</td><td class="${i.recycle === "Processed" ? "ok" : "bad"}">${esc(i.recycle)}</td><td class="${i.stock === "Available" ? "ok" : "bad"}">${esc(i.stock)}</td></tr>`).join("")}</table>
      <h3>Stock (POST /api/inventories/search by status)</h3><table>
      <tr><th></th><th>Before TC-04</th><th>After Confirmed</th><th>Expected</th></tr>
      <tr><td>Available</td><td>${before!.available}</td><td class="${okCount ? "ok" : "bad"}">${after.available}</td><td>${before!.available} + ${processed} = ${before!.available + processed}</td></tr>
      <tr><td>Waiting To Recycle</td><td>${before!.waiting}</td><td>${after.waiting}</td><td>—</td></tr></table>
      <p>Counts can also move if someone else takes / returns an eSIM on stage meanwhile.</p>`, {
      ac: AC, title: "TC-10 Recycled eSIMs Available – export vs stock",
      steps: [`Batch ${batchId}: ${b ? STATUS[b.status] : "-"} · totalEsim ${b?.totalEsim ?? "-"}`, `Export: ${items.length} eSIM, Processed ${processed}`,
        ...items.map((i) => `IMSI ${i.imsi}: ${i.recycle} → eSIM Codes ${i.stock}`), `Available: ${before!.available} → ${after.available} (expected ${before!.available + processed})`, `Waiting To Recycle: ${before!.waiting} → ${after.waiting}`],
      expected: ["Every eSIM of the confirmed batch is Processed and back in stock as Available", "Available count = before + number of recycled eSIMs"],
      status: items.length && processed === items.length && !notAvailable.length && okCount ? undefined : "failed",
    });
    // UI evidence: each IMSI in the eSIM Codes table.
    await openRecycle();
    const codesSearch = page.getByPlaceholder("Search", { exact: true });
    for (const i of items) {
      await codesSearch.fill(i.imsi);
      const respP = page.waitForResponse((r) => r.url().includes("/api/inventories/search") && r.request().method() === "POST", { timeout: 60000 });
      await codesSearch.press("Enter");
      await respP.catch(() => {});
      await spinnerGone();
      const row = page.locator(".ant-table-tbody").nth(1).locator("tr.ant-table-row").filter({ hasText: i.imsi }).first();
      await row.scrollIntoViewIfNeeded().catch(() => {});
      await mark(row);
      const header = (await page.getByText(/Available Codes/).first().locator("xpath=..").innerText().catch(() => "")).replace(/\s+/g, " ").trim();
      await evidence.saveScreenshot(page, testInfo, {
        ac: AC, title: `TC-10 eSIM Codes – ${i.imsi}`,
        steps: ["Admin › eSIM › eSIM Codes", `Search ${i.imsi}`, `Status: ${i.stock}`, header ? `Header: ${header}` : "Header: -"],
        expected: ["Status = Available (back in stock after recycle)"],
        status: i.stock === "Available" ? undefined : "failed",
      });
    }
    expect(items.length, "eSIMs in the batch").toBeGreaterThan(0);
    expect(processed, "Processed eSIMs (export)").toBe(items.length);
    expect(notAvailable.map((i) => `${i.imsi}=${i.stock}`), "eSIMs not Available").toEqual([]);
    expect(after.available, `Available count (before ${before!.available} + ${processed})`).toBe(before!.available + processed);
  });
});
