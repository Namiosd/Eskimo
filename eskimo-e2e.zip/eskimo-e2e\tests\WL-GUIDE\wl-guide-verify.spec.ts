// WL-GUIDE – read-only probe of stage to settle open points in docs/white-label-master-guide.*.md.
// Nothing is saved: dialogs are opened, read and closed (Cancel / Close / Escape); no Ok, Save, Assign or Delete.
// Output: test-results/wl-guide-verify.json
import fs from "node:fs";
import { test, type Page } from "@playwright/test";
import { ADMIN_URL } from "../_support/eskimo";
import { adminSessionRetry as adminSession } from "../_support/whitelabel";
import { api, tokenOf, websites, findPartner, openCorporate, readCorporateForm, formItem, corporate } from "../_support/whitelabel";

const out: Record<string, unknown> = {};
const save = () => fs.writeFileSync("test-results/wl-guide-verify.json", JSON.stringify(out, null, 2));
const WEBSITE_PARTNER = process.env.WLG_PARTNER || "WLBe2e";

test.describe.configure({ mode: "serial" });
test.setTimeout(300_000);

let page: Page;
let token = "";

test.beforeAll(async ({ browser }) => {
  ({ page } = await adminSession(browser));
  token = await tokenOf(page);
});
test.afterAll(save);

async function openTemplates() {
  // Right after login the SPA can bounce a deep link to the dashboard: set the hash again until the table shows
  for (let i = 0; i < 3; i++) {
    if (!page.url().includes("white-label-templates")) await page.goto(`${ADMIN_URL}/#/white-label-templates`, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(1500);
    if (!page.url().includes("white-label-templates")) {
      const nav = page.locator("a.c-sidebar-nav-link[href*='white-label-templates']").first();
      await nav.scrollIntoViewIfNeeded().catch(() => {});
      await nav.click({ timeout: 15000 }).catch(() => {});
    }
    if (await page.locator(".ant-table-row").filter({ hasText: /Website Template/ }).first().waitFor({ timeout: 40000 }).then(() => true).catch(() => false)) return;
  }
  throw new Error("Website Templates table did not load");
}
const rowOf = (name: RegExp) => page.locator(".ant-table-row").filter({ hasText: name }).first();

test("P1 websites + partner eligibility (API)", async () => {
  const list = await websites(token);
  out.websites = list.map((w) => ({ name: w.name, partnerId: w.partnerId ?? null, status: w.status ?? w.isActive ?? null, mode: w.mode ?? null, type: w.type ?? w.websiteType ?? null }));
});

test("P2 Assign/Reassign partner options vs corporate type", async () => {
  await openTemplates();
  const row = rowOf(new RegExp(`partner ${WEBSITE_PARTNER}`, "i"));
  await row.getByText(/Reassign Partner|Assign Partner/).first().click();
  const modal = page.locator(".ant-modal:visible").first();
  await modal.waitFor();
  await modal.locator(".ant-select").first().click();
  const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ timeout: 15000 });
  await page.waitForTimeout(1500);
  const names = (await dd.locator(".ant-select-item-option-content").allInnerTexts()).map((t) => t.trim()).filter(Boolean);
  await page.keyboard.press("Escape");
  await modal.getByRole("button", { name: /Cancel/i }).click();
  const checked: unknown[] = [];
  for (const n of names.slice(0, 25)) {
    const p = await findPartner(token, n.replace(/\s*\(.*\)\s*$/, ""));
    if (!p) { checked.push({ name: n, found: false }); continue; }
    const d = await api(token, "GET", `/api/partner/v2/${p.id}`);
    const c = d.json?.data?.configuration ?? {};
    checked.push({ name: n, code: p.code, hasCorporate: !!c.hasCorporate, corporateType: c.corporateSetting?.corporateType ?? null });
  }
  out.assignOptions = { total: names.length, checked };
});

test("P3 Edit Structure: Header drag + retired modules", async () => {
  await openTemplates();
  const row = rowOf(new RegExp(`partner ${WEBSITE_PARTNER}`, "i"));
  await row.getByText("Edit Structure").first().click();
  const drawer = page.locator(".ant-drawer-open, .ant-modal:visible").filter({ hasText: "Edit Structure" }).first();
  await drawer.waitFor({ timeout: 30000 });
  await page.waitForTimeout(2000);
  const titles = () => drawer.locator("[title='Drag to reorder']").evaluateAll((els) => els.map((e) => (e.parentElement?.innerText || "").trim().split("\n")[0]));
  const before = await titles();
  const handles = drawer.locator("[title='Drag to reorder']");
  const handleCount = await handles.count();
  // keyboard drag of the first module (Header) one step down; not saved
  let after: string[] = [];
  if (handleCount) {
    await handles.first().focus();
    await page.keyboard.press("Space");
    await page.waitForTimeout(400);
    await page.keyboard.press("ArrowDown");
    await page.waitForTimeout(400);
    await page.keyboard.press("Space");
    await page.waitForTimeout(1200);
    after = await titles();
  }
  const text = await drawer.innerText();
  out.editStructure = {
    tabs: (await drawer.locator(".ant-tabs-tab").allInnerTexts()).map((t) => t.trim()),
    firstRowsBefore: before.slice(0, 4), firstRowsAfter: after.slice(0, 4), handleCount,
    saveButton: (await drawer.getByRole("button", { name: /Save/ }).first().innerText().catch(() => "")).trim(),
    retiredWarning: /no longer used/i.test(text), hasDownloadApp: /downloadApp/.test(text),
  };
  await page.locator("button.btn-action-cancel:visible").filter({ hasText: /^\s*Close\s*$/ }).last().click();
  await page.waitForTimeout(800);
  out.editStructure = { ...(out.editStructure as object), closeShowedConfirm: await page.locator(".ant-popover:visible, .ant-modal-confirm:visible").count() };
});

test("P4 Config dialog labels", async () => {
  await openTemplates();
  const row = rowOf(new RegExp(`partner ${WEBSITE_PARTNER}`, "i"));
  await row.locator("[title='Custom domain and website settings']").first().click();
  const modal = page.locator(".ant-modal:visible").first();
  await modal.waitFor({ timeout: 20000 });
  await page.waitForTimeout(3000);
  out.config = { text: (await modal.innerText()).replace(/\s+\n/g, "\n").slice(0, 2500) };
  await page.keyboard.press("Escape");
});

for (const name of ["WhiteLabel Partner 2", WEBSITE_PARTNER]) {
  test(`P5 Corporate Program form: ${name}`, async () => {
    const { drawer } = await openCorporate(page, name);
    const form = await readCorporateForm(drawer);
    const { body } = corporate(drawer);
    const labels = (await body.locator(".ant-form-item-label label").allInnerTexts()).map((t) => t.trim()).filter(Boolean);
    const optsOf = async (label: string) => {
      const item = formItem(body, label);
      if (!(await item.count())) return null;
      await item.locator(".ant-select").first().click();
      const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
      await dd.waitFor({ timeout: 8000 });
      const o = await dd.locator(".ant-select-item-option").evaluateAll((els) => els.map((e) => `${(e as HTMLElement).innerText.trim()}${e.classList.contains("ant-select-item-option-disabled") ? " (disabled)" : ""}`));
      await page.keyboard.press("Escape");
      return o;
    };
    out[`corporate:${name}`] = { form: { ...form, text: undefined }, labels, payment: await optsOf("Payment method"), dataExpiry: await optsOf("Data Expiry"), hasNPC: /Network Partner Commission/i.test(form.text) };
    await page.goto(`${ADMIN_URL}/#/dashboard`).catch(() => {});
  });
}
