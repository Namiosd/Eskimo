// WL-GUIDE – read-only look at the live partner site: visible "no expiry" texts that are not CMS fields. View only.
import fs from "node:fs";
import { test } from "@playwright/test";

test("wellatsea home: Global card + meta description", async ({ page }) => {
  test.setTimeout(120_000);
  await page.goto("https://wellatsea.eskimo.travel/en", { waitUntil: "domcontentloaded" });
  const card = page.locator(".global-card").first();
  await card.waitFor({ timeout: 60_000 });
  await card.scrollIntoViewIfNeeded();
  await card.evaluate((el) => ((el as HTMLElement).style.outline = "3px solid #cf1322"));
  await page.screenshot({ path: "test-results/wl-live-global-card.png" });
  const out = {
    globalCard: (await card.innerText()).replace(/\s+/g, " ").trim(),
    metaHome: await page.locator('meta[name="description"]').getAttribute("content"),
  };
  await page.goto("https://wellatsea.eskimo.travel/en/plans/japan-esim", { waitUntil: "domcontentloaded" });
  (out as any).metaPlan = await page.locator('meta[name="description"]').getAttribute("content");
  fs.writeFileSync("test-results/wl-live-expiry.json", JSON.stringify(out, null, 2));
});
