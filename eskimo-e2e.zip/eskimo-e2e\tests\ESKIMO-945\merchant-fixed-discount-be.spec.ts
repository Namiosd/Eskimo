// ESKIMO-945 – [BE][Merchant Program] API accepts Fixed Discount > plan price → negative Discount Price;
// buying a voucher INCREASES Remaining Credits. Test cases: testcases/ESKIMO-945/ESKIMO-945.md (from the item's Expected).
//   TC-01 BE rejects Fixed Discount 456789 (or keeps the price valid)   TC-02 Discount Price >= 0 (UI + API)
//   TC-03 buy 1 voucher → credits not increased, debit <= plan price    TC-04 regression: Fixed Discount 5 → $16 − 5
// Not serial: every test sets the rule it needs and restores the original in `finally`, so a product
// failure in one case never hides the others. One partner (partnerofduc) → tests run in order in one worker.
// Evidence: evidence/ESKIMO-945-merchant-fixed-discount-be/ → npm run report:evidence -- ESKIMO-945 merchant-fixed-discount-be
import { test, expect, type Browser, type Locator, type Page, type TestInfo } from "@playwright/test";
import {
  adminSession, partnerSession, openPartnerDrawer, findMerchantRow, addMerchantRow, deleteMerchantRow,
  setDiscount, readDiscountType, rowValueInput, savePartnerDrawer,
  openPurchaseVoucher, selectVoucherPlan, openVouchers, readRemainingCredits, type PurchasePlan,
} from "../_support/eskimo";
import { createEvidence } from "../_support/evidence";

const ID = "@ESKIMO-945";
const AC = "ESKIMO-945";
const RULE = "Any Unlimited Vietnam";
const FIXED = "Fixed Discount ($US)";
const HUGE = 456789;
const NORMAL = 5;
const TARGET_PRICE = 16;
const evidence = createEvidence("ESKIMO-945", "merchant-fixed-discount-be");

test.describe(`ESKIMO-945 BE validates Merchant Fixed Discount ${ID}`, () => {
  test.setTimeout(300_000);

  let admin: { ctx: any; page: Page };
  let partner: { ctx: any; page: Page; partnerName: string };

  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    admin = await adminSession(browser);
    partner = await partnerSession(browser);
    console.log(`[INFO] partner = "${partner.partnerName}"`);
  });

  test.afterAll(async () => {
    await admin?.ctx.close();
    await partner?.ctx.close();
  });

  const shot = (page: Page, testInfo: TestInfo, title: string, steps: string[], expected: string[], ok = true) =>
    evidence.saveScreenshot(page, testInfo, { ac: AC, title, steps, expected, status: ok ? undefined : "failed" });

  const scrollTo = async (loc: Locator) => {
    await loc.evaluate((el) => el.scrollIntoView({ block: "center" })).catch(() => {});
  };

  const openRule = async () => {
    const { drawer } = await openPartnerDrawer(admin.page, partner.partnerName);
    return { drawer, row: await findMerchantRow(drawer, RULE) };
  };

  const pickTarget = (plans: PurchasePlan[]) => {
    const unl = plans.filter((p) => /^Unlimited Vietnam\b/i.test(p.dataPlanName));
    expect(unl.length, "No 'Unlimited Vietnam …' plan offered to this partner").toBeGreaterThan(0);
    return unl.find((p) => p.price === TARGET_PRICE) ?? unl[0];
  };

  // Set RULE = FIXED value, Save, reopen. Returns the BE's answer and what is stored afterwards.
  // `restore()` puts back the rule as it was before (or removes the row the test added).
  async function applyRule(value: number) {
    let { drawer, row } = await openRule();
    const original = row ? { type: await readDiscountType(row), value: await rowValueInput(row).inputValue() } : null;
    if (!row) await addMerchantRow(drawer, RULE);
    await setDiscount(drawer, RULE, FIXED, value);
    const warning = await drawer.getByText(/final bill < 1/).last().isVisible().catch(() => false);
    const res = await savePartnerDrawer(drawer);
    if (!res.closed) await admin.page.keyboard.press("Escape");
    ({ drawer, row } = await openRule());
    const storedType = row ? await readDiscountType(row) : null;
    const storedValue = row ? Number(await rowValueInput(row).inputValue()) : null;
    if (row) await scrollTo(row);
    const restore = async () => {
      try {
        const cur = await openRule();
        if (cur.row && original) await setDiscount(cur.drawer, RULE, original.type, original.value);
        else if (cur.row) await deleteMerchantRow(cur.row);
        else { await admin.page.keyboard.press("Escape"); return; }
        const r = await savePartnerDrawer(cur.drawer);
        console.log(`[INFO] Restore "${RULE}" (${original ? "original" : "removed"}) → HTTP ${r.status}`);
      } catch (e) {
        console.log(`[WARN] Restore failed, fix "${RULE}" on ${partner.partnerName} by hand: ${(e as Error).message}`);
      }
    };
    return { res, warning, storedType, storedValue, saved: storedType === FIXED && storedValue === value, original, restore };
  }

  test(`TC-01 BE rejects Fixed Discount ${HUGE} > plan price ${ID}`, async ({}, testInfo) => {
    if (!process.env.KEEP_EVIDENCE) evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Admin: BE rejects Fixed Discount > plan price");
    const r = await applyRule(HUGE);
    try {
      const rejected = !r.res.ok || !r.saved;
      await shot(admin.page, testInfo, `${RULE} = ${FIXED} ${HUGE} → Save → reopen`,
        [`Admin → Partnership → Partners → ${partner.partnerName} → Merchant Program`,
          `Discount Benefit: ${RULE}, ${FIXED}, ${HUGE} (plan price $${TARGET_PRICE})`, "Click Ok (Save)", "Reopen partner"],
        ["BE rejects the value (save fails or the value is not stored) — or keeps prices valid (TC-02/03)",
          `→ actual: HTTP ${r.res.status}${r.res.message ? ` "${r.res.message}"` : ""}, FE warning ${r.warning ? "shown" : "not shown"}, ` +
          `stored: ${r.storedType ? `${r.storedType} ${r.storedValue}` : "no row"}`], rejected);
      test.info().annotations.push({ type: "BE save", description: `HTTP ${r.res.status}, stored ${r.storedValue}` });
      expect(rejected, `BE accepted and stored ${FIXED} ${HUGE} (HTTP ${r.res.status})`).toBe(true);
    } finally {
      await r.restore();
    }
  });

  test(`TC-02 Discount Price never negative ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-02 Partner: Discount Price never negative");
    const r = await applyRule(HUGE);
    try {
      test.skip(!r.saved, `BE did not store ${HUGE} (HTTP ${r.res.status}): nothing to price`);
      const { drawer, plans } = await openPurchaseVoucher(partner.page);
      const plan = pickTarget(plans);
      const ui = await selectVoucherPlan(drawer, plan.dataPlanName);
      const ok = ui !== null && ui >= 0 && plan.discountPrice >= 0;
      await shot(partner.page, testInfo, `Purchase Voucher "${plan.dataPlanName}" with rule ${HUGE}`,
        [`Partner → Vouchers → Purchase Voucher`, `Select "${plan.dataPlanName}" (price $${plan.price}), no submit`],
        ["Discount Price >= 0 on the form and in the API",
          `→ actual: UI $${ui}, API discountPrice $${plan.discountPrice}`], ok);
      await partner.page.keyboard.press("Escape");
      expect.soft(plan.discountPrice, "API discountPrice must be >= 0").toBeGreaterThanOrEqual(0);
      expect(ui, "UI Discount Price must be >= 0").toBeGreaterThanOrEqual(0);
    } finally {
      await r.restore();
    }
  });

  // Buy 1 voucher of the $16 plan and check credits: never increased, debit <= plan price
  // (and, when `expectedDebit` is given, debit == that Discount Price).
  async function buyOneAndCheck(testInfo: TestInfo, expectedDebit?: number) {
      await openVouchers(partner.page);
      const before = await readRemainingCredits(partner.page);
      await shot(partner.page, testInfo, "Remaining Credits before purchase",
        [`Partner (${partner.partnerName}) → Vouchers`], [`→ Remaining Credits: $${before}`], before !== null);
      expect(before, "Remaining Credits not shown (prepaid merchant expected)").not.toBeNull();

      const { drawer, plans } = await openPurchaseVoucher(partner.page);
      const plan = pickTarget(plans);
      const discountPrice = await selectVoucherPlan(drawer, plan.dataPlanName);
      await drawer.locator("input[placeholder='Insert Quantity']").first().fill("1");
      await shot(partner.page, testInfo, `Purchase "${plan.dataPlanName}" × 1`,
        ["Purchase Voucher", `Plan "${plan.dataPlanName}" (price $${plan.price}), Quantity 1`],
        [`→ Discount Price shown: $${discountPrice}`]);
      await drawer.locator(".btn-action-ok").click();
      const closed = await drawer.waitFor({ state: "hidden", timeout: 60000 }).then(() => true).catch(() => false);
      if (!closed) {
        const err = await partner.page.locator(".ant-modal-body, .ant-notification-notice").first().innerText({ timeout: 2000 }).catch(() => "");
        // A refused purchase is a valid BE outcome: credits cannot have been raised.
        await shot(partner.page, testInfo, "Submit purchase", ["Click Ok"],
          ["Purchase refused or completed without raising credits", `→ actual: refused (${err || "drawer stayed open"})`]);
        await partner.page.keyboard.press("Escape");
        return;
      }

      await openVouchers(partner.page);
      const after = await readRemainingCredits(partner.page);
      const debited = Number((before! - after!).toFixed(2));
      const exact = expectedDebit === undefined || Math.abs(debited - expectedDebit) < 0.005;
      const ok = after! <= before! && debited <= plan.price && exact;
      test.info().annotations.push({ type: "credits", description: `before $${before}, after $${after}, debited $${debited}` });
      await shot(partner.page, testInfo, "Remaining Credits after purchase",
        ["Submit purchase", "Vouchers → read Remaining Credits"],
        ["Remaining Credits do NOT increase", `Debited <= plan price $${plan.price}`,
          ...(expectedDebit === undefined ? [] : [`Debited = Discount Price $${expectedDebit}`]),
          `→ actual: before $${before}, after $${after}, debited $${debited} (Discount Price $${discountPrice})`], ok);
      expect(after!, `Remaining Credits increased: $${before} → $${after}`).toBeLessThanOrEqual(before!);
      expect(debited, `Debited $${debited} exceeds plan price $${plan.price}`).toBeLessThanOrEqual(plan.price);
      if (expectedDebit !== undefined) expect(debited, "Debited = Discount Price").toBeCloseTo(expectedDebit, 2);
  }

  test(`TC-03 Remaining Credits not increased after buying a voucher ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-03 Partner: Remaining Credits after buying 1 voucher (rule 456789)");
    const r = await applyRule(HUGE);
    try {
      test.skip(!r.saved, `BE did not store ${HUGE} (HTTP ${r.res.status}): purchase precondition not met`);
      await buyOneAndCheck(testInfo);
    } finally {
      await r.restore();
    }
  });

  test(`TC-05 Buy 1 voucher with a valid rule: credits debited by the Discount Price ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-05 Partner: Remaining Credits after buying 1 voucher (rule 5)");
    const r = await applyRule(NORMAL);
    try {
      await admin.page.keyboard.press("Escape");
      expect(r.saved, `rule ${NORMAL} not stored (HTTP ${r.res.status} ${r.res.message})`).toBe(true);
      await buyOneAndCheck(testInfo, Number((TARGET_PRICE - NORMAL).toFixed(2)));
    } finally {
      await r.restore();
    }
  });

  test(`TC-04 Regression: Fixed Discount ${NORMAL} saves and prices correctly ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-04 Regression: valid Fixed Discount");
    const r = await applyRule(NORMAL);
    try {
      await shot(admin.page, testInfo, `${RULE} = ${FIXED} ${NORMAL} → Save → reopen`,
        [`Merchant Program: ${RULE}, ${FIXED}, ${NORMAL}`, "Click Ok (Save)", "Reopen partner"],
        [`Saved; row shows ${FIXED} ${NORMAL}`, `→ actual: HTTP ${r.res.status}, stored ${r.storedType} ${r.storedValue}`],
        r.res.ok && r.saved);
      await admin.page.keyboard.press("Escape");
      expect(r.res.ok, `Save failed: HTTP ${r.res.status} ${r.res.message}`).toBe(true);
      expect(r.saved, `stored ${r.storedType} ${r.storedValue}`).toBe(true);

      const { drawer, plans } = await openPurchaseVoucher(partner.page);
      const plan = pickTarget(plans);
      const expected = Number(Math.max(plan.price - NORMAL, 0).toFixed(2));
      const ui = await selectVoucherPlan(drawer, plan.dataPlanName);
      const ok = ui !== null && Math.abs(ui - expected) < 0.005 && Math.abs(plan.discountPrice - expected) < 0.005;
      await shot(partner.page, testInfo, `Purchase Voucher "${plan.dataPlanName}" with rule ${NORMAL}`,
        [`Partner → Vouchers → Purchase Voucher`, `Select "${plan.dataPlanName}" (price $${plan.price}), no submit`],
        [`Discount Price = $${plan.price} − $${NORMAL} = $${expected}`, `→ actual: UI $${ui}, API $${plan.discountPrice}`], ok);
      await partner.page.keyboard.press("Escape");
      expect.soft(plan.discountPrice, "API discountPrice").toBeCloseTo(expected, 2);
      expect(ui, "UI Discount Price").toBeCloseTo(expected, 2);
    } finally {
      await r.restore();
    }
  });
});
