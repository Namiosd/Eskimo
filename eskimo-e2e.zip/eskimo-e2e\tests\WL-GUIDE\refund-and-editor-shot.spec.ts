// WL-GUIDE – stage, no saved changes:
//  R1 read-only: can White Label sales (eskimoTransactionType 4) be refunded from Admin › Eskimo Sale? (canRefund from search API)
//  S1 Edit Structure screenshot for the Admin guide: add one module (not saved) so the tab shows Home (13), then Close.
import fs from "node:fs";
import { test, type Page } from "@playwright/test";
import { ADMIN_URL } from "../_support/eskimo";
import { adminSessionRetry as adminSession, api, tokenOf } from "../_support/whitelabel";

test.describe.configure({ mode: "serial" });
let page: Page;
let token = "";
const out: any = {};
test.beforeAll(async ({ browser }) => {
  test.setTimeout(300_000);
  ({ page } = await adminSession(browser));
  await page.setViewportSize({ width: 1280, height: 720 });
  token = await tokenOf(page);
});
test.afterAll(() => fs.writeFileSync("test-results/wl-guide-refund-shot.json", JSON.stringify(out, null, 2)));

test("R1 White Label sales: canRefund", async () => {
  test.setTimeout(180_000);
  const body = (type: number | null) => ({ pageIndex: 1, pageSize: 30, type: 1, amountId: null, platformFilter: "", eskimoTransactionType: type, cashbackFilter: 0, paymentMethodFilter: null, searchText: "", searchPlanName: "", fromDate: null, toDate: null, sortBy: { fieldName: "PurchaseDate", ascending: false } });
  const r = await api(token, "POST", "/api/data-plan-sale-transaction/search", body(4));
  const rows: any[] = r.json?.data?.data ?? [];
  out.whiteLabel = rows.slice(0, 15).map((x) => ({ id: x.transactionId ?? x.transactionID, status: x.transactionStatus ?? x.status, canRefund: x.canRefund, isRefund: x.isRefund, isRefunded: x.isRefunded, keys: undefined }));
  out.sampleKeys = rows[0] ? Object.keys(rows[0]).filter((k) => /refund|status|type|stripe|white/i.test(k)) : [];
  const reg = await api(token, "POST", "/api/data-plan-sale-transaction/search", body(null));
  out.regularSample = (reg.json?.data?.data ?? []).slice(0, 5).map((x: any) => ({ id: x.transactionId ?? x.transactionID, canRefund: x.canRefund, isRefund: x.isRefund, isRefunded: x.isRefunded }));
});

test("S1 Edit Structure: add one module, screenshot, close without saving", async () => {
  test.setTimeout(240_000);
  for (let i = 0; i < 3; i++) {
    if (!page.url().includes("white-label-templates")) await page.goto(`${ADMIN_URL}/#/white-label-templates`, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(1500);
    if (!page.url().includes("white-label-templates")) {
      const nav = page.locator("a.c-sidebar-nav-link[href*='white-label-templates']").first();
      await nav.scrollIntoViewIfNeeded().catch(() => {});
      await nav.click({ timeout: 15000 }).catch(() => {});
    }
    if (await page.locator(".ant-table-row").filter({ hasText: /Website Template/ }).first().waitFor({ timeout: 40000 }).then(() => true).catch(() => false)) break;
  }
  const row = page.locator(".ant-table-row").filter({ hasText: /partner WLBe2e/i }).first();
  await row.getByText("Edit Structure").first().click();
  const drawer = page.locator(".ant-drawer-open, .ant-modal:visible").filter({ hasText: "Edit Structure" }).first();
  await drawer.waitFor({ timeout: 30000 });
  await page.waitForTimeout(2500);
  const tabText = async () => (await drawer.locator("[role=tab], .ant-tabs-tab, button").filter({ hasText: /^Home \(\d+\)$/ }).first().innerText().catch(() => "")).trim();
  out.homeBefore = await tabText();
  await drawer.getByText("+ Add Section").first().click();
  await page.waitForTimeout(800);
  await page.locator(".ant-dropdown:visible, .ant-select-dropdown:visible, .ant-popover:visible, .ant-modal:visible, .ant-drawer-open").getByText("Feature Section", { exact: true }).last().click();
  await page.waitForTimeout(1500);
  out.homeAfter = await tabText();
  // bring the newly added module and "+ Add Section" into view, like the original screenshot
  await drawer.getByText("+ Add Section").first().scrollIntoViewIfNeeded();
  await page.waitForTimeout(800);
  await page.screenshot({ path: "test-results/03-editor-add-section.new.png" });
  await page.locator("button.btn-action-cancel:visible").filter({ hasText: /^\s*Close\s*$/ }).last().click();
  await page.waitForTimeout(1000);
  out.closed = true;
});
