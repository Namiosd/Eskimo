// ESKIMO-383 / EP-6055 – Admin › Partner PN105327 › Corporate Program (Type = White label) must have the AC1 fields
// of EP-5991 (AC revised for phase 1: Eskimo Stripe Pay and No Expiry hidden; Stripe status Not Connected / Verified).
// Test cases: testcases/ESKIMO-383/ESKIMO-383.md
//   TC-01 Corporate Program section opens: Status, Type = White label (disabled), Start/End Date (precondition)
//   TC-02 Data Expiry dropdown: "2 Years" selectable, "No Expiry" not selectable in phase 1 (hidden or disabled)
//   TC-03 Eskimo Email Notification is a True/False toggle
//   TC-04 Payment method: "Direct Charge" selectable, "Eskimo Stripe Pay" not selectable (hidden or disabled), no "Direct Credit Top Up"
// "Hidden in phase 1" (AC) is accepted as hidden OR disabled: the point is it cannot be chosen (agreed with QC 2026-10-19).
//   TC-05 Stripe Connect Status of an unconnected partner = "Not Connected", or "—" + the "connects Stripe from the
//         Partner portal" hint when the partner never started connecting (no status yet; accepted by QC 2026-10-19)
//   TC-06 No "Network Partner Commission (%)" for White Label
//   TC-07 "Application Fee Percentage" section shown (AC3)
// Read-only: nothing is saved.
// Evidence: evidence/ESKIMO-383-white-label-corporate-fields → npm run report:evidence -- ESKIMO-383 white-label-corporate-fields
import { test, expect, type BrowserContext, type Locator, type Page } from "@playwright/test";
import { adminSession, openPartnerDrawer } from "../_support/eskimo";
import { createEvidence } from "../_support/evidence";

const ID = "@ESKIMO-383";
const AC = "EP-6055 / AC1 EP-5991";
const PARTNER = process.env.E2E_WL_DEV_PARTNER_CODE || "PN105327";
const evidence = createEvidence("ESKIMO-383", "white-label-corporate-fields");

const mark = (l: Locator) => l.evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322" })).catch(() => {});

/** Corporate Program body = the 2nd div after its header (same JSX order as PartnerCorporate.js). */
const corporateHeader = (drawer: Locator) => drawer.locator(".header-member-view-detail").filter({ hasText: "Corporate Program" }).first();
const corporateBody = (drawer: Locator) => corporateHeader(drawer).locator("xpath=following-sibling::div[2]");
const formItem = (scope: Locator, label: RegExp) =>
  scope.locator(".ant-form-item").filter({ has: scope.page().locator(".ant-form-item-label label", { hasText: label }) }).first();

async function readOptions(page: Page, item: Locator) {
  const sel = item.locator(".ant-select").first();
  await sel.scrollIntoViewIfNeeded();
  await sel.locator(".ant-select-selector").click();
  const dd = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last();
  await dd.waitFor({ state: "visible", timeout: 8000 });
  const opts = dd.locator(".ant-select-item-option");
  const out: { text: string; disabled: boolean }[] = [];
  for (let i = 0; i < (await opts.count()); i++) {
    out.push({
      text: (await opts.nth(i).innerText()).trim(),
      disabled: await opts.nth(i).evaluate((el) => el.classList.contains("ant-select-item-option-disabled") || el.getAttribute("aria-disabled") === "true"),
    });
  }
  return out;
}
const selectable = (opts: { text: string; disabled: boolean }[]) => opts.filter((o) => !o.disabled).map((o) => o.text);
const describeOpts = (opts: { text: string; disabled: boolean }[]) => opts.map((o) => (o.disabled ? `${o.text} (disabled)` : o.text)).join(" / ");
const closeDropdown = async (page: Page) => {
  await page.keyboard.press("Escape");
  await page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").last().waitFor({ state: "hidden", timeout: 3000 }).catch(() => {});
};
const labels = async (body: Locator) => (await body.locator(".ant-form-item-label label").allInnerTexts()).map((t) => t.trim()).filter(Boolean);

// Not serial: a product failure must not skip the other cases. After a failure the worker restarts and
// beforeAll re-opens the drawer, so every test has its own fresh form.
test.describe(`ESKIMO-383 White Label Corporate Program fields ${ID}`, () => {
  let ctx: BrowserContext;
  let page: Page;
  let drawer: Locator;
  let body: Locator;
  let detail: any;

  test.beforeAll(async ({ browser }) => {
    test.setTimeout(240_000);
    ({ ctx, page } = await adminSession(browser));
    await page.setViewportSize({ width: 1600, height: 1000 });
    ({ drawer, detail } = await openPartnerDrawer(page, PARTNER));
    await corporateHeader(drawer).scrollIntoViewIfNeeded();
    body = corporateBody(drawer);
    await body.waitFor({ state: "visible", timeout: 15000 });
  });
  test.afterAll(async () => { await ctx?.close(); });

  test(`TC-01 Corporate Program section of ${PARTNER}, Type = White label ${ID}`, async ({}, testInfo) => {
    test.setTimeout(240_000);
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Corporate Program White label");
    // Partners › search PARTNER › Edit › Corporate Program: done in beforeAll
    await corporateHeader(drawer).scrollIntoViewIfNeeded();
    const typeItem = formItem(body, /^\s*Type\s*$/);
    const typeText = (await typeItem.locator(".ant-select-selection-item").first().innerText({ timeout: 5000 }).catch(() => "")).trim();
    const disabled = (await typeItem.locator(".ant-select-disabled").count()) > 0;
    const fields = await labels(body);
    // Status is the switch in the row right after the section header (outside the form body)
    const statusRow = corporateHeader(drawer).locator("xpath=following-sibling::div[1]");
    const hasStatus = /Status/.test(await statusRow.innerText().catch(() => "")) && (await statusRow.locator(".ant-switch").count()) > 0;
    const missing = [...(hasStatus ? [] : ["Status"]), ...["Type", "Start Date", "End Date"].filter((f) => !fields.includes(f))];
    console.log(`[INFO] ${PARTNER} = ${detail?.partnerName ?? "?"}; Type="${typeText}" disabled=${disabled}; fields: ${fields.join(" | ")}`);
    const ok = /white\s*label/i.test(typeText) && disabled && missing.length === 0;
    await mark(typeItem);
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: `Corporate Program of ${PARTNER}: Type = "${typeText}"`,
      steps: ["Admin STAGE → Partnership › Partners", `Search ${PARTNER} → Edit`, "Scroll to Corporate Program"],
      expected: ['Status, Type = "White label" (disabled), Start Date, End Date shown', `Fields on screen: ${fields.join(", ")}`],
      status: ok ? undefined : "failed",
    });
    expect(typeText, "Corporate Program Type").toMatch(/white\s*label/i);
    expect(disabled, "Type is disabled").toBe(true);
    expect(missing, "missing fields").toEqual([]);
  });

  test(`TC-02 Data Expiry: "2 Years" selectable, "No Expiry" not selectable (phase 1) ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-02 Data Expiry");
    const item = formItem(body, /Data Expiry/i);
    const present = await item.isVisible().catch(() => false);
    const opts = present ? await readOptions(page, item) : [];
    const options = selectable(opts);
    const ok = present && options.includes("2 Years") && !options.includes("No Expiry");
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: present ? `Data Expiry options: ${describeOpts(opts)}` : "Data Expiry field NOT present",
      steps: ["Corporate Program form (Type = White label)", 'Find "Data Expiry", open the dropdown'],
      expected: ['"Data Expiry" dropdown shown', 'Option "2 Years"', '"No Expiry" cannot be selected (hidden or disabled in phase 1)'],
      status: ok ? undefined : "failed",
    });
    if (present) await closeDropdown(page);
    expect(present, '"Data Expiry" field in Corporate Program').toBe(true);
    expect(options, "selectable Data Expiry options").toContain("2 Years");
    expect(options, '"No Expiry" not selectable in phase 1').not.toContain("No Expiry");
  });

  test(`TC-03 Eskimo Email Notification toggle ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-03 Email Notification");
    const item = formItem(body, /Email Notification/i);
    const present = await item.isVisible().catch(() => false);
    const sw = item.locator(".ant-switch").first();
    const isSwitch = present && (await sw.count()) > 0;
    const on = isSwitch ? await sw.evaluate((el) => el.classList.contains("ant-switch-checked")) : null;
    if (present) { await item.scrollIntoViewIfNeeded(); await mark(item); }
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: present ? `Eskimo Email Notification: switch=${isSwitch} (on=${on})` : "Eskimo Email Notification NOT present",
      steps: ["Corporate Program form (Type = White label)", 'Find "Eskimo Email Notification"'],
      expected: ['"Eskimo Email Notification" shown as a True/False toggle', `Saved value (API): ${detail?.configuration?.corporateSetting?.isEskimoEmailNotificationEnabled}`],
      status: isSwitch ? undefined : "failed",
    });
    expect(present, '"Eskimo Email Notification" field').toBe(true);
    expect(isSwitch, "is a toggle (switch)").toBe(true);
  });

  test(`TC-04 Payment method: "Direct Charge" selectable, "Eskimo Stripe Pay" not (phase 1) ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-04 Payment method");
    const item = formItem(body, /^\s*Payment method\s*$/i);
    await expect(item, '"Payment method" field').toBeVisible();
    const opts = await readOptions(page, item);
    const options = selectable(opts);
    const all = opts.map((o) => o.text);
    const ok = options.includes("Direct Charge") && !options.includes("Eskimo Stripe Pay") && !all.includes("Direct Credit Top Up");
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: `Payment method options: ${describeOpts(opts)}`,
      steps: ["Corporate Program form (Type = White label)", 'Open the "Payment method" dropdown'],
      expected: ['Option "Direct Charge"', '"Eskimo Stripe Pay" cannot be selected (hidden or disabled in phase 1)', 'No "Direct Credit Top Up" (old Corporate/Reseller logic)'],
      status: ok ? undefined : "failed",
    });
    await closeDropdown(page);
    expect(options, "selectable Payment method options").toContain("Direct Charge");
    expect(options, '"Eskimo Stripe Pay" not selectable in phase 1').not.toContain("Eskimo Stripe Pay");
    expect(all).not.toContain("Direct Credit Top Up");
  });

  test(`TC-05 Stripe Connect Status of an unconnected partner = "Not Connected" (or "—" + hint if never started) ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-05 Stripe Connect Status");
    const stripe = formItem(body, /Stripe Connect/i);
    const shown = await stripe.isVisible().catch(() => false);
    // the value reads "Loading…" until the website's stripeConnect arrives
    if (shown) await expect(stripe).not.toContainText("Loading", { timeout: 30000 }).catch(() => {});
    const status = shown ? (await stripe.locator(".ant-form-item-control").innerText()).replace(/\s+/g, " ").trim() : "";
    // Never-started partner: no Stripe status exists yet → "—" + hint is accepted as "not connected" (QC 2026-10-19)
    const notConnected = /\bNot Connected\b/i.test(status) || /^—\s*The partner connects Stripe from the Partner portal/i.test(status);
    const ok = shown && notConnected;
    if (shown) { await stripe.scrollIntoViewIfNeeded(); await mark(stripe); }
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: shown ? `Stripe Connect Status: "${status}"` : "Stripe Connect Status NOT shown",
      steps: ["Corporate Program form (Type = White label)", `Read "Stripe Connect Status" (${PARTNER} has not connected Stripe)`],
      expected: ['Stripe Connect Status shown', 'Not connected → "Not Connected" (verified → "Verified")', 'Accepted (QC 2026-10-19): partner never started connecting → no status yet → "—" + hint "The partner connects Stripe from the Partner portal (My Website)."'],
      status: ok ? undefined : "failed",
    });
    expect(shown, "Stripe Connect Status shown").toBe(true);
    expect(notConnected, `Stripe Connect Status of an unconnected partner: "${status}"`).toBe(true);
  });

  test(`TC-06 No Network Partner Commission for White Label ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-06 No Network Partner Commission");
    const text = await body.innerText();
    const ok = !/Network Partner Commission/i.test(text);
    await corporateHeader(drawer).scrollIntoViewIfNeeded();
    await evidence.saveScreenshot(page, testInfo, {
      ac: AC, title: ok ? "Network Partner Commission (%) not shown" : "Network Partner Commission (%) IS shown",
      steps: ["Corporate Program form (Type = White label)", 'Look for "Network Partner Commission (%)"'],
      expected: ["Network Partner Commission (%) not applied / not shown for White Label"],
      status: ok ? undefined : "failed",
    });
    expect(text).not.toMatch(/Network Partner Commission/i);
  });

  test(`TC-07 Application Fee Percentage section shown (AC3) ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-07 Application Fee Percentage");
    const section = body.getByText("Application Fee Percentage", { exact: true }).first();
    const shown = await section.isVisible().catch(() => false);
    if (shown) { await section.scrollIntoViewIfNeeded(); await mark(section); }
    await evidence.saveScreenshot(page, testInfo, {
      ac: "EP-6055 / AC3 EP-5991", title: shown ? '"Application Fee Percentage" section shown' : '"Application Fee Percentage" NOT shown',
      steps: ["Corporate Program form (Type = White label)", 'Look for "Application Fee Percentage"'],
      expected: ['"Application Fee Percentage" section shown when Type = White Label'],
      status: shown ? undefined : "failed",
    });
    expect(shown, '"Application Fee Percentage" section').toBe(true);
  });
});
