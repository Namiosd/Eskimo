# ESKIMO-388 – [EP-6063] Merchant Fixed Discount validate theo giá plan

Môi trường: STG (Admin = E2E_ADMIN_URL, Partner = E2E_PARTNER_URL)
Partner test: partnerofduc (merchant, login = E2E_PARTNER_EMAIL)
Plan mục tiêu: plan "Unlimited Vietnam …" giá $16.00 (thuộc rule "Any Unlimited Vietnam")

Quyết định QC (2026-10-13):
- TC-01: FE chỉ cảnh báo; lưu được hay không là do BE → chỉ GHI NHẬN kết quả Save, không assert.
- TC-03, TC-04: chỉ đọc giá trên form Purchase Voucher, KHÔNG submit mua.
- TC-05: mua thật 1 voucher để kiểm tra Remaining Credits (tăng = bug).

## TC-01 Admin: cảnh báo khi Fixed Discount lớn hơn giá plan
- Preconditions: Đăng nhập Admin STG; partner merchant "partnerofduc" có Merchant Program
- Steps:
  1. Admin → Partnership → Partners → mở partnerofduc → Merchant Program
  2. Discount Benefit → Add row: Apply to "Any Unlimited Vietnam", type "Fixed Discount ($US)", value 456789
  3. Bấm Save
- Expected: Hiện warning "<plan> final bill < 1" cho các plan bị ảnh hưởng. Kết quả Save (BE cho lưu hay chặn) được ghi lại, không tính pass/fail.

## TC-02 Admin: giá trị hợp lệ vẫn lưu được
- Preconditions: như TC-01
- Steps: Rule "Any Unlimited Vietnam" Fixed Discount value = 5, bấm Save, mở lại partner
- Expected: Lưu thành công, row hiển thị Fixed Discount = 5

## TC-03 Partner: Discount Price không bao giờ âm
- Preconditions: Rule Fixed Discount 456789 đã lưu được ở TC-01 (BE chặn lưu → case này skip)
- Steps:
  1. Partner Portal (partnerofduc) → Vouchers → Purchase Voucher
  2. Chọn plan $16.00 thuộc "Any Unlimited Vietnam" (KHÔNG submit)
- Expected: Discount Price >= 0 (không âm) trên form và trong API

## TC-04 Partner: discount bình thường tính đúng
- Preconditions: Rule Fixed Discount = 5 (TC-02)
- Steps: Purchase Voucher → chọn plan $16.00 (KHÔNG submit)
- Expected: Discount Price = $11.00 (= giá plan − 5)

## TC-05 Partner: Remaining Credits sau khi mua voucher
- Preconditions: Rule Fixed Discount 456789 đã lưu được ở TC-01 (BE chặn lưu → case này skip)
- Steps:
  1. Ghi lại Remaining Credits
  2. Purchase Voucher → chọn plan $16.00, Quantity 1 → Submit
  3. Đọc lại Remaining Credits
- Expected: Remaining Credits KHÔNG tăng (tăng = bug); số bị trừ đúng bằng Discount Price của voucher và không vượt giá plan

> TC-05 mua thật 1 voucher → trừ credit partner test. Chỉ chạy STG. Cleanup: xoá/khôi phục rule "Any Unlimited Vietnam" sau khi chạy.
