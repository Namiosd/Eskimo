// Bug evidence (ESKIMO-757 / EP-5991 AC1): Data Expiry "No Expiry" is not saved for a White Label program.
// FE (Admin) reads/sends corporateSetting.isNoExpiryDataPlan; BE stores corporateSetting.dataExpiryType (enum, 1 = NoExpiry).
// Partner: WLBe2e (own test partner, STAGING). Snapshot first, restored + verified at the end.
// Evidence: evidence/ESKIMO-757-bug-data-expiry → npm run report:evidence -- ESKIMO-757 bug-data-expiry
import { test, expect } from "@playwright/test";
import { ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import {
  api, tokenOf, apiMessage, findPartner, readPartner, restorePartner, corporateBody, formItem, focus,
  openCorporate, choose, selected, clickOk, findKeys, adminSessionRetry as adminSession, type PartnerState,
} from "../_support/whitelabel";

const ID = "@ESKIMO-757";
const AC = "EP-5991 AC1";
const evidence = createEvidence("ESKIMO-757", "bug-data-expiry");
const WLB = process.env.E2E_WL_TEST_PARTNER || "WLBe2e";
const table = (head: string[], rows: unknown[][]) =>
  `<table><tr>${head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr>${rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("")}</table>`;

test(`BUG Data Expiry "No Expiry" not saved (FE isNoExpiryDataPlan vs BE dataExpiryType) ${ID}`, async ({ browser }, testInfo) => {
  test.setTimeout(10 * 60 * 1000);
  evidence.resetIfFirstAttempt(testInfo);
  const { ctx, page } = await adminSession(browser);
  const scratch = await (await browser.newContext()).newPage();
  const card = (heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) => evidence.saveDataCard(scratch, testInfo, heading, html, meta);
  let state: PartnerState | null = null;
  try {
    const token = await tokenOf(page);
    const p = await findPartner(token, WLB);
    expect(p, `partner ${WLB}`).toBeTruthy();
    const before = await readPartner(token, p!);
    state = { ...p!, snapshot: before.snap, setting: before.detail?.configuration?.corporateSetting ?? null, fee: before.fee };

    evidence.setCase("1. Admin UI: select No Expiry and save");
    const o = await openCorporate(page, WLB);
    await choose(page, formItem(o.body, "Data Expiry"), "No Expiry");
    await focus(formItem(o.body, "Data Expiry"));
    await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "1.1 Data Expiry = No Expiry selected, before Ok", steps: [`Admin ${ADMIN_URL} › Partnership › Partners › ${WLB} (${p!.code}) › Edit`, "Corporate Program (Type White label) › Data Expiry → No Expiry"], expected: ["Ready to save"] });
    const saved = await clickOk(page, o.drawer);
    state.feBody = saved.reqBody;
    const sent = findKeys(saved.reqBody, /expir/i);
    const afterUi = await readPartner(token, p!);
    const stored = findKeys(afterUi.detail?.configuration, /expir/i);
    await card("1.2 FE request vs what the BE stored", table(["", "Value"], [
      ["PUT /api/partner/v2 (sent by Admin FE)", `${saved.status} ${saved.message}`],
      ["Data Expiry keys in the FE request body", sent.join(", ") || "none"],
      ["Data Expiry keys in GET /api/partner/v2/{id} afterwards", stored.join(", ") || "none"],
    ]), { ac: AC, title: "1.2 DATA FE sends isNoExpiryDataPlan, BE keeps dataExpiryType = null", steps: [`FE request: ${sent.join(", ")}`, `GET after save: ${stored.join(", ")}`], expected: ["No Expiry stored"], status: "failed" });

    const r1 = await openCorporate(page, WLB);
    const shown1 = await selected(formItem(r1.body, "Data Expiry"));
    await focus(formItem(r1.body, "Data Expiry"));
    await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "1.3 Reopened after save: Data Expiry", steps: ["Close, reload, reopen the partner", `Data Expiry shown: "${shown1}"`], expected: ['"No Expiry"'], status: shown1 === "No Expiry" ? undefined : "failed" });

    evidence.setCase("2. BE contract check: save dataExpiryType directly");
    const probes: unknown[][] = [];
    for (const [label, extra] of [["isNoExpiryDataPlan: true (FE field)", { isNoExpiryDataPlan: true }], ["dataExpiryType: 1", { dataExpiryType: 1 }]] as const) {
      const setting = { ...state.setting, ...extra };
      const r = await api(token, "PUT", "/api/partner/v2", corporateBody(state.feBody, true, setting), 2);
      const got = findKeys((await readPartner(token, p!)).detail?.configuration, /expir/i);
      probes.push([label, `${r.status} ${apiMessage(r.json)}`, got.join(", ")]);
    }
    await card("2.1 BE stores dataExpiryType, ignores isNoExpiryDataPlan", table(["corporateSetting sent (PUT /api/partner/v2)", "PUT", "GET afterwards"], probes) + "<p>BE enum: the string \"NoExpiry\" is stored as 1 → 1 = No Expiry.</p>",
      { ac: AC, title: "2.1 DATA BE contract = dataExpiryType", steps: probes.map((x) => `${x[0]} → ${x[2]}`), expected: ["The FE field is the one the BE stores"], status: "failed" });

    // BE now holds dataExpiryType = 1 (No Expiry): does the Admin form show it?
    const r2 = await openCorporate(page, WLB);
    const shown2 = await selected(formItem(r2.body, "Data Expiry"));
    await focus(formItem(r2.body, "Data Expiry"));
    await evidence.saveScreenshot(page, testInfo, { ac: AC, title: "2.2 BE has dataExpiryType = 1 (No Expiry): what the Admin form shows", steps: ["GET /api/partner/v2/{id} → corporateSetting.dataExpiryType = 1", "Reopen the partner", `Data Expiry shown: "${shown2}"`], expected: ['"No Expiry" (form reads the stored value)'], status: shown2 === "No Expiry" ? undefined : "failed" });

    await card("Summary — root cause", table(["Side", "Field used", "Behaviour"], [
      ["Admin FE (bundle: Form.Item name \"isNoExpiryDataPlan\", false = 2 Years, true = No Expiry)", "corporateSetting.isNoExpiryDataPlan", `sends it on save; reads it on load → shows "${shown2}" even when the BE holds No Expiry`],
      ["BE (GET/PUT /api/partner/v2)", "corporateSetting.dataExpiryType (enum, 1 = NoExpiry)", "stores dataExpiryType; ignores isNoExpiryDataPlan"],
    ]) + "<p><b>Fix (FE):</b> map the Data Expiry dropdown to corporateSetting.dataExpiryType (confirm with BE the value for \"2 Years\").</p>",
      { ac: AC, title: "Summary FE/BE field mismatch", steps: ["FE: isNoExpiryDataPlan", "BE: dataExpiryType"], expected: ["Same field on both sides"], status: "failed" });
  } finally {
    if (state) {
      evidence.setCase("3. Cleanup");
      const r = await restorePartner(await tokenOf(page), state);
      await card("3. Restore WLBe2e to the snapshot", table(["Field", "Snapshot", "Now"], Object.keys(state.snapshot).map((k) => [k, JSON.stringify(state!.snapshot[k]), JSON.stringify(r.now.snap[k])])) + `<p>${esc(r.notes.join(" · ") || "already equal")}</p>`,
        { ac: AC, title: "3. Restore WLBe2e (cleanup)", steps: r.notes.length ? r.notes : ["Already equal to the snapshot"], expected: ["Equal to the snapshot"], status: r.ok ? undefined : "failed" });
      console.log(`[bug-data-expiry] restore WLBe2e: ${r.ok ? "OK (verified)" : "NOT VERIFIED"} ${r.notes.join(" · ")}`);
    }
    await scratch.context().close();
    await ctx.close();
  }
});
