import { defineConfig, devices } from "@playwright/test";

// Local settings (URL, test accounts) live in .env next to this file, never in git or in prompts.
try {
  process.loadEnvFile(".env");
} catch {
  // no .env: rely on the shell environment
}

const baseURL = process.env.E2E_BASE_URL;
if (!baseURL) throw new Error("Set E2E_BASE_URL (in .env or the shell) to the test environment URL");

export default defineConfig({
  testDir: "tests",
  timeout: 60_000,
  expect: { timeout: 10_000 },
  retries: 0, // a flaky test must be fixed, not retried into green
  workers: 2,
  reporter: [["list"], ["html", { open: "never" }], ["json", { outputFile: "test-results/results.json" }]],
  use: {
    baseURL,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
});
