# ESKIMO-757 – [EP-5991] [Admin] Configure White Label under Corporate Program in partnership

Nguồn: AC1–AC4 của item ESKIMO-757 (đọc lại 2026-10-15; AC1 Stripe Connect = "Not Connected" / "Verified").
Cập nhật 2026-10-16 (BA sửa AC1): "Eskimo Stripe Pay" và "No Expiry" = hide on phase 1 → TC-02 / TC-03 đổi expected.
Quyết định QC 2026-10-16:
- AC4 TC-12/13/14: expected = WEBSITE (storefront) bị disable. API /api/white-label/websites/mine chỉ dùng phía Partner Portal
  (JWT partner) → chỉ ghi nhận, không tính pass/fail.
- Data Expiry: FE đang thêm lại field → TC-03 (và mục Data Expiry của TC-01) = PENDING; chạy lại khi FE xong
  (bỏ E2E_757_DATA_EXPIRY_PENDING).
Môi trường: STAGING — Admin = E2E_ADMIN_URL (https://app-eskimo-admin-stage-sea-001.azurewebsites.net), API = E2E_API_URL (stage),
partner portal = E2E_PARTNER_URL (stage), storefront = E2E_WL_URL (https://wellatsea.eskimo.travel → Partner 2)

Partner:
- WLBe2e (PN847236) — partner test riêng, dùng cho các thay đổi cấu hình (AC1–AC3). Snapshot trước, restore sau.
- WhiteLabel Partner 2 (PN101609) — partner duy nhất có storefront, dùng cho AC4 (website/API). Snapshot trước, restore + verify sau.
- Partner login cho kiểm API (AC4): E2E_WL_PARTNER_EMAIL / E2E_WL_PARTNER_OTP (= Partner 2)

Quyết định QC (2026-10-15):
- KHÔNG mua hàng mới (giữ mua cho flow journey). AC2/AC3 phần business (mail theo toggle, fee trên giao dịch thật)
  dùng lại evidence 2026-10-09 (EP-5991-white-label-business report: B1 WARNING mail QR, B2 PASS, B3 PASS) → TC ghi nhận, không chạy lại.
- Không bấm "Continue to payment".
- Storefront cache ~5 phút (BE) → kiểm storefront với request không cache, lặp 60s, tối đa 10 phút.

## AC1 — White Label Program Configuration

## TC-01 Form có đủ field khi Type = White Label
- Steps: Admin → Partnership › Partners → Edit WLBe2e → Corporate Program
- Expected: có Status, Type = White label, Start Date, End Date, Eskimo Email Notification toggle, Application Fee,
  Payment Method, Data Expiry dropdown, Stripe Connect Status

## TC-02 Payment Method: Direct Charge (Eskimo Stripe Pay ẩn ở phase 1)
- Steps: mở dropdown Payment Method; chọn Direct Charge → Ok → mở lại
- Expected: chỉ có lựa chọn Direct Charge (Eskimo Stripe Pay không hiển thị — hide on phase 1); Direct Charge được lưu

## TC-03 Data Expiry: 2 Years (No Expiry ẩn ở phase 1)
- Steps: mở dropdown Data Expiry; chọn 2 Years → Ok → mở lại
- Expected: chỉ có lựa chọn "2 Years" ("No Expiry" không hiển thị — hide on phase 1); 2 Years được lưu

## TC-04 Stripe Connect Status
- Steps: xem Stripe Connect của (a) 1 partner White Label CHƯA kết nối Stripe, (b) 1 partner đã xác minh Stripe (Partner 2) — chỉ xem, không lưu
- Expected: (a) "Not Connected"; (b) "Verified"

## TC-05 Network Partner Commission (%) không áp dụng cho White Label
- Steps: xem Corporate Program của WLBe2e (Type White label)
- Expected: Network Partner Commission (%) không hiển thị / không áp dụng

## AC2 — Eskimo Email Notification toggle

## TC-06 Mặc định False
- Steps: Partners → New Partner → bật Corporate Program → Type = White label → xem toggle (KHÔNG lưu, đóng form)
- Expected: Eskimo Email Notification = OFF (False)

## TC-07 Lưu True / False
- Steps: WLBe2e: bật toggle → Ok → mở lại; tắt toggle → Ok → mở lại
- Expected: giá trị True / False được lưu

## TC-08 True → Eskimo gửi mail; False → Eskimo không gửi (ghi nhận evidence 2026-10-09)
- Không chạy lại (không mua mới). Evidence: B1 (True: có mail purchase, chưa thấy mail QR trong 6 phút → WARNING), B2 (False: không có mail → PASS)

## AC3 — Application Fee Logic

## TC-09 Hiện "Application Fee Percentage" khi Type = White Label
- Steps: xem Corporate Program của WLBe2e
- Expected: section "Application Fee Percentage" hiển thị

## TC-10 Lưu Application Fee % và áp dụng
- Steps: nhập 90 → Ok → mở lại; kiểm fee hiệu lực (API stripeConnect.platformFeePercent)
- Expected: fee 90% được lưu; Application Fee = giá × 90%, Partner Benefit = giá × 10% (vd. USD 100 → 90 / 10)

## TC-11 Fee trên giao dịch thật (ghi nhận evidence 2026-10-09)
- Không chạy lại. Evidence: B3 — fee 10% → WHI 0.39 / US$3.90; fee 20% → WHI 0.78 / US$3.90 (PASS)

## AC4 — Program Availability & Configuration Persistence (Partner 2, snapshot/restore)

## TC-12 Status Disabled → partner không truy cập được website / API
- Steps: Partner 2 → Status OFF → Ok; kiểm storefront (không cache, ≤10 phút) + GET /api/white-label/websites/mine (partner JWT)
- Expected: storefront (website) không dùng được ("This store isn't available" / không có data plan). Ghi nhận thêm: API Partner Portal /websites/mine (không tính pass/fail)

## TC-13 Trước Start Date → không truy cập được website / API
- Steps: Partner 2 → Start Date = ngày mai → Ok (hoặc API nếu UI khóa ngày); kiểm storefront + API như TC-12
- Expected: storefront (website) không dùng được ("This store isn't available" / không có data plan). Ghi nhận thêm: API Partner Portal /websites/mine (không tính pass/fail)

## TC-14 Sau End Date → không truy cập được website / API
- Steps: Partner 2 → End Date = hôm qua (API nếu UI chặn ngày quá khứ); kiểm storefront + API
- Expected: storefront (website) không dùng được ("This store isn't available" / không có data plan). Ghi nhận thêm: API Partner Portal /websites/mine (không tính pass/fail)

## TC-15 Bật lại → giữ nguyên toàn bộ cấu hình, không cần cấu hình lại
- Steps: sau TC-12 bật Status ON → Ok (không sửa gì); sau TC-13/14 đặt lại ngày gốc; mở lại partner
- Expected: Start Date, End Date, Application Fee, Email, Payment Method, các setting khác giữ nguyên; storefront dùng lại được
