# Partner CMS: đề xuất cải thiện FE cho phase sau

| | |
|---|---|
| **Gửi** | Team FE (Partner Portal `eskimo_portal` + storefront `eskimo-whitelabel-storefront`) |
| **Nguồn** | QC ticket ESKIMO-752 / EP-5964, quá trình cấu hình site-l19wef giống eskimo.travel, và khi viết guideline cho khách (`02-partner-cms-setup-guide.md`) |
| **Phiên bản kiểm tra** | Portal `develop` 13/10/2026 (QA build), storefront `0afa49f` 14/10/2026 |
| **Ngày** | 16/10/2026 |

Mức ưu tiên:
- **P1**: partner dễ mất dữ liệu hoặc website hiển thị sai thương hiệu.
- **P2**: gây nhầm, phải giải thích dài trong guideline.
- **P3**: tiện ích, nên có.

Mỗi mục bên dưới đều là chỗ guideline cho khách đang phải cảnh báo hoặc giải thích. Sửa xong mục nào thì bỏ được đoạn tương ứng trong guideline.

---

## Tóm tắt

| ID | Ưu tiên | Vấn đề | Đề xuất ngắn |
|---|---|---|---|
| CMS-01 | P1 | Không cảnh báo khi rời trang mà chưa lưu | Chặn rời trang khi còn thay đổi chưa lưu, kèm hộp xác nhận |
| CMS-02 | P1 | Hai nút "Save" khác nghĩa (modal và Save Page) | Đổi nút modal thành **Apply**, hiện trạng thái "Unsaved changes" |
| CMS-03 | P1 | Header/Footer phải sửa 5 lần, mỗi trang một bản | Header/Footer dùng chung cấp website |
| CMS-04 | P1 | Nội dung mặc định mang thương hiệu Eskimo | Default trung tính khi clone cho partner, cảnh báo khi còn chữ "Eskimo" |
| CMS-05 | P1 | Hình mặc định Install eSIM có logo/nhân vật Eskimo | Bộ hình mặc định trung tính |
| CMS-06 | P2 | Ô ảnh nền Banner trống nhưng website vẫn có ảnh; preview khác live | Hiện ảnh mặc định trong form và preview |
| CMS-07 | P2 | Liên kết bị ẩn âm thầm (URL trống, cột Footer trống) | Cảnh báo ngay trong form |
| CMS-08 | P2 | Liên kết sai chỉ cảnh báo khi mở modal | Tổng hợp cảnh báo trên canvas / trước khi lưu |
| CMS-09 | P2 | Ô tick "Show my text exactly as entered" khó hiểu; preview không phản ánh việc thay chữ | Preview hiển thị đúng như live, đánh dấu câu sẽ bị thay |
| CMS-10 | P2 | Tên module và nhóm icon còn chữ "Eskimo" | Đổi nhãn phía partner, ẩn nhóm icon Eskimo |
| CMS-11 | P2 | Không biết khi nào website thật cập nhật, không có nút mở website | Nút "Open website" + thông báo thời gian cập nhật |
| CMS-12 | P2 | Mã màu, Logo URL, Video URL không được kiểm tra | Validate định dạng ngay khi nhập |
| CMS-13 | P3 | Ô hình chỉ hiện URL, không có ảnh thu nhỏ | Thumbnail + nút xoá ảnh |
| CMS-14 | P3 | Không đổi được thứ tự dòng trong danh sách | Nút lên/xuống hoặc kéo thả |
| CMS-15 | P3 | Footer cố định 3 cột | Cho thêm/bớt cột |
| CMS-16 | P3 | Không có "Reset to default" / lịch sử phiên bản | Reset theo module, lưu lịch sử bản đã lưu |
| CMS-17 | P3 | Số module mỗi trang khác giữa Admin và Partner | Thống nhất cách đếm |
| BE-01 | P2 | Thông tin gói từ BE còn chữ "Eskimo" | (BE) dùng `{brand}` hoặc text trung tính |
| OPS-01 | P2 | Build staging cũ hơn QA | Deploy cùng phiên bản lên staging |

---

## Chi tiết

### CMS-01 (P1): Không cảnh báo khi rời trang mà chưa lưu

- **Hiện tại:**
  - Ở chế độ partner, drawer không có nút đóng.
  - Partner bấm sang menu khác, tải lại trang (F5) hoặc đăng xuất thì mọi thay đổi chưa bấm **Save Page** sẽ mất, không có hộp xác nhận nào.
- **Ảnh hưởng:** partner sửa nhiều module trên nhiều trang rồi mất hết. Guideline phải ghi cảnh báo đỏ.
- **Đề xuất:**
  - Khi `hasUnsavedChanges` = true:
    - thêm `beforeunload`;
    - thêm `<Prompt>` của react-router v5 (đổi route trong app);
    - chặn khi đổi menu sidebar.
  - Nội dung hộp xác nhận: "You have unsaved changes on N page(s). Leave without saving?"
- **Code:** [WebsiteStructureEditor.js](../../eskimo_portal/src/pages/WhiteLabel/StructureEditor/WebsiteStructureEditor.js), `hasUnsavedChanges` dòng 150.

### CMS-02 (P1): Hai nút "Save" khác nghĩa

- **Hiện tại:**
  - Nút **Save** trong modal *Configure …* chỉ cập nhật state và preview.
  - Nút **Save Page** mới gọi API.
  - Partner bấm Save trong modal, thấy preview đổi, tưởng đã lưu xong.
- **Đề xuất:**
  - Đổi `okText="Save"` của modal thành **Apply** (hoặc "Apply to preview").
  - Khi có thay đổi chưa lưu:
    - hiện badge "Unsaved changes" cạnh tên trang trên thanh Segmented (ví dụ `Home (12) •`);
    - nút Save Page đổi màu nổi bật.
- **Code:**
  - [ModuleConfigModal.js](../../eskimo_portal/src/pages/WhiteLabel/StructureEditor/ModuleConfigModal.js) dòng 365;
  - Segmented label ở WebsiteStructureEditor.js dòng 291.

### CMS-03 (P1): Header/Footer phải sửa 5 lần

- **Hiện tại:**
  - Mỗi trang có module `header`/`footer` riêng.
  - Storefront chỉ mượn Header/Footer của trang Home khi module của trang đó **trống hoàn toàn** (`fillEmptyChromeFromHome`).
  - Trang được clone từ template đều đã có nội dung mẫu, nên sửa ở Home **không** áp dụng sang trang khác.
  - Partner phải nhập lại menu, email hỗ trợ, mạng xã hội trên cả 5 trang. Rất dễ lệch giữa các trang.
- **Đề xuất (chọn 1):**
  - (a) Chuyển Header/Footer lên cấp website (giống `branding`): sửa 1 lần, áp dụng mọi trang. Storefront đọc từ cấp website.
  - (b) Giữ cấu trúc hiện tại, thêm checkbox **"Apply to all pages"** (mặc định bật) trong modal Header/Footer. Khi Apply thì ghi cùng config vào header/footer của mọi trang và đánh dấu các trang đó là dirty.
- **Code:**
  - storefront [whiteLabelPageData.js](../../eskimo-whitelabel-storefront/src/lib/whiteLabelPageData.js) dòng 84–101;
  - Portal `handleSaveModuleConfig` (WebsiteStructureEditor.js dòng 120).

### CMS-04 (P1): Nội dung mặc định mang thương hiệu Eskimo

- **Hiện tại:** website clone cho partner chứa nguyên nội dung của Eskimo. Guideline phải có cả một phụ lục "nội dung bắt buộc phải thay":

  | Vị trí | Nội dung mặc định |
  |---|---|
  | Footer → Support email | `support@eskimo.travel` |
  | Header → nav | *Free eSIM* `/free-esim`, *Partnerships* `/partnerships`, *Blog* `/blog`: storefront không có các trang này nên link tự ẩn |
  | Footer → Cột 2 *Partner with Us* | 6 link tới trang Eskimo (Affiliate, Corporate, Reselling, White-Labelling…) |
  | Footer → Cột 3 | Blog, Contact Us (không có trang) |
  | Reviews | 9 review thật của khách Eskimo, có nhắc tên "Eskimo"; heading "…use Eskimo" |
  | Banner / Plan Detail Hero → rating | `4.8`, *Trusted by 1,000,000+ travelers worldwide*, *2.1K+ ratings across Google Play & App Store* (số liệu của Eskimo) |

- **Đề xuất:**
  - Bộ default riêng cho website White Label, áp dụng khi clone cho partner:
    - support email để trống (bắt buộc nhập);
    - nav chỉ gồm các trang storefront có;
    - Footer bỏ cột Partner with Us;
    - Reviews và rating để trống hoặc dùng placeholder rõ ràng ("Your customer review here").
  - Cảnh báo trong CMS khi bất kỳ ô nào còn chữ "Eskimo" hoặc `eskimo.travel` (trừ tên miền của chính partner). Hiện ở thanh module như icon cảnh báo, kèm gợi ý dùng `{brand}`.
- **Code:** `defaultConfig` trong [ModuleTypes.js](../../eskimo_portal/src/pages/WhiteLabel/StructureEditor/ModuleTypes.js) (header dòng 59, reviews dòng 339, footer dòng 430), và template *Eskimo eCommerce (Default)* phía BE.

### CMS-05 (P1): Hình mặc định Install eSIM có thương hiệu Eskimo

- **Hiện tại:**
  - Hình hướng dẫn cài (iOS 4 bước, Android 4 bước) lấy từ eskimo.travel. Hình có:
    - logo Eskimo;
    - chữ "Eskimo";
    - sticker bàn tay chỉ và gấu mascot;
    - mã QR thật của Eskimo.
  - Khi cấu hình site-l19wef, QC phải tự làm mờ logo, xoá sticker trên 11 hình Android và thay QR bằng tay.
- **Đề xuất:**
  - Bộ hình mặc định trung tính: không logo, không mascot, QR minh hoạ ghi rõ "Sample".
  - Hoặc để trống ảnh mặc định: storefront đã hiện placeholder khi ảnh trống.

### CMS-06 (P2): Ảnh nền Banner: form trống nhưng website có ảnh, preview khác live

- **Hiện tại:**
  - Ô *Background image* trống thì storefront dùng ảnh nền mặc định trong CSS (ảnh người du lịch trên wellatsea).
  - Preview trong CMS lại hiện nền gradient xanh.
  - Partner không biết website đang có ảnh. Preview không giống website thật (xem `01-cms-workspace.png` và `13-storefront-home.png` trong `docs/images/partner-cms/`).
- **Đề xuất:**
  - Preview dùng cùng ảnh mặc định với storefront.
  - Trong form, ô trống hiện ghi chú/thumbnail "Default image in use".
- **Code:**
  - storefront [BannerModule.js](../../eskimo-whitelabel-storefront/src/components/whitelabel/modules/BannerModule.js) dòng 28–36, 93;
  - Portal [PagePreview.js](../../eskimo_portal/src/pages/WhiteLabel/StructureEditor/PagePreview.js).

### CMS-07 (P2): Liên kết bị ẩn âm thầm

- **Hiện tại:**
  - Link có URL trống thì storefront bỏ qua.
  - Cột Footer có mọi link trống thì ẩn cả cột.
  - Form không báo gì. Riêng link tới path storefront không hỗ trợ thì đã có cảnh báo (WL-05).
- **Đề xuất:**
  - Mở rộng `LinkUrlField`: URL trống cũng hiện hint "Empty URL — this link is hidden on the site".
  - Footer: khi mọi link của một cột đều trống thì hiện "This column is hidden on the site".
- **Code:**
  - `LinkUrlField` / `isStorefrontPath` (ModuleConfigModal.js dòng 95; [storefrontRoutes.js](../../eskimo_portal/src/pages/WhiteLabel/StructureEditor/storefrontRoutes.js) dòng 18 đang trả `true` cho chuỗi rỗng).

### CMS-08 (P2): Cảnh báo link chỉ thấy khi mở modal

- **Hiện tại:** default config chứa link không hợp lệ (CMS-04), nhưng partner chỉ thấy cảnh báo màu cam khi tự mở đúng modal đó.
- **Đề xuất:**
  - Icon cảnh báo trên thanh tiêu đề module (canvas) khi module có link không hợp lệ.
  - Hoặc hiện danh sách cảnh báo khi bấm Save Page (không chặn lưu).

### CMS-09 (P2): Ô tick "Show my text exactly as entered" khó hiểu

- **Hiện tại:**
  - Storefront tự thay/ẩn các câu trùng y hệt câu mẫu cũ của Eskimo (`legacyDefaults`).
  - Preview CMS **không** áp dụng việc này, nên chữ trên live khác chữ trong preview.
  - Partner phải hiểu cơ chế mới biết khi nào cần tick (guideline mất một mục riêng để giải thích).
- **Đề xuất:**
  - Preview áp dụng cùng logic de-branding với storefront: dùng chung danh sách hoặc copy sang Portal.
  - Câu nào sẽ bị thay thì gạch chân/tooltip "This template sentence will be replaced on the live site".
  - Lâu dài: khi CMS-04 có default trung tính thì có thể bỏ hẳn cơ chế này và ô tick.
- **Code:**
  - storefront `src/lib/legacyDefaults.js`;
  - Portal ModuleConfigModal.js dòng 384–394.

### CMS-10 (P2): Partner vẫn thấy chữ "Eskimo" trong CMS

- **Hiện tại:**
  - Nhãn module **"Transfer Data (Why Eskimo eSIM)"** hiện trên canvas và tiêu đề modal của partner.
  - Ô chọn icon của **mọi** module có nhóm **"Eskimo brand icons (moreReasonsGrid only)"**, dù ghi "moreReasonsGrid only".
- **Đề xuất:**
  - Ở partner mode, đổi nhãn thành "Transfer Data (Why us)".
  - Chỉ hiện nhóm brand icons ở module More Reasons Grid, đổi tên nhóm thành "Illustrated icons".
- **Code:**
  - ModuleTypes.js dòng 149;
  - ModuleConfigModal.js dòng 162 (`renderField` case `icon` không biết module type).

### CMS-11 (P2): Không biết khi nào website thật cập nhật

- **Hiện tại:**
  - Sau khi Save, toast chỉ ghi `Saved: "Home"`.
  - Storefront cache config website khoảng 30 giây (`resolveWebsite.js`, `CACHE_TTL_MS = 30s`); dữ liệu gói và quốc gia cache 5 phút.
  - CMS không có nút mở website thật. Thanh địa chỉ giả ghi *Domain not set yet* khi chưa có custom domain.
- **Đề xuất:**
  - Nút **Open website ↗** cạnh tên trang: mở `https://<domain>/<path>` của trang đang chọn. Chưa có domain thì mở link preview `?websiteId=`.
  - Toast sau khi lưu: "Saved. Changes appear on your live site within about 1 minute."

### CMS-12 (P2): Không validate mã màu, Logo URL, Video URL

- **Hiện tại:**
  - Ô hex màu chỉ giới hạn 7 ký tự. Nhập sai (ví dụ `#12`, `blue`) vẫn lưu được, storefront âm thầm quay về màu mặc định (`sanitizeHexColor` trong `theme.js`).
  - Logo URL và Video URL nhận chuỗi bất kỳ.
- **Đề xuất:**
  - Validate `^#[0-9a-fA-F]{6}$`. Logo/ảnh phải là `https://`. Video phải là link YouTube hoặc `.mp4`.
  - Báo lỗi đỏ dưới ô và chặn Apply/Save.
- **Code:**
  - [BrandingPanel.js](../../eskimo_portal/src/pages/WhiteLabel/StructureEditor/BrandingPanel.js) `ColorField`;
  - ModuleTypes.js dòng 241 (video).

### CMS-13 (P3): Ô hình không có ảnh thu nhỏ

- **Hiện tại:**
  - Ô hình chỉ hiện URL blob dài, bị cắt.
  - Ở Install eSIM Guide có tới 8 bước × 4 hình = 32 ô URL giống nhau, rất khó biết ô nào là hình nào.
- **Đề xuất:**
  - Thumbnail 48–64px cạnh ô, click để xem lớn.
  - Nút **✕** xoá ảnh.
  - Ghi kích thước khuyến nghị (ví dụ banner 1920×1080, bước cài đặt 424×500).
- **Code:** `ImageUploadField` (ModuleConfigModal.js dòng 39).

### CMS-14 (P3): Không đổi được thứ tự dòng trong danh sách

- **Hiện tại:** `ListField` chỉ có **+ Add** (thêm cuối) và **Remove**. Muốn chèn một câu FAQ hay một bước cài đặt vào giữa thì phải xoá rồi nhập lại tất cả.
- **Đề xuất:** nút ↑ / ↓ mỗi dòng (antd `Form.List` có sẵn `move`), hoặc kéo thả.
- **Code:** ModuleConfigModal.js dòng 223.

### CMS-15 (P3): Footer cố định 3 cột

- **Hiện tại:** form Footer hard-code `linkColumns[0..2]`. Không thêm hay bớt cột được; muốn bỏ một cột phải xoá trống từng link (CMS-07).
- **Đề xuất:** dùng list lồng (cột → link) với min 0, max 4.
- **Code:** ModuleTypes.js dòng 473–478.

### CMS-16 (P3): Không có reset hay lịch sử phiên bản

- **Đề xuất:**
  - Nút **Reset to default** trong từng modal: điền lại `defaultConfig` sau khi xác nhận.
  - Phía BE lưu vài bản đã lưu gần nhất để partner khôi phục khi lỡ tay.
  - Khi QC cấu hình site-l19wef, phải tự backup bằng API trước mỗi lần thay đổi lớn.

### CMS-17 (P3): Số module mỗi trang khác giữa Admin và Partner

- **Hiện tại:** Admin thấy `Home (13)` (có module `downloadApp` đã ngưng dùng), Partner thấy `Home (12)` vì module ngưng dùng bị ẩn. Hai guideline (Admin và Partner) phải ghi hai con số khác nhau.
- **Đề xuất:** Admin đếm không gồm module ngưng dùng (hoặc ghi `13, 1 retired`). Tốt hơn nữa là migrate xoá `downloadApp` khỏi các website hiện có.

---

## Ngoài phạm vi FE (chuyển team liên quan)

### BE-01 (P2): Thông tin gói từ BE còn chữ "Eskimo"

- **Hiện tại:**
  - Panel thông tin gói và trang checkout hiển thị câu *"If you're unable to install Eskimo eSIM…"*.
  - Câu này lấy từ dữ liệu gói (`additionalInfo`), partner không sửa được qua CMS.
  - Đây là chữ "Eskimo" đứng riêng duy nhất còn lại trên site-l19wef sau khi cấu hình.
- **Đề xuất:**
  - BE trả text trung tính hoặc có `{brand}` để storefront thay.
  - Hoặc storefront thay "Eskimo" bằng brand name khi render nội dung gói cho website White Label.

### OPS-01 (P2): Build staging Partner Portal cũ hơn QA

- **Hiện tại (ghi nhận 07/10/2026):** portal QA có Upload ảnh trong modal, form Install eSIM Guide, bảng so sánh sửa được dòng. Portal staging thì chưa có các tính năng này: ô ảnh banner chỉ có ô URL, không có nút Upload.
- **Ảnh hưởng:**
  - Guideline và ảnh chụp theo bản QA.
  - Partner dùng staging sẽ thấy giao diện khác tài liệu.
  - Spec e2e phải xử lý cả hai kiểu.
- **Đề xuất:** deploy cùng phiên bản lên staging trước khi giao guideline cho khách.
