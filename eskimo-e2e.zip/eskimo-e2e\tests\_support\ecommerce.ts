// Eskimo e-commerce web (STG) helpers, ported from eskimo_portal e2e (helpers/page-objects.js
// EcommerceSignupPage + ecommerce/end-user-agent-ui.spec.js loginEcom). Login = existing member by phone + OTP.
import { expect, type Browser, type BrowserContextOptions, type Page } from "@playwright/test";

export const ECOM_URL = (process.env.E2E_ECOM_URL || "https://app-eskimo-www-stage-sea-001.azurewebsites.net").replace(/\/$/, "");

// Turnstile + reCAPTCHA mock (STG accepts any captcha token). Must run before the first goto.
export async function bypassCaptcha(page: Page) {
  await page.route("**/challenges.cloudflare.com/**", (route) => route.abort());
  await page.addInitScript((token) => {
    const w = window as any;
    w.turnstile = {
      ready: (cb: () => void) => setTimeout(cb, 0),
      render: (_el: unknown, o: any) => { if (o?.callback) setTimeout(() => o.callback(token), 100); return "mock"; },
      reset: () => {}, remove: () => {}, getResponse: () => token, isExpired: () => false,
      execute: (_c: unknown, o: any) => { if (o?.callback) setTimeout(() => o.callback(token), 100); },
    };
    w.grecaptcha = { ready: (cb: () => void) => setTimeout(cb, 0), execute: () => Promise.resolve(token), render: () => 0, getResponse: () => token };
    w.grecaptcha_enterprise = w.grecaptcha;
    let n = 0;
    const poll = () => {
      if (typeof w.onloadTurnstileCallback === "function") w.onloadTurnstileCallback();
      else if (n++ < 150) setTimeout(poll, 100);
    };
    setTimeout(poll, 1000);
  }, "playwright-bypass-token");
}

export async function dismissCampaignPopup(page: Page) {
  // Mobile: "Open the Eskimo app?" sheet → stay on the web.
  const stay = page.getByRole("button", { name: "No, browse here" });
  if (await stay.isVisible().catch(() => false)) await stay.click().catch(() => {});
  const popup = page.locator(".custom-campaign-pop-up").first();
  if (await popup.waitFor({ state: "visible", timeout: 3000 }).then(() => true).catch(() => false)) {
    await page.locator(".custom-campaign-mask button").first().click().catch(() => {});
    await popup.waitFor({ state: "hidden", timeout: 3000 }).catch(() => {});
  }
}

// Log in an existing member (E2E_ECOM_PHONE, Vietnam +84). Returns the context + page (desktop by default).
export async function ecomSession(browser: Browser, options: BrowserContextOptions = { viewport: { width: 1440, height: 900 } }, phoneOverride?: string) {
  const phone = (phoneOverride || process.env.E2E_ECOM_PHONE || "").replace(/^0/, "");
  if (!phone) throw new Error("Set E2E_ECOM_PHONE (existing STG member)");
  const ctx = await browser.newContext(options);
  const page = await ctx.newPage();
  await bypassCaptcha(page);
  await page.goto(`${ECOM_URL}/en/signup`, { waitUntil: "domcontentloaded" });
  // STG Azure cold start: the auth flow can take a while to hydrate.
  for (let i = 0; i < 3; i++) {
    if (await page.locator(".auth-flow, .step-content").first().waitFor({ state: "visible", timeout: 60000 }).then(() => true).catch(() => false)) break;
    await page.goto(`${ECOM_URL}/en/signup`, { waitUntil: "domcontentloaded" });
  }
  await page.locator(".social-btn.phone-btn, button.phone-btn").first().click();
  const phoneInput = page.locator(".phone-number-input input, input.phone-number-input").first();
  await phoneInput.waitFor({ state: "visible", timeout: 10000 });
  await page.locator(".country-button").click();
  await page.locator(".dropdown-search input").fill("Vietnam");
  await page.locator(".dropdown-item").filter({ hasText: "Vietnam" }).first().click();
  await phoneInput.fill(phone);
  await page.locator(".otp-method-select").click();
  await page.locator(`.ant-select-dropdown .ant-select-item-option[title="SMS OTP"]`).click();
  await page.evaluate(() => { const w = window as any; if (typeof w.onloadTurnstileCallback === "function") w.onloadTurnstileCallback(); });
  await page.locator(".continue-button:not([disabled])").click({ timeout: 15000 });
  const otpInputs = page.locator(".otp_input input");
  await otpInputs.first().waitFor({ state: "visible", timeout: 90000 });
  const otp = process.env.E2E_ECOM_OTP || "4321"; // STG OTP bypass code
  // STG needs a moment to register the OTP session before verification.
  await page.waitForTimeout(3000);
  const n = await otpInputs.count();
  if (n >= 4) for (let i = 0; i < 4; i++) await otpInputs.nth(i).fill(otp[i]);
  else await otpInputs.first().fill(otp);
  const submit = page.locator("button.btn__btn_continue");
  if (await submit.isEnabled({ timeout: 2000 }).catch(() => false)) await submit.click().catch(() => {});
  // A phone that is not a member lands on "Last step" (sign-up form): stop, never register a new user here.
  const signupForm = page.locator(".personaldetail");
  await Promise.race([
    page.waitForURL((u) => !u.pathname.includes("signup"), { timeout: 30000 }),
    signupForm.waitFor({ state: "visible", timeout: 30000 }),
  ]).catch(() => {});
  if (await signupForm.isVisible().catch(() => false)) throw new Error("E-commerce phone is not an existing STG member (sign-up form shown) – use another member phone");
  await page.waitForURL((u) => !u.pathname.includes("signup"), { timeout: 30000 });
  await expect.poll(() => page.evaluate(() => !!localStorage.getItem("accessToken")), { message: "ecommerce login: no accessToken" }).toBe(true);
  return { ctx, page };
}
