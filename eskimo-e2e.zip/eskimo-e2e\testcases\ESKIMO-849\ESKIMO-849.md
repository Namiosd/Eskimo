# ESKIMO-849 – [EP-6073] [Admin Corporate Program] Cannot disable White Label program on save

Nguồn: Steps to reproduce / Expected result của item ESKIMO-849 (bug EP-6073, related ESKIMO-757 = EP-5991 AC4).
Môi trường: Admin Portal QA = E2E_ADMIN_URL (https://app-eskimo-admin-qa-sea-001.azurewebsites.net, gọi stage API = E2E_API_URL)
Partner: PN101609 "WhiteLabel Partner 2" (Corporate Program Type = White label) — storefront https://wellatsea.eskimo.travel (E2E_WL_URL)
Partner login (cho TC-03): E2E_WL_PARTNER_EMAIL / E2E_WL_PARTNER_OTP (partner portal QA = E2E_PARTNER_URL)

Cập nhật 2026-10-14 (BA sửa item): Expected result chỉ còn (1) lưu được Status = Disabled và (2) bật lại giữ nguyên Start/End/Application Fee/setting khác.
Ý "storefront and APIs of this partner become unavailable (e.g. storefront returns 404)" đã bị bỏ khỏi item → TC-02, TC-03, TC-05 NGOÀI PHẠM VI ESKIMO-849
(thuộc EP-5991 AC4 / ESKIMO-757); code giữ lại, chỉ chạy khi E2E_849_AVAILABILITY=1.

Quyết định QC (2026-10-14):
- Chạy trên Partner 2 (đúng item). Trước khi chạy: snapshot cấu hình Corporate Program + Application Fee (API). Sau khi chạy (kể cả khi fail): restore về snapshot và GET lại để xác nhận.
- Không mua hàng, không bấm "Continue to payment".
- BE báo storefront cache ~5 phút → TC-02 kiểm storefront với request không cache, lặp mỗi 60s tối đa 10 phút sau khi Disable.

## TC-01 Lưu được Corporate Program = Disabled
- Precondition: Partner 2 Corporate Program Status ON, Type White label
- Steps:
  1. Admin QA → Partnership › Partners → tìm PN101609 → Edit
  2. Section "Corporate Program": chuyển Status ON → OFF (xác nhận popup Warning nếu có)
  3. Bấm Ok
  4. Đóng, reload trang, mở lại partner
- Expected:
  - Không có toast lỗi "Corporate type cannot be updated."; lưu thành công
  - Sau reload, Corporate Program Status = OFF (Disabled)
  - (DATA) GET /api/partner/v2/{id} → configuration.hasCorporate = false

## TC-02 Storefront White Label của partner không còn dùng được khi Disabled — NGOÀI PHẠM VI (đã bỏ khỏi item 2026-10-14)
- Precondition: TC-01 đã lưu Disabled
- Steps:
  1. Mở storefront https://wellatsea.eskimo.travel/en và trang plan (Japan / United States / Europe), request không cache, mỗi 60s, tối đa 10 phút
- Expected: Storefront không còn khả dụng (ví dụ trả 404) — không hiển thị data plan, không vào được checkout

## TC-03 API White Label của partner không còn dùng được khi Disabled — NGOÀI PHẠM VI (đã bỏ khỏi item 2026-10-14)
- Precondition: TC-01 đã lưu Disabled
- Steps:
  1. Đăng nhập partner portal QA bằng E2E_WL_PARTNER_EMAIL
  2. Gọi GET /api/white-label/websites/mine bằng partner JWT
- Expected: Bị từ chối (không trả website của partner)

## TC-04 Bật lại giữ nguyên cấu hình, không cần cấu hình lại
- Precondition: TC-01 đã lưu Disabled
- Steps:
  1. Admin QA → Edit PN101609 → Corporate Program: chuyển Status OFF → ON, KHÔNG sửa field nào khác
  2. Bấm Ok, reload, mở lại partner
- Expected:
  - Lưu thành công; Status = ON
  - Type White label, Start Date, End Date, Application Fee và các setting khác (Eskimo Email Notification, Payment method, Lifetime Account Limit) giống hệt trước khi Disable (so với snapshot)

## TC-05 Storefront dùng lại được sau khi bật lại (manual-hỗ trợ / ghi nhận) — NGOÀI PHẠM VI (đã bỏ khỏi item 2026-10-14)
- Steps: sau TC-04, mở storefront trang plan (không cache)
- Expected: Data plan hiển thị lại, vào được trang checkout (không thanh toán)
