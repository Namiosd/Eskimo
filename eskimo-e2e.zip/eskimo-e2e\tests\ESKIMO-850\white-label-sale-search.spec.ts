// ESKIMO-850 / EP-6074 – Admin › Transactions › Eskimo Sales: the Search box must find White Label (WHI-…)
// transactions by full Transaction ID, partial ID and member name, the same as regular transactions.
// Test cases: testcases/ESKIMO-850/ESKIMO-850.md (expected results = the bug's Expected result):
//   TC-01 full WHI Transaction ID → row found (+ API search returns it)
//   TC-02 partial WHI ID (digits after the last "-") → row found
//   TC-03 member name of the WHI transaction → row found
//   TC-04 e-mail of the White Label member → a WHI row of that member
//   TC-05 regular (non-WHI) transaction: full ID, partial ID, member name still work
//   TC-06 regular search, then WHI search → table refreshed (no stale row of the previous search)
//   TC-07 unknown ID → "No data"
// Read-only, STAGE. Evidence: evidence/ESKIMO-850-white-label-sale-search → npm run report:evidence -- ESKIMO-850 white-label-sale-search
import { test, expect, type Browser, type BrowserContext, type Locator, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import { API_URL, adminToken, membersByEmail, memberDetail } from "../_support/wellatsea";

const ID = "@ESKIMO-850";
const AC = "EP-6074";
const evidence = createEvidence("ESKIMO-850", "white-label-sale-search");
const WL_MEMBER_EMAIL = process.env.E2E_WL_MEMBER_EMAIL || "testwhitelabel168@yopmail.com";
const SEARCH_PATH = "/api/data-plan-sale-transaction/search";
const isWhi = (id: string) => /^WHI/i.test(String(id ?? "").trim());
const partialOf = (id: string) => id.split("-").pop() as string;

// ─── Stage API (it sometimes answers 200 with an empty body → retry until JSON) ───
async function api(token: string, method: string, p: string, body?: unknown) {
  for (let i = 0; i < 6; i++) {
    const r = await fetch(`${API_URL}${p}`, { method, headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: body === undefined ? undefined : JSON.stringify(body) }).catch(() => null);
    const text = r ? await r.text().catch(() => "") : "";
    try { if (text) return JSON.parse(text); } catch { /* not JSON */ }
    await new Promise((res) => setTimeout(res, 1000));
  }
  return null;
}
const saleSearch = (t: string, searchText: string, eskimoTransactionType: number | null = null, pageSize = 50) =>
  api(t, "POST", SEARCH_PATH, { pageIndex: 1, pageSize, type: 1, amountId: null, platformFilter: "", eskimoTransactionType, cashbackFilter: 0, paymentMethodFilter: null, searchText, searchPlanName: "", fromDate: null, toDate: null, sortBy: { fieldName: "PurchaseDate", ascending: false } })
    .then((r) => ({ ok: !!r?.isSuccess, total: (r?.data?.totalCount ?? r?.data?.total ?? null) as number | null, rows: (r?.data?.data ?? []) as any[] }));
const purchases = (t: string, memberId: string) =>
  api(t, "POST", "/api/membership/Details/DataPurchase", { pageIndex: 1, pageSize: 20, id: memberId, isAscending: false, searchText: "" }).then((r) => (r?.data?.data ?? []) as any[]);

// ─── UI helpers (antd table) ───
const spinnerGone = (page: Page) => page.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
const mark = (l: Locator) => l.evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", background: "rgba(255,229,143,.95)" })).catch(() => {});

async function readTable(page: Page) {
  const table = page.locator(".ant-table:visible").filter({ has: page.locator(".ant-table-thead") }).first();
  await table.waitFor({ state: "visible", timeout: 60000 });
  await spinnerGone(page);
  const headers = (await table.locator(".ant-table-thead tr").last().locator("th").allInnerTexts()).map((h) => h.trim());
  const rows = table.locator(".ant-table-tbody tr.ant-table-row");
  const out: { row: Locator; cells: Record<string, string> }[] = [];
  for (let i = 0; i < (await rows.count()); i++) {
    const texts = (await rows.nth(i).locator("> td").allInnerTexts()).map((x) => x.replace(/\s+/g, " ").trim());
    out.push({ row: rows.nth(i), cells: Object.fromEntries(headers.map((h, j) => [h, texts[j] ?? ""])) });
  }
  const noData = await table.locator(".ant-empty, .ant-table-placeholder:visible").first().isVisible().catch(() => false);
  return { headers, rows: out, noData: noData && out.length === 0 };
}

async function openSales(page: Page) {
  await page.goto(`${ADMIN_URL}/#/transactions-eskimo-sale`, { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
  await page.getByPlaceholder("Search", { exact: true }).first().waitFor({ state: "visible", timeout: 60000 });
}

/** Type into "Search", press Enter, wait for the search request the page sends; returns UI table + API response of that request. */
async function search(page: Page, text: string) {
  const box = page.getByPlaceholder("Search", { exact: true }).first();
  await box.fill(text);
  const resp = page.waitForResponse((r) => r.url().includes(SEARCH_PATH) && r.request().method() === "POST" && (r.request().postDataJSON()?.searchText ?? "") === text.trim(), { timeout: 60000 });
  await box.press("Enter");
  const r = await resp;
  const json = await r.json().catch(() => null);
  await page.keyboard.press("Escape").catch(() => {}); // close the suggestions dropdown
  const table = await readTable(page);
  return { ...table, status: r.status(), apiRows: (json?.data?.data ?? []) as any[], apiSuccess: !!json?.isSuccess };
}

async function card(browser: Browser, testInfo: TestInfo, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const ctx = await browser.newContext();
  try { await evidence.saveDataCard(await ctx.newPage(), testInfo, heading, html, meta); } finally { await ctx.close(); }
}

type Tx = { transactionId: string; memberName: string; memberId: string; email?: string };
type Check = { query: string; label: string; uiIds: string[]; apiIds: string[]; status: number; found: boolean };

/** Search `query`, record whether `tx` is in the table, screenshot with the row highlighted. */
async function checkSearch(page: Page, testInfo: TestInfo, tc: string, label: string, query: string, tx: Tx, expected: string[]) {
  const res = await test.step(`Search "${query}" (${label})`, () => search(page, query));
  const hit = res.rows.find((r) => r.cells["Transaction ID"] === tx.transactionId);
  if (hit) { await hit.row.scrollIntoViewIfNeeded(); await mark(hit.row); }
  const c: Check = { query, label, uiIds: res.rows.map((r) => r.cells["Transaction ID"]), apiIds: res.apiRows.map((x) => x.transactionId), status: res.status, found: !!hit };
  await evidence.saveScreenshot(page, testInfo, {
    ac: AC, title: `${tc} ${label}`,
    steps: [`Eskimo Sales › Search "${query}" + Enter`, `POST ${SEARCH_PATH} → HTTP ${res.status}, ${res.apiRows.length} row(s)`, `Rows on screen: ${res.rows.length}${res.noData ? ' ("No data")' : ""}`, `${tx.transactionId} shown: ${c.found}`],
    expected, status: c.found ? undefined : "failed",
  });
  return c;
}
const checksTable = (tx: Tx, checks: Check[]) =>
  `<p>Target: <b>${esc(tx.transactionId)}</b> · member <b>${esc(tx.memberName)}</b></p><table><tr><th>Search by</th><th>Query</th><th>HTTP</th><th>API rows</th><th>UI rows</th><th>Target shown</th></tr>${checks
    .map((c) => `<tr><td>${esc(c.label)}</td><td>${esc(c.query)}</td><td>${c.status}</td><td>${c.apiIds.length}</td><td>${esc(c.uiIds.slice(0, 5).join(", ") || "No data")}${c.uiIds.length > 5 ? " …" : ""}</td><td class="${c.found ? "ok" : "bad"}">${c.found ? "YES" : "NO"}</td></tr>`).join("")}</table>`;

// ─── Shared session + test data ───
let admin: { ctx: BrowserContext; page: Page };
let t = "";
let whi: Tx;
let regular: Tx;

test.describe(`ESKIMO-850 Eskimo Sales search finds White Label transactions ${ID}`, () => {
  test.beforeAll(async ({ browser }) => {
    test.setTimeout(240_000);
    admin = await adminSession(browser);
    t = await adminToken(admin.page);
    const latest = (await saleSearch(t, "", null, 100)).rows;
    // WHI target: a successful WHI purchase of the WL member if any, else the latest successful WHI row (type 4)
    const [member] = await membersByEmail(t, WL_MEMBER_EMAIL);
    const mine = member ? (await purchases(t, member.id)).find((p) => isWhi(p.transactionID) && p.status === 1) : undefined;
    const whiRows = [...latest.filter((x) => isWhi(x.transactionId)), ...(await saleSearch(t, "", 4, 50)).rows];
    const w = (mine && whiRows.find((x) => x.transactionId === mine.transactionID)) || whiRows.find((x) => x.status === 1 && x.memberName) || whiRows[0];
    const fromMember = mine && !w ? { transactionId: mine.transactionID, memberName: "", memberId: member.id } : null;
    if (!w && !fromMember) throw new Error("Environment: no WHI… transaction found on stage");
    whi = fromMember ?? { transactionId: w.transactionId, memberName: String(w.memberName ?? "").trim(), memberId: w.memberId };
    if (whi.memberId === member?.id) whi.email = WL_MEMBER_EMAIL;
    const r = latest.find((x) => !isWhi(x.transactionId) && x.status === 1 && String(x.memberName ?? "").trim().length > 2 && x.memberId);
    if (!r) throw new Error("Environment: no successful regular transaction found on stage");
    regular = { transactionId: r.transactionId, memberName: String(r.memberName).trim(), memberId: r.memberId };
    const d: any = await memberDetail(t, regular.memberId).catch(() => null);
    regular.email = (d?.email || d?.data?.email || undefined) as string | undefined;
  });
  test.afterAll(async () => { await admin?.ctx.close(); });
  test.beforeEach(() => test.setTimeout(180_000));

  test(`TC-01 full WHI Transaction ID ${ID}`, async ({}, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Full WHI Transaction ID");
    await test.step("Admin → Transactions › Eskimo Sales", () => openSales(admin.page));
    const c = await checkSearch(admin.page, testInfo, "TC-01", "full Transaction ID", whi.transactionId, whi, [`The row ${whi.transactionId} is returned`]);
    expect(c.apiIds, `API search "${whi.transactionId}" returns the transaction`).toContain(whi.transactionId);
    expect(c.found, `Eskimo Sales lists ${whi.transactionId}`).toBe(true);
  });

  test(`TC-02 partial WHI Transaction ID ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-02 Partial WHI Transaction ID");
    await openSales(admin.page);
    const q = partialOf(whi.transactionId);
    const c = await checkSearch(admin.page, testInfo, "TC-02", "partial Transaction ID", q, whi, [`The row ${whi.transactionId} is returned for "${q}"`]);
    expect(c.found, `search "${q}" lists ${whi.transactionId}`).toBe(true);
  });

  test(`TC-03 member name of the WHI transaction ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-03 WHI member name");
    test.skip(!whi.memberName, "WHI transaction has no member name on stage");
    await openSales(admin.page);
    const c = await checkSearch(admin.page, testInfo, "TC-03", "member name", whi.memberName, whi, [`The row ${whi.transactionId} (member ${whi.memberName}) is returned`]);
    // Many rows for a common name may push the target past page 1: then the API (page size 50) must contain it.
    const inApi = c.found || (await saleSearch(t, whi.memberName, null, 200)).rows.some((x) => x.transactionId === whi.transactionId);
    expect(inApi, `search "${whi.memberName}" returns ${whi.transactionId}`).toBe(true);
    expect(c.uiIds.length, "at least one row").toBeGreaterThan(0);
  });

  test(`TC-04 e-mail of the White Label member ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-04 WL member e-mail");
    test.skip(!whi.email, `WHI target is not a purchase of ${WL_MEMBER_EMAIL}`);
    await openSales(admin.page);
    // The bug only names ID + member name: e-mail is expected only if it works for a regular transaction too.
    const baseline = regular.email ? await test.step(`Control: search regular member e-mail "${regular.email}"`, () => search(admin.page, regular.email!)) : null;
    const baselineOk = !!baseline?.rows.some((r) => r.cells["Transaction ID"] === regular.transactionId);
    testInfo.annotations.push({ type: "control", description: regular.email ? `regular e-mail search ${baselineOk ? "returns" : "does NOT return"} ${regular.transactionId}` : "regular member e-mail unknown" });
    test.skip(!baselineOk, "Unclear: e-mail search does not work for regular transactions either (not in the bug's scope)");
    const res = await test.step(`Search "${whi.email}"`, () => search(admin.page, whi.email!));
    const whiShown = res.rows.filter((r) => isWhi(r.cells["Transaction ID"]));
    for (const r of whiShown) await mark(r.row);
    await evidence.saveScreenshot(admin.page, testInfo, { ac: AC, title: "TC-04 member e-mail", steps: [`Search "${whi.email}"`, `HTTP ${res.status}, API rows ${res.apiRows.length}`, `WHI rows on screen: ${whiShown.map((r) => r.cells["Transaction ID"]).join(", ") || "none"}`], expected: ["The White Label member's WHI transaction(s) are returned"], status: whiShown.length ? undefined : "failed" });
    expect(whiShown.length, `WHI rows for ${whi.email}`).toBeGreaterThan(0);
  });

  test(`TC-05 regular transaction search still works ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-05 Regular transaction (control)");
    await openSales(admin.page);
    const checks: Check[] = [];
    const exp = (l: string) => [`Regular transaction ${regular.transactionId} returned by ${l} (unchanged behaviour)`];
    checks.push(await checkSearch(admin.page, testInfo, "TC-05", "full Transaction ID", regular.transactionId, regular, exp("full ID")));
    checks.push(await checkSearch(admin.page, testInfo, "TC-05", "partial Transaction ID", partialOf(regular.transactionId), regular, exp("partial ID")));
    const byName = await checkSearch(admin.page, testInfo, "TC-05", "member name", regular.memberName, regular, exp("member name"));
    if (!byName.found) byName.found = (await saleSearch(t, regular.memberName, null, 200)).rows.some((x) => x.transactionId === regular.transactionId);
    checks.push(byName);
    await card(admin.page.context().browser()!, testInfo, "TC-05 Regular transaction search", checksTable(regular, checks), { ac: AC, title: "TC-05 summary", steps: checks.map((c) => `${c.label}: ${c.found ? "found" : "NOT found"}`), expected: ["All three searches return the regular transaction"], status: checks.every((c) => c.found) ? undefined : "failed" });
    expect(checks.filter((c) => !c.found).map((c) => c.label), "searches that miss the regular transaction").toEqual([]);
  });

  test(`TC-06 table refreshes on a new WHI search ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-06 No stale result");
    await openSales(admin.page);
    await test.step(`Search regular "${regular.transactionId}" first`, () => search(admin.page, regular.transactionId));
    const res = await test.step(`Then search "${whi.transactionId}"`, () => search(admin.page, whi.transactionId));
    const ids = res.rows.map((r) => r.cells["Transaction ID"]);
    const stale = ids.includes(regular.transactionId);
    const ok = ids.includes(whi.transactionId) && !stale;
    await evidence.saveScreenshot(admin.page, testInfo, { ac: AC, title: "TC-06 after second search", steps: [`Search "${regular.transactionId}" then "${whi.transactionId}"`, `Rows on screen: ${ids.join(", ") || "No data"}`], expected: [`Only ${whi.transactionId} is shown`, `${regular.transactionId} (previous search) is gone`], status: ok ? undefined : "failed" });
    expect(stale, "row of the previous search still shown").toBe(false);
    expect(ids, "WHI row after the second search").toContain(whi.transactionId);
  });

  test(`TC-07 unknown ID shows No data ${ID}`, async ({}, testInfo) => {
    evidence.setCase("TC-07 Unknown ID");
    await openSales(admin.page);
    const q = "WHI-000000-0000000";
    const res = await test.step(`Search "${q}"`, () => search(admin.page, q));
    await evidence.saveScreenshot(admin.page, testInfo, { ac: AC, title: "TC-07 unknown ID", steps: [`Search "${q}"`, `HTTP ${res.status}, API rows ${res.apiRows.length}`, `Rows on screen: ${res.rows.length}`], expected: ['"No data", no rows'], status: res.rows.length ? "failed" : undefined });
    expect(res.rows.length, "rows for an unknown ID").toBe(0);
  });
});
