// ESKIMO-928 – follow-up: a recycled eSIM (back to Available after batch 8e461172…) is given to a new customer.
// Member = E2E_SIGNUP_PHONE (existing STG member, Vietnam +84, SMS OTP), must have NO eSIM before the test.
//   TC-11 before (admin): member found, eSIM Status = no eSIM, Data Wallet recorded, stock Available counted
//   TC-12 e-commerce: buy the first Vietnam plan, Stripe test card → Payment successful + Transaction ID
//   TC-13 e-commerce: Data balance › "Install eSIM" → POST /api/Esims/web-activate succeeds (eSIM assigned)
//   TC-14 after (admin): eSIM Assigned = one of the recycled eSIMs; stock Available −1; Data Wallet = before + the
//         new plan only (nothing of the eSIM's previous owner); Singtel eSIM section shown for reference
// Real purchase + real assignment on stage: run once, only with QC's go-ahead. No physical install (no QR scan).
// Evidence: evidence/ESKIMO-928-recycled-esim-assign → npm run report:evidence -- ESKIMO-928 recycled-esim-assign
import fs from "node:fs";
import { test, expect, type Browser, type BrowserContext, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { ECOM_URL, ecomSession, dismissCampaignPopup } from "../_support/ecommerce";
import { createEvidence, esc } from "../_support/evidence";
import { API_URL, adminToken } from "../_support/wellatsea";

const ID = "@ESKIMO-928";
const AC = "ESKIMO-928 recycled eSIM reuse";
const evidence = createEvidence("ESKIMO-928", "recycled-esim-assign");
const BATCH_ID = "8e461172-fa77-4f2d-be48-c779353fb759"; // retest batch: recycled 525016144200010 + 525016144200009
const PHONE = (process.env.E2E_SIGNUP_PHONE || "").replace(/^0/, "");
const CARD = { number: "4242424242424242", exp: "12 / 28", cvc: "123", zip: "12345" };

type Plan = { subscriptionId: string; name: string; status: string; amount: string; tx: string; createdOn: string; fromAction: string };
type Esim = { imsi: string; iccid: string; serviceId: string; status: string; singtel: string; assigned: string };
type State = {
  memberId?: string; memberName?: string; recycled?: { imsi: string; prev: string }[];
  availableBefore?: number; plansBefore?: Plan[]; esimsBefore?: Esim[];
  transactionId?: string; planText?: string; activate?: { http: number; isSuccess?: boolean; detail?: string; message?: string };
};
const STATE_FILE = "test-results/ESKIMO-928-assign-state.json";
let S: State = {};
const save = () => { fs.mkdirSync("test-results", { recursive: true }); fs.writeFileSync(STATE_FILE, JSON.stringify(S)); };
const load = () => { try { S = JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); } catch { S = {}; } };

let adminCtx: BrowserContext;
let admin: Page;

// ─── Admin API (same endpoints as Member Detail / eSIM Codes) ───
async function api(method: string, path: string, body?: unknown) {
  const token = await adminToken(admin);
  const r = await fetch(`${API_URL}${path}`, {
    method, signal: AbortSignal.timeout(60000),
    headers: { "Content-Type": "application/json", Accept: "application/json", Authorization: `Bearer ${token}` },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  try { return { status: r.status, json: JSON.parse(text) as any }; } catch { return { status: r.status, json: null as any }; }
}
const digits = (s: unknown) => String(s ?? "").replace(/\D/g, "");
async function findMember() {
  const r = await api("POST", "/api/membership/search", { pageIndex: 1, pageSize: 10, searchText: PHONE, searchType: 4, partnerIds: [], status: null, fromDate: null, toDate: null, sortBy: { fieldName: "CreatedOn", ascending: false }, isShowPendingStatus: true, esimStatus: null });
  const list: any[] = r.json?.data?.data ?? r.json?.data?.items ?? [];
  return list.find((m) => digits(m.mobileNo).endsWith(digits(PHONE)));
}
async function memberEsims(memberId: string): Promise<Esim[]> {
  const r = await api("GET", `/api/Esims/${memberId}`);
  return ((r.json?.data?.userEsims ?? []) as any[]).map((e) => ({
    imsi: String(e.singTelIMSI ?? ""), iccid: String(e.singTelICCID ?? ""), serviceId: String(e.serviceId ?? ""),
    status: String(e.esimStatus ?? ""), singtel: String(e.singTeleSIMStatus ?? ""), assigned: String(e.createdOn ?? ""),
  }));
}
async function memberPlans(memberId: string): Promise<Plan[]> {
  const r = await api("POST", "/api/data-wallet/search-userId/v2", { userId: memberId, searchPlanTitle: "", searchPlanName: "", searchSubscriptionId: "", pageIndex: 1, pageSize: 100 });
  return ((r.json?.data?.data ?? []) as any[]).map((p) => ({
    subscriptionId: String(p.subcriptionId ?? ""), name: String(p.displayName ?? p.dataPlanText ?? ""), status: String(p.status ?? ""),
    amount: `${p.dataAmountValue ?? ""}${p.dataAmountUnit ?? ""}`, tx: String(p.transactionNo ?? p.transactionId ?? ""),
    createdOn: String(p.createdOn ?? ""), fromAction: String(p.fromAction ?? ""),
  }));
}
async function inventoryByImsi(imsi: string) {
  const r = await api("POST", "/api/inventories/search", { pageIndex: 1, pageSize: 5, searchText: imsi, status: null, partnerIds: [], fromDate: null, importFile: null, toDate: null });
  return ((r.json?.data?.data?.data ?? []) as any[]).find((x) => x.imsi === imsi);
}
async function availableCount() {
  const r = await api("POST", "/api/inventories/search", { pageIndex: 1, pageSize: 1, searchText: "", status: 0, partnerIds: [], fromDate: null, importFile: null, toDate: null });
  return Number(r.json?.data?.data?.numOfRecords ?? NaN);
}

// ─── Admin UI: Membership › Mobile Number search › View Detail ───
const spinnerGone = (p: Page) => p.locator(".ant-spin-spinning").last().waitFor({ state: "hidden", timeout: 30000 }).catch(() => {});
const mark = (loc: ReturnType<Page["locator"]>) => loc.first().evaluate((el) => Object.assign((el as HTMLElement).style, { outline: "3px solid #cf1322", outlineOffset: "2px" })).catch(() => {});
async function openMemberDetail() {
  await admin.goto(`${ADMIN_URL}/#/membership`, { waitUntil: "domcontentloaded", timeout: 90000 });
  // Same-hash goto does not remount the SPA: an earlier Member Detail drawer would stay open over the list.
  await admin.reload({ waitUntil: "domcontentloaded", timeout: 90000 });
  await admin.locator(".ant-table").first().waitFor({ state: "visible", timeout: 60000 });
  await spinnerGone(admin);
  await admin.locator(".search-type-select").first().click();
  await admin.locator(".ant-select-item-option").filter({ hasText: /^Mobile Number$/i }).first().click();
  const search = admin.getByPlaceholder("Search").first();
  await search.fill(PHONE);
  await search.press("Enter");
  await spinnerGone(admin);
  const row = admin.locator(".ant-table-tbody tr.ant-table-row").first();
  await row.waitFor({ state: "visible", timeout: 30000 });
  await row.locator("button, a").filter({ hasText: /View Detail/i }).first().click({ timeout: 15000 });
  await admin.locator(".ant-drawer-content:visible").first().waitFor({ state: "visible", timeout: 30000 });
  await spinnerGone(admin);
  await admin.waitForLoadState("networkidle", { timeout: 30000 }).catch(() => {});
}
/** Scrolls a Member Detail section (by its title) into view and outlines it. */
async function showSection(title: RegExp) {
  const t = admin.locator(".ant-drawer-content:visible").getByText(title).first();
  await t.scrollIntoViewIfNeeded().catch(() => {});
  await mark(t.locator("xpath=ancestor::div[2]"));
  return (await t.locator("xpath=ancestor::div[2]").innerText().catch(() => "")).replace(/\s+/g, " ").trim();
}

async function card(browser: Browser, testInfo: TestInfo | undefined, heading: string, html: string, meta: Parameters<typeof evidence.saveScreenshot>[2]) {
  const c = await browser.newContext();
  try { await evidence.saveDataCard(await c.newPage(), testInfo, heading, html, meta); } finally { await c.close(); }
}
const planRows = (ps: Plan[], hi?: (p: Plan) => boolean) => ps.map((p) => `<tr${hi?.(p) ? ' style="background:#f6ffed"' : ""}><td>${esc(p.name)}</td><td>${esc(p.amount)}</td><td>${esc(p.status)}</td><td>${esc(p.tx)}</td><td>${esc(p.subscriptionId)}</td><td>${esc(p.fromAction)}</td><td>${esc(p.createdOn)}</td></tr>`).join("");
const planTable = (ps: Plan[], hi?: (p: Plan) => boolean) => `<table><tr><th>Plan</th><th>Data</th><th>Status</th><th>Transaction</th><th>Subscription</th><th>From</th><th>Created</th></tr>${planRows(ps, hi) || '<tr><td colspan="7">(none)</td></tr>'}</table>`;
const esimTable = (es: Esim[], hi?: (e: Esim) => boolean) => `<table><tr><th>IMSI</th><th>ICCID</th><th>Service ID</th><th>eSIM status</th><th>Singtel status</th><th>Assigned</th></tr>${es.map((e) => `<tr${hi?.(e) ? ' style="background:#f6ffed"' : ""}><td>${esc(e.imsi)}</td><td>${esc(e.iccid)}</td><td>${esc(e.serviceId)}</td><td>${esc(e.status)}</td><td>${esc(e.singtel)}</td><td>${esc(e.assigned)}</td></tr>`).join("") || '<tr><td colspan="6">(no eSIM)</td></tr>'}</table>`;

test.describe(`ESKIMO-928 recycled eSIM assigned to a new customer ${ID}`, () => {
  test.describe.configure({ timeout: 300_000 });
  test.beforeAll(async ({ browser }) => { load(); ({ ctx: adminCtx, page: admin } = await adminSession(browser)); });
  test.afterAll(async () => { await adminCtx?.close(); });

  test(`TC-11 Member before purchase: no eSIM, Data Wallet recorded ${ID}`, async ({ browser }, testInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    S = {}; save();
    evidence.setCase("TC-11 Member before purchase");
    expect(PHONE, "E2E_SIGNUP_PHONE").toBeTruthy();
    const m = await findMember();
    expect(m, "member with E2E_SIGNUP_PHONE on stage").toBeTruthy();
    S.memberId = String(m.id); S.memberName = String(m.fullName ?? m.memberName ?? m.name ?? "");
    // Recycled eSIMs of the retest batch (export) and their previous owners.
    const ex = await api("POST", "/api/inventories/export-recycle-inventory", { batchIdList: [BATCH_ID] });
    const cols: string[] = ex.json?.data?.columns ?? [];
    S.recycled = ((ex.json?.data?.dataExports ?? []) as any[][]).map((r) => ({ imsi: String(r[cols.indexOf("IMSI")] ?? ""), prev: String(r[cols.indexOf("Previous User ID")] ?? "") }));
    S.availableBefore = await availableCount();
    S.esimsBefore = await memberEsims(S.memberId);
    S.plansBefore = await memberPlans(S.memberId);
    save();
    await openMemberDetail();
    const esimText = await showSection(/^eSIM Status$/);
    const noEsim = S.esimsBefore.length === 0;
    await evidence.saveScreenshot(admin, testInfo, {
      ac: AC, title: "TC-11 Member Detail – eSIM Status before purchase",
      steps: ["Admin › Membership › Search by Mobile Number (E2E_SIGNUP_PHONE) › View Detail", `eSIM Status: ${esimText.slice(0, 120)}`, `API eSIMs: ${S.esimsBefore.length}`],
      expected: ["Member has no eSIM yet (No Esim)"],
      status: noEsim ? undefined : "failed",
    });
    await showSection(/^Data Wallet$/);
    await evidence.saveScreenshot(admin, testInfo, {
      ac: AC, title: "TC-11 Member Detail – Data Wallet before purchase",
      steps: ["Member Detail › Data Wallet", `Plans: ${S.plansBefore.length}`],
      expected: ["Recorded as the baseline"],
    });
    await card(browser, testInfo, "TC-11 – baseline (admin API)", `<table>
      <tr><th>Member id</th><td>${esc(S.memberId)}</td></tr><tr><th>Stock Available</th><td>${S.availableBefore}</td></tr>
      <tr><th>Recycled eSIMs (batch ${esc(BATCH_ID)})</th><td>${S.recycled.map((r) => `${esc(r.imsi)} (previous user ${esc(r.prev || "—")})`).join("<br>")}</td></tr></table>
      <h3>eSIMs (GET /api/Esims/{memberId})</h3>${esimTable(S.esimsBefore)}<h3>Data Wallet (POST /api/data-wallet/search-userId/v2)</h3>${planTable(S.plansBefore)}`, {
      ac: AC, title: "TC-11 Baseline data",
      steps: [`Stock Available: ${S.availableBefore}`, `Recycled: ${S.recycled.map((r) => r.imsi).join(", ")}`, `Member eSIMs: ${S.esimsBefore.length} · plans: ${S.plansBefore.length}`],
      expected: ["Member has no eSIM; the recycled eSIMs are the Available stock"],
      status: noEsim ? undefined : "failed",
    });
    expect(S.esimsBefore, "member already has an eSIM (activation would return it, not a recycled one)").toEqual([]);
  });

  test(`TC-12 Buy a data plan on the e-commerce site ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-12 Buy data plan");
    test.skip(!S.memberId || (S.esimsBefore?.length ?? 1) > 0, "TC-11 precondition not met");
    const { ctx, page } = await ecomSession(browser, undefined, PHONE);
    try {
      await page.goto(`${ECOM_URL}/en`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await dismissCampaignPopup(page);
      await page.locator(".country-link, a[href*='vietnam']").filter({ hasText: /vietnam/i }).first().click({ timeout: 40000 });
      await page.waitForLoadState("domcontentloaded");
      await dismissCampaignPopup(page);
      const section = page.locator(".plans-section").filter({ has: page.locator(".plans-title-desc", { hasText: /^vietnam$/i }) });
      await section.scrollIntoViewIfNeeded();
      const planCard = section.locator(".day-card").first();
      await planCard.waitFor({ state: "visible", timeout: 20000 });
      S.planText = (await planCard.innerText()).replace(/\s+/g, " ").trim();
      await planCard.click();
      await page.locator(".btn-checkout").first().click({ timeout: 15000 });
      await page.waitForURL("**/checkout", { timeout: 30000 });
      await page.locator(".checkout-page").waitFor({ state: "visible", timeout: 30000 });
      const email = page.locator("input.email-input").first();
      await email.waitFor({ state: "visible", timeout: 15000 });
      if (!(await email.inputValue())) await email.fill("e2e.esim928@yopmail.com");
      await page.locator(".checkout-pay-by-card").click();
      if (!(await page.locator(".checkout-saved-card-row").isVisible({ timeout: 3000 }).catch(() => false))) {
        await page.locator(".checkout-inline-card-form").waitFor({ state: "visible", timeout: 20000 });
        await page.waitForFunction(() => !!document.querySelector("#checkout-payment-element iframe"), null, { timeout: 30000 });
        const stripe = page.frameLocator("#checkout-payment-element iframe").first();
        const num = stripe.locator('[placeholder="1234 1234 1234 1234"], [placeholder="Card number"]').first();
        await num.waitFor({ state: "visible", timeout: 20000 });
        await num.fill(CARD.number);
        await stripe.locator('[placeholder="MM / YY"], [placeholder="MM/YY"]').first().fill(CARD.exp);
        await stripe.locator('[placeholder="CVC"], [placeholder="CVV"]').first().fill(CARD.cvc);
        const zip = stripe.locator('[placeholder="ZIP"], [placeholder="Postal code"]');
        if (await zip.isVisible({ timeout: 2000 }).catch(() => false)) await zip.fill(CARD.zip);
      }
      await evidence.saveScreenshot(page, testInfo, {
        ac: AC, title: "TC-12 Checkout before paying",
        steps: [`E-commerce (E2E_SIGNUP_PHONE) › Vietnam › first plan: ${S.planText}`, "Checkout › Pay by card › Stripe test card 4242…"],
        expected: ["Checkout shows the plan and total"],
      });
      const proceed = page.locator(".checkout-proceed-btn").first();
      await expect(proceed).toBeEnabled({ timeout: 15000 });
      await proceed.click();
      const success = await page.locator(".payment-success-new").waitFor({ state: "visible", timeout: 120000 }).then(() => true).catch(() => false);
      const tx = page.locator(".details-item").filter({ has: page.locator(".item-label", { hasText: /transaction id/i }) }).locator(".item-value");
      S.transactionId = success ? (await tx.innerText({ timeout: 10000 }).catch(() => "")).trim() : "";
      save();
      await evidence.saveScreenshot(page, testInfo, {
        ac: AC, title: "TC-12 Payment successful",
        steps: ["Click Proceed to payment", `Success popup: ${success ? "shown" : "not shown"}`, `Transaction ID: ${S.transactionId || "-"}`],
        expected: ["Payment successful with a Transaction ID"],
        status: success && S.transactionId ? undefined : "failed",
      });
      expect(success, "payment success popup").toBe(true);
      expect(S.transactionId, "Transaction ID").toBeTruthy();
    } finally { await ctx.close(); }
  });

  test(`TC-13 Install eSIM on Data balance assigns an eSIM ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-13 Get eSIM");
    test.skip(!S.transactionId, "no purchase from TC-12");
    const { ctx, page } = await ecomSession(browser, undefined, PHONE);
    try {
      await page.goto(`${ECOM_URL}/en/data-balance`, { waitUntil: "domcontentloaded", timeout: 90000 });
      await dismissCampaignPopup(page);
      const btn = page.locator("button.btn-install-esim").first();
      await btn.waitFor({ state: "visible", timeout: 60000 });
      await btn.scrollIntoViewIfNeeded().catch(() => {});
      await evidence.saveScreenshot(page, testInfo, {
        ac: AC, title: "TC-13 Data balance before Install eSIM",
        steps: ["E-commerce › Data balance (the new plan is listed)", 'Button "Install eSIM"'],
        expected: ["The purchased plan is shown; Install eSIM available"],
      });
      const respP = page.waitForResponse((r) => r.url().includes("/api/Esims/web-activate") && r.request().method() === "POST", { timeout: 90000 }).catch(() => null);
      await btn.click();
      const resp = await respP;
      const body = resp ? await resp.json().catch(() => null) : null;
      S.activate = { http: resp?.status() ?? 0, isSuccess: body?.isSuccess, detail: body?.detail, message: body?.messages?.[0]?.content };
      save();
      const ok = resp?.status() === 200 && body?.isSuccess === true && body?.data != null;
      if (ok) await page.waitForURL(/operating-system/, { timeout: 60000 }).catch(() => {});
      await page.waitForLoadState("networkidle", { timeout: 20000 }).catch(() => {});
      await evidence.saveScreenshot(page, testInfo, {
        ac: AC, title: "TC-13 After Install eSIM (QR page – not scanned)",
        steps: ['Click "Install eSIM" → POST /api/Esims/web-activate', `HTTP ${S.activate.http} · isSuccess ${S.activate.isSuccess} · ${S.activate.detail || S.activate.message || ""}`, `Page: ${new URL(page.url()).pathname}`, "QR code is NOT scanned (no physical install)"],
        expected: ["web-activate succeeds: an eSIM is assigned and the install page (QR) opens"],
        status: ok ? undefined : "failed",
      });
      expect(ok, `web-activate: ${JSON.stringify(S.activate)}`).toBe(true);
    } finally { await ctx.close(); }
  });

  test(`TC-14 Member after: recycled eSIM assigned, only the new plan added ${ID}`, async ({ browser }, testInfo) => {
    evidence.setCase("TC-14 Member after eSIM assigned");
    test.skip(!S.memberId || !S.transactionId, "no purchase");
    const recycled = new Set((S.recycled ?? []).map((r) => r.imsi));
    // Assignment is synchronous, but give the stage API a moment.
    let esims: Esim[] = [];
    for (let i = 0; i < 10 && !esims.length; i++) { esims = await memberEsims(S.memberId!); if (!esims.length) await new Promise((r) => setTimeout(r, 3000)); }
    const plans = await memberPlans(S.memberId!);
    const availableAfter = await availableCount();
    const got = esims[0];
    const inv = got ? await inventoryByImsi(got.imsi) : undefined;
    const prevOwner = (S.recycled ?? []).find((r) => r.imsi === got?.imsi)?.prev ?? "";
    const prevPlans = prevOwner ? await memberPlans(prevOwner).catch(() => [] as Plan[]) : [];
    // A plan is identified by transaction + created time: assigning the eSIM activates the member's own Pending
    // plans (status and subscription id change), which must not count as new plans.
    const key = (p: Plan) => `${p.tx}|${p.createdOn}|${p.name}`;
    const beforeByKey = new Map((S.plansBefore ?? []).map((p) => [key(p), p]));
    const added = plans.filter((p) => !beforeByKey.has(key(p)));
    const activated = plans.filter((p) => { const b = beforeByKey.get(key(p)); return b && (b.status !== p.status || b.subscriptionId !== p.subscriptionId); })
      .map((p) => ({ p, b: beforeByKey.get(key(p))! }));
    const prevSubs = new Set(prevPlans.map((p) => p.subscriptionId).filter(Boolean));
    const carried = plans.filter((p) => p.subscriptionId && prevSubs.has(p.subscriptionId));
    const isRecycled = !!got && recycled.has(got.imsi);
    const stockOk = availableAfter === (S.availableBefore ?? NaN) - 1;
    const invOk = inv?.status === 3;
    const plansOk = added.length === 1 && carried.length === 0;
    await card(browser, testInfo, "TC-14 – member after Install eSIM (admin API)", `<h3>eSIMs of the member</h3>${esimTable(esims, (e) => recycled.has(e.imsi))}
      <table><tr><th>Assigned IMSI is a recycled eSIM (${esc([...recycled].join(", "))})</th><td class="${isRecycled ? "ok" : "bad"}">${isRecycled}</td></tr>
      <tr><th>eSIM Codes status of ${esc(got?.imsi ?? "-")}</th><td class="${invOk ? "ok" : "bad"}">${esc(inv ? inv.status : "-")} (3 = Assigned)</td></tr>
      <tr><th>Stock Available</th><td class="${stockOk ? "ok" : "bad"}">${S.availableBefore} → ${availableAfter} (expected ${(S.availableBefore ?? 0) - 1})</td></tr>
      <tr><th>Previous owner of this eSIM</th><td>${esc(prevOwner || "—")}</td></tr></table>
      <h3>Data Wallet now (new rows highlighted)</h3>${planTable(plans, (p) => added.includes(p))}
      <h3>Plans of the previous owner (reference)</h3>${planTable(prevPlans)}
      <p>Plans of the previous owner found in this member's wallet (same subscription id): <b class="${carried.length ? "bad" : "ok"}">${carried.length}</b></p>
      <h3>Member's own plans changed by the assignment (activated on the new eSIM)</h3><table><tr><th>Plan</th><th>Transaction</th><th>Status before → after</th><th>Subscription before → after</th></tr>
      ${activated.map(({ p, b }) => `<tr><td>${esc(p.name)}</td><td>${esc(p.tx)}</td><td>${esc(b.status)} → ${esc(p.status)}</td><td>${esc(b.subscriptionId || "—")} → ${esc(p.subscriptionId || "—")}</td></tr>`).join("") || '<tr><td colspan="4">(none)</td></tr>'}</table>`, {
      ac: AC, title: "TC-14 Recycled eSIM assigned – data check",
      steps: [`Transaction ${S.transactionId}`, `Member eSIM: ${got ? `${got.imsi} / ${got.iccid} (${got.status})` : "none"}`, `Recycled eSIM: ${isRecycled}`, `eSIM Codes status: ${inv?.status ?? "-"} (3 = Assigned)`,
        `Available ${S.availableBefore} → ${availableAfter}`, `Data Wallet: ${S.plansBefore?.length ?? 0} → ${plans.length} (new: ${added.map((p) => `${p.name} ${p.tx}`).join(", ") || "none"})`,
        `Own plans activated by the assignment: ${activated.length}`, `Previous owner's plans carried over: ${carried.length}`],
      expected: ["The member gets one of the recycled eSIMs (Assigned in eSIM Codes, Available −1)", "Data Wallet = before + only the purchased plan; no plan of the eSIM's previous owner"],
      status: isRecycled && invOk && stockOk && plansOk ? undefined : "failed",
    });
    await openMemberDetail();
    const esimText = await showSection(/^eSIM Status$/);
    await evidence.saveScreenshot(admin, testInfo, {
      ac: AC, title: "TC-14 Member Detail – eSIM Status after",
      steps: ["Admin › Membership › View Detail", `eSIM Status: ${esimText.slice(0, 160)}`],
      expected: ["eSIM Assigned (the recycled IMSI)"],
      status: isRecycled ? undefined : "failed",
    });
    await showSection(/^Data Wallet$/);
    await evidence.saveScreenshot(admin, testInfo, {
      ac: AC, title: "TC-14 Member Detail – Data Wallet after",
      steps: ["Member Detail › Data Wallet", `Plans: ${plans.length} (new: ${added.length})`],
      expected: ["Only the purchased plan was added"],
      status: plansOk ? undefined : "failed",
    });
    await showSection(/^Singtel eSIM$/);
    await evidence.saveScreenshot(admin, testInfo, {
      ac: AC, title: "TC-14 Member Detail – Singtel eSIM (reference)",
      steps: ["Member Detail › Singtel eSIM (subscriptions on the eSIM at Singtel)"],
      expected: ["No subscription of the previous owner on this eSIM"],
    });
    expect(got, "member eSIM after Install eSIM").toBeTruthy();
    expect(isRecycled, `assigned IMSI ${got?.imsi} is one of the recycled eSIMs`).toBe(true);
    expect(inv?.status, "eSIM Codes status (3 = Assigned)").toBe(3);
    expect(availableAfter, "stock Available after").toBe((S.availableBefore ?? NaN) - 1);
    expect(added.length, "new Data Wallet rows").toBe(1);
    expect(carried.map((p) => p.subscriptionId), "previous owner's plans in this wallet").toEqual([]);
  });
});
