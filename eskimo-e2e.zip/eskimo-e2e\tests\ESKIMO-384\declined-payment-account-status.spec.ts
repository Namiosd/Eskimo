// ESKIMO-384 / EP-6057 – WellAtSea: a failed payment must create the account as Pending, not Active.
// Test cases: testcases/ESKIMO-384/ESKIMO-384.md. Every run uses fresh yopmail addresses:
//   TC-01 declined card (4000…0002)  TC-02 Admin list Pending / No eSIM  TC-03 Member Detail Status Pending
//   TC-04 same email pays with 4242   TC-05 same account reused, Active (eSIM only recorded)
//   TC-06 checkout abandoned before paying → Pending
// Leaves Pending accounts + a Failed Eskimo Sale behind (no UI to delete them); TC-04 assigns 1 eSIM.
// Evidence: evidence/ESKIMO-384-declined-payment → npm run report:evidence -- ESKIMO-384 declined-payment
import fs from "node:fs";
import path from "node:path";
import { test, expect, type Browser, type Page, type TestInfo } from "@playwright/test";
import { adminSession, ADMIN_URL } from "../_support/eskimo";
import { createEvidence, esc } from "../_support/evidence";
import {
  WL_URL, CARD_DECLINED, CARD_OK, newShopper, pickPlan, goToCheckout, continueToPayment, payWithCard,
  readCompletePage, adminToken, membersByEmail, memberDetail, pollMembers, searchMembership, openMemberDetail,
  accountLabel, esimLabel, type Member,
} from "../_support/wellatsea";

const ID = "@ESKIMO-384";
const AC = "EP-6057";
const evidence = createEvidence("ESKIMO-384", "declined-payment");
const FIRST_NAME = "QA384";
const PLAN = { area: /^Japan/i, data: "1GB" };

// A failed test restarts the worker: the run's e-mails / order live in a file, not in module variables.
const STATE = path.join(evidence.SCREENSHOT_DIR, "run-state.json");
type RunState = { email: string; cancelEmail: string; declined?: boolean; paidOrder?: string; firstMemberId?: string };
const loadState = (): RunState => JSON.parse(fs.readFileSync(STATE, "utf8"));
const saveState = (patch: Partial<RunState>) => fs.writeFileSync(STATE, JSON.stringify({ ...loadState(), ...patch }, null, 2));

const memberCard = (members: Member[]) =>
  `<table><tr><th>id</th><th>email</th><th>Account Status</th><th>eSIM Status</th></tr>${members
    .map((m) => `<tr><td>${esc(m.id)}</td><td>${esc(m.email)}</td><td>${esc(`${m.status} = ${accountLabel(m.status)}`)}</td><td>${esc(`${m.esimStatus ?? "null"} = ${esimLabel(m.esimStatus)}`)}</td></tr>`)
    .join("") || "<tr><td colspan=4>no account</td></tr>"}</table>`;

test.describe(`ESKIMO-384 Declined payment → account Pending ${ID}`, () => {
  test.setTimeout(480_000);

  let admin: { ctx: any; page: Page };
  let token = "";

  test.beforeAll(async ({ browser }: { browser: Browser }) => {
    admin = await adminSession(browser);
    await admin.page.setViewportSize({ width: 1600, height: 900 });
    token = await adminToken(admin.page);
    if (!token) throw new Error("Admin token not found in localStorage after login");
  });

  test.afterAll(async () => {
    await admin?.ctx.close();
  });

  test(`TC-01 Declined card shows "Your card has been declined" ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.resetIfFirstAttempt(testInfo);
    evidence.setCase("TC-01 Storefront declined card");
    const stamp = Date.now().toString(36);
    fs.mkdirSync(evidence.SCREENSHOT_DIR, { recursive: true });
    fs.writeFileSync(STATE, JSON.stringify({ email: `qa384-${stamp}@yopmail.com`, cancelEmail: `qa384c-${stamp}@yopmail.com` }, null, 2));
    const { email } = loadState();
    console.log(`[INFO] TC-01..05 email = ${email}`);

    expect((await membersByEmail(token, email)).length, `${email} must be new`).toBe(0);
    const { ctx, page } = await newShopper(browser);
    try {
      let plan = "";
      await test.step("1. wellatsea → Japan → 1GB → Checkout", async () => {
        plan = await pickPlan(page, PLAN);
        await goToCheckout(page);
      });
      await test.step("2. First name + new email → Continue to payment", async () => {
        const r = await continueToPayment(page, FIRST_NAME, email);
        expect(r.outcome, `card step not reached: ${r.errors.join(" / ")}`).toBe("card");
      });
      await test.step("3. Card 4000 0000 0000 0002 → Pay", async () => {
        const res = await payWithCard(page, CARD_DECLINED);
        const ok = res.outcome === "error" && /declined/i.test(res.error) && !/\/checkout\/complete/.test(page.url());
        await evidence.saveScreenshot(page, testInfo, {
          ac: AC, title: "TC-01 Declined card 4000 0000 0000 0002",
          steps: [`${WL_URL} · plan ${plan || "Japan 1GB"}`, `First name ${FIRST_NAME} · email ${email}`, `Pay → ${res.outcome}: "${res.error || "—"}"`, `URL ${page.url()}`],
          expected: ['"Your card has been declined" shown', "Payment not completed (stays on checkout)"], status: ok ? undefined : "failed",
        });
        saveState({ declined: res.outcome === "error" });
        expect(res.outcome, "Pay result").toBe("error");
        expect(res.error).toMatch(/declined/i);
        expect(page.url()).not.toMatch(/\/checkout\/complete/);
      });
    } finally {
      await ctx.close();
    }
  });

  test(`TC-02 Admin Membership list: Pending, No eSIM ${ID}`, async ({}, testInfo: TestInfo) => {
    evidence.setCase("TC-02 Admin list after declined");
    const { email, declined } = loadState();
    test.skip(!declined, "TC-01 did not produce a declined payment");
    // Webhook payment_failed creates the account asynchronously.
    const members = await pollMembers(token, email, (m) => m.length > 0);
    await test.step("Admin → Membership → Search by Email", async () => {
      const ui = await searchMembership(admin.page, email);
      const m = members[0];
      const ok = members.length === 1 && m.status === 3 && m.esimStatus == null;
      await evidence.saveScreenshot(admin.page, testInfo, {
        ac: AC, title: "TC-02 Membership list – account after a declined payment",
        steps: [`${ADMIN_URL}/#/membership · Search by Email "${email}"`, `UI: ${ui.rowCount} row(s) · Account Status "${ui.accountStatus || "—"}" · eSIM Status "${ui.esimStatus || "—"}"`,
          `API: ${members.length} account(s)${m ? ` · status ${m.status} (${accountLabel(m.status)}) · esimStatus ${m.esimStatus ?? "null"} (${esimLabel(m.esimStatus)})` : ""}`],
        expected: ["Exactly 1 account", "Account Status = Pending", "eSIM Status = No eSIM"], status: ok ? undefined : "failed",
      });
      if (m) saveState({ firstMemberId: m.id });
      expect(members.length, "accounts for this email").toBe(1);
      expect(accountLabel(m.status), "Account Status").toBe("Pending");
      expect(esimLabel(m.esimStatus), "eSIM Status").toBe("No eSIM");
    });
  });

  test(`TC-03 Member Detail: Status Pending, Data Wallet No Data ${ID}`, async ({}, testInfo: TestInfo) => {
    evidence.setCase("TC-03 Member Detail after declined");
    const { email, firstMemberId } = loadState();
    test.skip(!firstMemberId, "No account found in TC-02");
    const detail = await memberDetail(token, firstMemberId!);
    await test.step("View Detail → Personal Account", async () => {
      const ui = await searchMembership(admin.page, email);
      const d = await openMemberDetail(admin.page, ui.row);
      const ok = /^Pending\b/i.test(d.status) && detail?.status === 3 && d.noData > 0;
      await evidence.saveScreenshot(admin.page, testInfo, {
        ac: AC, title: 'TC-03 Member Detail – Personal Account "Status"',
        steps: [`View Detail of ${email}`, `UI Status: "${d.status || "—"}" · "No Data" panels: ${d.noData}`,
          `API GET /api/membership/${firstMemberId}: status ${detail?.status ?? "—"} (${accountLabel(detail?.status)}) · isEsimAssign ${detail?.isEsimAssign ?? "—"}`],
        expected: ["Status = Pending", 'Data Wallet / Singtel eSIM = "No Data"'], status: ok ? undefined : "failed",
      });
      expect(d.status, "Member Detail Status (UI)").toMatch(/^Pending\b/i);
      expect(accountLabel(detail?.status), "Member Detail status (API)").toBe("Pending");
      expect(d.noData, '"No Data" panels').toBeGreaterThan(0);
    });
  });

  test(`TC-04 Same email pays with a valid card ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.setCase("TC-04 Retry with valid card");
    const { email, declined } = loadState();
    test.skip(!declined, "TC-01 did not produce a declined payment");
    const { ctx, page } = await newShopper(browser);
    try {
      await test.step("Checkout again with the same email, card 4242 → Pay", async () => {
        const plan = await pickPlan(page, PLAN);
        await goToCheckout(page);
        const r = await continueToPayment(page, FIRST_NAME, email);
        expect(r.outcome, `card step not reached: ${r.errors.join(" / ")}`).toBe("card");
        const res = await payWithCard(page, CARD_OK);
        const done = res.outcome === "complete" ? await readCompletePage(page) : { orderNumber: "", rows: {} };
        await evidence.saveScreenshot(page, testInfo, {
          ac: AC, title: "TC-04 Same email pays with 4242 4242 4242 4242",
          steps: [`Plan ${plan || "Japan 1GB"} · email ${email}`, `Pay → ${res.outcome}${res.error ? `: "${res.error}"` : ""}`, `Order number: ${done.orderNumber || "—"}`],
          expected: ["Checkout complete page with an Order number"], status: done.orderNumber ? undefined : "failed",
        });
        saveState({ paidOrder: done.orderNumber });
        expect(res.outcome, `Pay result ${res.error}`).toBe("complete");
        expect(done.orderNumber, "Order number").toBeTruthy();
      });
    } finally {
      await ctx.close();
    }
  });

  test(`TC-05 After payment: same account reused, Active ${ID}`, async ({}, testInfo: TestInfo) => {
    test.setTimeout(720_000); // 5 min webhook poll + Admin UI
    evidence.setCase("TC-05 Admin after successful payment");
    const { email, paidOrder, firstMemberId } = loadState();
    test.skip(!paidOrder, "TC-04 did not complete a payment");
    // Activation arrives with the payment webhook. eSIM assignment is only recorded: the STG eSIM pool
    // can be empty (environment), and it is outside EP-6057.
    const members = await pollMembers(token, email, (m) => m.length > 0 && m.every((x) => x.status === 1), 300000);
    const m = members[0];
    const detail = m ? await memberDetail(token, m.id) : null;
    await test.step("Admin → Membership → Search by Email → View Detail", async () => {
      const ui = await searchMembership(admin.page, email);
      await evidence.saveScreenshot(admin.page, testInfo, {
        ac: AC, title: "TC-05a Membership list – after the successful payment",
        steps: [`Order ${paidOrder} · Search by Email "${email}"`, `UI: ${ui.rowCount} row(s) · Account Status "${ui.accountStatus || "—"}" · eSIM Status "${ui.esimStatus || "—"}"`],
        expected: ["Exactly 1 account (reused)", "Account Status = Active", "eSIM: recorded only (STG eSIM pool empty = environment)"],
        status: members.length === 1 && m?.status === 1 ? undefined : "failed",
      });
      const d = ui.rowCount ? await openMemberDetail(admin.page, ui.row) : { status: "—", noData: 0 };
      const ok = members.length === 1 && m?.id === firstMemberId && detail?.status === 1;
      await evidence.saveScreenshot(admin.page, testInfo, {
        ac: AC, title: 'TC-05b Member Detail – "Status" after the successful payment',
        steps: [`UI Status: "${d.status}"`, `API: ${members.length} account(s); id ${m?.id ?? "—"} (TC-02 id ${firstMemberId ?? "—"}) · status ${detail?.status ?? "—"} (${accountLabel(detail?.status)}) · esimStatus ${m?.esimStatus ?? "null"} (${esimLabel(m?.esimStatus)}) — not assessed: STG eSIM pool empty`],
        expected: ["Same account as TC-02 (no duplicate)", "Status = Active"], status: ok ? undefined : "failed",
      });
      const scratch = await admin.ctx.newPage();
      await evidence.saveDataCard(scratch, testInfo, `Accounts for ${email}`, memberCard(members), {
        ac: AC, title: "TC-05c API – accounts for this email", steps: ["POST /api/membership/search (Search by Email, pending included)"], expected: ["1 account"], status: members.length === 1 ? undefined : "failed",
      });
      await scratch.close();
      expect(members.length, "accounts for this email (no duplicate)").toBe(1);
      if (firstMemberId) expect(m.id, "same account as TC-02").toBe(firstMemberId);
      expect(accountLabel(detail?.status), "Member Detail status").toBe("Active");
      if (m.esimStatus == null) testInfo.annotations.push({ type: "blocked (env)", description: "No eSIM assigned: STG eSIM pool empty, not part of EP-6057" });
    });
  });

  test(`TC-06 Checkout abandoned before paying → account Pending ${ID}`, async ({ browser }, testInfo: TestInfo) => {
    evidence.setCase("TC-06 Abandoned checkout");
    const { cancelEmail } = loadState();
    console.log(`[INFO] TC-06 email = ${cancelEmail}`);
    expect((await membersByEmail(token, cancelEmail)).length, `${cancelEmail} must be new`).toBe(0);
    const { ctx, page } = await newShopper(browser);
    try {
      await test.step("1. Checkout → Continue to payment (order created, card form shown)", async () => {
        await pickPlan(page, PLAN);
        await goToCheckout(page);
        const r = await continueToPayment(page, FIRST_NAME, cancelEmail);
        await evidence.saveScreenshot(page, testInfo, {
          ac: AC, title: "TC-06a Card form shown – customer leaves without paying",
          steps: [`Email ${cancelEmail}`, `Continue to payment → ${r.outcome}`, "No card entered; the page is closed"],
          expected: ["Card form shown (order created)"], status: r.outcome === "card" ? undefined : "failed",
        });
        expect(r.outcome, `card step not reached: ${r.errors.join(" / ")}`).toBe("card");
      });
    } finally {
      await ctx.close(); // 2. customer closes the page
    }
    await test.step("3. Admin → Membership → Search by Email", async () => {
      const members = await pollMembers(token, cancelEmail, (m) => m.length > 0);
      const ui = await searchMembership(admin.page, cancelEmail);
      const m = members[0];
      const ok = members.length === 1 && m.status === 3 && m.esimStatus == null;
      await evidence.saveScreenshot(admin.page, testInfo, {
        ac: AC, title: "TC-06b Membership list – after an abandoned checkout",
        steps: [`Search by Email "${cancelEmail}" (polled 3 min)`, `UI: ${ui.rowCount} row(s) · Account Status "${ui.accountStatus || "—"}" · eSIM Status "${ui.esimStatus || "—"}"`,
          `API: ${members.length} account(s)${m ? ` · status ${m.status} (${accountLabel(m.status)}) · esimStatus ${m.esimStatus ?? "null"}` : ""}`],
        expected: ["Account Status = Pending (AC1: payment fails or is cancelled)", "No eSIM"], status: ok ? undefined : "failed",
      });
      expect(members.length, "accounts for this email").toBe(1);
      expect(accountLabel(m.status), "Account Status").toBe("Pending");
      expect(esimLabel(m.esimStatus), "eSIM Status").toBe("No eSIM");
    });
  });
});
