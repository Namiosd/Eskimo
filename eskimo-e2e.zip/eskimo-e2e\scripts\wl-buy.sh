#!/usr/bin/env bash
# Buy one plan on a White Label storefront (STAGE / Stripe TEST mode only) without the UI.
#   1) POST {WL_URL}/en/checkout  (Next.js server action) -> orderId + PaymentIntent clientSecret
#   2) POST api.stripe.com/v1/payment_intents/{pi}/confirm with a Stripe test card -> paid
# Usage: scripts/wl-buy.sh <planId> [email] [firstName]
#   env: WL_URL (default https://wellatsea.eskimo.travel), WL_SITE_ID (default site-1i0dhg),
#        WL_NEXT_ACTION (auto-detected), STRIPE_PM (default pm_card_visa = test Visa 4242)
# Never point this at production: it refuses a live key (pk_live_).
set -euo pipefail
PLAN_ID="${1:?usage: wl-buy.sh <planId> [email] [firstName]}"
EMAIL="${2:-testwhitelabeluat2@yopmail.com}"
FIRST="${3:-Curl Buyer}"
WL_URL="${WL_URL:-https://wellatsea.eskimo.travel}"
SITE_ID="${WL_SITE_ID:-site-1i0dhg}"
PM="${STRIPE_PM:-pm_card_visa}"

# 0) publishable key + server-action id from the checkout page bundle
html=$(curl -s -m 60 "$WL_URL/en/checkout")
chunk=$(printf '%s' "$html" | grep -o '/_next/static/chunks/app/[^"]*checkout/page-[^"]*\.js' | head -1)
js=$(curl -s -m 60 "$WL_URL$chunk")
PK=$(printf '%s' "$js" | grep -o 'pk_[a-z]*_[A-Za-z0-9]*' | head -1)
case "$PK" in pk_test_*) ;; *) echo "Refusing: no Stripe TEST key found (got '${PK:0:8}...')." >&2; exit 1;; esac
ACTION="${WL_NEXT_ACTION:-$(printf '%s' "$js" | grep -o 'createServerReference)("[0-9a-f]\{40,42\}"' | grep -o '[0-9a-f]\{40,42\}' | head -1)}"
ACTION="${ACTION:-4081750e9d3c880676a6ed840927a713b0952b6b1a}"

# 1) create the order + PaymentIntent
REQ_ID=$(node -e 'console.log(crypto.randomUUID())')
resp=$(curl -s -m 60 -X POST "$WL_URL/en/checkout" \
  -H "accept: text/x-component" -H "content-type: text/plain;charset=UTF-8" \
  -H "next-action: $ACTION" -H "origin: $WL_URL" -H "referer: $WL_URL/en/checkout" \
  --data-raw "[{\"websiteId\":\"$SITE_ID\",\"clientRequestId\":\"$REQ_ID\",\"planId\":\"$PLAN_ID\",\"email\":\"$EMAIL\",\"firstName\":\"$FIRST\"}]")
line=$(printf '%s\n' "$resp" | grep -m1 '"orderId"' || true)
[ -n "$line" ] || { echo "Checkout failed (no orderId). Server action id may have changed: set WL_NEXT_ACTION." >&2; printf '%s\n' "$resp" | grep -m3 -i 'error\|"ok"' >&2; exit 1; }
json="${line#*:}"
ORDER=$(node -e 'const j=JSON.parse(process.argv[1]);console.log(j.orderId||"")' "$json")
SECRET=$(node -e 'const j=JSON.parse(process.argv[1]);console.log(j.clientSecret||"")' "$json")
ACCT=$(node -e 'const j=JSON.parse(process.argv[1]);console.log(j.stripeAccountId||"")' "$json")
PI="${SECRET%%_secret_*}"
echo "1) order $ORDER created (PaymentIntent ${PI})"

# 2) confirm the PaymentIntent with a Stripe test payment method
conf=$(curl -s -m 60 -X POST "https://api.stripe.com/v1/payment_intents/$PI/confirm" \
  -u "$PK:" -H "Stripe-Account: $ACCT" \
  --data-urlencode "client_secret=$SECRET" \
  --data-urlencode "payment_method=$PM" \
  --data-urlencode "return_url=$WL_URL/en/checkout/complete?orderId=$ORDER")
node -e '
const j=JSON.parse(process.argv[1]);
if (j.error) { console.error("2) Stripe confirm failed: " + j.error.message); process.exit(1); }
console.log("2) payment " + j.status + " - amount " + (j.amount/100).toFixed(2) + " " + String(j.currency).toUpperCase());
' "$conf"
echo "Done: $WL_URL/en/checkout/complete?orderId=$ORDER"
