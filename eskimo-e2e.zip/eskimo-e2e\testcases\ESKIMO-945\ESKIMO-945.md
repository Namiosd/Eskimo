# ESKIMO-945 – [BE][Merchant Program] Fixed Discount > plan price → negative Discount Price / credits increase

Môi trường: STAGE (admin/partner/api stage-sea-001). Partner: partnerofduc (prepaid merchant).
Plan mục tiêu: "Unlimited Vietnam 5 Days" $16 (rule "Any Unlimited Vietnam").
Nguồn: ticket-only mode — sinh từ phần Expected của ESKIMO-945 (2026-10-22).
Mỗi TC tự đặt rule và khôi phục lại rule ban đầu sau khi chạy.

## TC-01 Admin: BE từ chối Fixed Discount > giá plan
- Steps: Merchant Program → "Any Unlimited Vietnam", Fixed Discount ($US) 456789 → Save → mở lại partner
- Expected: BE từ chối (save lỗi hoặc giá trị không được lưu). (Nếu BE "clamp" thì kiểm tra qua TC-02/03.)

## TC-02 Partner: Discount Price không âm
- Preconditions: rule 456789 được lưu (BE từ chối → skip)
- Steps: Vouchers → Purchase Voucher → chọn plan $16 (không submit)
- Expected: Discount Price >= 0 trên UI và API

## TC-03 Partner: Remaining Credits sau khi mua 1 voucher
- Preconditions: rule 456789 được lưu (BE từ chối → skip)
- Steps: ghi Remaining Credits → mua plan $16 × 1 → đọc lại
- Expected: credits không tăng; số bị trừ <= giá plan. BE từ chối giao dịch cũng chấp nhận.

## TC-04 Regression: Fixed Discount hợp lệ
- Steps: rule = Fixed Discount 5 → Save → Purchase Voucher plan $16 (không submit)
- Expected: lưu được; Discount Price = $11

## TC-05 Partner: mua 1 voucher với rule hợp lệ — credits bị trừ đúng (thêm 2026-10-22)
- Lý do: BE từ chối 456789 nên TC-03 skip; vẫn phải mua thật để xác nhận credits không bị cộng thêm.
- Steps: rule = Fixed Discount 5 → ghi Remaining Credits → mua plan $16 × 1 → đọc lại
- Expected (ticket: "debits Remaining Credits by at most the plan price"): credits không tăng; số bị trừ <= $16 và = Discount Price $11
