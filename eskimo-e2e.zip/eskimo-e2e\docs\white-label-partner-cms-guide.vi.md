# Hướng dẫn Partner: Quản lý website trên Partner Portal

| | |
|---|---|
| **Dành cho** | Partner White Label (đội vận hành và hỗ trợ khách hàng của bạn) |
| **Phạm vi** | Đăng nhập → kết nối Stripe → dựng thương hiệu và nội dung website → tên miền và email gửi → mở bán → hỗ trợ khách |
| **Cập nhật** | 26/10/2026 |

---

## 1. Tổng quan

### 1.1 Bạn làm gì, Eskimo làm gì

| Ai | Phụ trách |
|---|---|
| **Bạn (Partner)** | Kết nối **Stripe** để nhận thanh toán; chỉnh **thương hiệu và nội dung** website (tên, logo, màu, chữ, hình, liên kết); thêm **bản ghi DNS** cho tên miền website và email gửi; hỗ trợ khách của bạn |
| **Đội Eskimo** | Kích hoạt tài khoản partner; tạo website và **bố cục trang** (trang nào có khối nội dung nào, theo thứ tự nào); cấu hình tên miền và email gửi bạn cung cấp, gửi bạn **bản ghi DNS**; kiểm tra và **mở bán** website; quản lý **gói data và giá** |

> Bạn **không** thêm, xoá hay đổi thứ tự các khối nội dung, và **không** chỉnh giá hay danh sách gói. Cần thay đổi những phần này, hãy liên hệ business team của Eskimo.

### 1.2 Quy trình

```
LANES
```

### 1.3 Khi nào cần chờ Eskimo

| Bạn muốn… | Cần Eskimo làm trước |
|---|---|
| Thấy website trong **My Website** | Tạo website và gán cho tài khoản của bạn |
| Thêm bản ghi DNS | Cấu hình tên miền và email gửi bạn đã cung cấp, rồi gửi bạn các bản ghi DNS |
| Khách mua được trên website | Kiểm tra và **mở bán** website (sau khi bạn đã kết nối Stripe xong) |
| Thêm, xoá hoặc đổi thứ tự khối nội dung | Chỉnh bố cục trang theo yêu cầu của bạn |

---

## 2. Chuẩn bị

1. **Tài khoản Partner Portal** và quyền truy cập hộp thư của email đăng nhập để nhận mã OTP.
2. **Thông tin doanh nghiệp và tài khoản ngân hàng** để khai báo với Stripe.
3. **Tên miền con** cho website (ví dụ `esim.yourdomain.com`) và **quyền quản lý DNS** của tên miền chính. Nếu bạn nhờ Eskimo gửi email cho khách: **tên miền email** riêng và **thông tin email gửi** (Sender name, From address, Reply-to).
4. **Tài liệu thương hiệu:**
    - **Logo**: file **PNG nền trong suốt** (transparent background), **dưới 1 MB**. Không dùng JPEG hay logo có nền màu: logo sẽ hiện kèm một khung nền trên Header và Footer.
    - **Mã màu** chính và phụ (dạng `#RRGGBB`, ví dụ `#1957F5`).
    - **Hình ảnh** cho banner, ô nổi bật, hướng dẫn cài eSIM: PNG hoặc JPEG, **dưới 5 MB** mỗi file.
    - **Nội dung**: tiêu đề, giới thiệu, câu hỏi thường gặp, email hỗ trợ, liên kết mạng xã hội.

---

## 3. Bước 1 — Đăng nhập Partner Portal

1. Mở Partner Portal theo đường dẫn Eskimo gửi.
2. Nhập email → bấm gửi mã → nhập **mã OTP** nhận qua email → đăng nhập.
3. Bấm **My Website** trên menu trái. Màn hình **Edit Website Content** mở ra.

> Thấy thông báo *"No website has been assigned to you yet. Please contact your account manager."* nghĩa là Eskimo chưa tạo hoặc chưa gán website cho bạn. Liên hệ business team của Eskimo.

![Màn hình My Website](images/partner-cms/01-cms-workspace.png)

| Vùng | Chức năng |
|---|---|
| **Thanh chọn trang** | Chuyển giữa 5 trang: Home, Plan Detail, Checkout, Data Balance, Install eSIM. Số trong ngoặc là số khối nội dung |
| **Brand identity** | Tên, logo, màu thương hiệu |
| **Stripe payments** | Trạng thái và nút kết nối Stripe |
| **Khung xem trước** | Trang đang chọn, gần giống website thật |
| **Nút bút chì** | Trên mỗi khối nội dung, mở cửa sổ **Configure &lt;tên khối&gt;** |
| **Save Page / Save All (N pages)** | Lưu thay đổi lên website |

---

## 4. Bước 2 — Kết nối Stripe

Thanh toán của khách trên website được xử lý qua **tài khoản Stripe của bạn**. Website chỉ nhận thanh toán khi Stripe đã **Verified**.

1. Trong **My Website**, tìm khu vực **Stripe payments** → bấm **Connect Stripe**.
2. Hệ thống chuyển sang trang **Stripe**. Khai báo thông tin doanh nghiệp, tài khoản nhận tiền và hoàn tất xác minh.
3. Làm dở thì quay lại **My Website** → bấm **Continue setup** để tiếp tục.

> Nút **Connect Stripe / Continue setup** chỉ hiện với tài khoản vai trò **Owner** hoặc **Admin User**. Vai trò khác chỉ thấy trạng thái.

| Trạng thái | Ý nghĩa | Bạn cần làm |
|---|---|---|
| **Not Connected** / **—** | Chưa kết nối | Bấm **Connect Stripe** |
| **Pending verification** | Stripe đang xác minh | Chờ; nếu Stripe yêu cầu thêm thông tin, bấm **Continue setup** |
| **Verified** | Sẵn sàng nhận thanh toán | Hoàn tất |

> Trạng thái có thể mất **vài phút** để cập nhật sau khi Stripe xác minh xong. Tải lại trang để xem mới nhất.

---

## 5. Bước 3 — Thương hiệu và nội dung website

### 5.1 Cách chỉnh — hai nút Save khác nhau

1. Chọn trang trên thanh chọn trang → bấm **bút chì** trên khối cần sửa.
2. Sửa nội dung → bấm **Save** trong cửa sổ → **chỉ cập nhật khung xem trước**.
3. Làm tiếp các khối, các trang khác.
4. Bấm **Save Page / Save All** ở góc phải dưới → **lưu lên website**, thông báo `Saved: "<tên trang>"`.

> ⚠️ **Save** trong cửa sổ ≠ **Save Page**. Chỉ **Save Page / Save All** mới đưa thay đổi lên website. Luôn bấm trước khi rời màn hình.

**Các loại ô nhập**

| Loại ô | Cách dùng |
|---|---|
| Chữ một dòng / nhiều dòng | Ô ghi *"one per line"*: mỗi dòng thành một gạch đầu dòng |
| Liên kết (URL) | Trang trong website (`/esim`) hoặc đầy đủ (`https://...`), `mailto:`, `tel:`. Trang không có trên website → cảnh báo màu cam dưới ô và liên kết **không hiển thị**. **Không** thêm tiền tố ngôn ngữ (dùng `/esim`, không dùng `/en/esim`) |
| Hình ảnh | Bấm **Upload** để tải ảnh từ máy |
| Biểu tượng | Chọn trong thư viện có sẵn (wifi, globe, shield…), có ô tìm |
| Danh sách | **+ Add** thêm dòng, **Remove** xoá dòng. Nút mờ khi đã đạt số lượng tối thiểu / tối đa |
| Ô ✓ / ! / ✕ | Bảng so sánh: `✓ Yes`, `! Partly`, `✕ No` |
| Từ khoá `{brand}` | Tự thay bằng Brand name ở mọi khối. Ví dụ `Why {brand}?` → *Why Your Brand?* |
| Từ khoá `{country}` | Chỉ dùng trong tiêu đề Plan Detail Hero. Ví dụ `{country} eSIM` → *Japan eSIM* |

### 5.2 Thương hiệu (Brand identity)

![Brand identity](images/partner-cms/02-brand-identity.png)

| Ô | Hiển thị trên website |
|---|---|
| **Brand name** | Tiêu đề tab trình duyệt và mọi chỗ có `{brand}` (kể cả dòng bản quyền) |
| **Logo** (**Upload**) | Header và Footer mọi trang. **PNG nền trong suốt**, dưới 1 MB. **Luôn dùng nút Upload**: link ảnh dán từ nơi khác sẽ không hiển thị. Không có logo thì hiển thị Brand name dạng chữ |
| **Primary** | Nút bấm, tiêu đề nhấn, liên kết, form thanh toán |
| **Secondary** | Thẻ khu vực trong danh sách gói và các thẻ hướng dẫn cài đặt (Install Steps) |

Mã màu phải đúng dạng `#RRGGBB`; sai định dạng thì website dùng màu mặc định. Nhập xong bấm **Save Page** → thông báo `Branding saved`.

### 5.3 Header và Footer

Mỗi trang có Header và Footer **riêng**. Cấu hình **giống nhau trên cả 5 trang** để website đồng nhất, rồi **Save All**.

![Configure Header](images/partner-cms/06-configure-header.png)

- **Header — Navigation links**: mỗi mục gồm *Label* và *URL*, ví dụ `Travel eSIM` → `/esim`, `Install eSIM` → `/install-esim`. Logo lấy từ Brand identity. Nút **My Data** tự hiện ở góc phải, trừ khi menu của bạn đã có liên kết tới `/data-balance`.

![Configure Footer](images/partner-cms/07-configure-footer.png)

| Ô Footer | Mô tả |
|---|---|
| **Support email** | Email hỗ trợ của bạn, hiện ở dòng *Need help?* (để trống thì dòng này ẩn) |
| **Column 1/2/3 title + links** | 3 cột chân trang. Liên kết có URL trống hoặc trỏ tới trang không có trên website sẽ bị bỏ; cột không còn liên kết nào bị ẩn, kể cả khi có tiêu đề |
| **Social links** | Biểu tượng (facebook, instagram, youtube-play, tiktok…) và đường dẫn. Dòng có URL trống **vẫn hiện biểu tượng**: xoá dòng nếu không dùng |
| **Locale/currency label** | Ví dụ `EN • USD — $` |
| **Copyright text** | Ví dụ `© 2026 {brand}` |

### 5.4 Nội dung từng trang

| Trang | Khối | Nội dung bạn chỉnh được |
|---|---|---|
| **Home** | Banner | Ảnh nền, tiêu đề, mô tả, nhãn và chữ gợi ý ô tìm quốc gia (trống → *"Search N+ countries"* theo số thật), chữ và liên kết nút kêu gọi (trống chữ → không có nút), điểm đánh giá |
| | Data Plan Section | Tiêu đề, dòng nhấn, mô tả. Khu vực và số quốc gia **tự động** |
| | Transfer Data | Nhãn, tiêu đề, mô tả, 1–4 tính năng (icon, tiêu đề, mô tả), 1–4 ô nổi bật (tiêu đề, mô tả, hình) |
| | More Reasons Grid | Tiêu đề, 3–9 lý do (icon, tiêu đề, mô tả) |
| | Video Section | Link video (YouTube hoặc `.mp4`), 2 dòng chữ trên video |
| | Comparison Table | Tiêu đề, mô tả, tên 4 cột, 1–12 dòng so sánh (✓ / ! / ✕) |
| | Install Steps | Tiêu đề, mô tả, 3–8 bước tóm tắt |
| | Reviews | Tiêu đề, 3–9 đánh giá (tên, ngày, nội dung) |
| | FAQ | Tiêu đề, mô tả, 1–9 câu hỏi và trả lời (**+ Add Question**) |
| | Recommendations | Tiêu đề, tên 3 tab, liên kết hướng dẫn ở tab 3. Tab 1 (quốc gia phổ biến) và tab 2 (khu vực) **tự động** |
| **Plan Detail** | Plan Detail Hero | Tiêu đề trang (dùng `{country}`), điểm đánh giá, 2 tab loại gói (tên, nhãn, tính năng), 3–4 thẻ tính năng |
| | Sticky Checkout Bar | Chữ trên nút thanh toán. Tên gói và giá **tự động** |
| **Checkout** | — | Chỉ Header và Footer; form thanh toán do hệ thống cung cấp |
| **Install eSIM** | Install eSIM Guide | Tiêu đề, mô tả, tên tab iOS / Android, chữ đứng trước số bước (`Step` → *Step 1, Step 2…*), 1–8 bước mỗi hệ điều hành (tiêu đề, gạch đầu dòng, tối đa 4 hình) |
| **Data Balance** | Data Balance Screen | Tên trang, tên tab *My Plans* / *History*, nội dung khi khách chưa có gói, chữ *How to install eSIM*, chữ nút *Buy more data*. Gói, dung lượng, lịch sử của khách **tự động** |
| | Data & eSIM Information | Tiêu đề, quyền lợi gói Fixed (3–8) và gói Unlimited (3–8) |

![Configure Banner](images/partner-cms/04-configure-banner.png)
![Configure FAQ](images/partner-cms/05-configure-faq.png)
![Configure Plan Detail Hero](images/partner-cms/08-configure-plan-detail-hero.png)
![Configure Install eSIM Guide](images/partner-cms/09-configure-install-guide.png)
![Configure Data Balance Screen](images/partner-cms/10-configure-data-balance.png)

### 5.5 Phần hiển thị tự động

Các phần sau luôn lấy dữ liệu thật từ hệ thống để khách thấy đúng gói và giá, bạn không cần nhập:
- Danh sách quốc gia, khu vực và số quốc gia.
- Gói data, dung lượng, giá.
- Quốc gia phổ biến và khu vực trong Recommendations.
- Tên gói và giá trên thanh thanh toán.
- Gói, dung lượng và lịch sử của khách trong My Data.

### 5.6 Lưu và kiểm tra

1. Bấm **Save Page / Save All**, chờ thông báo `Saved: …`.
2. Mở website và tải lại. Nội dung mới thường hiện sau **khoảng 30 giây**; chưa thấy thì chờ thêm và tải lại sau 1 phút.

![Website sau khi cấu hình](images/partner-cms/13-storefront-home.png)

> Mỗi partner chỉ xem và chỉnh **website của chính mình**. Ảnh bạn tải lên được lưu riêng cho website của bạn.

---

## 6. Bước 4 — Tên miền và email gửi

1. Gửi Eskimo:
    - **Tên miền con** cho website, ví dụ `esim.yourdomain.com` (không dùng tên miền gốc `yourdomain.com`).
    - Nếu bạn nhờ Eskimo gửi email cho khách: **thông tin email gửi** trên tên miền email của bạn (Sender name, From address, Reply-to).
2. Eskimo cấu hình và gửi lại bạn các **bản ghi DNS**:

| Bản ghi | Dùng cho |
|---|---|
| CNAME **esim.yourdomain.com** | Trỏ website về hệ thống Eskimo, để khách truy cập bằng tên miền của bạn |
| CNAME **_acme-challenge.esim.yourdomain.com** | Cấp và tự gia hạn chứng chỉ HTTPS. ⚠️ **Không bao giờ xoá**: xoá thì tới kỳ gia hạn (vài tháng sau) website không truy cập được |
| Bản ghi xác thực email (Type / Host / Value), chỉ khi Eskimo gửi email | Gửi email cho khách bằng địa chỉ của bạn |

3. Thêm tất cả vào DNS của tên miền chính, chọn chế độ **DNS only, not proxied** (Cloudflare: đám mây xám).
4. Báo lại Eskimo để kiểm tra. Website chạy trên tên miền của bạn khi DNS trỏ đúng; email gửi bằng địa chỉ của bạn khi tên miền được xác thực.

> **Ai gửi email cho khách:** bạn nhờ Eskimo gửi thì bắt buộc có **tên miền email** riêng và làm đủ phần email ở trên. Bạn không gửi tên miền email cho Eskimo thì **tự xử lý** việc gửi xác nhận đơn, mã QR eSIM và mã OTP đăng nhập My Data cho khách qua **External API**, và bỏ qua phần email; khi đó Eskimo không gửi email nào.

> Cần hỗ trợ thêm bản ghi DNS → liên hệ **business team của Eskimo**.

---

## 7. Bước 5 — Mở bán

1. Khi bạn đã kết nối Stripe (**Verified**), hoàn tất nội dung và thêm xong các bản ghi DNS, báo Eskimo.
2. Eskimo kiểm tra và **mở bán** website. Website chỉ được mở khi Stripe của bạn đã **Verified**, kể cả khi tên miền và DNS đã xong.
3. Bạn kiểm tra lại website trên máy tính và điện thoại: đủ 5 trang, logo, màu, liên kết, email hỗ trợ.

**Cần biết khi website đang bán:**
- Website chỉ bán trong **thời gian hợp tác** đã thoả thuận. Khi hợp tác tạm ngưng hoặc hết hạn, website hiển thị **"This store isn't available — Please check back later."** và khách không mua được. Liên hệ business team của Eskimo nếu thấy trang này ngoài dự kiến.
- Bạn vẫn chỉnh nội dung bất cứ lúc nào (xem 5.6).

![Website khi không mở bán](images/corporate-program/07-store-unavailable.png)

---

## 8. Khách mua và dùng eSIM (kiến thức cho đội hỗ trợ)

> Chữ in `như thế này` là nội dung hiển thị nguyên văn trên website.

### 8.1 Hành trình của khách

| # | Giai đoạn | Khách làm gì | Kết quả |
|---|---|---|---|
| 1 | **Chọn gói** | Mở website → chọn quốc gia / khu vực → chọn gói | Thấy danh sách gói của thương hiệu bạn |
| 2 | **Checkout** | Nhập First name + Email → thanh toán bằng thẻ | Thanh toán thành công |
| 3 | **Nhận eSIM** | (tự động) | Email có **mã QR** cài eSIM và link vào My Data: Eskimo gửi bằng địa chỉ email của bạn, hoặc bạn tự gửi nếu dùng hệ thống email riêng (Bước 4) |
| 4 | **My Data** | Mở Magic Link, hoặc nhập Email + mã OTP | Xem gói, dung lượng còn lại, lịch sử |
| 5 | **Mua thêm** | Mua gói mới bằng **cùng email** | Data được cộng vào cùng email: hiện trong **My Plans** và **History** của My Data, dùng trên **eSIM đã kích hoạt** (không cần cài eSIM mới) |

**Kết quả thanh toán quyết định khách có xem được My Data không:**

| Kết quả thanh toán | Khách nhận được | My Data |
|---|---|---|
| **Thành công** | Trang xác nhận có Order number; eSIM và gói được tạo cho email đã nhập | **Xem được** (Magic Link hoặc Email + OTP) sau khoảng 30–60 giây |
| **Thất bại** (thẻ bị từ chối, thanh toán không qua) | Thông báo lỗi, **không bị trừ tiền**, **không** có eSIM, **không** có gói | **Không xem được**. Email chưa mua thành công không nhận được mã đăng nhập |

> Khách thanh toán thất bại chỉ cần **thanh toán lại thành công bằng cùng email**. Đơn hoàn tất bình thường và khách xem được My Data, không tạo tài khoản trùng.

**Nguyên tắc:**
- Website bán bằng **tiếng Anh**, giá **USD**, thanh toán **thẻ qua Stripe**. Không có chọn ngôn ngữ, đổi tiền tệ hay mã giảm giá.
- Data của khách hết hạn sau **2 năm** kể từ ngày mua.
- **Tài khoản khách tách theo thương hiệu.** Cùng một email ở website khác là tài khoản khác, không gộp gói hay lịch sử.
- Nếu bạn tự gửi email cho khách (qua External API), bạn phải gửi đủ **xác nhận đơn**, **mã QR eSIM** và **mã OTP** đăng nhập My Data.

### 8.2 Mua hàng

1. Chọn gói → bấm nút thanh toán (mặc định **`Checkout`**).
2. Nhập **First name** và **Email** (email nhận eSIM và đăng nhập My Data, cần đúng chính tả) → **`Continue to payment`**.
3. Nhập thẻ → **`Pay US$ …`** → `Processing payment…`.
4. Trang xác nhận hiện **Order number** (`PUR-PN…`), gói, tổng tiền, email nhận eSIM và `Payment received — we're preparing your eSIM`.

### 8.3 Truy cập My Data

- **Magic Link** trong email: vào thẳng ví, không cần mã, dùng lại nhiều lần.
- **Email + OTP**: bấm **`My Data`** → nhập email đã mua → **`Send code`** → nhập **mã 4 chữ số** (hết hạn sau **5 phút**) → **`View my data`**. Sau khi đăng nhập, phiên được lưu **7 ngày** trên cùng thiết bị: khách mở lại My Data không phải nhập mã lại.

Trong ví: tab **My Plans** (quốc gia, dung lượng còn lại; gói không giới hạn hiện nhãn như `Unlimited 30 days`) và **History** (ngày, gói, trạng thái).

### 8.4 Thông báo lỗi thường gặp

**Checkout**

| Tình huống | Thông báo | Hướng dẫn khách |
|---|---|---|
| Để trống tên | `Enter your first name.` | Nhập First name |
| Email trống / sai định dạng | `Enter a valid email address.` | Nhập email đúng |
| Mở trang thanh toán khi chưa chọn gói | `No plan selected` | Quay lại chọn gói |
| Thanh toán quá nhiều lần liên tiếp | `Too many checkout attempts. Please wait a few minutes and try again.` | Chờ vài phút |

**Thanh toán**

| Tình huống | Thông báo | Hướng dẫn khách |
|---|---|---|
| Thẻ bị từ chối | `Your card has been declined.` | **Chưa bị trừ tiền**. Thử thẻ khác, dùng cùng email |
| Không khởi tạo được | `We couldn't start your payment. Please try again in a moment.` | Thử lại sau giây lát |
| Thanh toán không qua | `Your payment didn't go through.` + `You haven't been charged. You can try again with the same or a different card.` | Chưa bị trừ tiền, thử lại |
| Ngân hàng đang xác nhận | `Your bank is still confirming the payment. We'll email your eSIM as soon as it goes through — no need to pay again.` | **Không thanh toán lại**, chờ email |
| Không xác nhận được kết quả | `We couldn't confirm your payment` + `Please check your email before trying again — if the payment went through, your eSIM is on its way.` | **Kiểm tra email trước** để tránh trả hai lần |

**My Data**

| Tình huống | Thông báo | Hướng dẫn khách |
|---|---|---|
| Email chưa từng mua, hoặc vừa mua xong | `We're unable to process your request yet. Please purchase a data plan with this email to get started.` | Kiểm tra email đã nhập lúc mua; nếu vừa mua thì chờ 30–60 giây rồi `Send code` lại |
| Sai mã / mã cũ | `Invalid OTP` hoặc `That code isn't valid any more. Request a new one.` | Dùng mã mới nhất hoặc xin mã mới |
| Sai mã nhiều lần | `Too many invalid attempts. Please request a new OTP and try again in a few minutes.` | Chờ vài phút, xin mã mới |
| Xin mã quá nhiều lần | `Too many codes requested. Please wait a few minutes and try again.` | Chờ vài phút |
| Không gửi được mã | `We couldn't send your code right now. Please try again.` | Thử lại |
| Magic Link hết hạn / hỏng | `That link has expired. Enter the email you used at checkout and we'll send you a code.` | Đăng nhập bằng Email + OTP |

---

## 9. Xử lý sự cố

| Vấn đề | Cách xử lý |
|---|---|
| My Website báo *"No website has been assigned to you yet…"* | Eskimo chưa tạo hoặc chưa gán website. Liên hệ business team |
| Không thấy nút **Connect Stripe** | Tài khoản của bạn không phải vai trò Owner / Admin User. Dùng tài khoản có quyền, hoặc liên hệ Eskimo |
| Sửa xong nhưng website không đổi | Chưa bấm **Save Page / Save All** (nút Save trong cửa sổ chỉ cập nhật xem trước), hoặc chưa đủ 30 giây – 1 phút |
| Logo không hiện | Logo phải tải lên bằng nút **Upload**, PNG dưới 1 MB |
| Logo hiện kèm khung nền trắng / màu | File logo có nền. Xuất lại logo dạng **PNG nền trong suốt** rồi Upload lại |
| Liên kết không hiện trên website | URL trống, trỏ tới trang không có trên website, hoặc có tiền tố `/en`. Xem Phụ lục A |
| Biểu tượng mạng xã hội thừa | Dòng có URL trống vẫn hiện biểu tượng. Xoá dòng đó |
| Header / Footer khác nhau giữa các trang | Mỗi trang có Header / Footer riêng. Cấu hình đủ 5 trang rồi **Save All** |
| Website hiện *"This store isn't available"* | Website chưa mở bán (thường do Stripe chưa **Verified**: kiểm tra Bước 2), hoặc hợp tác đang tạm ngưng / hết hạn. Liên hệ business team |
| Website không mở được bằng tên miền của bạn | Kiểm tra đã thêm đủ 2 CNAME, để chế độ DNS only; vẫn lỗi thì liên hệ business team |
| Khách không nhận được email eSIM | Nhờ khách kiểm tra thư rác và email đã nhập lúc mua. Nếu bạn tự gửi email, kiểm tra hệ thống gửi của bạn |
| Khách yêu cầu **hoàn tiền** | Hoàn tiền đơn trên website **chưa hỗ trợ**. Liên hệ business team của Eskimo trước khi xử lý |

---

## Phụ lục

### Phụ lục A — Đường dẫn trong website

| Đường dẫn | Trang |
|---|---|
| `/` | Trang chủ |
| `/esim` | Danh sách gói theo quốc gia / khu vực |
| `/plans/<quốc-gia>-esim` | Chi tiết gói (`/plans/japan-esim`, `/plans/global-esim`) |
| `/checkout` | Thanh toán |
| `/data-balance` | My Data |
| `/install-esim` | Hướng dẫn cài eSIM; thêm `?platform=ios` hoặc `?platform=android` để mở sẵn tab |

Trên trình duyệt, website có tiền tố ngôn ngữ (ví dụ `/en/data-balance`), nhưng khi nhập liên kết trong Partner Portal thì **bỏ tiền tố** (`/data-balance`). Liên kết tới website khác dùng đường dẫn đầy đủ `https://...`.

### Phụ lục B — Giới hạn tải ảnh

| Loại | Định dạng | Tối đa |
|---|---|---|
| Logo | **PNG nền trong suốt** | 1 MB |
| Hình trong khối nội dung (banner, ô nổi bật, hướng dẫn cài) | PNG, JPEG | 5 MB |

### Phụ lục C — Khối nội dung theo trang

| Trang | Khối nội dung (theo thứ tự hiển thị mặc định) |
|---|---|
| **Home** | Header → Banner → Data Plan Section → Transfer Data → More Reasons Grid → Video Section → Comparison Table → Install Steps → Reviews → FAQ → Recommendations → Footer |
| **Plan Detail** | Header → Plan Detail Hero → Sticky Checkout Bar → Footer |
| **Checkout** | Header → Footer (form thanh toán do hệ thống cung cấp) |
| **Data Balance** | Header → Data Balance Screen → Data & eSIM Information → Footer |
| **Install eSIM** | Header → Install eSIM Guide (iOS / Android) → Footer |
