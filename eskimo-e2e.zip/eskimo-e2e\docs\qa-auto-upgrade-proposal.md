# Đề xuất nâng cấp skill `qa-auto` để toàn đội QC dùng chung

**Người đề xuất:** (QC) · **Ngày:** 2026-10-19 · **Trạng thái:** chờ sếp duyệt
**Gửi:** Quản lý đội / chủ repo `pg4-ai-workflow`

---

## TL;DR
Skill `qa-auto` bản gốc **chưa tạo được file bằng chứng (evidence report) và chưa đính lên ticket** —
đây là khâu quan trọng nhất của QC. Tôi đã tự xây phần này trong project riêng (`eskimo-e2e`) và dùng
tốt qua nhiều ticket. **Đề xuất đưa phần đó vào bộ chung `pg4-ai-workflow` (starter + skill + doc)** để
mọi QC trong đội "ké" được, kèm vá vài rough edge trước khi phổ biến.

---

## 1. Hiện trạng

**Skill `qa-auto` bản gốc** (`claude/commands/qa-auto.md`) dừng ở:
- Chạy Playwright → HTML tạm (`npx playwright show-report`), một **bảng trong chat**, và **comment
  chữ** lên Plane.
- **Không** sinh file evidence theo ticket, **không** đính file lên ticket. Bước cuối chỉ *nhắc QC tự
  làm*.

Starter chung (`qa/playwright-starter`) hiện chỉ có `package.json` + `playwright.config.ts` — **không có**
công cụ evidence.

**Project `eskimo-e2e` (tôi tự bổ sung)** đã có thêm, dùng ổn định qua ESKIMO-381/382/384/385/386/753:
- `tests/_support/evidence.ts` — chụp screenshot + manifest theo từng bước/case.
- `generate-report.mjs` — gom thành **1 report HTML theo ticket** (input/output mỗi case) → in PDF đính
  Jira/Plane.
- Report hiện được đủ **STEPS / EXPECTED / SCREENSHOT**, phục vụ QC verify logic không cần đọc source.

→ Tức là setup của tôi **đang đi trước skill gốc**; nhưng nó nằm riêng, đồng nghiệp chưa dùng được.

## 2. Vấn đề cho đội
- Mỗi QC muốn có evidence report phải **tự chế lại** (hoặc copy từ tôi) → không đồng bộ, dễ lệch chuẩn.
- Khâu "đính bằng chứng lên ticket" làm tay từng lần → dễ quên, không kiểm soát được.
- Một vài rough edge trong bản của tôi, nếu nhân rộng cần vá trước (xem mục 3B).

## 3. Đề xuất

### 3A. Đưa phần evidence vào starter chung (mọi project mới kế thừa)
`evidence.ts` và `generate-report.mjs` của tôi chỉ dùng **node core + @playwright/test** (không dính
code sản phẩm) → **port sạch được**.

| Đưa vào | Nội dung | Lợi ích |
|---|---|---|
| `qa/playwright-starter/tests/_support/evidence.ts` | công cụ chụp evidence theo case | mọi QC có sẵn |
| `qa/playwright-starter/tests/_support/generate-report.mjs` | gom report HTML theo ticket | 1 lệnh ra report |
| `qa/playwright-starter/package.json` | thêm script `report:evidence` + bước **xuất PDF** (headless) | có file đính được |

### 3B. Vá rough edge trước khi phổ biến
- **B1 — manifest:** hiện ghi *append*, chạy lại 1 case bị đọng ảnh cũ → sửa thành **ghi-đè-theo-case**
  + **sort theo mã TC** khi render.
- **B2 — tên report:** hiện gắn cứng tên folder ảnh → thêm `--ticket / --from / --title` để đặt tên theo
  mã ticket độc lập nguồn.
- **B3 — verdict:** report đang **pass/fail nhị phân**; môi trường lỗi (vd. hết eSIM stage) hiện **đỏ như
  bug**. Sửa để đọc `testInfo.annotations` → thang **PASS / GAP / CLARIFY / WARNING / BLOCKED**.

### 3C. Cập nhật skill + doc (tuỳ chọn, làm sau cũng được)
- `qa-auto.md`: thêm bước dựng evidence report → PDF → đính; chế độ **derive test case từ AC** (thay vì
  "thiếu file thì dừng"); hạng **pause-for-human** cho OTP/captcha; trạng thái **slow-but-passed**; **ledger
  dữ liệu test tạo ra**.
- `docs/qc-automation.md`: tài liệu hoá quy ước evidence + lệnh report.

## 4. Lợi ích
- Toàn đội QC có **evidence report chuẩn, đính ticket được** ngay từ starter — không ai phải tự chế.
- Report phân loại đúng **env vs product vs chờ-BA** → giảm hiểu nhầm.
- Chạy lại từng case sạch sẽ (không sửa file tay).

## 5. Phạm vi & công sức (ước lượng)
- **Core (3A + 3B):** nhỏ — chủ yếu copy 2 file generic + vá 3 điểm + thêm script. Rủi ro thấp (chỉ
  thêm vào starter, không đổi hành vi test có sẵn).
- **Skill/doc (3C):** vừa — chạm `qa-auto.md` (toàn đội đang dùng) → **nên đi qua branch/MR + review**,
  không sửa thẳng.

## 6. Rủi ro / lưu ý
- Sửa `qa-auto.md` ảnh hưởng mọi người → bắt buộc qua **MR + review**, không push thẳng `main`.
- Bản `pg4-ai-workflow` trên máy tôi là **copy local (không phải git)** → việc đóng góp phải làm trên
  repo GitLab thật.
- `evidence.ts/generate-report.mjs` cần **review code** trước khi vào starter (đảm bảo không kéo theo
  giả định riêng của project tôi).

## 7. Cần sếp quyết
1. **Đồng ý hướng** đưa evidence vào starter chung không?
2. **Phạm vi đợt này:** chỉ **Core (3A+3B)**, hay **trọn gói** gồm sửa skill/doc (3C)?
3. **Cách merge:** tạo branch/MR trên repo GitLab `pg4-ai-workflow`; ai review?
4. Có cần tôi **đính kèm demo** (1 report mẫu `ESKIMO-384-...-e2e-report.html`) để sếp hình dung không?

---

*Phụ lục chi tiết kỹ thuật (từng hạn chế + ví dụ thật): xem `qa-flow-gaps-feedback.md` cùng thư mục.*
