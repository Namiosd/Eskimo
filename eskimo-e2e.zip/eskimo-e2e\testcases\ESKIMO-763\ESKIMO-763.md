# ESKIMO-763 – [EP-6072] [Admin - Partner Portal] Display White Label Transactions and User Accounts in corporate section

Nguồn: AC1–AC4 của item ESKIMO-763 (BE: ESKIMO-737 / EA-4399). Bản nháp QC 2026-10-15, chờ BA/dev xác nhận các điểm "Cần làm rõ".
Môi trường: Admin Portal QA = E2E_ADMIN_URL, Partner Portal QA = E2E_PARTNER_URL (gọi stage API = E2E_API_URL)
Partner White Label: PN101609 "WhiteLabel Partner 2" (Corporate Program Type = White label), storefront https://wellatsea.eskimo.travel
Login partner WL: E2E_WL_PARTNER_EMAIL / E2E_WL_PARTNER_OTP
Khách WL có giao dịch sẵn: testwhitelabel168@yopmail.com (đã mua thành công trên wellatsea 2026-10-14) → E2E_WL_MEMBER_EMAIL

Quyết định QC:
- Chỉ đọc (read-only): dùng giao dịch WL đã có, KHÔNG mua mới, KHÔNG refund, KHÔNG đổi trạng thái account.
- Nếu STG không còn giao dịch WHI nào thì báo blocked (env), xin phép trước khi mua 1 gói bằng thẻ test 4242.
- Mỗi TC đối chiếu UI với API (Expected lấy từ AC, không lấy từ app).

Định nghĩa giao dịch White Label (AC1): Transaction ID bắt đầu bằng `WHI` VÀ Transaction Type = `White Label Payment`.

## TC-01 Eskimo Sale hiển thị giao dịch White Label (AC1.1)
- Precondition: có ít nhất 1 giao dịch WL của E2E_WL_MEMBER_EMAIL
- Steps:
  1. Admin → Transactions › Eskimo Sales (#/transactions-eskimo-sale)
  2. Search theo email E2E_WL_MEMBER_EMAIL (hoặc Transaction ID có tiền tố WHI)
- Expected:
  - Có dòng giao dịch với Transaction ID bắt đầu `WHI`
  - Cột Type của dòng đó = "White Label Payment"
  - (DATA) POST /api/data-plan-sale-transaction/search trả về giao dịch đó

## TC-02 Eskimo Sale chỉ gắn "White Label Payment" cho giao dịch WHI (AC1 – "Only transactions matching…")
- Steps:
  1. Admin → Eskimo Sales, trang 1 không filter (và filter Type = White Label Payment nếu có option)
- Expected:
  - Mọi dòng có Type "White Label Payment" đều có Transaction ID bắt đầu `WHI`
  - Không dòng nào có Transaction ID `WHI…` mà Type khác "White Label Payment"
  - Các loại cũ (Personal Account Payment, Work Account Payment, Work Account Top Up, Corporate Top Up) vẫn hiển thị như trước

## TC-03 Membership Detail hiển thị giao dịch White Label (AC1.2)
- Steps:
  1. Admin → Membership, search E2E_WL_MEMBER_EMAIL → mở Detail
  2. Xem section "Data Purchase"
- Expected:
  - Có giao dịch với Transaction ID bắt đầu `WHI`
  - (DATA) POST /api/membership/Details/DataPurchase trả về giao dịch đó

## TC-04 Partner Portal Corporate › Top Up History hiển thị giao dịch White Label (AC1.3)
- Steps:
  1. Đăng nhập Partner Portal bằng partner WL (PN101609)
  2. Corporate › Top Up History (#/corporate-top-up-history)
  3. Search by Transaction ID `WHI` / Search by Member info = E2E_WL_MEMBER_EMAIL
- Expected:
  - Có giao dịch với Transaction ID bắt đầu `WHI`, Transaction Type = "White Label Payment"
  - Các cột còn lại (Created Date, Member Name, Email Address, Data Plan Name, Data Amount, Original/Purchase Value) có dữ liệu
  - (DATA) POST /api/partner/corporate/search-top-up-histories trả về giao dịch đó

## TC-05 Partner Portal Corporate › Accounts hiển thị account White Label (AC2)
- Steps:
  1. Partner WL → Corporate › Accounts (#/corporate-accounts)
  2. Search E2E_WL_MEMBER_EMAIL
- Expected:
  - Account của khách WL có trong danh sách, hiển thị theo quy tắc hiện có (Member Name, Email, Account Status, eSIM Status, Remaining Data, Credit…)
  - (DATA) POST /api/partner/worker-management/search trả về account đó
- Bước phụ 5.2 (QC thêm 2026-10-15): bấm **View Detail** ở dòng account
  - Expected: thông tin chi tiết đúng account: Sign Up Email = email của dòng (E2E_WL_MEMBER_EMAIL); First/Last Name = Admin › Membership Detail; Status = Account Status ở dòng
  - (DATA) GET /api/partner/worker-management/users/{id}/profile

## TC-06 Accounts không bị ảnh hưởng với account thường (AC2 – "without affecting the existing account display logic")
- Steps:
  1. Partner WL → Corporate › Accounts, trang 1 không filter
  2. (Regression) Partner corporate thường (E2E_PARTNER_EMAIL) → Corporate › Accounts
- Expected:
  - Danh sách load bình thường, cùng bộ cột như trước
  - Partner corporate thường KHÔNG thấy account WL của PN101609

## TC-07 Membership Detail – chi tiết giao dịch WHI có Transaction Partner ID và Transaction Price (AC3)
- Steps:
  1. Admin → Membership Detail của E2E_WL_MEMBER_EMAIL → Data Purchase
  2. Mở (expand) giao dịch `WHI…`
- Expected:
  - Có dòng "Transaction Partner ID" = PN101609 (partner của giao dịch WL gốc)
  - Có dòng "Transaction Price" = giá gốc của giao dịch WL (khớp giá lúc mua trên storefront / API)

## TC-08 Giao dịch không phải WHI không có 2 trường AC3 (AC3 – negative)
- Steps:
  1. Admin → Membership Detail của một member có giao dịch thường (không WHI)
  2. Expand giao dịch đó
- Expected: KHÔNG có "Transaction Partner ID" / "Transaction Price"

## TC-09 Membership Detail của account White Label: tiêu đề + dòng White Label Partner (AC4)
- Steps:
  1. Admin → Membership Detail của E2E_WL_MEMBER_EMAIL
  2. Xem section Account (cột trái)
- Expected:
  - Tiêu đề section = "White Label Account" (không còn "Account")
  - Có dòng "White Label Partner" chứa partner id PN101609 (thông tin partner WL tương ứng)

## TC-10 Membership Detail của account không phải White Label giữ nguyên (AC4 – negative)
- Steps:
  1. Admin → Membership Detail của account Personal và account Work (corporate thường)
- Expected:
  - Tiêu đề giữ nguyên "Personal Account" / "Work Account"
  - KHÔNG có dòng "White Label Partner"

## Cần làm rõ (unclear – hỏi BA trước khi chốt Expected)
- Q1 (AC1): Filter "Type" ở Eskimo Sale và "Transaction Type" ở Top Up History có thêm option "White Label Payment" không?
- Q2 (AC3): Nhãn chính xác và định dạng "Transaction Price" (có $US? giá gốc trước hay sau discount/Application Fee?). Hiển thị ở đâu — dòng expand của Data Purchase?
- Q3 (AC4): Ảnh đính kèm trong item (image-20261009-074358.png) — QC chưa xem được; "White Label Partner" hiển thị chỉ Partner ID hay "ID – tên partner"?
- Q4 (AC2): Account WL có được cho các action như account corporate thường (top up credit, suspend…) không, hay chỉ hiển thị?
- Q5: Item đang **In Review** (chưa QA) và chưa thấy code FE cho EP-6072 trên nhánh nào của eskimo_portal → đã deploy lên QA chưa?

## Chưa cover / manual
- Export Excel ở Eskimo Sale / Top Up History có chứa giao dịch WHI với đúng Type: không nằm trong AC → manual nếu BA muốn.

## Kết quả chạy 2026-10-15 (Admin/Partner QA → stage API, partner wlb2 = PN101609): 10/10 PASS
Ghi nhận (không chặn PASS, cần BA xác nhận):
- TC-07: "Transaction Partner ID" hiển thị **PUR-PN101609-261014-4171627** (ID giao dịch WL gốc, có chứa partner code), không phải đúng "PN101609" như chữ trong AC3. Label giá là "Transaction Price ($US)" = 69 = relatedTransaction.metadata.total (Value ($US) = 6.9).
- TC-02: không có option "White Label Payment" được kiểm trong filter Type (Q1 chưa trả lời) — test chỉ kiểm cột Type trên 100 dòng.

## Chạy lại 2026-10-15 (sau khi thêm bước 5.2): 9/10 PASS, TC-05 FAIL (product)
- TC-05.2 View Detail: **Sign Up Email hiển thị GUID `6eeb92e3-a62a-40a4-b30b-fe62b58d7687` thay vì `testwhitelabel168@yopmail.com`**. Profile API `/api/partner/worker-management/users/{id}/profile` trả chính `signUpEmail` = GUID → lỗi BE (FE hiển thị đúng theo API). First Name / Last Name / Status khớp.
- Ghi nhận thêm: email testwhitelabel168@yopmail.com hiện có 2 account trong Admin Membership (aec6932a… có giao dịch WHI, f28aae09… mới, chưa có giao dịch) — cần kiểm tra có phải tạo trùng account không (liên quan EP-6057).

## Quyết định QC 2026-10-15 (TC-05.2): 10/10 PASS, có 2 WARNING
- Account WL không có nút View Detail và Top Up (ẩn có chủ đích), nên test mở View Detail qua link `#/corporate-accounts?key=<email>?detail=<id>`. Người dùng thật không đi được đường này → các trường sai chỉ là **WARNING**. Nếu nút View Detail xuất hiện lại mà trường vẫn sai → FAIL.
- WARNING 1: Sign Up Email = GUID `6eeb92e3-…`. Lỗi BE: `/api/partner/worker-management/users/{id}/profile` trả `signUpEmail` = GUID.
- WARNING 2: nút "Top Up" vẫn còn ở Data Wallet trong View Detail.
