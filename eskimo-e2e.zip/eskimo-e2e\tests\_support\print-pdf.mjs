// node tests/_support/print-pdf.mjs <in.html> <out.pdf>
import { chromium } from "@playwright/test";
import path from "node:path";

const [inp, out] = process.argv.slice(2);
if (!inp || !out) {
  console.error("Usage: node print-pdf.mjs <in.html> <out.pdf>");
  process.exit(1);
}

const browser = await chromium.launch();
const page = await browser.newPage();
await page.goto("file://" + path.resolve(inp), { waitUntil: "load" });
await page.pdf({
  path: out,
  format: "A4",
  printBackground: true,
  margin: { top: "0", right: "0", bottom: "0", left: "0" }
});
await browser.close();
console.log("PDF generated:", out);
